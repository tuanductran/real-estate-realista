<?php

function create_user_with_metadata( $username, $password, $email = "", $meta = array() ) 
{
    $user = wp_create_user( $username, $password, $email );

    if ( ! is_wp_error( $user ) ) {
        foreach( $meta as $key => $val ) {
            update_user_meta( $user, $key, $val ); 
        }
    }

    return $user;
}


if(!function_exists('is_valid_password_repeat'))
{
    function is_valid_password_repeat($string)
    {
        $postBody = file_get_contents('php://input');
        $data_json = json_decode($postBody);

        if(empty($data_json->password) && empty($string))return true;

        if(empty($data_json->password))return false;

        return $string == $data_json->password;
    }
}


