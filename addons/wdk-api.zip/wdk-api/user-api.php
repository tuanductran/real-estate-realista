<?php

/* Login user */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/login', [
        'methods' => 'POST',
        'callback' => 'wdk_post_login',
        'permission_callback' => '__return_true',
    ]);
});

// Login user
function wdk_post_login($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    $rules = array(
        array(
            'field' => 'email',
            'label' => __('Email', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'password',
            'label' => __('Password', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'returnSecureToken',
            'label' => __('Token', 'wpdirectorykit'),
            'rules' => ''
        ),
    );

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) 
    {
        $creds = array(
            'user_login'    => $data_json->email,
            'user_password' => $data_json->password,
            'remember'      => true
        );
    
        $user = wp_signon( $creds, false );
        
        $ret = !is_wp_error( $user );
        if( $ret) {

            $results['localId']     = $user->ID;
            $results['display_name']   = $user->display_name;
            $results['user_email']   = $user->user_email;

            if($data_json->returnSecureToken)
            {

                // Remove all expired tokens and old tokens from this user

                //$Winter_MVC_WDK->db->where('expire_date < \''.date('Y-m-d H:i:s').'\' OR user_id = '.$results['localId']);

                // Remove all expired tokens
                $Winter_MVC_WDK->db->where('expire_date < \''.date('Y-m-d H:i:s').'\'');
                $Winter_MVC_WDK->db->delete($Winter_MVC_WDK->token_m->_table_name);

                // Create new token

                $data = array(
                    'token' => $user->ID.'-'.md5(time().$user->ID.AUTH_KEY),
                    'user_id' =>  $user->ID,
                    'expire_date' =>  date('Y-m-d H:i:s', strtotime("+2 months")),
                    'user_email' =>  $user->user_email,
                );
        
                $insert_idtoken = $Winter_MVC_WDK->token_m->insert($data, null);

                $results['token']     = $data['token'];
                $results['expire_date']   = strtotime($data['expire_date']);
            }

            $results['message'] = __('Login successfully', 'wpdirectorykit');
            $results['code'] = 'success';
        }
        else
        {
            //$results['message'] = __('Login failed, wrong username or password', 'wpdirectorykit');
            $results['message'] = strip_tags($user->get_error_message());
            $results['code'] = 'failed';
        }
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }
    
    return $results;
}


/* Register user */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/register', [
        'methods' => 'POST',
        'callback' => 'wdk_post_register',
        'permission_callback' => '__return_true',
    ]);
});

// Register user
function wdk_post_register($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    $rules = array(
        array(
            'field' => 'email',
            'label' => __('Email', 'wpdirectorykit'),
            'rules' => 'required|valid_email'
        ),
        array(
            'field' => 'password',
            'label' => __('Password', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'first_name',
            'label' => __('First Name', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'last_name',
            'label' => __('Last Name', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_phone',
            'label' => __('Phone number', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_address',
            'label' => __('Address', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_city',
            'label' => __('City', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_facebook',
            'label' => __('Facebook', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'wdk_instagram',
            'label' => __('Instagram', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'returnSecureToken',
            'label' => __('Token', 'wpdirectorykit'),
            'rules' => ''
        ),
    );

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) 
    {
        $meta = array(
            'first_name'    => $data_json->first_name,
            'last_name'     => $data_json->last_name,
            'display_name'  => $data_json->first_name.' '.$data_json->last_name,
            'nickname'      => $data_json->first_name.' '.$data_json->last_name,
            'wdk_phone'     => $data_json->wdk_phone,
            'wdk_address'   => $data_json->wdk_address,
            'wdk_city'      => $data_json->wdk_city,
            'wdk_facebook'  => $data_json->wdk_facebook,
            'wdk_instagram' => $data_json->wdk_instagram,
        );
    
        $user_id = create_user_with_metadata($data_json->email, $data_json->password, $data_json->email, $meta);
        
        $ret = !is_wp_error( $user_id );
        if( $ret) {
            $user = get_user_by('id', $user_id);

            $results['localId']     = $user->ID;
            $results['display_name']   = $user->display_name;
            $results['user_email']   = $user->user_email;

            $user->set_role('wdk_owner');

            $results = array_merge($results, $meta);

            if($data_json->returnSecureToken)
            {
                // Remove all expired tokens and old tokens from this user

                $Winter_MVC_WDK->db->where('expire_date < \''.date('Y-m-d H:i:s').'\' OR user_id = '.$user->ID);
                $Winter_MVC_WDK->db->delete($Winter_MVC_WDK->token_m->_table_name);

                // Create new token

                $data = array(
                    'token' => $user->ID.'-'.md5(time().$user->ID.AUTH_KEY),
                    'user_id' =>  $user->ID,
                    'expire_date' =>  date('Y-m-d H:i:s', strtotime("+2 months")),
                    'user_email' =>  $user->user_email,
                );
        
                $insert_idtoken = $Winter_MVC_WDK->token_m->insert($data, null);

                $results['token']     = $data['token'];
                $results['expire_date']   = strtotime($data['expire_date']);
            }

            
            if(get_option('wdk_membership_enable_varification_mail') && get_option('wdk_membership_enable_varification_mail_mobile_api')){
                do_action('wdk-membership/extension/registration/user_created', $user_id);
                $results['message'] = __('Register successfully, please check your email', 'wpdirectorykit');
            } else {
                $results['message'] = __('Register successfully', 'wpdirectorykit');
                update_user_meta($user_id, 'wdk_is_not_activated', 0);

                /* message data */
                $data_message = array();
                $data_message['data'] = __('Thank you very much for registering on our website. Please log in here:', 'wdk-membership');
                $data_message['data'] .= ' <a href="' . esc_url(get_home_url()) . '">' . get_home_url() . '</a> ';
                $ret =  wdk_mail( $data_json->email, __('Welcome to our website', 'wdk-membership'), $data_message, 'default');
            }

            // Email to admin
            if(true){
                $subject = __('New user on our website!', 'wdk-membership');

                $data_message = array();
                $data_message['user'] = get_userdata($user_id);
                $data_message['data'] =  __('New user registered on website, please check account', 'wdk-membership').': <a href="'. admin_url('user-edit.php?user_id='.$user_id).'">'.$user->display_name.'</a>';
                $ret = wdk_mail( get_bloginfo('admin_email'), $subject, $data_message);
            }

            $results['code'] = 'success';
        }
        else
        {
            //$results['message'] = __('Register failed, missing data', 'wpdirectorykit');
            $results['message'] = $user_id->get_error_message();
            $results['code'] = 'failed';
        }
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }
    
    return $results;
}


/* Edit user */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/edit_user', [
        'methods' => 'POST',
        'callback' => 'wdk_post_edit_user',
        'permission_callback' => '__return_true',
    ]);
});

// Edit user
function wdk_post_edit_user($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];

    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    $rules = array(
        array(
            'field' => 'user_email',
            'label' => __('Email', 'wpdirectorykit'),
            'rules' => 'required|valid_email'
        ),
        array(
            'field' => 'password',
            'label' => __('Password', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'password_repeat',
            'label' => __('Repeat Password', 'wpdirectorykit'),
            'rules' => 'valid_password_repeat'
        ),
        array(
            'field' => 'last_name',
            'label' => __('Last Name', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_phone',
            'label' => __('Phone number', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_address',
            'label' => __('Address', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_city',
            'label' => __('City', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'wdk_facebook',
            'label' => __('Facebook', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'wdk_instagram',
            'label' => __('Instagram', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'returnSecureToken',
            'label' => __('Token', 'wpdirectorykit'),
            'rules' => ''
        ),
    );

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) 
    {
        $data_update = array(
            'ID'            => $user_token->user_id,
        );

        $meta = array(
            'user_email'    => $data_json->user_email,
            'first_name'    => $data_json->first_name,
            'last_name'     => $data_json->last_name,
            'display_name'  => $data_json->first_name.' '.$data_json->last_name,
            'nickname'      => $data_json->first_name.' '.$data_json->last_name,
            'wdk_phone'     => $data_json->wdk_phone,
            'wdk_address'   => $data_json->wdk_address,
            'wdk_city'      => $data_json->wdk_city,
            'wdk_facebook'  => $data_json->wdk_facebook,
            'wdk_instagram' => $data_json->wdk_instagram,
        );

        $data_update = array_merge($data_update, $meta);

        if(!empty($data_json->password))
        {
            $data_update['user_pass'] = $data_json->password;
        }

        $user_id = wp_update_user( $data_update);
        
        $ret = !is_wp_error( $user_id );
        if( $ret) {

            // save meta
            foreach( $meta as $key => $val ) {
                update_user_meta( $user_id, $key, $val ); 
            }

            $user = get_user_by('id', $user_id);

            $results['display_name']   = $user->display_name;
            $results['user_email']   = $user->user_email;

            unset($data_update['user_pass']);
            $results = array_merge($data_update, $results);

            $results['message'] = __('Update successfully', 'wpdirectorykit');
            $results['code'] = 'success';






        }
        else
        {
            //$results['message'] = __('Update failed, missing data', 'wpdirectorykit');
            $results['message'] = $user_id->get_error_message();
            $results['code'] = 'failed';
        }
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }
    
    return $results;
}

/* Delete user */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/delete_user', [
        'methods' => 'DELETE',
        'callback' => 'wdk_delete_delete_user',
        'permission_callback' => '__return_true',
    ]);
});

// Delete user
function wdk_delete_delete_user($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];

    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if(empty($_GET['user_id']))
    {
        $results['message'] = __('User ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if($user_token->user_id != $_GET['user_id'])
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    $user_id = $_GET['user_id'];

    if(wp_delete_user($user_id))
    {
        $results['message'] = __('Deleted successfully', 'wpdirectorykit');
        $results['code'] = 'success';
        return $results;
    }

    $results['message'] = __('Deleting failed, please contact support team', 'wpdirectorykit');
    $results['code'] = 'failed';
    
    return $results;
}

/* Get user */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/user', [
        'methods' => 'GET',
        'callback' => 'wdk_get_user',
        'permission_callback' => '__return_true',
    ]);
});

// Edit user
function wdk_get_user($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if(empty($_GET['user_id']))
    {
        $results['message'] = __('User ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if($user_token->user_id != $_GET['user_id'])
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    $user_id = $_GET['user_id'];

    $userdata_res = array();

    $userdata = get_userdata($user_id);

    if(!isset($userdata->data))
    {
        $results['message'] = __('User data missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $results['user_id'] = $user_id;

    foreach((array) $userdata->data as $key=>$val)
    {
        if(in_array($key, array('user_pass', 'user_activation_key', 'ID')))continue;

        $results[$key] = $val;
    }

    $results['profile_url'] = wdk_generate_profile_permalink($userdata);
    $results['avatar_url'] = esc_url(get_avatar_url( $user_id, array("size"=>300)));

    $user_meta = get_user_meta($user_id);

    foreach($user_meta as $key_meta=>$arr)
    {
        if(in_array(substr($key_meta, 0, 4), array('wdk_', 'firs', 'last')))
        {
            if(isset($arr[0]))
            {
                $results[$key_meta] = $arr[0];
            }
            else
            {
                $results[$key_meta] = '';
            }
        }
    }

    $results['message'] = __('User found and returning data', 'wpdirectorykit');
    $results['code'] = 'success';
    
    return $results;
}

