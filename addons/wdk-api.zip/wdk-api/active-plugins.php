<?php

/*

This plugin is used for performance optimizations when using mobile/rest api

How to use? 

In array $myplugins put your wanted plugins to load when using rest api

This file copy to /wp-content/mu-plugins/active-plugins.php

To reduce number of queries you can also define in db:
UPDATE `wp_options` SET `autoload`='yes' 

*/

$wdkapi_request_uri = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );

$wdkapi_is_admin = strpos( $wdkapi_request_uri, '/wp-admin/' );

if( false === $wdkapi_is_admin ){
	add_filter( 'option_active_plugins', function( $plugins ){

		global $wdkapi_request_uri;

		$is_rest = strpos( $wdkapi_request_uri, '/wp-json/' );
		
		if($is_rest === FALSE) return $plugins;

		$myplugins = array( 
			"wpdirectorykit/wpdirectorykit.php",
			"wdk-favorites/wdk-favorites.php",
			"wdk-api/wdk-api.php",
		);

		return $myplugins;

	} );
}

?>