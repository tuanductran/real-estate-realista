<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Api
 *
 * @wordpress-plugin
 * Plugin Name:       WDK API
 * Plugin URI:        https://wpdirectorykit.com/plugins/
 * Description:       REST API for mobile apps
 * Version:           1.0.0
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-api
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

require_once('helpers.php');
require_once('user-api.php');
require_once('mylisting-api.php');

/** Custom values into wdk-listing **/

add_action('rest_api_init', 'wdk_rest_api_custom_values');

function wdk_rest_api_custom_values()
{

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');

    $fields = $Winter_MVC_WDK->field_m->get();

    register_rest_field(
        'wdk-listing',
        'custom_fields',
        array(
            'get_callback'    => function ($object) use ($fields) {

                global $Winter_MVC_WDK;
                $post_id = $object['id'];

                $listing_db_data = $Winter_MVC_WDK->listing_m->get($post_id, TRUE);
                //$listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($post_id, TRUE);
                //$listingusers_db_data = $Winter_MVC_WDK->listingusers_m->get($post_id, TRUE);

                // Get field as single value from post meta.
                return (array) $listing_db_data;
            },
            'schema'       => null,
            'update_callback' => null,
        )
    );

    /*
    register_rest_field(
        'wdk-listing',
        $field,
        array(
            'get_callback'    => function ( $object ) use ( $field ) {
                // Get field as single value from post meta.
                return get_post_meta( $object['id'], $field, true );
            },
            'update_callback' => function ( $value, $object ) use ( $field ) {
                // Update the field/meta value.
                update_post_meta( $object->ID, $field, $value );
            },
            'schema'          => array(
                'type'        => 'string',
                'arg_options' => array(
                    'sanitize_callback' => function ( $value ) {
                        // Make the value safe for storage.
                        return sanitize_text_field( $value );
                    },
                    'validate_callback' => function ( $value ) {
                        // Valid if it contains exactly 10 English letters.
                        return (bool) preg_match( '/\A[a-z]{10}\Z/', $value );
                    },
                ),
            ),
        )
    );
*/
}

/* Fetch fields data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/fields', [
        'methods' => 'GET',
        'callback' => 'wdk_get_fields',
        'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_fields($params)
{
    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');

    $fields = $Winter_MVC_WDK->field_m->get();

    return $fields;
}



/* Fetch listings data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/listings', [
    'methods' => 'GET',
    'callback' => 'wdk_get_listings',
    'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_listings($params)
{
    $temp=$_GET;

    if(!empty($params) && is_array($params))
    {
        $_GET = (array) $params;
    }

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->model('cachedusers_m');
	$Winter_MVC_WDK->load_helper('listing');

    $results = array();

    // [Check Token]
    
    $user_id = NULL;
    
    if(!empty($temp['token']))
    {
        $token = $temp['token'];
        
        $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);
        
        if(!empty($user_token))
        {
            $user_id = $user_token->user_id;

            $results['token'] = (array) $user_token;
        }
    }

    // [/Check Token]

    $locations = $Winter_MVC_WDK->location_m->get_parents(NULL, FALSE);
    $categories = $Winter_MVC_WDK->category_m->get_parents(NULL, FALSE);
    $fields = $Winter_MVC_WDK->field_m->get();

    $columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by', 'is_featured', 'address');
    $external_columns = array('location_id', 'category_id', 'post_title');
    $custom_parameters = array();
    $controller = 'listing';
    $skip_postget = FALSE;

    $current_page = 1;

    if(isset($_GET['paged']))
        $current_page = intval($_GET['paged']);

    $per_page = 20;

    if(isset($_GET['per_page']))
        $per_page = intval($_GET['per_page']);

    $offset = $per_page*($current_page-1);
    
    $custom_filter = array('is_activated' => 1,'is_approved'=>1);

    if(!empty($user_id) && isset($_GET['is_favorite']))
    {
        $custom_filter['idfavorite > 0'] = NULL;
    }

    wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, $skip_postget);
    $total_items = $Winter_MVC_WDK->listing_m->total($custom_filter, false, $user_id);

    $results['listings_count'] = "$total_items";

    wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, $skip_postget);
    $results['listings'] = $Winter_MVC_WDK->listing_m->get_pagination($per_page, $offset, $custom_filter, false, $user_id);


    //show last query
    //echo $Winter_MVC_WDK->db->last_query();
    //exit();

    foreach($results['listings'] as $key=>$obj){

        $results['listings'][$key]->location_name = '';

        if(!empty($results['listings'][$key]->location_id))
        {
            if(!empty($locations[$results['listings'][$key]->location_id]))
                $results['listings'][$key]->location_name = str_replace('|-', '', str_replace('&nbsp;', '', $locations[$results['listings'][$key]->location_id]));
        }

        $results['listings'][$key]->category_name = '';

        if(!empty($results['listings'][$key]->category_id))
        {
            if(!empty($categories[$results['listings'][$key]->category_id]))
                $results['listings'][$key]->category_name = str_replace('|-', '', str_replace('&nbsp;', '', $categories[$results['listings'][$key]->category_id]));
        }

        // add prefix/sufix

        foreach($fields as $field)
        {
            if(!empty($results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type}))
            {
                $results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type} = 
                    $field->prefix.$results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type}.$field->suffix;
            }
        }
        
        if(empty($results['listings'][$key]->listing_images_path))
        {
            $results['listings'][$key]->listing_images_path = '';
            
            if(!empty($results['listings'][$key]->listing_images))
            {
                $ids_images = explode(',', $results['listings'][$key]->listing_images);

                $listing_images_paths_array = array();
                foreach($ids_images as $image_id)
                {
                    $parsed = parse_url( wp_get_attachment_url($image_id) );
                    
                    //$parsed = parse_url(  wp_get_attachment_image_url($image_id, 'medium') );

                    $listing_images_paths_array[] = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
                }
                
                if(count($listing_images_paths_array) > 0)
                    $results['listings'][$key]->listing_images_path = join(',', $listing_images_paths_array);
            }
        }
        
        if(empty($results['listings'][$key]->listing_images_path_medium))
        {
            $results['listings'][$key]->listing_images_path_medium = '';
            
            if(!empty($results['listings'][$key]->listing_images))
            {
                $ids_images = explode(',', $results['listings'][$key]->listing_images);

                $listing_images_paths_array = array();
                foreach($ids_images as $image_id)
                {
                    //$parsed = parse_url( wp_get_attachment_url($image_id) );
                    
                    $parsed = parse_url(  wp_get_attachment_image_url($image_id, 'large') );

                    $listing_images_paths_array[] = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
                }
                
                if(count($listing_images_paths_array) > 0)
                    $results['listings'][$key]->listing_images_path_medium = join(',', $listing_images_paths_array);
            }
        }

        // clean html

        $results['listings'][$key]->post_content_stripped = strip_tags($results['listings'][$key]->post_content);

        // user data

        $results['listings'][$key]->agent_exists = '0';
        if(!empty($results['listings'][$key]->user_id_editor))
        {
            $agent_data = array();
            $results['listings'][$key]->agent_exists = '1';

            /* from cache */
            if(defined( 'WDK_EXTENSIONS_CACHED_USERS_ACTIVATED' ) && WDK_EXTENSIONS_CACHED_USERS_ACTIVATED 
                && isset($results['listings'][$key]->cacheduser_display_name) && !empty($results['listings'][$key]->cacheduser_display_name)) {

                $results['listings'][$key]->profile_display_name = $results['listings'][$key]->cacheduser_display_name;
                $results['listings'][$key]->profile_email = $results['listings'][$key]->cacheduser_email;
                $results['listings'][$key]->profile_url = $results['listings'][$key]->cacheduser_profile_url;
                $results['listings'][$key]->avatar_url =  $results['listings'][$key]->cacheduser_avatar_url;
    
                /* meta */
                $results['listings'][$key]->wdk_address = $results['listings'][$key]->cacheduser_wdk_address;
                $results['listings'][$key]->wdk_phone = $results['listings'][$key]->cacheduser_wdk_phone;
                $results['listings'][$key]->wdk_city = $results['listings'][$key]->cacheduser_wdk_city;
                $results['listings'][$key]->wdk_company_name = $results['listings'][$key]->cacheduser_wdk_company_name;
                $results['listings'][$key]->wdk_facebook = $results['listings'][$key]->cacheduser_wdk_facebook;
                $results['listings'][$key]->wdk_youtube = $results['listings'][$key]->cacheduser_wdk_youtube;
                $results['listings'][$key]->wdk_linkedin = $results['listings'][$key]->cacheduser_wdk_linkedin;
                $results['listings'][$key]->wdk_twitter = $results['listings'][$key]->cacheduser_wdk_twitter;
                $results['listings'][$key]->wdk_instagram = $results['listings'][$key]->cacheduser_wdk_instagram;
                $results['listings'][$key]->wdk_whatsapp = $results['listings'][$key]->cacheduser_wdk_whatsapp;
                $results['listings'][$key]->wdk_viber = $results['listings'][$key]->cacheduser_wdk_viber;
                $results['listings'][$key]->wdk_iban = $results['listings'][$key]->cacheduser_wdk_iban;
                $results['listings'][$key]->wdk_telegram = $results['listings'][$key]->cacheduser_wdk_telegram;
                $results['listings'][$key]->wdk_position_title = $results['listings'][$key]->cacheduser_wdk_position_title;
                $results['listings'][$key]->agency_name = $results['listings'][$key]->cacheduser_agency_name;

                $fields = array('user_id','profile_url','avatar_url','display_name','email','wdk_address','wdk_phone','wdk_city','wdk_company_name','wdk_facebook','wdk_youtube','wdk_linkedin','wdk_twitter','wdk_instagram','wdk_whatsapp',
                                'wdk_viber','wdk_iban','wdk_telegram','wdk_position_title','agency_name','description','user_url','roles','json_data','date_updated');
                
                foreach ($fields as $field) {
                    unset($results['listings'][$key]->{'cacheduser_'.$field});
                }
            } else {

                $user_data = wdk_get_user_data($results['listings'][$key]->user_id_editor);
                $results['listings'][$key]->agent_exists = '1';
                $results['listings'][$key]->profile_display_name = wdk_get_user_field ($results['listings'][$key]->user_id_editor, 'display_name');
                $results['listings'][$key]->profile_email = wdk_get_user_field ($results['listings'][$key]->user_id_editor, 'user_email');
                $results['listings'][$key]->profile_url = $user_data['profile_url'];
                $results['listings'][$key]->avatar_url = $user_data['avatar'];

                if(false) {
                    $user_meta = get_user_meta($results['listings'][$key]->user_id_editor);
                    foreach($user_meta as $key_meta=>$arr)
                    {
                        if(substr($key_meta, 0, 4) == 'wdk_')
                        {
                            if(isset($arr[0]))
                            {
                                $results['listings'][$key]->$key_meta = $arr[0];
                            }
                            else
                            {
                                $results['listings'][$key]->$key_meta = '';
                            }
                        }
                    }

                } else {
                    /* meta from get_user_data object */
                    $meta_fields = array('wdk_address','wdk_phone','wdk_city','wdk_company_name','wdk_facebook','wdk_youtube','wdk_linkedin','wdk_twitter','wdk_instagram','wdk_whatsapp',
                                            'wdk_viber','wdk_iban','agency_name','wdk_telegram','wdk_position_title');

                    foreach ($meta_fields as $key_meta_field) {
                        $results['listings'][$key]->{$key_meta_field} = wdk_get_user_field ($results['listings'][$key]->user_id_editor, $key_meta_field);
                    }
                }

            }
        }
    }

    if(!empty($params))
    {
        $_GET = $temp;
    }

    return $results;
}

/* Fetch categories data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/categories', [
    'methods' => 'GET',
    'callback' => 'wdk_get_categories',
    'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_categories($params)
{
    $temp=$_GET;

    if(!empty($params) && is_array($params))
    {
        $_GET = (array) $params;
    }

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');
    $Winter_MVC_WDK->load_helper('listing');

    /* count listings */

    $Winter_MVC_WDK->db->select($Winter_MVC_WDK->category_m->_table_name.'.*, COUNT(DISTINCT '.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS count_listings');
    $Winter_MVC_WDK->db->join($Winter_MVC_WDK->category_m->_table_name.' AS categories_table ON (CONCAT(",", categories_table.parent_path, ",") LIKE CONCAT("%,", '.$Winter_MVC_WDK->category_m->_table_name.'.idcategory ,",%"))', TRUE, 'LEFT');
    $Winter_MVC_WDK->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON (
                                                        ('.$Winter_MVC_WDK->listing_m->_table_name.'.is_activated = 1 AND '.$Winter_MVC_WDK->listing_m->_table_name.'.is_approved = 1) AND
                                                        ('.$Winter_MVC_WDK->listing_m->_table_name.'.category_id = '.$Winter_MVC_WDK->category_m->_table_name.'.idcategory
                                                            OR '.$Winter_MVC_WDK->listing_m->_table_name.'.category_id = categories_table.idcategory
                                                        ))', TRUE, 'LEFT');

    $Winter_MVC_WDK->db->group_by('idcategory');

    $categories = $Winter_MVC_WDK->category_m->get();

    foreach($categories as $key=>$obj){

        $obj->image_url = '';
        $obj->icon_url = '';

        if(!empty($obj->image_id))
        {
            //$parsed = parse_url( wp_get_attachment_url($obj->image_id ) );
            /*
            $parsed = parse_url( wp_get_attachment_image_url($obj->image_id, 'large') );
            $obj->image_url = substr($parsed['path'], strpos($parsed['path'], 'wp-content'));
            */
            
            $path = wdk_image_src($obj, 'full', NULL, 'image_id', 'image_path');

            $obj->image_url = substr($path, strpos($path, 'wp-content'));
        }

        if(!empty($obj->icon_id))
        {
            //$parsed = parse_url( wp_get_attachment_url($obj->icon_id ) );
            /*
            $parsed = parse_url( wp_get_attachment_image_url($obj->image_id, 'large') );
            $obj->icon_url = substr($parsed['path'], strpos($parsed['path'], 'wp-content'));
            */
            
            $path = wdk_image_src($obj, 'full', NULL, 'icon_id', 'icon_path');

            $obj->icon_url = substr($path, strpos($path, 'wp-content'));
        }
        
    }

    if(!empty($params))
    {
        $_GET = $temp;
    }

    return $categories;
}

/* Fetch locations data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/locations', [
    'methods' => 'GET',
    'callback' => 'wdk_get_locations',
    'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_locations($params)
{
    $temp=$_GET;

    if(!empty($params) && is_array($params))
    {
        $_GET = (array) $params;
    }

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');
    $Winter_MVC_WDK->load_helper('listing');
    
    $where = NULL;

    if(isset($_GET['level']))
    {
        $where[$Winter_MVC_WDK->location_m->_table_name.'.level = '.intval($_GET['level'])] = NULL; 
    }

    $Winter_MVC_WDK->db->where($where); 

    /* count listings */
    /*
    SELECT wptest_wdk_locations.*,COUNT(DISTINCT post_id) AS count_listings
    FROM wptest_wdk_locations

    LEFT JOIN wptest_wdk_locations AS location_table ON (
                                CONCAT(',', location_table.parent_path ,',') LIKE CONCAT('%,', wptest_wdk_locations.idlocation ,',%')
                                )

    LEFT JOIN wptest_wdk_listings ON (
        wptest_wdk_listings.location_id = wptest_wdk_locations.idlocation OR wptest_wdk_listings.location_id = location_table.idlocation
    )

    GROUP BY idlocation
    ORDER BY order_index;
    */


    $Winter_MVC_WDK->db->select($Winter_MVC_WDK->location_m->_table_name.'.*, COUNT(DISTINCT '.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS count_listings, MAX('.$Winter_MVC_WDK->location_m->_table_name.'.level) as level');
    $Winter_MVC_WDK->db->join($Winter_MVC_WDK->location_m->_table_name.' AS location_table ON (CONCAT(",", location_table.parent_path, ",") LIKE CONCAT("%,", '.$Winter_MVC_WDK->location_m->_table_name.'.idlocation ,",%"))', TRUE, 'LEFT');
    $Winter_MVC_WDK->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON (
                                                            ('.$Winter_MVC_WDK->listing_m->_table_name.'.is_activated = 1 AND '.$Winter_MVC_WDK->listing_m->_table_name.'.is_approved = 1) AND
                                                            ('.$Winter_MVC_WDK->listing_m->_table_name.'.location_id = '.$Winter_MVC_WDK->location_m->_table_name.'.idlocation
                                                            OR '.$Winter_MVC_WDK->listing_m->_table_name.'.location_id = location_table.idlocation)

                                                        )', TRUE, 'LEFT');
    $Winter_MVC_WDK->db->group_by('idlocation');

    $locations = $Winter_MVC_WDK->location_m->get();

    foreach($locations as $key=>$obj){

        $obj->image_url = '';
        $obj->icon_url = '';

        if(!empty($obj->image_id))
        {
            //$parsed = parse_url( wp_get_attachment_url($obj->image_id ) );
            /*
            $parsed = parse_url( wp_get_attachment_image_url($obj->image_id, 'large') );
            $obj->image_url = substr($parsed['path'], strpos($parsed['path'], 'wp-content'));
            */

            $path = wdk_image_src($obj, 'full', NULL, 'image_id', 'image_path');

            $obj->image_url = substr($path, strpos($path, 'wp-content'));
        }

        if(!empty($obj->icon_id))
        {
            //$parsed = parse_url( wp_get_attachment_url($obj->icon_id ) );
            /*
            $parsed = parse_url( wp_get_attachment_image_url($obj->image_id, 'medium') );
            $obj->icon_url = substr($parsed['path'], strpos($parsed['path'], 'wp-content'));
            */
            
            $path = wdk_image_src($obj, 'full', NULL, 'icon_id', 'icon_path');

            $obj->icon_url = substr($path, strpos($path, 'wp-content'));
        }
    }

    if(!empty($params))
    {
        $_GET = $temp;
    }

    return $locations;
}

/* Fetch agents data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/agents', [
    'methods' => 'GET',
    'callback' => 'wdk_get_agents',
    'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_agents($params)
{
    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('user_m');

    $where = NULL;

    global $wp_roles;
    if ( ! isset( $wp_roles ) ) {
        $wp_roles = new \WP_Roles();
    }

    $page = 0;

    if(isset($_GET['paged']))
    {
        $page = intval($_GET['paged']);
    }

    $per_page = 20;

    if(isset($_GET['per_page']))
    {
        $per_page = intval($_GET['per_page']);
    }

    $search_like_roles = "(meta_value LIKE '%wdk_agent%' OR meta_value LIKE '%wdk_agency%')";

    $controller = 'user';
    $columns = array('user_login','user_nicename','user_email','user_url','display_name');
    $external_columns = array('user_login','user_nicename','user_email','user_url','display_name');

    wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1, 'is_approved'=>1));

    $profiles_list = $Winter_MVC_WDK->user_m->get_pagination($per_page, $page*$per_page, array(), 'listings_counter DESC', $search_like_roles, FALSE, TRUE);
   
    foreach($profiles_list as $key=>$profile)
    {

        $userdata = get_userdata($profile->ID);
        $profiles_list[$key]->profile_url = wdk_generate_profile_permalink($userdata);
        $profiles_list[$key]->count_listings = wmvc_show_data('listings_counter', $profile, 0);
        $profiles_list[$key]->avatar_url = esc_url(get_avatar_url( wmvc_show_data('ID', $profile), array("size"=>300)));

        $user_meta = get_user_meta($profile->ID);

        foreach($user_meta as $key_meta=>$arr)
        {
            if(substr($key_meta, 0, 4) == 'wdk_')
            {
                if(isset($arr[0]))
                {
                    $profiles_list[$key]->$key_meta = $arr[0];
                }
                else
                {
                    $profiles_list[$key]->$key_meta = '';
                }
            }
        }
    }

    return $profiles_list;
}

/* Fetch news data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/news', [
    'methods' => 'GET',
    'callback' => 'wdk_get_news',
    'permission_callback' => '__return_true',
    ]);
});

// Get all projects and assign thumbnail
function wdk_get_news($params)
{
    $args = array(
        'numberposts'	=> 10,
        //'category'		=> 4
        'post_type'		=> 'post'
    );
    $posts_list = get_posts( $args );

    foreach($posts_list as $key=>$post)
    {
        $parsed = parse_url( get_the_post_thumbnail_url( $post->ID, 'large' ) );
        
        //var_dump($parsed);exit;

        $posts_list[$key]->image_url = substr($parsed['path'], strpos($parsed['path'], 'wp-content'));

        $posts_list[$key]->post_author_display_name = get_the_author_meta('display_name', $post->post_author);
        
        $posts_list[$key]->guid = get_post_permalink($post);

    }
    
    return $posts_list;
}

/* Fetch home screen data */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/home', [
    'methods' => 'GET',
    'callback' => 'wdk_get_home',
    'permission_callback' => '__return_true',
    ]);
});

// Get all data for homescreen
function wdk_get_home($params)
{
    $time_start = microtime(true);
    $results = array();

    // fetch categories, 15 queries
    $results['categories'] = wdk_get_categories($params);

    // fetch locations, 21 queries
    $results['locations'] = wdk_get_locations(array('level'=>'0'));

    // fetch agents, 8 queries
    $results['agents'] = wdk_get_agents($params);

    // fetch trending listings
    $results['trending_listings'] = wdk_get_listings(array('is_featured'=>'on'));

    // fetch latest listings
    $results['latest_listings'] = wdk_get_listings(array());

    // fetch latest news, 15 queries
    $results['news'] = wdk_get_news($params);

    if(defined('SAVEQUERIES'))
    {
        global $wpdb;
        $results['queries'] = $wpdb->queries;
        $results['count_queries'] = count($wpdb->queries);
        $results['execution_time_wdk (ms)'] = (microtime(true)-$time_start)*1000;
        $results['execution_time_total (ms)'] = (microtime(true)-$_SERVER["REQUEST_TIME_FLOAT"])*1000;
    }
    
    return $results;
}

/* Listing Agent Message */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/listing_agent_message', [
    'methods' => 'POST',
    'callback' => 'wdk_post_listing_agent_message',
    'permission_callback' => '__return_true',
    ]);
});

// Send message to agent
function wdk_post_listing_agent_message($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('messages_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();
    $data_listing = $Winter_MVC_WDK->listing_m->get($data_json->listing_id, TRUE);


    $rules = array(
        array(
            'field' => 'Name',
            'label' => __('Name', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'Email',
            'label' => __('Please populate Email', 'wpdirectorykit'),
            'rules' => 'required|valid_email'
        ),

        array(
            'field' => 'Message',
            'label' => __('Message', 'wpdirectorykit'),
            'rules' => 'required'
        ),
    );

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) {

        $data = array(
            'post_id' => ($data_json->listing_id),
            'email_sender' =>  ($data_json->Email),
            'message' =>  ($data_json->Message),
            'json_object' => json_encode((array) $data_json)
        );

        $insert_idmessage = $Winter_MVC_WDK->messages_m->insert($data, null);

        $data_message = array();
        $data_message['email_data'] = (array) $data_json;
        $data_message['message'] =  $data_json->Message;

        $message_title = __('New Message', 'wpdirectorykit');

        $data_message['message'] .= '<p>'.__('Contact message related to listing', 'wpdirectorykit').' <a href="'.esc_url(get_permalink($data_listing)).'">'.esc_html(wmvc_show_data('post_title', $data_listing, '', TRUE, TRUE)).'</a></p>';
        $data_message['message'] .= implode('', $data_message['email_data']);

        /* owner data */
        $user_owner = NULL;
        $owner_email = get_bloginfo('admin_email');
        if(wmvc_show_data('user_id_editor', $data_listing, false, TRUE, TRUE )) {
            $user_owner = get_userdata( wmvc_show_data('user_id_editor', $data_listing, false, TRUE, TRUE ) );
            if($user_owner)
                $owner_email = $user_owner->user_email;
        }

        $ret = wdk_mail($owner_email, $message_title, $data_message, 'new_message');
        if( $ret) {
            $results['message'] = __('Thanks, your message is sent successfully', 'wpdirectorykit');
            $results['code'] = 'success';
        }
        else
        {
            $results['message'] = __('Server can\'t send emails, please use SMTP mail configuration.', 'wpdirectorykit');
            $results['code'] = 'failed';
        }
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }
    
    return $results;
}

/* Listing Favorite */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/listing_favorite', [
    'methods' => 'POST',
    'callback' => 'wdk_post_listing_favorite',
    'permission_callback' => '__return_true',
    ]);
});

// Add/Remove listing from favorite
function wdk_post_listing_favorite($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    global $Winter_MVC_wdk_favorites;
    $Winter_MVC_wdk_favorites->model('favorite_m');

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];

    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    $user_id = $user_token->user_id;

    $rules = array(
        array(
            'field' => 'is_favorite',
            'label' => __('Favorite missing', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'listing_id',
            'label' => __('Listing ID missing', 'wpdirectorykit'),
            'rules' => 'required|numeric'
        ),
    );

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) 
    {
        if(empty($data_json->is_favorite))
        {
            // Remove favorite
            
            $Winter_MVC_wdk_favorites->favorite_m->delete_by_post($data_json->listing_id, $user_id);

            $results['message'] = __('Removed from favorites', 'wpdirectorykit');
            $results['code'] = 'success';
            return $results;
        }
        else
        {
			$favorite_added = $Winter_MVC_wdk_favorites->favorite_m->check_if_exists($user_id, $data_json->listing_id);
            
            if($favorite_added)
            {
                $results['message'] = __('Favorite already exists', 'wpdirectorykit');
                $results['code'] = 'failed';
                return $results;
            }
            
            // Add favorite

            $data = array(
                'post_id' => ($data_json->listing_id),
                'post_type' => 'wdk-listing',
                'user_id' =>  ($user_id),
                'date' => date("Y-m-d H:i:s")
            );
    
            $insert_id = $Winter_MVC_wdk_favorites->favorite_m->insert($data, null);

            $results['message'] = __('Added to favorites', 'wpdirectorykit');
            $results['code'] = 'success';
            return $results;
        }
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }
    
    return $results;
}



