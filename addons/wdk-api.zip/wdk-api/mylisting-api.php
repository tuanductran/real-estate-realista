<?php

/* Fetch Listings */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/mylistings', [
        'methods' => 'GET',
        'callback' => 'wdk_get_mylistings',
        'permission_callback' => '__return_true',
    ]);
});


function wdk_get_mylistings($params)
{
    $temp=$_GET;

    if(!empty($params) && is_array($params))
    {
        $_GET = (array) $params;
    }

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');
    $Winter_MVC_WDK->model('token_m');

    $results = array();

    // [Check Token]
    
    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $user_id = $user_token->user_id;

    // [/Check Token]

    $locations = $Winter_MVC_WDK->location_m->get_parents(NULL, FALSE);
    $categories = $Winter_MVC_WDK->category_m->get_parents(NULL, FALSE);
    $fields = $Winter_MVC_WDK->field_m->get();

    $columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by', 'is_featured', 'address');
    $external_columns = array('location_id', 'category_id', 'post_title');
    $custom_parameters = array();
    $controller = 'listing';
    $skip_postget = FALSE;

    $current_page = 1;

    if(isset($_GET['paged']))
        $current_page = intval($_GET['paged']);

    $per_page = null;

    if(isset($_GET['per_page']))
        $per_page = intval($_GET['per_page']);

    $offset = $per_page*($current_page-1);
    
    $custom_filter = array();

    if(!empty($user_id) && isset($_GET['is_favorite']))
    {
        $custom_filter['idfavorite > 0'] = NULL;
    }

    wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, $skip_postget);
    $total_items = $Winter_MVC_WDK->listing_m->total($custom_filter, true, $user_id);

    $results['listings_count'] = "$total_items";

    wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, $skip_postget);
    $results['listings'] = $Winter_MVC_WDK->listing_m->get_pagination($per_page, $offset, $custom_filter, true, $user_id);

    //show last query
    //echo $Winter_MVC_WDK->db->last_query();
    //exit();

    foreach($results['listings'] as $key=>$obj){

        $results['listings'][$key]->location_name = '';

        if(!empty($results['listings'][$key]->location_id))
        {
            if(!empty($locations[$results['listings'][$key]->location_id]))
                $results['listings'][$key]->location_name = str_replace('|-', '', str_replace('&nbsp;', '', $locations[$results['listings'][$key]->location_id]));
        }

        $results['listings'][$key]->category_name = '';

        if(!empty($results['listings'][$key]->category_id))
        {
            if(!empty($categories[$results['listings'][$key]->category_id]))
                $results['listings'][$key]->category_name = str_replace('|-', '', str_replace('&nbsp;', '', $categories[$results['listings'][$key]->category_id]));
        }

        // add prefix/sufix

        foreach($fields as $field)
        {
            if(!empty($results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type}))
            {
                $results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type} = 
                    $results['listings'][$key]->{'field_'.$field->idfield.'_'.$field->field_type};
            }
        }
        
        if(empty($results['listings'][$key]->listing_images_path))
        {
            $results['listings'][$key]->listing_images_path = '';
            
            if(!empty($results['listings'][$key]->listing_images))
            {
                $ids_images = explode(',', $results['listings'][$key]->listing_images);

                $listing_images_paths_array = array();
                foreach($ids_images as $image_id)
                {
                    $parsed = parse_url( wp_get_attachment_url($image_id) );
                    
                    //$parsed = parse_url(  wp_get_attachment_image_url($image_id, 'medium') );

                    $listing_images_paths_array[] = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
                }
                
                if(count($listing_images_paths_array) > 0)
                    $results['listings'][$key]->listing_images_path = join(',', $listing_images_paths_array);
            }
        }
        
        if(empty($results['listings'][$key]->listing_images_path_medium))
        {
            $results['listings'][$key]->listing_images_path_medium = '';
            
            if(!empty($results['listings'][$key]->listing_images))
            {
                $ids_images = explode(',', $results['listings'][$key]->listing_images);

                $listing_images_paths_array = array();
                foreach($ids_images as $image_id)
                {
                    //$parsed = parse_url( wp_get_attachment_url($image_id) );
                    
                    $parsed = parse_url(  wp_get_attachment_image_url($image_id, 'large') );

                    $listing_images_paths_array[] = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
                }
                
                if(count($listing_images_paths_array) > 0)
                    $results['listings'][$key]->listing_images_path_medium = join(',', $listing_images_paths_array);
            }
        }

        // clean html

        $results['listings'][$key]->post_content_stripped = strip_tags($results['listings'][$key]->post_content);

        // user data

        $results['listings'][$key]->agent_exists = '0';
        if(!empty($results['listings'][$key]->user_id_editor))
        {
            $agent_data = array();

            $userdata = get_userdata($results['listings'][$key]->user_id_editor);

            $results['listings'][$key]->agent_exists = '1';
            $results['listings'][$key]->profile_display_name = $userdata->display_name;
            $results['listings'][$key]->profile_email = $userdata->user_email;
            $results['listings'][$key]->profile_url = wdk_generate_profile_permalink($userdata);
            $results['listings'][$key]->avatar_url = esc_url(get_avatar_url( wmvc_show_data('ID', $userdata), array("size"=>300)));

            $user_meta = get_user_meta($results['listings'][$key]->user_id_editor);

            foreach($user_meta as $key_meta=>$arr)
            {
                if(substr($key_meta, 0, 4) == 'wdk_')
                {
                    if(isset($arr[0]))
                    {
                        $results['listings'][$key]->$key_meta = $arr[0];
                    }
                    else
                    {
                        $results['listings'][$key]->$key_meta = '';
                    }
                }
            }
        }
    }

    if(!empty($params))
    {
        $_GET = $temp;
    }

    return $results;
}


/* Delete Listings */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/delete_listing', [
        'methods' => 'DELETE',
        'callback' => 'wdk_delete_delete_listing',
        'permission_callback' => '__return_true',
    ]);
});

function wdk_delete_delete_listing($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');

    $this_tmp = $Winter_MVC_WDK;

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    if(empty($_GET['post_id']))
    {
        $results['message'] = __('Post ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_post_id = intval($_GET['post_id']);

    $listing_db_data = $this_tmp->listing_m->get($listing_post_id, TRUE);

    if(!isset($listing_db_data->user_id_editor) || $listing_db_data->user_id_editor != $user_token->user_id)
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if($this_tmp->listing_m->delete($listing_post_id, $user_token->user_id) == TRUE)
    {
        $results['message'] = __('Listing submitted deleted', 'wpdirectorykit');
        $results['code'] = 'success';
        return $results;
    }

    $results['message'] = __('Deleting failed', 'wpdirectorykit');
    $results['code'] = 'failed';
    return $results;
}

/* Delete Image from listing */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/delete_image', [
        'methods' => 'DELETE',
        'callback' => 'wdk_delete_delete_image',
        'permission_callback' => '__return_true',
    ]);
});

function wdk_delete_delete_image($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');

    $this_tmp = $Winter_MVC_WDK;

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    if(empty($_GET['post_id']))
    {
        $results['message'] = __('Post ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if(empty($_GET['image_path']))
    {
        $results['message'] = __('Image path missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_post_id = intval($_GET['post_id']);

    $listing_db_data = $this_tmp->listing_m->get($listing_post_id, TRUE);

    if(!isset($listing_db_data->user_id_editor) || $listing_db_data->user_id_editor != $user_token->user_id)
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // Detect image index

    $images_path_array = explode(',', $listing_db_data->listing_images_path);
    $index = array_search($_GET['image_path'], $images_path_array);

    //var_dump($images_path_array);
    //var_dump($_GET['image_path']);

    if($index === FALSE)
    {
        $results['message'] = __('Image not found', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_images_path_medium_array = explode(',', $listing_db_data->listing_images_path_medium);
    $listing_images_array = explode(',', $listing_db_data->listing_images);

    $image_id = $listing_images_array[$index];

    // Remove images from listing

    unset($images_path_array[$index]);
    unset($listing_images_path_medium_array[$index]);
    unset($listing_images_array[$index]);

    $listing_data = array();
    $listing_data['listing_images_path'] = join(',', $images_path_array);
    $listing_data['listing_images_path_medium'] = join(',', $listing_images_path_medium_array);
    $listing_data['listing_images'] = join(',', $listing_images_array);

    $Winter_MVC_WDK->listing_m->insert($listing_data, $listing_post_id);

    // delete image from system
    wp_delete_attachment($image_id, TRUE);

    $results['message'] = __('Image removed #', 'wpdirectorykit').$image_id;
    $results['code'] = 'success';
    return $results;
}

/* Delete Image from listing */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/move_image_top', [
        'methods' => 'GET',
        'callback' => 'wdk_get_move_image_top',
        'permission_callback' => '__return_true',
    ]);
});

function wdk_get_move_image_top($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');

    $this_tmp = $Winter_MVC_WDK;

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    if(empty($_GET['post_id']))
    {
        $results['message'] = __('Post ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if(empty($_GET['image_path']))
    {
        $results['message'] = __('Image path missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_post_id = intval($_GET['post_id']);

    $listing_db_data = $this_tmp->listing_m->get($listing_post_id, TRUE);

    if(!isset($listing_db_data->user_id_editor) || $listing_db_data->user_id_editor != $user_token->user_id)
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // Detect image index

    $images_path_array = explode(',', $listing_db_data->listing_images_path);
    $index = array_search($_GET['image_path'], $images_path_array);

    if($index === FALSE)
    {
        $results['message'] = __('Image not found', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_images_path_medium_array = explode(',', $listing_db_data->listing_images_path_medium);
    $listing_images_array = explode(',', $listing_db_data->listing_images);

    $image_id = $listing_images_array[$index];

    // move image to top for listing

    $temp = $images_path_array[$index];
    $images_path_array[$index] = $images_path_array[0];
    $images_path_array[0] = $temp;

    $temp = $listing_images_path_medium_array[$index];
    $listing_images_path_medium_array[$index] = $listing_images_path_medium_array[0];
    $listing_images_path_medium_array[0] = $temp;

    $temp = $listing_images_array[$index];
    $listing_images_array[$index] = $listing_images_array[0];
    $listing_images_array[0] = $temp;

    $listing_data = array();
    $listing_data['listing_images_path'] = join(',', $images_path_array);
    $listing_data['listing_images_path_medium'] = join(',', $listing_images_path_medium_array);
    $listing_data['listing_images'] = join(',', $listing_images_array);

    $Winter_MVC_WDK->listing_m->insert($listing_data, $listing_post_id);

    $results['message'] = __('Image moved to top #', 'wpdirectorykit').$image_id;
    $results['code'] = 'success';
    return $results;
}

/* Upload Listing */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/images_upload', [
        'methods' => 'POST',
        'callback' => 'wdk_post_images_upload',
        'permission_callback' => '__return_true',
    ]);
});


function wdk_post_images_upload($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    $this_tmp = $Winter_MVC_WDK;

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    // [Check Post Permissions]
    
    if(empty($_GET['post_id']))
    {
        $results['message'] = __('Post ID missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $listing_post_id = intval($_GET['post_id']);

    $post = get_post($listing_post_id); 
    $listing_db_data = $this_tmp->listing_m->get($listing_post_id, TRUE);

    if(!isset($listing_db_data->user_id_editor) || $listing_db_data->user_id_editor != $user_token->user_id)
    {
        $results['message'] = __('Token missing permissions', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    if(empty($post->post_name))
    {
        $results['message'] = __('Listing post not found: ', 'wpdirectorykit').$listing_post_id;
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Post Permissions]

    $img = ['jpg', 'jpeg', 'png', 'bmp'];
    $doc = [];//['zip', 'rar', 'pdf', 'doc', 'docx', 'xls','xlsx','ppt','pptx'];
    
    
    $whitelistExt = array_merge($img, $doc);

    //var_dump($_POST);
    //var_dump($data_json);

    //$attachments_array = json_decode($_POST['attachment']);

    //var_dump($data_json);

    $attachment_files = array();
    //$results_files = array();
    $wp_upload_dir = wp_upload_dir();
    
    foreach ($data_json as $key => $value)
    {
        $file_name = $value->fileName;
        $ext = pathinfo($file_name, PATHINFO_EXTENSION);
        $f_decoded = base64_decode($value->encoded);   

        // Rename file baased on listing
        for($detect_file_number=1;$detect_file_number<9999;$detect_file_number++)
        {
            $file_name = $post->post_name.'-'.$listing_post_id.'-'.$detect_file_number .'.'.$ext;
            if(!file_exists($wp_upload_dir['path'] . '/' . $file_name))
                break;
        }

        // Upload file to wp
        
        $file_path = $wp_upload_dir['path'] . '/' . $file_name;
        $file_url = $wp_upload_dir['url'] . '/' . $file_name;

        $transfer = file_put_contents($file_path, $f_decoded);

        $file_type = wp_check_filetype( $file_name, null );
        $attachment_title = sanitize_file_name( pathinfo( $file_name, PATHINFO_FILENAME ) );
    
        $post_info = array(
            'guid'           => $file_url,
            'post_mime_type' => $file_type['type'],
            'post_title'     => $attachment_title,
            'post_content'   => '',
            'post_status'    => 'inherit',
        );
    
        // Create the attachment
        $attach_id = wp_insert_attachment( $post_info, $file_path, $listing_post_id );
    
        // Include image.php
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
    
        // Define attachment metadata
        $attach_data = wp_generate_attachment_metadata( $attach_id, $file_path );
    
        // Assign metadata to attachment
        wp_update_attachment_metadata( $attach_id,  $attach_data );

        if($attach_id == 0) // on error
        {
            continue;
        }

        $attachment_files[] = $attach_id;

        //$attachment_files[] = wmvc_add_wp_image($f_decoded, $parent_post_id);


        //var_dump(ABSPATH."uploads/".$file_name);
    }

    

    $listing_data = array();
    $results_files = array();

    if(count($attachment_files) > 0)
    {
        $prev_images = '';
        if(!empty($listing_db_data->listing_images))
            $prev_images = $listing_db_data->listing_images.',';

        $listing_data['listing_images'] = $prev_images.join(',', $attachment_files);

        // also update image paths for caching/reduce queries
        // listing_images_path_medium, listing_images_path

        $listing_images_paths_array = array();
        $listing_images_paths_array_large = array();
        foreach($attachment_files as $image_id)
        {
            $parsed = parse_url( wp_get_attachment_url($image_id) );
            
            $parsed2 = parse_url(  wp_get_attachment_image_url($image_id, 'large') );

            $file_url_relative = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
    
            $results_files[] = array('file_url'=>$file_url_relative, 
                                     'attach_id' =>$image_id);

            $listing_images_paths_array[] = $file_url_relative;
            $listing_images_paths_array_large[] = substr($parsed2['path'], strpos($parsed2['path'], 'uploads/')+8);
        }

        $prev_images = '';
        if(!empty($listing_db_data->listing_images_path))
            $prev_images = $listing_db_data->listing_images_path.',';

        if(count($listing_images_paths_array) > 0) // originals goes to path
            $listing_data['listing_images_path'] = $prev_images.join(',', $listing_images_paths_array);

        $prev_images = '';
        if(!empty($listing_db_data->listing_images_path_medium))
            $prev_images = $listing_db_data->listing_images_path_medium.',';

        if(count($listing_images_paths_array_large) > 0) // large goes to medium
            $listing_data['listing_images_path_medium'] = $prev_images.join(',', $listing_images_paths_array_large);

        $Winter_MVC_WDK->listing_m->insert($listing_data, $listing_post_id);

        $results['files'] = $results_files;

        $results['message'] = __('Uploaded images: ', 'wpdirectorykit').count($attachment_files);
        $results['code'] = 'success';
        return $results;
    }

    $results['message'] = __('Images not uploaded', 'wpdirectorykit');
    $results['code'] = 'failed';
    return $results;
}








/* Add/Edit Listing */

add_action('rest_api_init', function () 
{
    register_rest_route('wdk/v1', '/edit_listing', [
        'methods' => 'POST',
        'callback' => 'wdk_post_edit_listing',
        'permission_callback' => '__return_true',
    ]);
});

// Add/Edit Listing
function wdk_post_edit_listing($params)
{
    $results = array(
        'code'	    => 'empty_code',
        'message'   => 'Empty Message'
    );

    $postBody = file_get_contents('php://input');
    $data_json = json_decode($postBody);

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('field_m');
    $Winter_MVC_WDK->model('token_m');
    $Winter_MVC_WDK->load_helper('listing');
    $Winter_MVC_WDK->form = new MVC_Form();

    $this_tmp = $Winter_MVC_WDK;

    // [Check Token]

    if(empty($_GET['token']))
    {
        $results['message'] = __('Token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    $token = $_GET['token'];
    $user_token = $Winter_MVC_WDK->token_m->get_by(array('token' => $token ), TRUE);

    if(empty($user_token))
    {
        $results['message'] = __('Valid token missing', 'wpdirectorykit');
        $results['code'] = 'failed';
        return $results;
    }

    // [/Check Token]

    $this_tmp->db->where(array('field_type !='=> 'SECTION'));
    $this_tmp->data['listing_fields'] = $this_tmp->field_m->get();
    
    $this_tmp->data['fields'] = $this_tmp->field_m->get();

    $rules = array(
        array(
            'field' => 'post_title',
            'label' => __('Title', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'post_content',
            'label' => __('Content', 'wpdirectorykit'),
            'rules' => 'required'
        ),
        array(
            'field' => 'category_id',
            'label' => __('Category', 'wpdirectorykit'),
            'rules' => (wdk_get_option('wdk_listing_category_required')) ? 'required':''
        ),
        array(
            'field' => 'location_id',
            'label' => __('Location', 'wpdirectorykit'),
            'rules' => (wdk_get_option('wdk_listing_location_required')) ? 'required':''
        ),
        array(
            'field' => 'is_activated',
            'label' => __('Is Activated', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'lat',
            'label' => __('lat', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'address',
            'label' => __('Address', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'lng',
            'label' => __('lng', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'listing_images',
            'label' => __('Listing images', 'wpdirectorykit'),
            'rules' => ''
        ),
        array(
            'field' => 'listing_plans_documents',
            'label' => __('Listing plans and documents', 'wpdirectorykit'),
            'rules' => ''
        ),
    );

    foreach($this_tmp->data['fields'] as $key => $field)
    {
        if($field->field_type == 'SECTION'){
            $this_tmp->data['fields'][$key]->is_required = '';
            continue;
        }

        $rule_required = (wmvc_show_data('is_required', $field) == 1) ? 'required' : '';

        if(wmvc_show_data('validation', $field)) {
            if(!empty($rule_required)) {
                $rule_required .= '|';
            }
            $rule_required .= wmvc_show_data('validation', $field);
        }

        if(!empty(wmvc_show_data('min_length', $field))) {
            if(!empty($rule_required)) {
                $rule_required .= '|';
            }
            
            if(wmvc_show_data('field_type', $field) == "NUMBER") {
                $rule_required .= "min_number";
            } else {
                $rule_required .= "min_length";
            }
            $rule_required .= "[".wmvc_show_data('min_length', $field)."]";

        }

        if(!empty(wmvc_show_data('max_length', $field))) {
            if(!empty($rule_required)) {
                $rule_required .= '|';
            }
            if(wmvc_show_data('field_type', $field) == "NUMBER") {
                $rule_required .= "max_number";
            } else {
                $rule_required .= "max_length";
            }
            $rule_required .= "[".wmvc_show_data('max_length', $field)."]";
        }

        $rules[] = 
            array(
                'field' => 'field_'.$field->idfield,
                'label' => $field->field_label,
                'rules' => $rule_required
            );

            /*
        if(isset($this_tmp->data['db_data']['field_'.$field->idfield.'_'.$field->field_type]))
            $this_tmp->data['db_data']['field_'.$field->idfield] = 
                $this_tmp->data['db_data']['field_'.$field->idfield.'_'.$field->field_type];*/
    }

    $listing_post_id = NULL;

    if(!empty($data_json->post_id))
    {
        $listing_post_id = intval($data_json->post_id);

        $listing_post = get_post( $listing_post_id );

        $listing_db_data = $this_tmp->listing_m->get($listing_post_id, TRUE);

        $listingfield_db_data = $this_tmp->listingfield_m->get($listing_post_id, TRUE);
        $listingusers_db_data = $this_tmp->listingusers_m->get($listing_post_id);

        $this_tmp->data['db_data'] = array_merge((array) $listing_post, 
                                             (array) $listing_db_data, 
                                             (array) $listingfield_db_data);

        if($this_tmp->data['db_data']['user_id_editor'] != $user_token->user_id)
        {
            $results['message'] = __('Token missing permissions', 'wpdirectorykit');
            $results['code'] = 'failed';
            return $results;
        }
    }

    /* message for user */
    if($Winter_MVC_WDK->form->run_json($rules)) 
    {
        // Save procedure for basic data

        //$data = $this_tmp->listing_m->prepare_data(wdk_get_post(), $rules, FALSE);

        // Save standard wp post
        
        // Create post object
        $listing_post = array(
            'ID' => $listing_post_id,
            'post_type'     => 'wdk-listing',
            'post_title'    => wp_strip_all_tags( $data_json->post_title ),
            'post_content'  => $data_json->post_content,
            'post_status'   => 'publish',
            'post_author'   => get_current_user_id()
        );
        
        // Insert the post into the database
        $id = wp_insert_post( $listing_post );

        // Save our main listing data

        $listing_data = array(  'post_id' => $id, 
                                'user_id_editor' => $user_token->user_id);

        $listing_data_fields = array('category_id', 'location_id', 'address', 'lat', 'lng', 'listing_images','listing_plans_documents', 'is_activated');

        foreach($listing_data_fields as $field_name)
        {
            if(isset($data_json->$field_name))
                $listing_data[$field_name] = $data_json->$field_name;
        }

        unset($listing_data['rank']);

        /* dates set */
        if(isset($this_tmp->data['db_data']['date']))
            $listing_data['date'] = $this_tmp->data['db_data']['date'];

        $listing_data['date_modified'] = date('Y-m-d H:i:s');

        // get gps coordinates

        if(!empty($listing_data['address']))
        if($listing_data['address'] != $listing_db_data->address)
        {
            $coordinates = NULL;

            /* if enable google try use google api for detect gps */
            if(get_option('wdk_import_google_api_enable') && wdk_get_option('wdk_geo_google_api_key')) {
                $coordinates = wdk_get_gps_google($listing_data['address']);
            } 
            
            /* if gps not detected, try free api */
            if(empty($coordinates)) {
                $coordinates = wdk_get_gps($listing_data['address']);
            }

            if(!empty($coordinates)) {
                $listing_data['lat'] = $coordinates['lat'];
                $listing_data['lng'] = $coordinates['lng'];
            }
        }

        if(empty($listing_db_data))
        {
            $this_tmp->listing_m->insert($listing_data, NULL);
        }
        else
        {
            $this_tmp->listing_m->insert($listing_data, $id);
        }

        $data_update = array(
            'categories_list'=> '',
            'locations_list'=>''
        );

        // Save dynamic fields data

        $data = (array) $data_json; // prepare for insert function

        $data['post_id'] = $id;
        $results['post_id'] = $id;

        if(empty($listingfield_db_data))
        {
            $this_tmp->listingfield_m->insert_custom_fields($this_tmp->data['listing_fields'], $data, NULL);
        }
        else
        {
            $this_tmp->listingfield_m->insert_custom_fields($this_tmp->data['listing_fields'], $data, $id);
        }

        //exit('test1');

        $results['message'] = __('Listing submitted successfully', 'wpdirectorykit');
        $results['code'] = 'success';
    }
    else
    {
        $results['message'] = $Winter_MVC_WDK->form->messages_api();
        $results['code'] = 'failed';
    }

    //var_dump($results);
    
    return $results;
}
