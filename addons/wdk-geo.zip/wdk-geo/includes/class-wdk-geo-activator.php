<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Geo
 * @subpackage Wdk_Geo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Geo
 * @subpackage Wdk_Geo/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Geo_Activator {
	public static $db_version = 1.1;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_geo_';
	}

	public static function plugins_loaded(){
      
		if ( get_site_option( 'wdk_geo_db_version' ) === false ||
		     get_site_option( 'wdk_geo_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

	
    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_geo_db_version' ) === false)
        {
            // Main table for visited pages

        }
        
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_geo_db_version' ) < '1.1' ) {

           
        }

        //update_option( 'wdk_db_version', self::$db_version );
    }

}
