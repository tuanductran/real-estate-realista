<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


if(!function_exists('wdk_geo_get_locations')) {
    /**
	 * Get Locations Array By APi (geoplugin).
	 *
	 * @param      string    $ip     ip address
	 * @param      string    $default     The default value, will be return if empty or no exists
	 * @param      string|array    $ext_list     Allowed extensions, mixed sring with separated like jpg,doc,pdf or array
	 * @return     array
	 */
    function wdk_geo_get_locations($ip = NULL) {
        static $results = NULL;
        
        global $_SERVER;
        if ( empty( $ip ) ) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        if(isset($_GET['sw_kit']) || isset($_POST['sw_kit'])) {
            $ip = '212.15.177.3';
        }
       
        if($ip == '127.0.0.0') {
            return $results;
        }

        $results = array();
        // deprecated
        //$url = 'http://www.geoplugin.net/php.gp?ip='.$ip;
        $url = 'http://ip-api.com/json/'.$ip;

        if(isset($_COOKIE['wdk_geo_get_locations'])) {
            return unserialize(base64_decode($_COOKIE['wdk_geo_get_locations']));
        }

        $response = NULL;
        if ( function_exists('curl_init') ) {
                        
            //use cURL to fetch data
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_USERAGENT, 'geoPlugin PHP Class v1.0');
            $response = curl_exec($ch);
            curl_close ($ch);
        } else if(false){
            $request    = wp_remote_get( $url );
            $response = '';
    
            // request failed
            if ( is_wp_error( $request ) ) {
                $response = $request;
            }
            $code = (int) wp_remote_retrieve_response_code( $request );
    
            // make sure the fetch was successful
            if (empty($response) && $code == 200 ) {
                $response = wp_remote_retrieve_body( $request );
            } 
        }

        if( $response) {
            $response = json_decode($response, true);
            if(isset($response['city'])) {
                $results [] = trim(str_replace(array('City','of'),'',$response['city']));
            }

            if(isset($response['regionName'])) {
                $results [] = trim(str_replace(array('City','of'),'',$response['regionName']));
            }

            if(isset($response['country'])) {
                $results [] = trim(str_replace(array('City','of'),'',$response['country']));
            }

            setcookie( 'wdk_geo_get_locations', base64_encode(serialize($results)), time() + (HOUR_IN_SECONDS * 24 * 7), COOKIEPATH, '', is_ssl(), true );
        }

        return $results;
    }
}

if(!function_exists('wdk_geo_google_get_locations_by_gps')) {
    /**
	 * Get Locations Array By APi (GOOGLE).
	 *
	 * @param      string    $ip     ip address
	 * @param      string    $default     The default value, will be return if empty or no exists
	 * @param      string|array    $ext_list     Allowed extensions, mixed sring with separated like jpg,doc,pdf or array
	 * @return     array
	 */
    function wdk_geo_google_get_locations_by_gps($lat = NULL, $lng = NULL, $api_key = NULL) {
        static $results = NULL;
        
        if ( empty( $api_key ) ) {
            $api_key =  get_option('wdk_geo_google_api_key');
        }

        if(is_null($results)) {
            $results = array();
            $url = 'https://maps.googleapis.com/maps/api/geocode/json?latlng='.trim($lat).','.trim($lng).'&key='.$api_key;
            $request = wp_remote_get( $url );

            $response = '';
            // request failed
            if ( is_wp_error( $request ) ) {
                $response = $request;
            }

            $code = (int) wp_remote_retrieve_response_code( $request );

            // make sure the fetch was successful
            if (empty($response) && $code == 200 ) {
                $response = wp_remote_retrieve_body( $request );
                $data = json_decode($response);
                $status = $data->status;
                
                //if request status is successful
                if($status == "OK"){
                    //get address from json data
                    foreach ($data->results[0]->address_components as $value) {
                        if(in_array('street_number',$value->types)) continue;
                        if(in_array('postal_code',$value->types)) continue;
                        if(in_array('route',$value->types)) continue;

                        $results [] = trim(str_replace(array('City','of'),'',$value->long_name));
                    }
                }
            }
        }
       
        return $results;
    }
}


function wdk_geo_get_location_id($ip = NULL) {
    static $location_id = NULL;

    $res = wdk_geo_get_locations($ip);
    if(is_null($location_id)) {
        $location_id = false;
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('location_m');
        $location = NULL;
        while(!$location && current($res)) {
            $location = $Winter_MVC_WDK->location_m->get_by(array('location_title'=>current($res)), TRUE); 
            next($res);
        }
        if($location) {
            $location_id = $location->idlocation;
        }
    }
   
    return $location_id;

}

function wdk_geo_google_get_by_gps_location_id($lat = NULL, $lng = NULL, $api_key = NULL) {
    static $location_id = NULL;

    $res = wdk_geo_google_get_locations_by_gps($lat, $lng, $api_key);
    if(is_null($location_id)) {
        $location_id = false;
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('location_m');
        $location = NULL;
        while(!$location && current($res)) {
            $location = $Winter_MVC_WDK->location_m->get_by(array('location_title'=>current($res)), TRUE); 
            next($res);
        }
        if($location) {
            $location_id = $location->idlocation;
        }
    }
   
    return $location_id;

}


?>