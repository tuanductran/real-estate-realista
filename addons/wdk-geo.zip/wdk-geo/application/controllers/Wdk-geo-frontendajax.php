<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_geo_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function get_location_by_gps($output="", $atts=array(), $instance=NULL)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('location_m');

        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;
		$data['output'] = array(
			'location_name' => '',
			'location_id' => '',
		);

		if(empty($data['popup_text_error'])) {
			//if latitude and longitude are submitted
			if(!empty($_POST['latitude']) && !empty($_POST['longitude'])){
				//send request and receive json data by latitude and longitude
				$results = NULL;
				$location_id = NULL;
				if(get_option('wdk_geo_google_api_key')) {
					$results = wdk_geo_google_get_locations_by_gps($_POST['latitude'], $_POST['longitude']);

					$location = NULL;
					while(!$location && current($results)) {
						$location = $Winter_MVC_WDK->location_m->get_by(array('location_title'=>esc_sql(current($results))), TRUE); 
						next($results);
					}
					if($location) {
						$location_id = $location->idlocation;
					}
				}
			
				if(empty($results)) {
					$results = wdk_geo_get_locations();
				}
			
				if(empty($location_id)) {
					$location_id = wdk_geo_get_location_id();
				}

				if(!empty($results)) {
					reset($results);
					$data['output']['location_name'] = current($results);
					$data['output']['location_id'] = $location_id;
					$data['success'] = true;
				}

			} else if(wdk_get_option('wdk_geo_autodetect_by_ip_enable')) {
				$results = NULL;
				$location_id = NULL;
				$location_id = wdk_geo_get_location_id();
				$results = wdk_geo_get_locations();

				if(!empty($results)) {
					reset($results);
					$data['output']['location_name'] = current($results);
					$data['output']['location_id'] = $location_id;
					$data['success'] = true;
				}
			}
		}
		$this->output($data);
    }

     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
