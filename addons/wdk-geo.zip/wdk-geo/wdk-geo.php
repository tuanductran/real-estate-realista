<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Geo
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Geo
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-geo-coding.html
 * Description:       Based on geo coding by google detect location and try select from locations treefield if exists, otherwise put city name into smart search field
 * Version:           1.0.1
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-geo
 * Domain Path:       /languages
 * 
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_GEO_VERSION', '1.0.1' );
define( 'WDK_GEO_NAME', 'wdk-geo' );
define( 'WDK_GEO_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_GEO_URL', plugin_dir_url( __FILE__ ) );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-geo-activator.php
 */
function activate_wdk_geo() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-geo-activator.php';
	Wdk_Geo_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-geo-deactivator.php
 */
function deactivate_wdk_geo() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-geo-deactivator.php';
	Wdk_Geo_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_geo' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_geo' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-geo.php';

run_wdk_geo();

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wdk_geo() {

	$plugin = new Wdk_Geo();
	$plugin->run();
	
}
