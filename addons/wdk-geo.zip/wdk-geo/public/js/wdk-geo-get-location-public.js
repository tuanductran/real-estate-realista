(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

    $(function () {
		$(document).ready(function(){
			if(jQuery('.wdk-search-start').length) {
				if(navigator.geolocation){
					navigator.geolocation.getCurrentPosition(wdk_geo_showLocation, function(error) {
						wdk_geo_showLocation();
					});
				} else {
					wdk_geo_showLocation();
				}
			}
		});
    });

})(jQuery);

function wdk_geo_showLocation(position){
	var latitude,longitude,setCookie,getCookie;

	if(typeof position != 'undefined') {
		latitude = position.coords.latitude;
		longitude = position.coords.longitude;
	}

	var data = {};
	jQuery.extend( data, {
		"action": 'wdk_geo_public_action',
		"page": 'wdk_geo_frontendajax',
		"function": 'get_location_by_gps',
		"latitude": latitude,
		"longitude": longitude,
	});

	if(typeof wdk_geo_script_parameters.sw_kit !='undefined') {
		data['sw_kit'] = 1;
	}

	jQuery.post(wdk_geo_script_parameters.ajax_url, data, 
		function(data){
			
			if(data.popup_text_success)
				wdk_log_notify(data.popup_text_success);
				
			if(data.popup_text_error)
				wdk_log_notify(data.popup_text_error, 'error');
			
			if(data.success)
			{
				if(data.output.location_id) {
					if(jQuery('input[name="search_location"]').val() == '') {
						jQuery('input[name="search_location"]').val(data.output.location_id);
						jQuery('input[name="search_location"]').parent().find('.btn-group button:first-child').html(data.output.location_name);
						jQuery('input[name="search_location"]').parent().find('.list_items li[key="'+data.output.location_id+'"]').trigger('click');
					}

				} else if(data.output.location_name) {
					if(jQuery('input[name="field_search"]').val() == '') {
						jQuery('input[name="field_search"]').val(data.output.location_name);
					}
				}

				/* wdk pro feature ask */
				if(getCookie('wdk_geo_auto_search_confirmed') == '' && typeof wdk_geo_script_parameters.wdk_geo_coding_results_location !='undefined' && jQuery('.wdk-search-start').length) {
					if(data.output.location_name && (window.location.href.indexOf('field_') == -1 && window.location.href.indexOf('#results') == -1) ) {
						if (typeof jQuery.fn.confirm == 'function') {
							setCookie('wdk_geo_auto_search_confirmed', 'yes');
							jQuery.confirm({
								boxWidth: '400px',
								useBootstrap: false,
								title:  wdk_geo_script_parameters.text.title,
								content:  wdk_geo_script_parameters.text.auto_detected_location.replace('%1$s', data.output.location_name),
								buttons: {
									cancel: {
										text: wdk_geo_script_parameters.text.btn_cancel,
										action: function(){}
									},
									somethingElse: {
										text: wdk_geo_script_parameters.text.btn_success,
										btnClass: 'btn-blue activate-now',
										keys: ['enter', 'shift'],
										action: function(){
											jQuery('.wdk-search-start').first().trigger('click');
											return false;
										}
									}
								}
							});
						} else {
						}
					}
				}

			} else {
				
			}
	});

	setCookie = (cname, cvalue, exdays) => {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires="+d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}

	getCookie = (cname) => {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	};
}
