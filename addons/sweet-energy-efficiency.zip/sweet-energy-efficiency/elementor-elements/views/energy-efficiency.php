<div class="sweet-energy-efficiency-element" id="see_el_<?php echo esc_html($id_element);?>">
<?php
  echo do_shortcode('[see_graph id="'.$settings['widget_id'].'" wdk_field_id="'.$settings['wdk_field_id'].'"  value="'.$settings['value'].'"]');
?>
</div>

