<?php

// 1. Create a new WordPress plugin, and include the rapid-addon.php file.

/*
Plugin Name: WDK WP All Import
Description: XML Export, CSV/XML Import via popular Plugin Wp All Import and VIsual Fields Mapping.
Plugin URI: https://wpdirectorykit.com/plugins/wp-directory-import-export.html
Version: 1.0.1
Author: wpdirectorykit.com
Author URI: https://wpdirectorykit.com
Text Domain:       wdk-wp-all-import
Domain Path:       /languages

*  @fs_premium_only /premium_functions.php

*/

/*
if(!file_exists(plugin_dir_path( 'wpdirectorykit' ))) {
    return false;
}
*/

if(version_compare(phpversion(), '5.6.0', '<'))
{
    return false;  
}

include "rapid-addon.php";

require_once plugin_dir_path(__FILE__ ) . 'tgm-pa/configuration.php';

final class wdk_import_add_on {

    protected static $instance;

    protected $add_on;

    private $wdk_num_images = 5;

    static public function get_instance() {
        if ( self::$instance == NULL ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    protected function __construct() {

        // 2. Initialize your add-on.

        $this->add_on = new RapidAddon('WDK WP All Import Add-On', 'wdk_listings_addon');

        // 4. Register your import function.

        $this->add_on->set_import_function([ $this, 'wdk_listings_addon_import_function' ]);
        add_action( 'init', [ $this, 'init' ] );

        add_filter('pmxi_article_data', [ $this, 'wdk_pmxi_article_data' ], 10, 4);

        add_action( 'pmxi_delete_post', [ $this, 'wdk_postlistings_sync' ], 10, 1);

        add_filter( 'pmxi_article_data', array($this, 'my_pmxi_article_data'), 10, 4 );
        add_filter( 'is_xml_preprocess_enabled', array($this, 'roomble_is_xml_preprocess_enabled'), 10, 4 );
    }  
      
    function roomble_is_xml_preprocess_enabled( $is_enabled ) {
        return false;
    }

    function _generate_path_to_array_data($root_array, $path, $get_first = FALSE) {
        $output = '';
        
        if(stripos($path, ',') !== FALSE) {
            $path = substr($path, 0, stripos($path, ','));
        }
        $path = str_replace(array('{','}'),'', $path);
        $path = explode('/' ,$path);

        array_walk($path, function(&$item){$item = (substr($item, 0, stripos($item, '[') !== FALSE)) ? substr($item, 0, stripos($item, '[')) : $item;});

        $_data = $root_array;
        foreach ($path as $key) {
            if(is_object($_data))
                $_data = (array) $_data;
            if(isset($_data[$key])) {
                $_data = $_data[$key];
                
                if(is_object($_data))
                    $_data = (array) $_data;
                
                if($get_first && is_array($_data) && isset($_data[0]))
                    $_data = $_data[0];

                if(!next($path)) {
                    $output = $_data;
                }
            }
        }

        return $output;
    }

    function generate_value ($path, $data) {
        $output = '';
        $path_list = $path;
        $current_node = $data;
        foreach ($path as $key => $node) {
            unset($path_list[$key]);
            if(is_object($current_node))
                $current_node = (array) $current_node;
            if(isset($current_node[$node])) {
                $current_node = $current_node[$node];
                
                if(is_object($current_node)) {
                    
                    $current_node = (array) $current_node;
                 
                }

                if(is_array($current_node) && isset($current_node[0])) {
                    foreach ($current_node as $k => $n) {
                      $output .= $this->generate_value($path_list,$n);
                    }
                } else {
                    if(!next($path)) {
                        if(is_array($current_node) && isset($current_node[0])) {
                            $current_node = $current_node[0];
                        }
                    
                        if(!is_string($current_node))
                            $current_node = (string) $current_node;
                            
                        $output .= ', '.(string) $current_node;
                    }
                }
            }
        }

        return $output;
    }

    function object_to_array($obj) {
        if(is_object($obj)) $obj = (array) $obj;
        if(is_array($obj)) {
            $new = array();
            foreach($obj as $key => $val) {
                $new[$key] = $this->object_to_array($val);
            }
        }
        else $new = $obj;
        return $new;       
    }

    function my_pmxi_article_data( $articleData, $import, $post_to_update, $current_xml_node ) {
        $articleData['wdk_fields'] = array();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
        $Winter_MVC_WDK->model('field_m');

        $fields = $Winter_MVC_WDK->field_m->get();
        foreach($fields as $key => $field)
        {
            if( true || $field->field_type != 'SECTION') {

                /* if defiend get from fields list */
                if(!empty($import->options['wdk_listings_addon']['field_'.$field->idfield.'_fields_list_path']) &&
                    !empty($import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_path']) && 
                    !empty($import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_title']) && 
                    !empty($import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_key']) && 
                    !empty($import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_value'])) {

                    $fields_list = $this->_generate_path_to_array_data($current_xml_node, $import->options['wdk_listings_addon']['field_'.$field->idfield.'_fields_list_path']);
                    $field_title = $import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_key'];

                    /* get fields */
                    $xml_fields = $this->_generate_path_to_array_data($fields_list, $import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_path']);
                    foreach ($xml_fields as $xml_field) {
                        //$xml_field = $this->object_to_array($xml_field);
                        $xml_title = $this->_generate_path_to_array_data($xml_field, $import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_title']);
                        if(!is_string($xml_title))
                            $xml_title = (string) $xml_title;

                        if(trim($field_title) == trim($xml_title)) {

                            $xml_value = $this->_generate_path_to_array_data($xml_field, $import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_value'], TRUE);
                            
                            if(is_array($xml_value) && isset($xml_value[0]))
                                $xml_value = $xml_value[0];

                            if(!is_string($xml_value))
                                $xml_value = (string) $xml_value;

                            $output = '';
                            $path = $import->options['wdk_listings_addon']['field_'.$field->idfield.'_field_node_value'];
                            if(stripos($path, ',') !== FALSE) {
                                $path = substr($path, 0, stripos($path, ','));
                            }
                            $path = str_replace(array('{','}'),'', $path);
                            $path = explode('/' ,$path);
                    
                            array_walk($path, function(&$item){$item = (substr($item, 0, stripos($item, '[') !== FALSE)) ? substr($item, 0, stripos($item, '[')) : $item;});
                            $xml_value = $this->generate_value($path, $xml_field);
                            $articleData['wdk_fields']['field_'.$field->idfield] = trim($xml_value,',');
                        }
                    }
                }
            }
        }
        return $articleData;
    }
    
    public function init() {

        if(!function_exists('run_wpdirectorykit'))
            return FALSE;

        $this->define_fields();

        //6. Specify when your add-on runs.

        $this->add_on->disable_default_images();

        $this->add_on->run(array(
            "post_types" => array( "wdk-listing" ),
        ));
    
    }

    private function define_fields()
    {
        // 3. Add fields to your add-on.
        if (defined('WP_DEBUG') && true === WP_DEBUG) {
            ini_set('display_errors',1);
            ini_set('display_startup_errors',1);
            error_reporting(-1);
         }



        $this->add_on->add_field('address', 'Address', 'text');

        $this->add_on->add_options( 
                $this->add_on->add_field( 'property_price', 'Property Price', 'text', null, 'Only digits, example: 435000' ),
                'Price Settings', 
                array(
                        $this->add_on->add_field( 'property_price_postfix', 'Price Postfix', 'text', null, 'Example: Per Month' ),
                        $this->add_on->add_field( 'property_price_currency', 'Currency Symbol', 'text', null, 'Example: $, or €' )
                )
        );

        $this->add_on->add_field(
            'enable_autodetect_gps', 'Autodetect coordinates if not entered address',
            'radio',
            array(
                '0' => 'Not Enable',
                '1' => 'Enable'
            )
        );

        $this->add_on->add_field('lat', 'Gps LAT', 'text');
        $this->add_on->add_field('lng', 'Gps LNG', 'text');

        //$this->add_on->add_field('user_id', 'Agent ID', 'text');

        $this->add_on->add_field(
            'field_agent_enable',
            'Agent', 
            'radio', 
            array(
                    'no' => array(
                            'No'
                    ),
                    'yes' => array(
                            'Agent Fields',
                            $this->add_on->add_field( 'field_agent_name', 'Agent Name', 'text' ),
                            $this->add_on->add_field( 'field_agent_phone', 'Agent Phone', 'text' ),
                            $this->add_on->add_field( 'field_agent_email', 'Agent Email', 'text' ),
                            $this->add_on->add_field( 'field_agent_image', 'Agent Image', 'text' ),
                            $this->add_on->add_field( 'field_agent_id', 'Agent ID', 'text' ),
                    )
            )
        );


        $this->add_on->add_field('location_id', 'Location (ID or Name)', 'text');
        $this->add_on->add_field('category_id', 'Category (ID or Name)', 'text');
        
        //$this->add_on->add_field('transition_id', 'Transition id (ID from external system, because of update)', 'text');

        $this->add_on->add_field(
            'is_featured', 'Is featured',
            'radio',
            array(
                '0' => 'Not selected',
                '1' => 'Selected'
            )
        );

        $this->add_on->add_field(
            'is_activated', 'Is activated',
            'radio',
            array(
                '1' => 'Selected',
                '0' => 'Not selected'
            )
        );

        $this->add_on->add_field(
            'is_approved', 'Is approved',
            'radio',
            array(
                '1' => 'Selected',
                '0' => 'Not selected'
            )
        );
        
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK = new MVC_Loader(WPDIRECTORYKIT_PATH);
        $Winter_MVC_WDK->model('field_m');

        $fields = $Winter_MVC_WDK->field_m->get();

        //var_dump($fields[0]);
        $this->add_on->add_options(
            null,
            'Price Settings', 
            array(
                    $this->add_on->add_field( 'property_price_postfix', 'Price Postfix', 'text', null, 'Example: Per Month' )
            )
        );


        foreach ($Winter_MVC_WDK->field_m->get_fields_section() as $key => $section_data) {
                $fields = array();
                $fields[] = 'Field List';
                foreach ($section_data['fields'] as $field) {
                    $fields [] = $this->add_on->add_options(
                        $this->add_on->add_field( 'field_'.$field->idfield,  $field->field_label.' '.$field->prefix.' '.$field->suffix, 'text' ),
                        'From Fields List', 
                        array(
                            $this->add_on->add_field( 'field_'.$field->idfield.'_fields_list_path', 'Fields Path', 'text' ),
                            $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_path', 'Field Node', 'text' ),
                            $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_title', 'Field Title node (in field node)', 'text' ),
                            $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_value', 'Field Value node (in field node)', 'text' ),
                            $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_key', 'Field name from title node (we use like key)', 'text' ),
                        )
                    );
                }

                $this->add_on->add_field(
                    'section_'.wmvc_show_data('idfield', $section_data),
                    'Section'. ' '.wmvc_show_data('field_label', $section_data),
                    'radio', 
                    array(
                            'search_by_address' => array(
                                    'Import section (Only for checkboxes)',
                                    $this->add_on->add_options(
                                        $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data),  'Path', 'text' ),
                                        'From Fields List', 
                                        array(
                                            $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data).'_fields_list_path', 'Fields Path', 'text' ),
                                            $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data).'_field_node_path', 'Field Node', 'text' ),
                                            $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data).'_field_node_title', 'Field Title node (in field node)', 'text' ),
                                            $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data).'_field_node_value', 'Field Value node (in field node)', 'text' ),
                                            $this->add_on->add_field( 'field_'.wmvc_show_data('idfield', $section_data).'_field_node_key', 'Field name from title node (we use like key)', 'text' ),
                                        )
                                    )
                            ), // end Search by Address radio field
                            'fields_list' => $fields
                    )
            );
        }

        if(false)
        foreach($fields as $key => $field)
        {
            if( false && $field->field_type != 'SECTION') {
                $this->add_on->add_field(
                    'field_'.$field->idfield,
                    $field->field_label.' '.$field->prefix.' '.$field->suffix,
                    'radio', 
                    array(
                            'field_key' => array(
                                    'Path',
                                    $this->add_on->add_field( 'property_latitude', 'field name', 'text' ),
                            ),
                            'field_by_category' => array(
                                    'From Fields List',
                                    $this->add_on->add_field( 'fields_path', 'Fields Path', 'text' ),
                                    $this->add_on->add_field( 'field_node', 'Field Node', 'text' ),
                                    $this->add_on->add_field( 'field_node', 'Field Title node (in field node)', 'text' ),
                                    $this->add_on->add_field( 'field_node', 'Field Value node (in field node)', 'text' ),
                                    $this->add_on->add_field( 'field_key', 'Field name in xml (we use like key)', 'text' ),
                            )
                    )
                );
            }

            if( $field->field_type != 'SECTION') {

                $this->add_on->add_options(
                    $this->add_on->add_field( 'field_'.$field->idfield,  $field->field_label.' '.$field->prefix.' '.$field->suffix, 'text' ),
                    'From Fields List', 
                    array(
                        $this->add_on->add_field( 'field_'.$field->idfield.'_fields_list_path', 'Fields Path', 'text' ),
                        $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_path', 'Field Node', 'text' ),
                        $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_title', 'Field Title node (in field node)', 'text' ),
                        $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_value', 'Field Value node (in field node)', 'text' ),
                        $this->add_on->add_field( 'field_'.$field->idfield.'_field_node_key', 'Field name from title node (we use like key)', 'text' ),
                    )
                );
            }
        }

        // For n images

        $this->add_on->add_field('gallery_0', 'Gallery image 0 (also front image), complete URL required', 'text');

        for($i=1;$i<$this->wdk_num_images;$i++)
        {
            $this->add_on->add_field('gallery_'.$i, 'Gallery image '.$i.', complete URL required', 'text');
        }

        $this->add_on->add_field('gallery_list', 'Multiple gallery images in same field comma separated, complete URL required', 'text');

        $this->add_on->add_field(
            'remove_images', 'Remove images in updated listing',
            'radio',
            array(
                '0' => 'No',
                '1' => 'Yes remove images even if used on other places'
            )
        );
    }

    public function wdk_pmxi_article_data( $articleData, $import, $post_to_update, $current_xml_node ) {
        // Do something with the article data.
       
        $articleData['post_title'] = str_replace('\n', '<br />', $articleData['post_title']);
        $articleData['post_title'] = str_replace('\r', '', $articleData['post_title']);

        $articleData['post_excerpt'] = str_replace('\n', '<br />', $articleData['post_excerpt']);
        $articleData['post_excerpt'] = str_replace('\r', '', $articleData['post_excerpt']);

        $articleData['post_name'] = str_replace('\n', '<br />', $articleData['post_name']);
        $articleData['post_name'] = str_replace('\r', '', $articleData['post_name']);

        $articleData['post_content'] = str_replace('\n', '<br />', $articleData['post_content']);
        $articleData['post_content'] = str_replace('\r', '', $articleData['post_content']);

        return $articleData;
    }


    //5. Write your import function.

    public function wdk_listings_addon_import_function( $post_id, $data, $import_options, $article )
    {

       
        /*

        array(68) { ["address"]=> string(9) "Retro old" ["lat"]=> string(0) "" ["lng"]=> string(0) "" ["location_id"]=> string(0) "" ["category_id"]=> string(0) "" ["transition_id"]=> string(0) "" ["is_featured"]=> string(1) "0" ["is_activated"]=> string(1) "1" ["field_2"]=> string(272) "

        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vulputate nec neque gravida rhoncus. Donec sit amet blandit mauris, sed bibendum risus.
        " ["field_3"]=> string(0) "" ["field_5"]=> string(0) "" ["field_6"]=> string(0) "" ["field_7"]=> string(0) "" ["field_8"]=> string(0) "" ["field_9"]=> string(0) "" ["field_10"]=> string(0) "" ["field_11"]=> string(0) "" ["field_12"]=> string(0) "" ["field_13"]=> string(0) "" ["field_14"]=> string(0) "" ["field_15"]=> string(0) "" ["field_16"]=> string(0) "" ["field_17"]=> string(0) "" ["field_19"]=> stri

        */

        //var_dump($article);

        //add_filter('intermediate_image_sizes_advanced', array($this, 'wdk_images_convert_disable'));

        global $Winter_MVC_WDK;

        //if(empty($Winter_MVC_WDK))
        //    $Winter_MVC_WDK = wdk_get_instance();

        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('listingfield_m');
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('field_m');

        $listing_db_data = $Winter_MVC_WDK->listing_m->get($post_id, TRUE);
        $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($post_id, TRUE);
        $listingusers_db_data = $Winter_MVC_WDK->listingusers_m->get($post_id, TRUE);

        $Winter_MVC_WDK->db->where(array('field_type !='=> 'SECTION'));
        $listing_fields = $Winter_MVC_WDK->field_m->get();

        // Save our main listing data
        $listing_data = array('post_id' => $post_id);
        
        $listing_data_fields = array('address', 'listing_images');
        foreach($listing_data_fields as $field_name)
        {
            if(!empty($data[$field_name]))
                $listing_data[$field_name] = esc_sql($data[$field_name]);
        }

        $listing_data_fields = array('lat', 'lng', 'is_featured', 'is_activated', 'is_approved');
        foreach($listing_data_fields as $field_name)
        {
            if((!empty($data[$field_name]) && is_numeric($data[$field_name])) || $data[$field_name] == 0)
                $listing_data[$field_name] = esc_sql($data[$field_name]);
        }

        if($data['enable_autodetect_gps'] == 1 && empty( $listing_data['lat']) && empty( $listing_data['lng']) && !empty($listing_data['address'])) {
           
            $coordinates = NULL;

            /* if enable google try use google api for detect gps */
            if(get_option('wdk_import_google_api_enable') && wdk_get_option('wdk_geo_google_api_key')) {
                $coordinates = wdk_get_gps_google($listing_data['address']);
            } 
            
            /* if gps not detected, try free api */
            if(empty($coordinates)) {
                $coordinates = wdk_get_gps($listing_data['address']);
            }

            if(!empty($coordinates)) {
                $listing_data['lat'] = $coordinates['lat'];
                $listing_data['lng'] = $coordinates['lng'];
            }
        }

        if(!empty($data['field_agent_enable']) && $data['field_agent_enable'] == 'yes') {
                
            if(!empty($data['field_agent_id'])) {
                $listing_data['user_id_editor'] = intval($data['field_agent_id']);
            } elseif(!empty($data['field_agent_name']) || !empty($data['field_agent_email'])) {

                // Search for users
                $search_text = (!empty($data['field_agent_email']) ) ? $data['field_agent_email'] : $data['field_agent_name'];
                $args = array(
                    'search'         => '*' . esc_attr($search_text) . '*',
                    'search_columns' => array( 'user_login', 'user_email','user_nicename','display_name' ),
                );
                $users = get_users( $args );

                if(!empty($users)) {
                    $listing_data['user_id_editor'] = $users[0]->ID;
                } else {
                    /* try create */
                    $username = (!empty($data['field_agent_name']) ) ? $data['field_agent_name'] : $data['field_agent_email'];

                    $domain = '';
                    $url = site_url();
                    $parsed_url = parse_url($url);
                    if (isset($parsed_url['host'])) {
                        $domain = $parsed_url['host'];
                    } 

                    $email_address = (!empty($data['field_agent_email']) ) ? $data['field_agent_email'] : wdk_export_xml_slug($username).'@'.$domain;

                    $password = wp_generate_password();
            
                    $user_id = wp_create_user( $username, $password, $email_address );
            
                    if(is_intval($user_id)){
                        // Set the nickname
                        wp_update_user(
                            array(
                                'ID'          =>    $user_id,
                                'nickname'    =>    $username
                            )
                        );
            
                        $user = new WP_User( $user_id );
                        $user->set_role('wdk_agent');
            
                        wp_update_user( array ('ID' => $user_id, 'display_name' => esc_html( $username ) ) );

                        if(!empty($data['field_agent_phone'])) {
                            wp_update_user( array ('ID' => $user_id, 'phone' => esc_html( $data['field_agent_phone'] ) ) );
                        }

                        if(!empty($data['field_agent_image'])) {
                            $profile_picture_id = wmvc_add_wp_image($data['field_agent_image']);
                            if($profile_picture_id)
                                update_user_meta( $user_id, 'profile_picture_id', (int) $profile_picture_id );
                        }
                        
                        $listing_data['user_id_editor'] = $user_id;

                    } elseif($user = get_user_by( 'email', $email_address)) {
                        $listing_data['user_id_editor'] = $users[0]->ID;
                    }
                }
            }
        }

        // category insert

        if(!empty($data['category_id']))
        {
            if(is_numeric($data['category_id']))
            {
                $listing_data['category_id'] = $data['category_id'];
            }
            else
            {
                if(strpos($data['category_id'], ',') !== FALSE)
                {
                    //array/list detected, wdk support only one category at time
                    $categories = explode(',', $data['category_id']);

                    $data['category_id'] = trim($categories[0]);
                }

                // logic to get category by name or create one if not exists
                $category_found = $Winter_MVC_WDK->category_m->get_by(array('category_title' => $data['category_id']), TRUE);

                if(!empty($category_found))
                {
                    // if found, define id from found category
                    $listing_data['category_id'] = $category_found->idcategory;
                }
                else
                {
                    // if not found then add define id from new added
                    $id_inserted = $Winter_MVC_WDK->category_m->insert(array('category_title' => $data['category_id']), NULL);

                    $listing_data['category_id'] = $id_inserted;

                    $this->add_on->log('Creating NEW Category #'.$id_inserted.', '.$data['category_id']);
                }
            }
        }

        // location insert

        if(!empty($data['location_id']))
        {
            if(is_numeric($data['location_id']))
            {
                $listing_data['location_id'] = $data['location_id'];
            }
            else
            {
                if(strpos($data['location_id'], ',') !== FALSE)
                {
                    //array/list detected, wdk support only one category at time
                    $locations = explode(',', $data['location_id']);

                    $data['location_id'] = trim($locations[0]);
                }

                // logic to get location by name or create one if not exists
                $location_found = $Winter_MVC_WDK->location_m->get_by(array('location_title' => $data['location_id']), TRUE);

                if(!empty($location_found))
                {
                    // if found, define id from found location
                    $listing_data['location_id'] = $location_found->idlocation;
                }
                else
                {
                    // if not found then add define id from new added
                    $id_inserted = $Winter_MVC_WDK->location_m->insert(array('location_title' => $data['location_id'], 'parent_id' => 0), NULL);

                    $listing_data['location_id'] = $id_inserted;

                    $this->add_on->log('Creating NEW Location #'.$id_inserted.', '.$data['location_id']);
                }
            }
        }

        // Remove images from updated listings

        if(!empty($listing_db_data) &&
        !empty($listing_db_data->listing_images) && 
        isset($data['remove_images'] ) && 
        $data['remove_images'] == '1')
        {
            // remove old images
            $image_ids = explode(',', $listing_db_data->listing_images);

            foreach($image_ids as $image_id)
            {
                $this->add_on->log('Removing Image ID#: '.$image_id);
                //$this->add_on->log('Removing Image URL#: '.wp_get_attachment_image_url( $image_id));
                
                wp_delete_attachment($image_id, TRUE);
            }
        }
        // images upload

        $attachment_files = array();
       
        for($i=0;$i<$this->wdk_num_images;$i++)
        {
            if(!empty($data['gallery_'.$i]))
                if(substr($data['gallery_'.$i], 0, 4) == 'http')
                {

                    /*
                    // consider skip uplaoding if image with same filename exists
                    // wdk_does_file_exists($filename)
                    $image_file_name = substr($data['gallery_'.$i], strrpos($data['gallery_'.$i], '/')+1);
                    //$this->add_on->log('Searching for filename: '.$image_file_name);

                    //$this->add_on->log('XXXXXXXXXSearching for filename: '.$listing_db_data->listing_images);
                    //$this->add_on->log('XXXXXXXXXXSearching for filename ID: '.$exists_file_id);

                    $exists_file_id = wdk_does_file_exists($image_file_name);
                    if(!empty($listing_db_data) && 
                        $exists_file_id > 0 && 
                        strpos($listing_db_data->listing_images, $exists_file_id) !== FALSE)
                    {
                        $this->add_on->log('Image Filename Found, skip upload: '.$image_file_name);
                        $attachment_files[] = $exists_file_id;
                    }
                    else
                    {
                        
                    }*/

                    
                    $pattern = '/(https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp|bmp))/';
                    preg_match($pattern, $data['gallery_'.$i], $matches);
                    if (!empty($matches[0])) {
                        $this->add_on->log('Uploading image: '.$matches[0]);
                        $insert_img_id = wdk_insert_attachment_from_url( $matches[0], $post_id);
                        $attachment_files[] = $insert_img_id;
                    } 

                }   
        }

        if(!empty($data['gallery_list']))
        { 

            $gallery_list = explode(',', $data['gallery_list']);

            $num_images_imported = 0;

            foreach($gallery_list as $gallery_image_url)
            {
                $gallery_image_url = trim($gallery_image_url);
                
                if($num_images_imported >= $this->wdk_num_images)break;

                if(substr($gallery_image_url, 0, 4) == 'http')
                {
                    $this->add_on->log('Uploading image: '.$gallery_image_url);
                    $attachment_files[] = wdk_insert_attachment_from_url($gallery_image_url, $post_id);
                    $num_images_imported++;
                }
            }
        }

        if(count($attachment_files) > 0)
        {
            $listing_data['listing_images'] = join(',', $attachment_files);

            $this->add_on->log('Inserting images ID#: '.$listing_data['listing_images']);

            // also update image paths for caching/reduce queries
            // listing_images_path_medium, listing_images_path

            $listing_images_paths_array = array();
            $listing_images_paths_array_large = array();
            foreach($attachment_files as $image_id)
            {
                $parsed = parse_url( wp_get_attachment_url($image_id) );
                
                $parsed2 = parse_url(  wp_get_attachment_image_url($image_id, 'large') );
    
                $listing_images_paths_array[] = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
                $listing_images_paths_array_large[] = substr($parsed2['path'], strpos($parsed2['path'], 'uploads/')+8);
            }
    
            if(count($listing_images_paths_array) > 0) // originals goes to path
                $listing_data['listing_images_path'] = join(',', $listing_images_paths_array);
    
            if(count($listing_images_paths_array_large) > 0) // large goes to medium
                $listing_data['listing_images_path_medium'] = join(',', $listing_images_paths_array_large);
    
        }

        foreach($listing_data as $key=>$val)
        {
            $listing_data[$key] = str_replace('\n', '<br />', $listing_data[$key]);
            $listing_data[$key] = str_replace('\r', '', $listing_data[$key]);
            $listing_data[$key] = esc_sql($listing_data[$key]);
        }

        if(empty($listing_db_data))
        {
            $Winter_MVC_WDK->listing_m->insert($listing_data, NULL);
        }
        else
        {
            $Winter_MVC_WDK->listing_m->insert($listing_data, $post_id);
        }

        // insert users/agents

        if(!empty($data['user_id']) && is_numeric($data['user_id']))
        {
            $Winter_MVC_WDK->listingusers_m->delete_where(array('post_id' => $post_id));
            $Winter_MVC_WDK->listingusers_m->insert(array('post_id' => $post_id, 'user_id' => $data['user_id']), NULL);
        }
            
        // Save dynamic fields data

        $data['post_id'] = $post_id;
        $insert_res = NULL;

        foreach($listing_fields as $key => $field)
        {
            if(isset($article['wdk_fields']['field_'.$field->idfield])) {

                if($field->field_type == "CHECKBOX") {
                    $values = ','.trim($article['wdk_fields']['field_'.$field->idfield]).',';

                    if(stripos($values, ','.$field->field_label.',') !== FALSE) {
                        $data['field_'.$field->idfield] = 1;
                    }
                    elseif(stripos($values, ', '.$field->field_label.',') !== FALSE) {
                        $data['field_'.$field->idfield] = 1;
                    } else {
                        $data['field_'.$field->idfield] = $article['wdk_fields']['field_'.$field->idfield];
                    }
                } else {
                    $data['field_'.$field->idfield] = $article['wdk_fields']['field_'.$field->idfield];
                }
            }
        }

        foreach ($Winter_MVC_WDK->field_m->get_fields_section() as $key => $section_data) {

            if(isset($article['wdk_fields']['field_'.wmvc_show_data('idfield', $section_data)])) {
                $values = ','.trim($article['wdk_fields']['field_'.wmvc_show_data('idfield', $section_data)]).',';

                foreach ($section_data['fields'] as $field) {
                    if(stripos($values, ','.$field->field_label.',') !== FALSE) {
                        $data['field_'.$field->idfield] = 1;
                    }
                    if(stripos($values, ', '.$field->field_label.',') !== FALSE) {
                        $data['field_'.$field->idfield] = 1;
                    }
                 
                }

            }
        }

        foreach($data as $key=>$val)
        {
            $data[$key] = str_replace('\n', '<br />', $data[$key]);
            $data[$key] = str_replace('\r', '', $data[$key]);
            $data[$key] = esc_sql($data[$key]);
        }
     
        if(empty($listingfield_db_data))
        {
            $insert_res = $Winter_MVC_WDK->listingfield_m->insert_custom_fields($listing_fields, $data, NULL);
        }
        else
        {
            $insert_res = $Winter_MVC_WDK->listingfield_m->insert_custom_fields($listing_fields, $data, $post_id);
        }

        if(empty($insert_res))
        {
            $this->add_on->log('Error when inserting custom fields listing data');
            $this->add_on->log($Winter_MVC_WDK->db->last_query());
        }
        else
        {
            $this->add_on->log('Custom fields data inserted for listing Post #'.$post_id);
        }
    }

    public function wdk_postlistings_sync( $ids ) {

    }
/*
    private function wdk_images_convert_disable($sizes) {
        unset($sizes['thumb']);
        unset($sizes['thumbnail']);
        unset($sizes['medium']);
        unset($sizes['large']);
        unset($sizes['medium_large']);
        unset($sizes['big_image_size_threshold']);
        unset($sizes['post-thumbnail']);
        unset($sizes['1536x1536']);
        unset($sizes['nexproperty-footer-thumbnail']);
        unset($sizes['nexproperty-slider-thumbnail']);
        unset($sizes['nexproperty-post-thumbnail']);
        unset($sizes['woocommerce_thumbnail']);
        unset($sizes['woocommerce_single']);
        unset($sizes['woocommerce_gallery_thumbnail']);
        unset($sizes['shop_single']);
        unset($sizes['shop_thumbnail']);
        return $sizes;
    }*/
}

function wdk_does_file_exists($filename) {
    global $wpdb;
    
    return intval( $wpdb->get_var( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_value LIKE '%/$filename'" ) );
}

// Export features

function wdk_export_xml() {
    add_submenu_page('tools.php', 
                       esc_html__('Export WDK Listings', 'wdk-wp-all-import'), esc_html__('Export WDK Listings', 'wdk-wp-all-import'), 'manage_options', 'wdk-export-xml-content', 'wdk_export_xml_content');
}

function wdk_export_xml_content() {
    
    global $Winter_MVC_WDK;

    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('listingfield_m');
    $Winter_MVC_WDK->model('listingusers_m');
    $Winter_MVC_WDK->model('category_m');
    $Winter_MVC_WDK->model('location_m');

    $Winter_MVC_WDK->load_helper('basic');
    $Winter_MVC_WDK->load_helper('listing');

    $export_limit = 1000;
    if(isset($_GET['export_limit']))
        $export_limit = sanitize_key($_GET['export_limit']);

    $export_offset = 0;
    if(isset($_GET['export_offset']))
        $export_offset = sanitize_key($_GET['export_offset']);

    $listing_db_data = $Winter_MVC_WDK->listing_m->get_pagination($export_limit, $export_offset);

    ob_clean();
    ob_start();
    header('Pragma: no-cache');
    header('Content-Disposition: attachment; filename="wdk_listings_export_'.$export_offset.'-'.($export_offset+$export_limit).'.xml"');
    header('Cache-Control: no-store, no-cache');
    header('Content-type: text/xml');

    echo '<?xml version="1.0"?>';
    echo '<catalog>';

    foreach($listing_db_data as $listing_object)
    {
        $listing_array = (array) $listing_object;

        echo '<listing id="'.$listing_array['idlisting'].'">';
        foreach($listing_array as $key => $val)
        {
            if(!empty($val))
            {
                echo "<$key><![CDATA[$val]]></$key>";
            }
        }

        if(!empty($listing_array['category_id']))
        {
            $category = $Winter_MVC_WDK->category_m->get($listing_array['category_id'], TRUE);

            echo "<category_name>".$category->category_title."</category_name>";
        }

        if(!empty($listing_array['location_id']))
        {
            $location = $Winter_MVC_WDK->location_m->get($listing_array['location_id'], TRUE);

            echo "<location_name>".$location->location_title."</location_name>";
        }

        if(!empty($listing_array['listing_images']))
        {
            echo "<images>";
            
            $images = wdk_listing_images($listing_array);
            foreach($images as $image_src)
            {
                echo "<image_src>$image_src</image_src>";
            }

            echo "</images>";
        }

        echo '</listing>';
    }

    echo '</catalog>';

    exit();
}

if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    wdk_import_add_on::get_instance();

    add_action('admin_menu', 'wdk_export_xml');
}

if (! function_exists('wdk_export_xml_slug'))
{
	function wdk_export_xml_slug($str, $separator = '_', $lowercase = TRUE)
	{
		
        $str = str_replace(' ', $separator, $str);
		$search = ' ';
        $replace = '_';

		$trans = array(
						$search								=> $replace,
						"\s+"								=> $replace,
						"[^a-z0-9".$replace.$separator."]"		=> '',
						$replace."+"						=> $replace,
						$replace."$"						=> '',
						"^".$replace						=> ''
					   );
        
        // For Croatia
		$str = str_replace(array('č','ć','ž','š','đ', 'Č','Ć','Ž','Š','Đ'), 
						   array('c','c','z','s','d', 'c','c','z','s','d'), $str);
                           
        // For Turkish
		$str = str_replace(array('ş','Ş','ı','İ','ğ','Ğ','Ü','ü','Ö','ö','ç','Ç'),
						   array('s','s','i','i','g','g','u','u','o','o','c','c'), $str);  
        
        // Russian alphabet
		$str = str_replace(array('А','Б','В','Г','Д','Е','Ё','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ъ','Ы','Ь','Э','Ю','Я'),
						   array('a','b','v','g','d','e','e','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','c','ch','sh','sh','','y','','e','yu','ya'), $str);
        $str = str_replace(array('а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я'),
						   array('a','b','v','g','d','e','e','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','c','ch','sh','sh','','y','','e','yu','ya'), $str);
        
        // Ukrainian alphabet
       	$str = str_replace(array('Ґ','Є','І','Ї'),
						   array('G','E','I','I'), $str);
        $str = str_replace(array('ґ','є','і','ї'),
						   array('g','e','i','i'), $str);
        // Symbols
        $str = str_replace(array("  ","’","–",'«','»','№','„','”'),
						   array("","","-",'','','no','',''), $str);
        
        // Alphabets Czech Croatian Turkish and other
        $str = str_replace(array('Á','Ä','Ď','É','Ě','Ë','Í','Ň','Ń','Ó','Ŕ','Ř','Ť','Ú','Ů','Ý','Ź','Č','Ć','Ž','Š','Đ','Ş','İ','Ğ','Ü','Ö','Ç'),
						   array('a','a','d','e','e','e','i','n','n','o','r','r','t','u','u','y','z','c','c','z','s','d','s','i','g','u','o','c'), $str);
        $str = str_replace(array('á','ä','ď','é','ě','ë','í','ň','ń','ó','ŕ','ř','ť','ú','ů','ý','ź','č','ć','ž','š','đ','ş','ı','ğ','ü','ö','ç'),
						   array('a','a','d','e','e','e','i','n','n','o','r','r','t','u','u','y','z','c','c','z','s','d','s','i','g','u','o','c'), $str);

        // For french
		$str = str_replace(array('â','é','è','û','ê', 'à','Â','ç','ï','î','ä','î'), 
						   array('a','e','e','u','e', 'a','c','c','i','î','a','î'), $str);
        
        $str = strip_tags(strtolower($str));

		
		foreach ($trans as $key => $val)
		{
			$str = preg_replace("#".$key."#", $val, $str);
		}
	
		return trim(stripslashes($str));
	}
}
?>