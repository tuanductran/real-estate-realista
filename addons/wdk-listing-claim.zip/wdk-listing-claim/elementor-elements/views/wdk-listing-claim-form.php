<?php
/**
 * The template for Element Listing Claim Form
 * This is the template that elementor element button and form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-listing-claim-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-listing-claim-form" id="wdk_listing_claim">
        <?php if($claims_status == 'added'):?>
            <p class="wdk_alert wdk_alert-success"><?php echo esc_html__('Thanks, for your claim!', 'wdk-listing-claim');?></p>
        <?php else:?>
            <?php if(!is_user_logged_in()):?>
                <a href="<?php echo esc_url(wdk_login_url(wdk_current_url(), esc_html__('Please login for Claim Listing', 'wdk-listing-claim')));?>" class="wdk-field_toggle_claim noevent promise_link">
                    <?php if(wmvc_show_data('link_icon_position', $settings) == 'left') :?>
                        <span class="fas fa-exclamation-triangle"></span> 
                    <?php endif;?>
                    <?php echo esc_html__('Take Ownership / Claim Listing', 'wdk-listing-claim'); ?>
                    <?php if(wmvc_show_data('link_icon_position', $settings) == 'right') :?>
                        <span class="fas fa-exclamation-triangle"></span> 
                    <?php endif;?>
                </a>
            <?php else:?>
                <a href="#" data-wdk-toggle="modal" data-wdk-target="#listing_claim" class="wdk-field_toggle_claim clear_event">
                    <?php if(wmvc_show_data('link_icon_position', $settings) == 'left') :?>
                        <span class="fas fa-exclamation-triangle"></span> 
                    <?php endif;?>
                    <?php echo esc_html(wmvc_show_data('field_toggle',$settings));?>
                    <?php if(wmvc_show_data('link_icon_position', $settings) == 'right') :?>
                        <span class="fas fa-exclamation-triangle"></span> 
                    <?php endif;?>
                </a>
            <?php endif;?>
            
            <div class="wdk-modal wkd-fade" id="listing_claim" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-notice">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?php echo esc_html__('Claim Listing', 'wdk-listing-claim'); ?>
                            </h5>
                            <button type="button" class="close" data-wdk-dismiss="modal" aria-hidden="true">
                                <span class="dashicons dashicons-no-alt"></span>
                            </button>
                        </div>
                        <div class="modal-body">
                        <div class="wdk-listing-claim-box" <?php if(false && !isset($_POST[$id_element.'_listingclaim_form'])):?> style="display: none" <?php endif;?>>
                            <?php
                                $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                            ?>
                            <form id="" action="<?php echo esc_url($current_url);?>#wdk_listing_claim" id="wdk_reviews_form" method="post" class="wdk-listing-claim wdk-listing-claim-ajax">    
                                <div class="alert_box">
                                    <?php
                                        if($validation_messages) {
                                            $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-listing-claim'));
                                        }
                                    ?>
                                </div>
                                <div class="config" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></div>
                                <input type="hidden" name="post_id" value="<?php echo esc_attr($post_id);?>"/>
                                <input type="hidden" value="" name="<?php echo esc_html($id_element);?>_listingclaim_form" id="<?php echo esc_html($id_element);?>_listingclaim_form" value="1" class="wdk-control">
                                <div class="wdk-row">
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_name"><?php echo esc_html(wmvc_show_data('field_name_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="name" id="<?php echo esc_html($id_element);?>_name" placeholder="<?php echo esc_html(wmvc_show_data('field_name_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_email"><?php echo esc_html(wmvc_show_data('field_email_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="email" value="" name="email" id="<?php echo esc_html($id_element);?>_email" placeholder="<?php echo esc_html(wmvc_show_data('field_email_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wdk-row">
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_phone"><?php echo esc_html(wmvc_show_data('field_phone_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="phone" id="<?php echo esc_html($id_element);?>_phone" placeholder="<?php echo esc_html(wmvc_show_data('field_phone_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_address"><?php echo esc_html(wmvc_show_data('field_address_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="address" id="<?php echo esc_html($id_element);?>_address" placeholder="<?php echo esc_html(wmvc_show_data('field_address_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wdk-row">
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_city"><?php echo esc_html(wmvc_show_data('field_city_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="city" id="<?php echo esc_html($id_element);?>_city" placeholder="<?php echo esc_html(wmvc_show_data('field_city_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_country"><?php echo esc_html(wmvc_show_data('field_country_label',$settings));?></label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="country" id="<?php echo esc_html($id_element);?>_country" placeholder="<?php echo esc_html(wmvc_show_data('field_country_placeholder',$settings));?>" class="wdk-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wdk-form-group">
                                    <label for="<?php echo esc_html($id_element);?>_message"><?php echo esc_html(wmvc_show_data('field_message_label',$settings));?></label>
                                    <div class="input">
                                        <textarea required="required" type="text" value="" row="3" name="message" id="<?php echo esc_html($id_element);?>_message" placeholder="<?php echo esc_html(wmvc_show_data('field_message_placeholder',$settings));?>" class="wdk-control"></textarea>
                                    </div>
                                </div>
                                <?php if(wmvc_show_data('term_hide',$settings) !='true'):?>
                                <div class="wdk-form-group">
                                    <div class="input">
                                        <label for="<?php echo esc_html($id_element);?>_term" class='term'>
                                            <input required="required" type="checkbox" value="1" name="term" id="<?php echo esc_html($id_element);?>_term" class="wdk-control">
                                            <?php if(wmvc_show_data('term_link', $settings) && wmvc_show_data('term_link', $settings) !='#'):?>
                                            <a href="<?php echo esc_html(wmvc_show_data('term_link', $settings));?>">
                                                <?php echo esc_html(wmvc_show_data('term_label', $settings));?>
                                            </a>
                                            <?php else:?>
                                                <?php echo esc_html(wmvc_show_data('term_label', $settings));?>
                                            <?php endif;?>
                                        </label>
                                    </div>
                                </div>
                                <?php endif;?>
                                <?php
                                if(
                                    (get_option('wdk_listing_claim_recaptcha_site_key') && get_option('wdk_listing_claim_recaptcha_secret_key'))
                                    || (get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key'))
                                ):?>
                                    <div class="wdk-form-group">
                                        <?php wdk_listing_claim_recaptcha_field(); ?>
                                    </div>
                                <?php endif;?>
                                <div class="wdk-form-group">
                                    <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
                                </div>
                            </form>
                        </div> 
                        </div> 
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div> 
</div>

