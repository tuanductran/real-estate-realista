<?php

namespace WdkListing_Claim\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkListingClaimForm extends WdkListing_ClaimElementorBase {

    public $field_id = NULL;
    public $fields_list = array();
	const REPORT_SENT = 'sent';
	const REPORT_ADDED = 'added';
	const REPORT_LOGIN = 'login';
	const REPORT_FORM = 'form';

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-listing-claim')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-listing-claim')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-listing-claim')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-listing-claim-form';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Listing Claim', 'wdk-listing-claim');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-warning-full';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['post_id'] = $wdk_listing_id;
        $this->data['post_type'] = 'wdk-listing';

        $this->data['validation_messages'] = false;
        $this->data['claims_status'] = false;
        
        global $Winter_MVC_wdk_listing_claim, $Winter_MVC_WDK;
		$Winter_MVC_wdk_listing_claim->model('listing_claim_m');
		$Winter_MVC_WDK->load_helper('listing');

        if(is_user_logged_in()) {
            $claimed = $Winter_MVC_wdk_listing_claim->listing_claim_m->get_by(array('post_id'=>$wdk_listing_id, 'user_id'=>get_current_user_id()));

            if($claimed) {
                $this->data['claims_status'] = true;
            }
        }

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
            $this->data['claims_status'] = false;
        }

        echo $this->view('wdk-listing-claim-form', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-listing-claim'),
                'tab' => '1',
            ]
        );

        $this->add_responsive_control(
            'field_labels',
                [
                    'label' => esc_html__( 'Hide Labels', 'wdk-listing-claim' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Show', 'wdk-listing-claim' ),
                    'block' => esc_html__( 'Hide', 'wdk-listing-claim' ) ,
                    'return_value' => 'block',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-listing-claim-form label' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $fields = array(
            array('field_name_label'=>__( 'Full Name', 'wdk-listing-claim' ), 'field_name_placeholder'=>__( 'Full Name', 'wdk-listing-claim' )),
            array('field_address_label'=>__( 'Address', 'wdk-listing-claim' ), 'field_address_placeholder'=>__( 'Address', 'wdk-listing-claim' )),
            array('field_city_label'=>__( 'City', 'wdk-listing-claim' ), 'field_city_placeholder'=>__( 'City', 'wdk-listing-claim' )),
            array('field_country_label'=>__( 'Country', 'wdk-listing-claim' ), 'field_country_placeholder'=>__( 'Country', 'wdk-listing-claim' )),
            array('field_email_label'=>__( 'Email', 'wdk-listing-claim' ), 'field_email_placeholder'=>__( 'Email', 'wdk-listing-claim' )),
            array('field_phone_label'=>__( 'Phone number', 'wdk-listing-claim' ), 'field_phone_placeholder'=>__( 'Phone number', 'wdk-listing-claim' )),
            array('field_message_label'=>__( 'Claim reason', 'wdk-listing-claim' ), 'field_message_placeholder'=>__( 'Claim reason', 'wdk-listing-claim' )),
        );

        foreach($fields as $field) {
            $key = key ($field);
            $value = current($field);

            $this->add_control(
                $key,
                [
                    'label' => __( 'Label', 'wdk-listing-claim' ).' '.$value,
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => $value,
                ]
            );

            next($field);
            $key = key ($field);
            $value = current($field);
            $this->add_control(
                $key,
                [
                    'label' => __( 'Placeholder', 'wdk-listing-claim' ).' '.$value,
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => $value,
                ]
            );
        }

        /* agree link */
        
        $this->add_control(
            'term_hide',
            [
                'label' => __( 'Hide Term', 'wdk-listing-claim' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'wdk-listing-claim' ),
                'label_off' => __( 'Off', 'wdk-listing-claim' ),
                'return_value' => 'true',
                'default' => '',
              
            ]
        );

        $this->add_control(
            'term_label',
            [
                'label' => __( 'Term Label', 'wdk-listing-claim' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Please Agree Terms', 'wdk-listing-claim' ),
                'separator' => 'before',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'term_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );

        $this->add_control(
            'term_link',
            [
                'label' => __( 'Term Link', 'wdk-listing-claim' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '#',
                'separator' => 'before',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'term_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );

        $this->add_control(
            'field_submit',
            [
                'label' => __( 'Text Submit Button', 'wdk-listing-claim' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Send', 'wdk-listing-claim' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_toggle',
            [
                'label' => __( 'Text Toggle Button', 'wdk-listing-claim' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Claim', 'wdk-listing-claim' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'link_icon_position',
            [
                'label' => esc_html__('icon Position', 'wdk-listing-claim'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'wdk-listing-claim'),
                    'right' => esc_html__('Right', 'wdk-listing-claim'),
                ],
                'default' => 'right',
            ]
        );
        
        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'form_group',
                'label'=> esc_html__('Form group', 'wdk-listing-claim'),
                'selector'=>'#listing_claim .wdk-form-group',
                'options'=>'block',
            ],
            [
                'key'=>'style_label',
                'label'=> esc_html__('Label', 'wdk-listing-claim'),
                'selector'=>'#listing_claim .wdk-form-group label:not(.remember_btn)',
                'options'=>'full',
            ],
            [
                'key'=>'style_field',
                'label'=> esc_html__('Fields', 'wdk-listing-claim'),
                'selector'=>'#listing_claim .wdk-form-group .wdk-control:not([type="checkbox"])',
                'options'=>'full',
            ],
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-listing-claim'),
                'selector'=>'#listing_claim .wdk-btn',
                'options'=>['margin','typo','color','background','border','border_radius','padding','shadow','transition', 'height'],
            ],
            [
                'key'=>'style_button_toggle',
                'label'=> esc_html__('Button Toggle', 'wdk-listing-claim'),
                'selector'=>'{{WRAPPER}} .wdk-listing-claim-element .wdk-field_toggle_claim',
                'options'=>['margin','typo','color','background','border','border_radius','padding','shadow','transition', 'height'],
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if( $item ['key'] == 'style_label'){
                $selectors = array(
                    'normal' => $item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if ($item ['key'] == 'style_field' || $item ['key'] == 'style_button') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Height', 'wdk-listing-claim'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            $item['selector'] => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }
            $selectors = array(
                'normal' => $item['selector'],
                'hover'=>$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-listing-claim-form');
        wp_enqueue_script('wdk-modal');
        wp_enqueue_style('wdk-modal');

        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
    }
}
