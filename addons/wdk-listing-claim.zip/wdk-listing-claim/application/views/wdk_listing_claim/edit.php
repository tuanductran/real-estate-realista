<?php
/**
 * The template for Claim Edit.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Listing Claim Management','wdk-listing-claim'); ?></h1>
    <br /><br />
        <div class="wdk-body">
            <div class="postbox" style="display: block;">
                <div class="postbox-header"><h3><?php echo esc_html__('Edit Claim/Listing Claim','wdk-listing-claim'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-listing-claim'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?> 
                    
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-listing-claim'); ?>">
                    <?php if(wmvc_show_data('post_id', $db_data, false)):?>
                    <a target="_blank" href="<?php echo esc_url(get_permalink(wmvc_show_data('post_id', $db_data)));?>" class="button button-default"><?php echo esc_html__('View Listing','wdk-listing-claim'); ?></a>
                    <?php endif;?>
                    <a href="mailto:<?php echo esc_attr(wmvc_show_data('email', $db_data));?>?subject=<?php echo esc_attr__('Claim Reply','wdk-listing-claim');?> - <?php echo wdk_field_value ('post_title', wmvc_show_data('post_id', $db_data));?>:&amp;body=<?php echo esc_attr(strip_tags(wmvc_show_data('message', $db_data)));?>" class="button button-default"><?php echo esc_html__('Reply To Email','wdk-listing-claim'); ?></a>
                    
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-listing-claim&function=give_ownership&id=" . wmvc_show_data('idlistingclaim', $db_data, '-'); ?>" 
                        class="button button-default"><?php echo esc_html__('Give ownership','wdk-listing-claim'); ?></a>
                    <?php if($owner_user_id):?>
                        <a target="_blank" href="<?php echo esc_attr(admin_url('user-edit.php?user_id='.$owner_user_id));?>" class="button button-default"><?php echo esc_html__('Edit owner User','wdk-listing-claim'); ?></a>
                    <?php endif;?>

                    <?php if(wmvc_show_data('user_id', $db_data, false)):?>
                        <a target="_blank" href="<?php echo esc_attr(admin_url('user-edit.php?user_id='.wmvc_show_data('user_id', $db_data)));?>" class="button button-default"><?php echo esc_html__('Edit Claim User','wdk-listing-claim'); ?></a>
                    <?php endif;?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $this->view('general/footer', $data); ?>