<?php
/**
 * The template for Claim Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Listing Claim','wdk-listing-claim'); ?></h1>
    <br />
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-listing-claim" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-listing-claim'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-listing-claim'); ?>" />
                
                <label class="screen-reader-text" for="category_id"><?php echo __('Filter by category', 'wdk-listing-claim'); ?></label>
                <?php echo wmvc_select_option('status',array( ''=>__('Select status', 'wdk-listing-claim')) + $this->listing_claim_m->statuses_list, wmvc_show_data('status', $db_data, ''), NULL, __('Status', 'wdk-listing-claim')); ?>

                <label class="screen-reader-text" for="post_id"><?php echo esc_html__('Post Id', 'wdk-listing-claim'); ?></label>
                <span class="wdk-unwrapp-field">
                    <?php echo wdk_treefield_option('post_id', 'listing_m', wmvc_show_data('post_id', $db_data, ''), 'post_title', '', __('Not Selected', 'wdk-listing-claim'));?>
                </span>

                <label class="screen-reader-text" for="user_id"><?php echo esc_html__('Filter by user name', 'wdk-listing-claim'); ?></label>
                <input type="text" name="name" id="name" class="postform left" value="<?php echo wmvc_show_data('name', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Name', 'wdk-listing-claim'); ?>" />

                <label class="screen-reader-text" for="address"><?php echo esc_html__('Filter by user address', 'wdk-listing-claim'); ?></label>
                <input type="text" name="address" id="address" class="postform left" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-listing-claim'); ?>" />

                <label class="screen-reader-text" for="email"><?php echo esc_html__('Filter by user email', 'wdk-listing-claim'); ?></label>
                <input type="text" name="email" id="email" class="postform left" value="<?php echo wmvc_show_data('email', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Email', 'wdk-listing-claim'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-listing-claim'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-listing-claim')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-listing-claim'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Title','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Full Name','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Email','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Date','wdk-listing-claim'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-listing-claim'); ?></th>
            </tr>
        </thead>
        <?php if(count($listing_claim) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="7"><?php echo esc_html__('No Listing Claim found.','wdk-listing-claim'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $listing_claim as $listing_claim ):?>
            <tr>
                <td>
                    <?php echo wmvc_show_data('idlistingclaim', $listing_claim, '-'); ?>
                    <?php
                        $class="label-danger";
                        if(wmvc_show_data('status', $listing_claim) == 'WAITING'){
                            $class="label-warning";
                        } else if(wmvc_show_data('status', $listing_claim) == 'NO OWNERSHIP') {
                            $class="label-info";
                        } else if(wmvc_show_data('status', $listing_claim) == 'NOT READED') {
                            $class="label-danger";
                        } else if(wmvc_show_data('status', $listing_claim) == 'TAKEN OWNERSHIP') {
                            $class="label-success";
                        }
                    ?>

                    <?php if(wmvc_show_data('status', $listing_claim, false) && isset($this->listing_claim_m->statuses_list[wmvc_show_data('status', $listing_claim, '-')])):?>
                        <span class="label <?php echo esc_attr($class);?>"><?php echo esc_html($this->listing_claim_m->statuses_list[wmvc_show_data('status', $listing_claim, '-')]); ?></span>
                    <?php endif;?>

                </td>
                <td>
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $listing_claim, '-')); ?>" title="<?php echo esc_attr__('View Listing', 'wdk-listing-claim');?> <?php echo esc_attr(wmvc_show_data('post_title', $listing_claim, '-')); ?>">
                        <?php echo wmvc_show_data('post_title', $listing_claim, '-'); ?>
                    </a>
                </td>
                <td>
                    <?php echo wmvc_show_data('name', $listing_claim, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('address', $listing_claim, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('email', $listing_claim, '-'); ?>
                </td>
                <td>
                    <?php echo wdk_get_date(wmvc_show_data('date', $listing_claim), false); ?>
                </td>
          
                <td class="actions_column">
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $listing_claim, '-')); ?>" title="<?php echo esc_attr__('View Listing');?> <?php echo esc_attr(wmvc_show_data('post_title', $listing_claim, '-')); ?>" target="_blank"><span class="dashicons dashicons-visibility"></span></a>
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-listing-claim&function=edit&id=" . wmvc_show_data('idlistingclaim', $listing_claim, '-'); ?>" title="<?php echo esc_attr__('Edit', 'wdk-listing-claim');?>"><span class="dashicons dashicons-edit"></span></a>
                    <a class="question_sure" href="<?php echo get_admin_url() . "admin.php?page=wdk-listing-claim&function=delete&id=".wmvc_show_data('idlistingclaim', $listing_claim, '-'); ?>" title="<?php echo esc_attr__('Remove', 'wdk-listing-claim');?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Title','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Name', 'wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Email','wdk-listing-claim'); ?></th>
                <th><?php echo esc_html__('Date','wdk-listing-claim'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-listing-claim'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-listing-claim')); ?>");
        });
    });
</script>

<?php $this->view('general/footer', $data); ?>
