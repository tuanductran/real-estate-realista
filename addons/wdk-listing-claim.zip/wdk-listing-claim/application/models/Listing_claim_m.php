<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Listing_claim_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_listing_claim';
	public $_order_by = 'idlistingclaim DESC';
    public $_primary_key = 'idlistingclaim';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $statuses_list = array();
    
	public function __construct(){
        parent::__construct();

        $this->statuses_list = array(
            'NOT READED'=>__('Unread', 'wdk-listing-claim'),
            'WAITING '=>__('Waiting ', 'wdk-listing-claim'),
            'TAKEN OWNERSHIP'=>__('Taken Ownership', 'wdk-listing-claim'),
            'NO OWNERSHIP'=>__('No Ownership', 'wdk-listing-claim'),
        );

        $this->fields_list = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'LISTING', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'name',
                'field_label' => __('Full Name', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'address',
                'field_label' => __('Address', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'city',
                'field_label' => __('City', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'country',
                'field_label' => __('Country', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'email',
                'field_label' => __('Email', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'email|required'
            ),
            array(
                'field' => 'phone',
                'field_label' => __('Phone', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'message',
                'field_label' => __('Message', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'TEXTAREA', 
                'rules' => 'required'
            ),
            array(
                'field' => 'date',
                'field_label' => __('Date', 'wdk-listing-claim'),
                'hint' => '', 
                'field_type' => 'DATE', 
                'rules' => ''
            ),

        );

        if(wmvc_user_in_role('administrator')){
            $this->fields_list[] =
                array(
                    'field' => 'status',
                    'field_label' => __('Status', 'wdk-listing-claim'),
                    'hint' => '', 
                    'field_type' => 'DROPDOWN', 
                    'values' =>  array( ''=>__('Select status', 'wdk-listing-claim')) + $this->statuses_list,
                    'rules' => ''
                );
            $this->fields_list[] =
                array(
                    'field' => 'note',
                    'field_label' => __('Note (only for admin)', 'wdk-listing-claim'),
                    'hint' => '', 
                    'field_type' => 'TEXTAREA', 
                    'rules' => ''
                );
        }

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }
	}
  
    public function get($id = NULL, $single = FALSE)
    {
        return parent::get($id, $single);
    }
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE)
    {
        global $wpdb;

        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));
        
        $this->db->order_by($this->_order_by);

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }

    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = TRUE)
    {
        global $wpdb;

        $post_table = $this->db->prefix.'posts';

        $this->db->select($this->_table_name.'.*, '.$this->db->prefix.'posts.post_title,'.$this->db->prefix.'posts.post_type' );
       
        $wp_usermeta_table = $wpdb->users;
        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.post_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');
       
        /* wp post table */
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        $this->db->from($this->_table_name);
        
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $query = $this->get(NULL, FALSE, $user_check);

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(empty($user_id))
            $user_id = get_current_user_id();    

        if(wmvc_user_in_role('administrator')) return true;
        
        $listing_claim = $this->get($id, TRUE);
        if(isset($listing_claim->user_id) && $listing_claim->user_id == $user_id)
            return true;

        return false;
    }
    
     /* [END] For dynamic data table */
    
    public function check_if_exists($user_id, $post_id)
    {
        $this->db->from($this->_table_name);
        $this->db->where(array('user_id'=> $user_id, 
                               'post_id'=> $post_id));
        $query = $this->db->get();

        if (!empty($query))
            return true;

        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        /* remove */
        parent::delete($id);

        return true;
    }
  
    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $listing_claim = $this->get($item_id, TRUE);
        if(isset($listing_claim->user_id) && $listing_claim->user_id == $user_id)
            return true;
            
        return false;
    }

}
?>