<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;


	public function __construct(){
        parent::__construct();

        $this->fields_list = array( 
            array(
                'field' => 'wdk_listing_claim_recaptcha_site_key', 
                'field_label' => __('Recaptcha site key', 'wdk-listing-claim'), 
                'hint' => __('Please add Recaptcha site and Secret keys for enable recaptcha Add Google Recaptcha site key (use V2 recaptcha key)', 'wdk-listing-claim'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),

            array(
                'field' => 'wdk_listing_claim_recaptcha_secret_key', 
                'field_label' => __('Recaptcha site secret key', 'wdk-listing-claim'), 
                'hint' => __('Add Google Recaptcha secret key', 'wdk-listing-claim'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),
        );
	}
}
?>