<?php
defined('WINTER_MVC_PATH') OR exit('No direct script access allowed');

class Wdk_listing_claim_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function listing_claim_send($output="", $atts=array(), $instance=NULL)
    {

		$this->load->load_helper('listing');
		$this->load->model('listing_claim_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();
		global $Winter_MVC_wdk_listing_claim, $Winter_MVC_WDK;
		$Winter_MVC_WDK->model('listingusers_m');
		$Winter_MVC_WDK->model('listing_m');
		$Winter_MVC_WDK->load_helper('listing');

		$Winter_MVC_wdk_listing_claim->input = new \MVC_Input();
		$Winter_MVC_wdk_listing_claim->form = new \MVC_Form();
		
		$Winter_MVC_wdk_listing_claim->model('listing_claim_m');
		/* save review */

		$fields_list = $Winter_MVC_wdk_listing_claim->listing_claim_m->fields_list;
		if(
			(get_option('wdk_listing_claim_recaptcha_site_key') && get_option('wdk_listing_claim_recaptcha_secret_key'))
			|| (get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key'))
		) {
			$fields_list [] = array (
				'field' => 'g-recaptcha-response',
				'field_label' => __('Recaptcha', 'wdk-listing-claim'),
				'label' => __('Recaptcha', 'wdk-listing-claim'),
				'hint' => '', 
				'field_type' => 'INPUTBOX', 
				'rules' => 'required|wdk_listing_claim_valid_recaptcha',
			);
		}

		$Winter_MVC_wdk_listing_claim->form->add_error_message('wdk_valid_recaptcha', __('Recaptcha is wrong', 'wdk-listing-claim'));

		if($Winter_MVC_wdk_listing_claim->form->run($fields_list))
		{

			// Save procedure for basic data
			$data_r = $Winter_MVC_wdk_listing_claim->listing_claim_m->prepare_data($Winter_MVC_wdk_listing_claim->input->post(), $fields_list);
			$data_r['date'] = date('Y-m-d H:i:s');
			$data_r['status'] = 'NOT READED';

			if(isset($data_r['g-recaptcha-response'])) {
				unset($data_r['g-recaptcha-response']);
			}

			if(get_current_user_id())
				$data_r['user_id'] = get_current_user_id();
			// Save standard wp post

			$insert_id = $Winter_MVC_wdk_listing_claim->listing_claim_m->insert($data_r);


			$listing = $Winter_MVC_WDK->listing_m->get($data_r['post_id'], TRUE);

			/* owner data */
			$user_owner = NULL;
			if($listing) {
				if(wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE )) {
					$user_owner = get_userdata( wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE ) );
				}
			}

			if(empty($user_owner)) {
				$user_owner = array(
					'display_name' => __('Administrator', 'wdk-bookings'),
					'user_email' => get_bloginfo('admin_email'),
				);
			}

			// Save procedure for basic data
			$data_message = array();
			$data_message['user'] = get_userdata( wmvc_show_data('user_id', $data_r) );
			$data_message['data'] = $data_r;  /* claim data */
			$data_message['data']['listing_title'] = '<a href="'.esc_url(get_permalink($listing)).'">'.esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'</a>';
			if(wmvc_show_data('address', $listing, false, TRUE, TRUE)){
				$data_message['data']['listing_address'] = esc_html(wmvc_show_data('address', $listing, '', TRUE, TRUE));
			}
			$data_message['data']['listing_link'] = get_permalink(intval($_POST['post_id']));
			$data_message['data']['user_name'] = wmvc_show_data('display_name', $user_owner, '', TRUE, TRUE);
			$data_message['data']['user_email'] = wmvc_show_data('user_email', $user_owner, '', TRUE, TRUE);
			if(wmvc_show_data('user_id', $user_listing, false, TRUE, TRUE )) {
				$data_message['data']['user_edit_link'] =admin_url('user-edit.php?user_id='.wmvc_show_data('user_id', $user_listing, false, TRUE, TRUE ))  ;
			}

			$subject =  __('Claim on', 'wdk-listing-claim').' "'.esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'" #'.intval($insert_id).' '.date('Y-m-d');

			$ret =  wdk_mail( get_bloginfo('admin_email'), $subject, $data_message, 'new_claim');

			$data['success'] = true;

			$data['popup_text_success'] = __('Claim sent', 'wdk-listing-claim');

		} else {
			ob_start();
			$Winter_MVC_wdk_listing_claim->form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-listing-claim'));
			$data['message'] = ob_get_contents();
			ob_end_clean();
			
			$this->data['validation_messages'] = true;
		}

		$this->output($data);
    }

     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
