<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_listing_claim_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('listing_claim_m');


        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->data['post_types'] = array();

        $this->data['order_by']   = array(  'idlistingclaim DESC' => __('ID', 'wdk-listing-claim').' DESC', 
                                            'idlistingclaim ASC' => __('ID', 'wdk-listing-claim').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-listing-claim').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-listing-claim').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'address',
                'label' => __('Address', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'name',
                'label' => __('Name', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'email',
                'label' => __('Email', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'post_id',
                'label' => __('Post Id', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-listing-claim'),
                'rules' => ''
            ),
            array(
                'field' => 'status',
                'label' => __('Status', 'wdk-listing-claim'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->listing_claim_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'listing_claim';
        $columns = array('idlistingclaim', 'post_id','order_by', 'name', 'address', 'email','status');
        $external_columns = array('post_title', 'address');

        wdk_listing_claim_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->listing_claim_m->total( array(), FALSE);

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_listing_claim_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['listing_claim'] = $this->listing_claim_m->get_pagination($per_page, $offset, array(), NULL, FALSE);
       
        // Load view
        $this->load->view('wdk_listing_claim/index', $this->data);
    }

    public function edit()
	{
    
        $id = $this->input->post_get('id');
        $this->load->model('listing_claim_m');
        global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');

		$Winter_MVC_WDK->model('listing_m');
		$Winter_MVC_WDK->model('listingusers_m');
        $this->data['owner_user_id'] = NULL;

        if(function_exists('wdk_access_check'))
            wdk_access_check('listing_claim_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['fields'] = $this->listing_claim_m->fields_list;


        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->listing_claim_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post
            $insert_id = $this->listing_claim_m->insert($data, $id);

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-listing-claim&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->listing_claim_m->get($id, TRUE);
            $listing = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $this->data['db_data']), TRUE);
            if($listing)
                $this->data['owner_user_id'] = wdk_show_data('user_id_editor', $listing, '',TRUE, TRUE);
        }

        $this->load->view('wdk_listing_claim/edit', $this->data);
    }

    public function give_ownership()
	{
    
        $id = $this->input->post_get('id');
        $this->load->model('listing_claim_m');

        global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');

		$Winter_MVC_WDK->model('listing_m');
		$Winter_MVC_WDK->model('listingusers_m');

        if(function_exists('wdk_access_check'))
            wdk_access_check('listing_claim_m', $id);

        $listing_claim = $this->listing_claim_m->get($id, TRUE);
        $listing = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $listing_claim), TRUE);
        $data = array(
            'status'=> 'TAKEN OWNERSHIP'
        );
        // Save standard wp post
        $id = $this->listing_claim_m->insert($data, $id);

        if(wmvc_show_data('post_id', $listing_claim, false))
            $Winter_MVC_WDK->listing_m->insert(array('user_id_editor' =>  wmvc_show_data('user_id', $listing_claim)), wmvc_show_data('post_id', $listing_claim));

        // Mail procedure
        $data_message = array();
        $data_message['user'] = get_userdata( wmvc_show_data('user_id', $data_r) );
        $data_message['data'] = array();
        $data_message['data']['requiest_message'] = esc_html(wmvc_show_data('message', $listing_claim, '', TRUE, TRUE));
        $data_message['data']['listing_title'] = '<a href="'.esc_url(wmvc_show_data('post_id', $listing_claim)).'">'
                                                    .esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'</a>';
        if(wmvc_show_data('address', $listing, false, TRUE, TRUE)){
            $data_message['data']['listing_address'] = esc_html(wmvc_show_data('address', $listing, '', TRUE, TRUE));
        }
        $data_message['data']['listing_link'] = get_permalink(wmvc_show_data('post_id', $listing_claim));

        $subject =  __('You received ownership for Listing', 'wdk-listing-claim').' "'.esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'" #'.intval(wmvc_show_data('post_id', $listing_claim));

        $ret =  wdk_mail( get_bloginfo('admin_email'), $subject, $data_message);

        // redirect
        wp_redirect(admin_url("admin.php?page=wdk-listing-claim&function=edit&&id=$id&is_updated=true"));
        exit;
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('listing_claim_m');
        
        $this->listing_claim_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-listing-claim&paged=$paged"));
    }
    
}
