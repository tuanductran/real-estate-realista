<?php
/**
 * The template for {some title}.
 *
 * This is the template that {some description of file}
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<span class="wdk-listing-claim-shortcode wdk-listing-claim-actions">
    <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-add-listing_claim-action <?php echo (esc_attr($listing_claim_added))?'wdk-hidden':''; ?>"  data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
        <i class="fa fa-heart-o"></i>
    </a>
    <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-remove-listing_claim-action <?php echo (!esc_attr($listing_claim_added))?'wdk-hidden':''; ?>" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
        <i class="fa fa-heart"></i>
    </a>
    <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
</span>

