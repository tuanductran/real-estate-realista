<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-listing-claim-action], show action add/remove listing-claim
*
* Layout path : 
* get_template_directory().'/wdk-listing-claim/shortcodes/views/shortcode-listing-claim-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-listing-claim-action.php'
*/

//add_shortcode('wdk-listing-claim-action', 'wdk_listing_claim_action');
function wdk_listing_claim_action($atts, $content){
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'post_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;
    
    if(!wmvc_show_data('post_id', $data, false)){
        global $wdk_listing_id;
        if(isset($wdk_listing_id)){
            $data['post_id'] = $wdk_listing_id;
            $data['post_type'] = 'wdk-listing';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $data['post_id'] = $post_object_id;

            $data['post_type'] = get_post_type();
        }
    }

    /* Favorite module */
    $listing_claim_added=false;
    global $Winter_MVC_wdk_listing_claim; 
    if(get_current_user_id() != 0 && isset($Winter_MVC_wdk_listing_claim) && wmvc_show_data('post_id', $data, false))
    {
        $Winter_MVC_wdk_listing_claim->model('listing_claim_m');
        $listing_claim_added = $Winter_MVC_wdk_listing_claim->listing_claim_m->check_if_exists(get_current_user_id(), 
                                                                wmvc_show_data('post_id', $data));
        if($listing_claim_added>0)$listing_claim_added = true;
    }
    
    $data ['listing-claim_added'] = $listing_claim_added;
    /* End Favorite module */
    
    return wdklisting_claim_shortcodes_view('shortcode-listing-claim-action', $data);
}

?>