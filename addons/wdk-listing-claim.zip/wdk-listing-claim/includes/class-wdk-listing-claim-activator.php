<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Listing_Claim
 * @subpackage Wdk_Listing_Claim/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Listing_Claim
 * @subpackage Wdk_Listing_Claim/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Listing_Claim_Activator {
	public static $db_version = 1.0;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_listing_claim_';
	}

	public static function plugins_loaded(){
      
		if ( get_site_option( 'wdk_listing_claim_db_version' ) === false ||
		     get_site_option( 'wdk_listing_claim_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_listing_claim_db_version' ) === false)
        {
            // Main table for visited pages

            $table_name = $wpdb->prefix . 'wdk_listing_claim';

            $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                        `idlistingclaim` int(11) NOT NULL AUTO_INCREMENT,
                        `post_id` int DEFAULT NULL,
                        `user_id` int NULL DEFAULT NULL,
                        `name` varchar(45) DEFAULT NULL,
                        `address` varchar(45) DEFAULT NULL,
                        `city` varchar(45) DEFAULT NULL,
                        `country` varchar(45) DEFAULT NULL,
                        `email` varchar(45) DEFAULT NULL,
                        `phone` varchar(45) DEFAULT NULL,
                        `status` varchar(64) DEFAULT NULL,
                        `message` text DEFAULT NULL,
                        `note` text DEFAULT NULL,
                        `date` datetime DEFAULT NULL,
                        `is_read` int(1) DEFAULT NULL,
                PRIMARY KEY  (idlistingclaim)
                ) $charset_collate;";

 			dbDelta( $sql );

             self::$db_version = 1;

        }

        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_listing_claim_db_version' ) < '1.1' ) {

            self::$db_version = 1.2;
            /* udpate option with db version */
           
        }

        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_listing_claim_db_version' ) < '1.2' ) {
         
           
        }

        update_option( 'wdk_listing_claim_db_version', self::$db_version );
    }

}
