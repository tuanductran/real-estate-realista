<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Listing_Claim
 * @subpackage Wdk_Listing_Claim/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wdk_Listing_Claim
 * @subpackage Wdk_Listing_Claim/public
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Listing_Claim_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Listing_Claim_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Listing_Claim_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_register_style( 'wdk-listing-claim-form', WDK_LISTING_CLAIM_URL. 'elementor-elements/assets/css/widgets/wdk-listing-claim-form.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wdk-listing-claim-public.css', array(), $this->version, 'all' );
		
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Listing_Claim_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Listing_Claim_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$text_parameters = array(
            'login_text_claim' => esc_html__('Required Login for Claim Listing (auto redirected at 3 sec)', 'wdk-listing-claim'),
            'listing_claimed' => esc_html__('Thanks, for your claim!', 'wdk-listing-claim'),
        );

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wdk-listing-claim-public.js', array( 'jquery' ), $this->version, false );

        wp_localize_script($this->plugin_name, 'text_parameters_claim', $text_parameters);

	}

	public function ajax_public()
	{
		global $Winter_MVC_wdk_listing_claim;

		$page = '';
		$function = '';

		if(isset($_POST['page']))$page = wmvc_xss_clean($_POST['page']);
		if(isset($_POST['function']))$function = wmvc_xss_clean($_POST['function']);

		/* protect access only to ajax controller */
		if($page == 'wdk_listing_claim_frontendajax') {
			$page = 'wdk-listing-claim-frontendajax';
		} 

		if($page != 'wdk-listing-claim-frontendajax') {
			exit(esc_html__('Access denied','wdk-listing-claim'));
		} 

		$Winter_MVC_wdk_listing_claim = new MVC_Loader(plugin_dir_path( __FILE__ ).'../');
		$Winter_MVC_wdk_listing_claim->load_helper('basic');
		$Winter_MVC_wdk_listing_claim->load_controller($page, $function, array());
	}


}
