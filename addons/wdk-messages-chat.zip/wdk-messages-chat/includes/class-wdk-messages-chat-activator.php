<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_MessagesChat
 * @subpackage Wdk_MessagesChat/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_MessagesChat
 * @subpackage Wdk_MessagesChat/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_MessagesChat_Activator {
	public static $db_version = 1.2;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_messages_chat_';
	}

	public static function plugins_loaded(){
      
		if ( get_site_option( 'wdk_messages_chat_db_version' ) === false ||
		     get_site_option( 'wdk_messages_chat_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

	
    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_messages_chat_db_version' ) === false)
        {
            // Main table for visited pages
            $table_name = $wpdb->prefix . 'wdk_messages_chat';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idmessageschat` int(11) NOT NULL AUTO_INCREMENT,
                    `related_key` int(11) DEFAULT NULL,
                    `outgoing_msg_user_id` int(11) DEFAULT NULL,
                    `outgoing_msg_user_email` varchar(256) DEFAULT '',
                    `chat_is_readed` tinyint(1) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `message` TEXT  DEFAULT '',
                PRIMARY KEY  (idmessageschat)
            ) $charset_collate";

            dbDelta( $sql );
            self::$db_version = 1.0;
        }
        
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_messages_chat_db_version' ) < '1.2' ) {

            $table_name = $wpdb->prefix . 'wdk_messages_chat';
            $sql = "ALTER TABLE `$table_name` ADD `chat_is_notified` tinyint(1) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.2;
           
        }

        update_option( 'wdk_messages_chat_db_version', self::$db_version );
    }

}
