<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action('wp_footer', function(){
    if(substr_count($_SERVER['REQUEST_URI'], 'widgets.php') || substr_count($_SERVER['PHP_SELF'], 'wp-json')) return false;

    if(!function_exists('wdk_dash_url') || !is_user_logged_in()) return false;
    global $Winter_MVC_WDK,$Winter_MVC_wdk_messages_chat;
    $Winter_MVC_wdk_messages_chat->model('messageschat_m');
    $Winter_MVC_WDK->model('messages_m');
    if(!$Winter_MVC_wdk_messages_chat->messageschat_m->total_relationship_user(NULL, array('chat_is_readed IS NULL'=>NULL)) && !$Winter_MVC_WDK->messages_m->total(array('(is_readed IS NULL)'=>NULL), TRUE)) return false;
    ?>
        <a href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=chat'));?>" class="wdk-messages-chat-live-open"><?php echo esc_html__('Live Chat', 'wdk-messages-chat'); ?></a>
    <?php
});

/* messages CRON */

wdk_membership_messages_chat_unread_cron();
function wdk_membership_messages_chat_unread_cron()
{
    if ( ! wp_next_scheduled( 'wdk_membership_messages_chat_unread_cron' ) ) {
        wp_schedule_event( time(), 'daily', 'wdk_membership_messages_chat_unread_cron' );
    }

}

add_action( 'wdk_membership_messages_chat_unread_cron', 'wdk_membership_messages_chat_unread_cron_alert', 10, 2 );

function wdk_membership_messages_chat_unread_cron_alert($print = FALSE)
{
    global $Winter_MVC_WDK,$Winter_MVC_wdk_messages_chat;
    $Winter_MVC_wdk_messages_chat->model('messageschat_m');
    $Winter_MVC_WDK->model('messages_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->load_helper('listing');

    $table_post = $Winter_MVC_WDK->db->prefix.'posts';
    $table_listing = $Winter_MVC_WDK->listing_m->_table_name;
    $table_inbox = $Winter_MVC_WDK->messages_m->_table_name;
    $table_chat = $Winter_MVC_wdk_messages_chat->messageschat_m->_table_name;

    $Winter_MVC_WDK->db->select($table_chat.'.*,'.$table_post.'.post_title,'.$table_inbox.'.post_id,'.$table_inbox.'.date as inbox_date,'.$table_inbox.'.message as inbox_message,'
                                .$table_inbox.'.idmessage,'
                                .$table_inbox.'.user_id_sender,'
                                .$table_listing.'.user_id_editor'
                            );

    $Winter_MVC_WDK->db->join($table_inbox.' ON '.$table_inbox.'.idmessage = '.$table_chat.'.related_key', NULL, 'LEFT');
    $Winter_MVC_WDK->db->join($table_listing.' ON '.$table_listing.'.post_id = '.$table_inbox.'.post_id', NULL, 'LEFT');
    $Winter_MVC_WDK->db->join($table_post.' ON '.$table_post.'.ID = '.$table_inbox.'.post_id', NULL, 'LEFT');
    
    $Winter_MVC_WDK->db->where(array('chat_is_readed IS NULL'=>NULL/*, $Winter_MVC_WDK->messages_m->_table_name.'.date < "'.date('Y-m-d H:i:s', time() - 86400).'"'=> NULL*/));

    $Winter_MVC_WDK->db->from($table_chat);
    $Winter_MVC_WDK->db->order_by('idmessageschat DESC');
    $query = $Winter_MVC_WDK->db->get();
    $unread_messages = $Winter_MVC_WDK->db->results();
   
     if($print)     
        echo esc_html__('CRON START', 'wdk-membership').'<br />';

    if($print)
        echo esc_html__('Unread Messages', 'wdk-membership').': '.count($unread_messages).'<br />';

    $users_messages = array();
    foreach ($unread_messages as $message) {
        if(empty($message->user_id_editor)) continue;

        /* to owner */
        if($message->user_id_editor != $message->outgoing_msg_user_id) {
            $users_messages[$message->post_id.'_'.$message->user_id_editor][$message->idmessage][] = $message;
        } elseif($message->user_id_sender != $message->outgoing_msg_user_id) {
            /* to visitor */
            $users_messages[$message->post_id.'_'.$message->user_id_sender][$message->idmessage][] = $message;
        }
    }
    
    $messages_count = 0;
    foreach($users_messages as $key=>$user_messages) {
        list($post_id, $user_id) = explode('_', $key);

        $data_message = array();
        $subject = sprintf(esc_html__('Unread messages about %1$s from %2$s', 'wdk-membership'),  wdk_field_value('post_title', $post_id), date('d-m'));

        $data_message['chats'] = array();
        $user_info_in = wdk_get_user_data($user_id);
        $data_message['user_in'] = $user_info_in['userdata'];
        
        foreach($user_messages as $message_id=>$messages)
        {
            $inbox_data = current($messages);
            $user_info_from = wdk_get_user_data($inbox_data->outgoing_msg_user_id);
            
            $chat = array();
            $chat['user_from'] = $user_info_from['userdata'];
            $chat['inbox'] = $inbox_data;
            $chat['messages'] = $messages;
            $chat['count'] = count($messages);
            $data_message['chats'][] = $chat;
        }

        if($print) {
            echo esc_html__('User From Messages', 'wdk-membership').': #'.$user_info_from['user_id'].', '.$user_info_from['userdata']-> display_name.' '.$user_info_from['userdata']->user_email.'<br />';
            echo esc_html__('User Receiver', 'wdk-membership').': #'.$user_id.', '.$user_info_in['userdata']->display_name .' '.$user_info_in['userdata']->user_email.'<br />';
            echo esc_html__('Subject', 'wdk-membership').': '.$subject.'<br />';
            $data_preview = array('subject' => $subject) + $data_message;
            $Winter_MVC_WDK->view('email/messages_unread_notify', $data_preview, TRUE);
        }

        $ret = wdk_mail(wdk_show_data('user_email', $user_info_in['userdata'] ), $subject, $data_message, 'messages_unread_notify');

        // Save info about notified user
        if($ret === TRUE)
        {
            echo esc_html__('Sending Message SUCCESSFULLY', 'wdk-membership').'<br />';
            $messages_count++;
        }
        else
        {
            echo '<b style="color:red;">'.esc_html__('Sending Message FAILED', 'wdk-membership').'</b><br />';
        }   
    }
        
    if($print)
        echo '<br /><br />'.esc_html__('Total Email Alerts sent', 'wdk-membership').': '.$messages_count.'<br />';

    if($print)
        echo esc_html__('CRON END', 'wdk-membership').'<br />';

    exit('END wdk_save_search_alert');
}

function wdk_membership_messages_chat_unread_cron_manual()
{
    if(isset($_GET['wdk_membership_messages_chat_unread_cron'])) {
        wdk_membership_messages_chat_unread_cron_alert(TRUE);
        exit();
    }
}

add_action( 'init', 'wdk_membership_messages_chat_unread_cron_manual', 10, 2 );