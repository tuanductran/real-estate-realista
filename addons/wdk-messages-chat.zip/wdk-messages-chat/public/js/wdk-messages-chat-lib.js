;(function(factory) {
    if ((typeof jQuery === 'undefined' || !jQuery) && typeof define === "function" && define.amd) {
        define(["jquery"], function (jQuery) {
            return factory(jQuery, document, window, navigator);
        });
    } else if ((typeof jQuery === 'undefined' || !jQuery) && typeof exports === "object") {
        factory(require("jquery"), document, window, navigator);
    } else {
        factory(jQuery, document, window, navigator);
    }
} (function ($, document, window, navigator, undefined) {
    "use strict";

    // =================================================================================================================
    // Service

    var plugin_count = 0;

    if (!Function.prototype.bind) {
        Function.prototype.bind = function bind(that) {

            var target = this;
            var slice = [].slice;

            if (typeof target != "function") {
                throw new TypeError();
            }

            var args = slice.call(arguments, 1),
                bound = function () {

                    if (this instanceof bound) {

                        var F = function(){};
                        F.prototype = target.prototype;
                        var self = new F();

                        var result = target.apply(
                            self,
                            args.concat(slice.call(arguments))
                        );
                        if (Object(result) === result) {
                            return result;
                        }
                        return self;

                    } else {

                        return target.apply(
                            that,
                            args.concat(slice.call(arguments))
                        );

                    }

                };

            return bound;
        };
    }
    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function(searchElement, fromIndex) {
            var k;
            if (this == null) {
                throw new TypeError('"this" is null or not defined');
            }
            var O = Object(this);
            var len = O.length >>> 0;
            if (len === 0) {
                return -1;
            }
            var n = +fromIndex || 0;
            if (Math.abs(n) === Infinity) {
                n = 0;
            }
            if (n >= len) {
                return -1;
            }
            k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);
            while (k < len) {
                if (k in O && O[k] === searchElement) {
                    return k;
                }
                k++;
            }
            return -1;
        };
    }

    // =================================================================================================================
    // Template

    // =================================================================================================================
    // Core

    /**
     * Main plugin constructor
     *
     * @param object {Object} link to base input element
     * @param options {Object} slider config
     * @param plugin_count {Number}
     * @constructor
     */

    var WdkMessagesChat_form = null; 

    var WdkMessagesChat_form = function (object, options, plugin_count) {
        this.VERSION = "1";
        this.plugin_count = plugin_count;
        this.plugin_count = plugin_count;
        this.object = $(object);
        
        this.is_update = false;
        this.jqxhr = null;
        this.jqxhr_submit = null;
        this.chat_list_jqxhr = null;
        this.latest_message_id = null;
        this.update_chat_paused = false;

        var conf_data = this.object.find('.config') || '';
        var config;
        if(conf_data)
            var config = {
                'related_key': this.object.find('[name="related_key"]').val(),
                'outgoing_msg_user_id': this.object.find('[name="outgoing_msg_user_id"]').val(),
                'outgoing_msg_user_email': this.object.find('[name="outgoing_msg_user_email"]').val(),           
            }

        options = options || {};

        this.messages_list = this.object.parent().find('.messages-chat');
        this.messages_text = this.object.find('[name="message"]');
        this.chats_list = this.object.closest('.wdk-form-chat').find('.chats-list') || null;
        this.header_chat = this.object.closest('.wdk-form-chat').find('.header-chat') || null;

        // js config extends default config
        $.extend(config, options);

        this.options = config;

        // validate config, to be sure that all data types are correct
        this.update_check = {};
        this.init();
    };

    WdkMessagesChat_form.prototype = {
        /**
         * Starts or updates the plugin instance
         *
         * @param [is_update] {boolean}
         */

        init: function (is_update) {
            var that = this;
            that.tree_maps = [];
            that.object.addClass('WdkMessagesChat_form');
            that.updateChat();

            this.object.on('submit', function(e){
                e.preventDefault();
                that.sendMessage(that.object.find('[name="message"]').val(),that.options.related_key, that.options.outgoing_msg_user_id, that.options.outgoing_msg_user_email)
            });

            /* send message on enter */
            this.messages_text.keydown(function(e){
                var key = e.which;  
                if (key == 13) {
                    if(e.shiftKey){
                    } else {
                        e.preventDefault();
                        that.sendMessage(that.object.find('[name="message"]').val(),that.options.related_key, that.options.outgoing_msg_user_id, that.options.outgoing_msg_user_email)
                    }
                }  
            })

            /* send message on submit form */
            this.messages_text.on('submit', function(e){
                e.preventDefault();
                that.sendMessage(that.object.find('[name="message"]').val(),that.options.related_key, that.options.outgoing_msg_user_id, that.options.outgoing_msg_user_email)
            });
            
            setInterval(function(){that.updateChat()}, 5000);

            that.action_open_chat();
            return that;
        },

        set_config: function(options){
            this.options = $.extend(this.options, options);
        },

        regenerateChat: function (related_key, outgoing_msg_user_id, outgoing_msg_user_email) {
            var that = this;
            if(typeof related_key == 'undefined') return false;

            /* stop update */
            that.update_chat_paused = true;
            that.jqxhr.abort();

            that.latest_message_id = null;
            that.options.related_key = related_key;
            that.messages_text.val('').removeAttr('readonly');

            that.messages_list.html(that.get_chat_placeholder());
            that.updateChat(true, true);
        },

        updateChat: function ($waiting_query = false, $related_message_udpate = false) {
            var that = this;

            if(!$waiting_query && that.update_chat_paused) return false;
            if($waiting_query) {
                that.update_chat_paused = true;
            } 

            var data = {
                "action": 'wdk_messages_chat_public_action',
                "page": 'wdk_messages_chat_frontendajax',
                "function": 'get_messages',
                "related_key": that.options.related_key,
                "latest_message_id": that.latest_message_id,
            };

            if($related_message_udpate) {
                data['related_message'] = 1;
            }

            // Assign handlers immediately after making the request,
            // and remember the jqxhr object for this request
            if(!$waiting_query) {
                if (that.jqxhr != null)
                    that.jqxhr.abort();
            }

            that.jqxhr = jQuery.post( wdk_messages_chat_script_parameters.ajax_url, data , function (data) {
                if(data.success) {
                    that.messages_list.find('.message.placeholder').remove(); 

                    var html='';

                    if(data.output.related_message) {
                        html += '<div class="message" data-message_id="inbox_message">\n\
                                    <div class="wdkchat-message-body">\n\
                                        <div class="text">'+ data.output.related_message.message+'</div>\n\
                                        <div class="footer">'+ data.output.related_message.date+' </div>\n\
                                    </div>\n\
                                </div>';

                        html += '<div class="separed-chat">'+(wdk_messages_chat_script_parameters.text_strings.start_chat)+'</div>';
                    }

                    $.each(data.output.messages, function(index, value) {
                        var message_exists = that.messages_list.find('.message[data-message_id="'+ value.idmessageschat+'"]');   
                        if(message_exists && message_exists.length) {  
                            //_o.find('.date_live').html(value.date_interval)
                        } else {
                            let _cls = '';
                    
                            if(value.outgoing_msg_user_id == that.options.outgoing_msg_user_id){
                                _cls='outcoming_msg';
                            }

                            html += '<div class="message '+_cls+'" data-message_id="'+ value.idmessageschat+'">\n\
                                <div class="wdkchat-thumbnail-user">\n\
                                    <a href="'+ value.profile_url+'">\n\
                                        <img src="'+ value.profile_image+'" alt="'+ value.display_name+'">\n\
                                    </a>\n\
                                </div>\n\
                                <div class="wdkchat-message-body">\n\
                                    <div class="text">'+ value.message+'</div>\n\
                                    <div class="footer">'+ value.date+'</div>\n\
                                </div>\n\
                            </div>';

                        }
                    })
                    
                    that.latest_message_id = data.output.latest_chat_id;

                    if(html != '') {
                        that.messages_list.append(html);
                        that.messages_list.scrollTop(that.messages_list.prop('scrollHeight')  + 250);
                    }

                }
            }).always(function() {
                that.update_chat_paused = false;
            });
        },

        updateChatsList: function () {
            var that = this;

            if(!$waiting_query && that.update_chat_paused) return false;
            if($waiting_query) {
                that.update_chat_paused = true;
            } 

            var data = {
                "action": 'wdk_messages_chat_public_action',
                "page": 'wdk_messages_chat_frontendajax',
                "function": 'get_chats_list',
            };

            // Assign handlers immediately after making the request,
            // and remember the jqxhr object for this request
            if(!$waiting_query) {
                if (that.chat_list_jqxhr != null)
                    that.chat_list_jqxhr.abort();
            }

            that.chat_list_jqxhr = jQuery.post( wdk_messages_chat_script_parameters.ajax_url, data , function (data) {
                if(data.success) {
                    var html='';
                    $.each(data.output.chats_list, function(index, value) {
                        let _cls = '';
                        if(value.idmessage == that.options.related_key){
                            _cls='active';
                        }

                        html += '<div class="chat '+_cls+'" data-chat_id="'+ value.idmessage+'" data-chat_url="'+ value.idmessage+'">\n\
                                    <div class="wdk-chatlst-thumbnail">\n\
                                        <img src="'+ value.profile_image+'" alt="'+ value.display_name+'">\n\
                                    </div>\n\
                                    <div class="wdk-chatlst-body">\n\
                                        <div class="name">'+ value.display_name+''+((value.chat_unread_counter) ? '<span class="count_unread">('+ value.chat_unread_counter+'</div>' : '')+')</span>\n\
                                        <div class="text">'+ value.message+'</div>\n\
                                    </div>\n\
                                </div>';
                    })
                    
                    if(html != '') {
                        that.chats_list.append(html);
                        //that.messages_list.scrollTop(that.messages_list.prop('scrollHeight')  + 250);
                    }

                }
            }).always(function() {
                that.update_chat_paused = false;
            });
        },

        sendMessage: function (message, related_key, outgoing_msg_user_id, outgoing_msg_user_email = '') {
            if(typeof related_key == 'undefined') return false;
            if(message == '') return false;
            var that = this;

            if(that.messages_text.attr('readonly') == 'readonly') return false;

            var loading_el = this.object.find('[type="submit"]')
            var data = {
                "action": 'wdk_messages_chat_public_action',
                "page": 'wdk_messages_chat_frontendajax',
                "function": 'send_message',
                "related_key": related_key,
                "outgoing_msg_user_id": outgoing_msg_user_id,
                "outgoing_msg_user_email": outgoing_msg_user_email,
                "message": message,
            };
            that.messages_text.attr('readonly','readonly');
            loading_el.addClass('loading');

            // Assign handlers immediately after making the request,
            // and remember the jqxhr object for this request
            if (that.jqxhr_submit != null)
                that.jqxhr_submit.abort();

            that.jqxhr_submit = jQuery.post( wdk_messages_chat_script_parameters.ajax_url, data , function (data) {
                if(data.success) {
                    that.messages_text.val('');
                    that.updateChat();
                }
            }).always(function(data) {
                loading_el.removeClass('loading');
                that.messages_text.removeAttr('readonly');

                /* set placeholder */
                that.messages_list.append(
                    '<div class="message outcoming_msg placeholder"><div class="wdkchat-thumbnail-user"><span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span></div>\n\
                    <div class="wdkchat-message-body"><div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;">\n\
                    </span></div><div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div></div></div>'
                );
                that.messages_list.scrollTop(that.messages_list.prop('scrollHeight')  + 250);
            });

            return true;
        },

        get_messages: function (relatedchat_key) {
            if(typeof relatedchat_key == 'undefined') return null;

            var data = {
                "action": 'wdk_messages_chat_public_action',
                "page": 'wdk_messages_chat_frontendajax',
                "function": 'get_messages',
                "related_key": relatedchat_key,
            };
         
            jQuery.ajax({
                url : wdk_messages_chat_script_parameters.ajax_url,
                type : "POST",
                data: data,
                async: true,
                success: function (data) {
                    if(data.success)
                        output = data.output;
                },
            });
            return true;
        },

        /* actions */

        action_open_chat: function () {
            var that = this;
            if(!that.chats_list) return false;

            that.chats_list.find('.chat').on('click', function(e){
                e.preventDefault();
                var self = jQuery(this);

                that.chats_list.find('.chat').removeClass('active');
                self.addClass('active').removeClass('unreaded').find('.count_unread').remove();
                that.regenerateChat(self.data('chat_id'),self.data('user_id'),self.data('user_email'));

                /* header replace */

                that.header_chat.find('.name').html(self.data('user_name'));
                that.header_chat.find('.listing_link').attr('href', self.data('listing_url'));
                that.header_chat.find('.listing_link').html(self.data('listing_name'));

                that.header_chat.find('.thumbnail').attr('href', self.data('user_url'));
                that.header_chat.find('.thumbnail img').attr('src', self.data('user_src'));

                if (self.data('chat_url') && 'history' in window && 'pushState' in history)
                    history.pushState(null, null, self.data('chat_url'));
            });

        },

        /**
         * Is mobile
         */
        is_mobile: function () {
            let check = false;
            (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
            
            return check;
        },

        /**
         * Remove slider instance
         * and unbind all events
         */
        remove: function () {
            this.remove();
        },

        get_chat_placeholder: function () {
            return '<div class="message incoming_msg placeholder"><div class="wdkchat-thumbnail-user"><span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span></div>\n\
                        <div class="wdkchat-message-body"><div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>\n\
                        <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div></div></div>\n\
                        <div class="message outcoming_msg placeholder"><div class="wdkchat-thumbnail-user"><span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span></div>\n\
                        <div class="wdkchat-message-body"><div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>\n\
                        <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div></div></div>\n\
                        <div class="message incoming_msg placeholder"><div class="wdkchat-thumbnail-user"><span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span></div>\n\
                        <div class="wdkchat-message-body"><div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>\n\
                        <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div> </div></div>';
        }
    };
    
    $.fn.WdkMessagesChat_form = function (option, event) {
        //get the args of the outer function..
        var args = arguments;
        var value;
        var chain = this.each(function () {
            var $this = $(this),
                    data = $this.data('WdkMessagesChat_form'),
                    options = typeof option == 'object' && option;

            if (!data) {
                $this.data('WdkMessagesChat_form', (data = new WdkMessagesChat_form(this, options, event)));
            } else if (options) {
                for (var i in options) {
                    data.options[i] = options[i];
                }
            }

            if (typeof option == 'string') {
                //Copy the value of option, as once we shift the arguments
                //it also shifts the value of option.
                var property = option;
                if (data[property] instanceof Function) {
                    [].shift.apply(args);
                    value = data[property].apply(data, args);
                } else {
                    value = data.options[property];
                }
            }
        });

        if (value != undefined) {
            return value;
        } else {
            return chain;
        }
    };

}));
