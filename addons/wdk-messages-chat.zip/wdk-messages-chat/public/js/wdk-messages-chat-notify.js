(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

    $(function () {

        jQuery(document).ready(function($){
            wdk_messages_chat_notify();
        });

    });

})(jQuery);

const wdk_messages_chat_notify = (popup_place) =>{
    if(typeof wdk_messages_disable != 'undefined') return true;

	var $ = jQuery;
    if (!$('.message_live-popup-box').length) $('body').append('<div class="message_live-popup-box"></div>')
    if (typeof popup_place == "undefined") var popup_place = $('.message_live-popup-box');

    var el_timer_end = 10000;
    var el_interval = 20000;

    setInterval(function(){
        var data = {};
        $.extend( data, {
            "action": 'wdk_messages_chat_public_action',
            "page": 'wdk_messages_chat_frontendajax',
            "function": 'notification'
        });

        $.post(wdk_messages_chat_notify_script_parameters.ajax_url, data, 
        function(data){
            if(data.success) {
                var rec = false;

                $.each(data.output.messages, function(index, value){

                    var html = '<div class="message_live-popup">\n\
                               <div class="header">\n\
                                   '+((value.image_src) ? '<div class="prw"><img src="'+ value.image_src +'" alt="'+ value.image_alt+'"></div>' : '')+'\n\
                                   <div class="title">'+ value.title+'</div>\n\
                                   <div class="time">'+ value.date+'</div>\n\
                               </div>\n\
                               <div class="caption">\n\
                                   '+((value.second_title) ? '<div class="capt-title">'+ value.second_title+'</div>' : '')+'\n\
                                   <div class="div capt-text">'+ value.message+'</div>\n\
                               </div>\n\
                               <a href="'+ value.link+'" target="_blank" class="complete_link"></a>\n\
                           </div>';

                    setTimeout(function() {
                        var notification = $(html).appendTo(popup_place).delay(100).queue(function() {
                            $(this).addClass('show')
                            setTimeout(function() {
                                notification.removeClass('show')
                                setTimeout(function() {
                                    notification.remove();
                                }, 1000);
                            }, el_timer_end);

                            var audio = new Audio(wdk_messages_chat_notify_script_parameters.audio_alert);
                            audio.play();
                        });
                    }, 500*index);

                    rec = true;
                })
            } else {

            }
        }).success(function(){
        });
    },el_interval)
}



        
