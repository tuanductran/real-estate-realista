<?php
/**
 * The template for SvgMap Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Svg Map','wdk-messages-chat'); ?>   
 
    <?php echo esc_html__('Demo Page','wdk-messages-chat'); ?>   
</div>

<?php $this->view('general/footer', $data); ?>