<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Messageschat_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_messages_chat';
	public $_order_by = 'idmessageschat DESC';
    public $_primary_key = 'related_key';
    public $_own_columns = array();
    public $_timestamps = FALSE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list_dash = NULL;
    public $fields_list = NULL;
    public $current_user_id = NULL;
    
	public function __construct() {
        parent::__construct();
        $this->current_user_id = get_current_user_id();
                
        $this->fields_list_dash = array (
            array(
                'field' => 'post_id',
                'field_label' => __('Listing id', 'wpdirectorykit'),
                'hint' => '', 
                'field_type' => 'LISTING_READONLY', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list_dash as $key=>$field)
        {
            $this->fields_list_dash[$key]['label'] = $field['field_label'];
        }
	}

    /* [START] For dynamic data table */
    
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($related_key = NULL, $where = array())
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        if(!empty($related_key)) {
            $this->db->join($this->db->prefix.'wdk_messages ON '.$this->db->prefix.'wdk_messages.idmessage = '.$this->_table_name.'.related_key');
            $this->db->where(array('related_key'=>$related_key));
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($related_key = NULL, $limit = 100, $offset = NULL, $where = array(), $order_by = NULL)
    {
        $this->db->select($this->_table_name.'.*');
       
        $this->db->from($this->_table_name);

        if(!empty($related_key)) {
            $this->db->join($this->db->prefix.'wdk_messages ON '.$this->db->prefix.'wdk_messages.idmessage = '.$this->_table_name.'.related_key');
            $this->db->where(array('related_key'=>$related_key));
        }

        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $query = $this->db->get();
        
        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function total_relationship_user($user_id = NULL, $where = array())
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);

        $table_messages = "{$this->db->prefix}wdk_messages";
        $this->db->join($table_messages.' ON '.$table_messages.'.idmessage = '.$this->_table_name.'.related_key');
        $this->db->join($this->db->prefix.'wdk_listings ON '.$this->db->prefix.'wdk_listings.post_id = '.$table_messages.'.post_id', NULL, 'LEFT');

        $this->db->where($where);
        $this->db->order_by($this->_order_by);

        if(!empty($user_id)) {
            $user_id = intval($user_id);
            $this->db->where("(user_id_editor = {$user_id} OR user_id_sender = {$user_id} OR user_id_receiver = {$user_id})");
            
            /* no self messages */
            $this->db->where("(outgoing_msg_user_id != {$user_id})");
        }

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination_relationship_user($user_id = NULL, $limit = 100, $offset = NULL, $where = array(), $order_by = NULL)
    {

        $post_table = $this->db->prefix.'posts';
     
        $table_messages = "{$this->db->prefix}wdk_messages";
        $this->db->select("{$post_table}.post_title, idmessage,{$table_messages}.post_id,{$table_messages}.date,user_id_sender,email_sender, {$table_messages}.message,
                            is_readed,idmessageschat,outgoing_msg_user_id,outgoing_msg_user_email,chat_is_readed,idlisting,user_id_editor,
                            {$this->_table_name}.message AS chat_message,
                            {$this->_table_name}.date AS chat_date,listing_images,listing_images_path
                        ");
       
        $this->db->from($this->_table_name);
        
        $this->db->join($table_messages.' ON '.$table_messages.'.idmessage = '.$this->_table_name.'.related_key');
        $this->db->join($this->db->prefix.'wdk_listings ON '.$this->db->prefix.'wdk_listings.post_id = '.$table_messages.'.post_id', NULL, 'LEFT');
        $this->db->join($post_table.' ON '.$table_messages.'.post_id = '.$post_table.'.ID', NULL, 'LEFT');

        if(!empty($user_id)) {
            $user_id = intval($user_id);
            $this->db->where("(user_id_editor = {$user_id} OR user_id_sender = {$user_id} OR user_id_receiver = {$user_id})");
            
            /* no self messages */
            $this->db->where("(outgoing_msg_user_id != {$user_id})");
        }

        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $query = $this->db->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        return true;
    }
    
    /* [END] For dynamic data table */

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $this->db->select('*');
        $this->db->join($this->db->prefix.'wdk_listings ON '.$this->db->prefix.'wdk_listings.post_id = '.$this->db->prefix.'wdk_messages.post_id', NULL, 'LEFT');
        $this->db->where(array($this->db->prefix.'wdk_messages`.`idmessage' => $item_id));
       
        $query = $this->db->get($this->db->prefix.'wdk_messages', 1);
        $row = $this->db->row();
        
        if(wmvc_show_data('user_id_editor', $row) == $user_id || wmvc_show_data('user_id_sender', $row) == $user_id || wmvc_show_data('user_id_receiver', $row) == $user_id )
            return true;
            
        return false;
    }

    public function do_readed_notified($related_key = NULL)
    {
        if($related_key === NULL)
            return false;

        global $wpdb;
        $user_id = get_current_user_id();
        if($user_id){
            $wpdb->query("UPDATE `{$this->_table_name}` SET `chat_is_readed` = 1, `chat_is_notified` = 1 WHERE `related_key` = {$related_key} AND `outgoing_msg_user_id`!= {$user_id}");
            return true;
        }

        return false;
    }

    public function read_related($related_key = NULL)
    {
        if($related_key === NULL)
            return false;

        global $wpdb;
        $user_id = get_current_user_id();
        if($user_id){
            $wpdb->query("UPDATE `{$this->_table_name}` SET `chat_is_readed` = 1 WHERE `related_key` = {$related_key} AND `outgoing_msg_user_id`!= {$user_id}");
            return true;
        }

        return false;
    }

    public function do_notified($related_key = NULL)
    {
        if($related_key === NULL)
            return false;

        global $wpdb;
        $user_id = get_current_user_id();
        if($user_id){
            $wpdb->query("UPDATE `{$this->_table_name}` SET `chat_is_notified` = 1 WHERE `related_key` = {$related_key} AND `outgoing_msg_user_id`!= {$user_id}");
            return true;
        }

        return false;
    }

    public function do_notified_by_user($user_id = NULL)
    {
        if(empty($user_id))
            $user_id = get_current_user_id();

        global $wpdb;
        if($user_id){
            $wpdb->query("UPDATE `{$this->_table_name}` 
                            JOIN `{$this->db->prefix}wdk_messages` ON {$this->db->prefix}wdk_messages.idmessage = {$this->_table_name}.related_key  
                            LEFT JOIN `{$this->db->prefix}wdk_listings` ON `{$this->db->prefix}wdk_listings`.post_id = `{$this->db->prefix}wdk_messages`.post_id  
                            SET `chat_is_notified` = 1 
                            WHERE 
                            (`user_id_editor` = {$user_id}
                            OR `user_id_sender` = {$user_id}
                            OR `user_id_receiver` = {$user_id})
                            AND `outgoing_msg_user_id`!= {$user_id}
                        ");
            return true;
        }

        return false;
    }

}
?>