<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_messages_chat_frontendajax extends Winter_MVC_Controller {
	private $cookie_key_notify_last_message_id = 'wdk_messages_chat_notify_last_message_id';
	private $cookie_key_notify_last_chat_id = 'wdk_messages_chat_notify_last_chat_id';

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

	/* get notification  */
	public function get_chats_list ($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');
		$Winter_MVC_WDK->model('messages_m');
		$this->load->model('messageschat_m');

		$current_user_id = get_current_user_id();

		if($current_user_id != '' && empty($data['popup_text_error'])) {
			$output = '';
			$output = array();
			$output['chats_list'] = array();

			/* chats */
			$chats = $Winter_MVC_WDK->messages_m->get_pagination_merge(30, 0, array(), NULL, TRUE, NULL, true);


			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$output['chats_sql'] = $this->db->last_query();

			if($chats) {
				foreach ($chats as $chat) {

					$userdata = wdk_get_user_data($chat->user_id_editor);
					$chat->profile_image = (!empty($userdata)) ? $userdata['avatar'] : '#';
					$chat->profile_url = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
					$chat->display_name = wdk_get_user_field($chat->user_id_editor, 'display_name');
					$chat->chat_link = esc_url(wdk_dash_url('dash_page=messages&function=chat&id=' . wmvc_show_data('idmessage', $chat)));

					$output['chats_list'][] = $chat;

					if($output['latest_chat_id'] < $message->idmessage) {
						$output['latest_chat_id'] = $message->idmessage;
					}
				}
			}

			$output['chats_list'] = array_reverse($output['chats_list']);

			if(!empty($output['latest_chat_id'])){
				setcookie( $this->cookie_key_notify_last_chat_id, $output['latest_chat_id'], time() + 7200, '/', $_SERVER['SERVER_NAME'], false );
			}
			if(!empty($output['latest_message_id'])){
				setcookie( $this->cookie_key_notify_last_message_id, $output['latest_message_id'], time() + 7200, '/', $_SERVER['SERVER_NAME'], false );
			}

			$data['success'] = true;
			$data['output'] = $output;
		}

		$this->output($data);
    }

	/* get notification  */
	public function notification ($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');
		$Winter_MVC_WDK->model('messages_m');
		$this->load->model('messageschat_m');

		$current_user_id = get_current_user_id();

		if($current_user_id != '' && empty($data['popup_text_error'])) {
			$output = '';
			$output = array();
			$output['latest_chat_id'] = NULL;
			$output['latest_message_id'] = NULL;
			$output['messages'] = array();
			if(isset($_COOKIE[$this->cookie_key_notify_last_chat_id])) {
				$output['latest_chat_id'] = $_COOKIE[$this->cookie_key_notify_last_chat_id];
			}

			if(isset($_COOKIE[$this->cookie_key_notify_last_message_id])) {
				$output['latest_message_id'] = $_COOKIE[$this->cookie_key_notify_last_message_id];
			}
			/* chat messages */
			$messages_chat = $this->messageschat_m->get_pagination_relationship_user($current_user_id, 50, NULL, array(
									$this->messageschat_m->_table_name.'.date > "'.date('Y-m-d H:i:s', time() - 86400).'"'=> NULL,
									'(chat_is_readed IS NULL AND chat_is_notified IS NULL)'=>NULL,
									'(idmessageschat > '.intval($output['latest_chat_id']).')'=>NULL,
								));


			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$output['chat_sql'] = $this->db->last_query();

			if($messages_chat) {
				$this->messageschat_m->do_notified_by_user($current_user_id);
				foreach ($messages_chat as $message) {
					$message->second_title = '';

					$userdata = wdk_get_user_data($message->outgoing_msg_user_id);

					if($message->post_title) {
						$message->title = $message->post_title;
						$message->second_title = esc_html__('From','wdk-messages-chat').' '.wdk_get_user_field($message->outgoing_msg_user_id, 'display_name');
						
						$message->image_src = wdk_image_src($message, 'full');
						$message->image_alt = $message->post_title;
					} else {
						$message->title = wdk_get_user_field($message->outgoing_msg_user_id, 'display_name');
						$message->image_src = (!empty($userdata)) ? $userdata['avatar'] : '';
						$message->image_alt = wdk_get_user_field($message->outgoing_msg_user_id, 'display_name');
					}
					
					$message->message = wmvc_character_hard_limiter($message->chat_message, 50);
					$message->user_email = wdk_get_user_field($message->outgoing_msg_user_id, 'user_email');
					$message->date = wdk_get_date($message->chat_date);

					$message->link = get_admin_url() . "admin.php?page=wdk_messages&function=edit&id=".$message->idmessage;
					if(function_exists('wdk_dash_url') && get_option('wdk_membership_dash_page') &&  wdk_dash_url()){
						$message->link = wdk_dash_url('dash_page=messages&function=chat&id=' . $message->idmessage);
					} 
					
					$output['messages'][] = $message;

					if($output['latest_chat_id'] < $message->idmessageschat) {
						$output['latest_chat_id'] = $message->idmessageschat;
					}
				}
			}

			/* form messages */
			$messages_form = $Winter_MVC_WDK->messages_m->get_pagination(50, NULL, array(
									$Winter_MVC_WDK->messages_m->_table_name.'.date > "'.date('Y-m-d H:i:s', time() - 86400).'"'=> NULL,
									'(is_readed IS NULL AND is_notified IS NULL)'=>NULL,
									'(idmessage > '.intval($output['latest_message_id']).')'=>NULL,
								), NULL, TRUE);
			
			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$output['messages_sql'] = $this->db->last_query();
			
			if($messages_form) {
				$Winter_MVC_WDK->messages_m->do_notified_by_user($user_id = NULL);
				foreach ($messages_form as $message) {
					$message->title = '';
					$message->second_title = ''; 
					$message->image_src = '';
					$message->image_alt = '';
					$message->user_email = '';
					$message->link = get_admin_url() . "admin.php?page=wdk_messages";
					$message->message = wmvc_character_hard_limiter($message->message, 50);
					$message->date = wdk_get_date($message->date);

					/* message from form on listing preview */
					if(!empty($message->post_id)) {
						if($message->user_id_editor == $current_user_id) {
							$message->title = wmvc_character_hard_limiter($message->post_title, 50);
							$message->image_src = wdk_image_src($message, 'full');
							$message->image_alt = wmvc_character_hard_limiter($message->post_title, 50);

							if($message->user_id_sender) {
								$message->second_title = esc_html__('From','wdk-messages-chat').' '.wdk_get_user_field($message->user_id_sender, 'display_name');
								$message->user_email = wdk_get_user_field($message->user_id_sender, 'user_email');
							} 

							$message->link = get_admin_url() . "admin.php?page=wdk_messages&function=edit&id=".$message->idmessage;
							if(function_exists('wdk_dash_url') && get_option('wdk_membership_dash_page') &&  wdk_dash_url()){
								$message->link = wdk_dash_url('dash_page=messages&function=chat&id=' . $message->idmessage);

								if(empty(wmvc_show_data('user_id_sender', $message, '')))
									$message->link = wdk_dash_url('dash_page=messages&function=edit&id=' . $message->idmessage);
							} 

							$output['messages'][] = $message;
						} 
					}
					/* message from other forms */
					else {
					}

					if($output['latest_message_id'] < $message->idmessage) {
						$output['latest_message_id'] = $message->idmessage;
					}
				}
			}

			$output['messages'] = array_reverse($output['messages']);

			if(!empty($output['latest_chat_id'])){
				setcookie( $this->cookie_key_notify_last_chat_id, $output['latest_chat_id'], time() + 7200, '/', $_SERVER['SERVER_NAME'], false );
			}
			if(!empty($output['latest_message_id'])){
				setcookie( $this->cookie_key_notify_last_message_id, $output['latest_message_id'], time() + 7200, '/', $_SERVER['SERVER_NAME'], false );
			}

			$data['success'] = true;
			$data['output'] = $output;
		}

		$this->output($data);
    }

	/* get messages */
	public function get_messages($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		if(!isset($parameters['latest_chat_id'])) {
			$parameters['latest_chat_id'] = NULL;
		}

		global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');
		$Winter_MVC_WDK->model('messages_m');

		$this->load->model('messageschat_m');

		if(empty($parameters['related_key'])) {
			$data['popup_text_error'] = esc_html__('Missing related_key','wdk-messages-chat');
		}

		if(!$this->messageschat_m->is_related($parameters['related_key'], get_current_user_id())) {
			$data['popup_text_error'] = esc_html__('Chat is not related account','wdk-messages-chat');
		} 

		if(empty($data['popup_text_error'])) {
			$output =  array();
			$output['related_message'] = NULL;
			$output['latest_chat_id'] = NULL;
			$output['messages'] = array();

			$this->messageschat_m->do_readed_notified($parameters['related_key']);

			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$output['do_readed_notified_sql'] = $this->db->last_query();


			$messages = $this->messageschat_m->get_pagination($parameters['related_key'], 50, NULL, array(
																	'(idmessageschat > '.intval($parameters['latest_chat_id']).')'=>NULL,
																));
			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$output['sql_get_messages_chat'] = $this->db->last_query();

			if($messages) {

				foreach ($messages as $message) {
					if(!empty($message->outgoing_msg_user_id)) {
						$userdata = wdk_get_user_data($message->outgoing_msg_user_id);
						$message->profile_image = (!empty($userdata)) ? $userdata['avatar'] : '#';
						$message->profile_url = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
						$message->display_name = wdk_get_user_field($message->outgoing_msg_user_id, 'display_name');
						$message->user_email = wdk_get_user_field($message->outgoing_msg_user_id, 'user_email');
						$message->date = wdk_get_date($message->date);

						$output['messages'][] = $message;
					}
					
					if($output['latest_chat_id'] < $message->idmessageschat) {
						$output['latest_chat_id'] = $message->idmessageschat;
					}
				}
			}

			$output['messages'] = array_reverse($output['messages']);
			
			if(isset($parameters['related_message']) && $parameters['related_message'] == 1) {
				$output['related_message'] = $Winter_MVC_WDK->messages_m->get(intval($parameters['related_key']), true);
				if(defined( 'WP_DEBUG' ) && WP_DEBUG)
					$output['sql_get_inbox_message'] = $this->db->last_query();

				if($output['related_message']) {
					$Winter_MVC_WDK->messages_m->_timestamps = false;
					$Winter_MVC_WDK->messages_m->insert(array('is_readed'=>1), $output['related_message']->idmessage);
					$output['related_message']->date = wdk_get_date($output['related_message']->date);
					$output['related_message']->message = (!empty($output['related_message']->message)) ? $output['related_message']->message : esc_html__('No inquiry Message','wdk-messages-chat');
				}
			}

			$data['success'] = true;
			$data['output'] = $output;
		}

		$this->output($data);
    }

	/* send update */
	public function update($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		if(empty($parameters['related_key'])) {
			$data['popup_text_error'] = esc_html__('Missing related_key','wdk-messages-chat');
		}

		$this->load->model('messageschat_m');
		if(!$this->messageschat_m->is_related($parameters['related_key'], get_current_user_id())) {
			$this->messageschat_m->do_readed_notified($parameters['related_key']);
			$data['success'] = true;
		}

		$this->output($data);
    }

	/* send messages */
	public function send_message($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		if(empty($parameters['related_key'])) {
			$data['popup_text_error'] = esc_html__('Missing related_key','wdk-messages-chat');
		}
		$this->load->model('messageschat_m');
		if(!$this->messageschat_m->is_related($parameters['related_key'], get_current_user_id())) {
			$data['popup_text_error'] = esc_html__('Chat is not related account','wdk-messages-chat');
		}

		if(empty($data['popup_text_error'])) {
			$insert_id = $this->messageschat_m->insert(array(
				'related_key' =>$parameters['related_key'],
				'outgoing_msg_user_id' => wmvc_show_data('outgoing_msg_user_id', $parameters, '', FALSE, TRUE),
				'outgoing_msg_user_email' => wmvc_show_data('outgoing_msg_user_email', $parameters, '', FALSE, TRUE),
				'message' => wmvc_show_data('message', $parameters, '', FALSE, TRUE),
				'date' => date('Y-m-d H:i:s'),
			), NULL);

            if(defined( 'WP_DEBUG' ) && WP_DEBUG)
                $data['last_query'] = $this->db->last_query();

			if($insert_id)
				$data['success'] = true;
		}

		$this->output($data);
    }

    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
