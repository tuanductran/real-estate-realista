<?php

/**
 * Fired during plugin deactivation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Duplicate_Listing
 * @subpackage Wdk_Duplicate_Listing/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wdk_Duplicate_Listing
 * @subpackage Wdk_Duplicate_Listing/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Duplicate_Listing_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
