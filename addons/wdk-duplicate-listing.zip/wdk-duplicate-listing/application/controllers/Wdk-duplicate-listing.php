<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_duplicate_listing_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{

        echo '';
       
    }
    
	public function duplicate()
	{
        global $Winter_MVC_WDK;

        $Winter_MVC_WDK->model('field_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('listingfield_m');
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('user_m');
        $Winter_MVC_WDK->model('categorieslistings_m');
        $Winter_MVC_WDK->model('locationslistings_m');
        $Winter_MVC_WDK->load_helper('listing');

        $this->data['db_data'] = NULL;
        $this->data['db_data']['listing_agents'] = array();
        $this->data['db_data']['listing_sub_locations'] = array();
        $this->data['db_data']['listing_sub_categories'] = array();

        $listing_post_id = $this->input->post_get('listing_post_id');
        
        if(empty($listing_post_id)) {
            exit('Listing Not Cloned');
        }

        /* get listing data */
        if(!empty($listing_post_id))
        {
            $listing_post = get_post( $listing_post_id );
            $listing_db_data = $Winter_MVC_WDK->listing_m->get($listing_post_id, TRUE);
            $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($listing_post_id, TRUE);

            $this->data['db_data'] = array_merge((array) $listing_post, 
                                                 (array) $listing_db_data, 
                                                 (array) $listingfield_db_data);
           
           
        } 
        /* save */
        if(!empty($this->data['db_data'])) {

            // Create post object
            $listing_post = array(
                'ID' => NULL,
                'post_type'     => 'wdk-listing',
                'post_title'    => wp_strip_all_tags( $this->data['db_data']['post_title'] ),
                'post_content'  => $this->data['db_data']['post_content'],
                'post_status'   => 'publish',
                'post_author'   => get_current_user_id()
            );
            
            // Insert the post into the database
            $id = wp_insert_post( $listing_post );

            if(empty($id)) {
                exit('Listing Not Cloned');
            }

            $listing_data = array('post_id' => $id);
            $listing_data_fields = array('category_id', 'location_id', 'address', 'lat', 'lng', 'listing_images', 'is_featured', 'is_activated','is_approved', 'rank','user_id_editor','listing_images_path');
            foreach($listing_data_fields as $field_name)
            {
                if(isset($this->data['db_data'][$field_name]))
                    $listing_data[$field_name] = $this->data['db_data'][$field_name];
            }

            $listing_data['date_modified'] = date('Y-m-d H:i:s');
            $Winter_MVC_WDK->listing_m->insert($listing_data, NULL);

            $this->db->where(array('field_type !='=> 'SECTION'));
            $this->data['listing_fields'] = $Winter_MVC_WDK->field_m->get();


            $listingfield = array('post_id' => $id);
            foreach($this->data['listing_fields'] as $key => $field)
            {
                if(isset($listingfield_db_data->{'field_'.$field->idfield.'_'.$field->field_type}))
                    $listingfield['field_'.$field->idfield] = $listingfield_db_data->{'field_'.$field->idfield.'_'.$field->field_type};
            }

            $Winter_MVC_WDK->listingfield_m->insert_custom_fields($this->data['listing_fields'], $listingfield, NULL);

            $listing_sub_categories = wdk_generate_other_categories_keys($listing_post_id);
            if($listing_sub_categories) {
                $Winter_MVC_WDK->categorieslistings_m->delete_where(array('post_id' => $id));
                foreach($listing_sub_categories as $val)
                {
                    $Winter_MVC_WDK->categorieslistings_m->insert(array('post_id' => $id, 'category_id' => $val), NULL);
                }
            }

            $listing_sub_locations = wdk_generate_other_locations_keys($listing_post_id);
            if($listing_sub_locations) {
                $Winter_MVC_WDK->locationslistings_m->delete_where(array('post_id' => $id));
                foreach($listing_sub_locations as $val)
                {
                    $Winter_MVC_WDK->locationslistings_m->insert(array('post_id' => $id, 'location_id' => $val), NULL);
                }
            }

            wp_redirect(admin_url("admin.php?page=wdk_listing&id=$id&is_updated=true&custom_message=".urlencode(esc_html__('Listing successfully duplicated, you are now located on duplicated listing','wdk-duplicate-listing'))));
            exit;
        }
        
    }

   
}
