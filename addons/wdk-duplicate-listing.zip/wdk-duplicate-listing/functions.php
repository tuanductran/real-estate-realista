<?php

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wdk_duplicate_listing() {

	$plugin = new Wdk_Duplicate_Listing();
	$plugin->run();

}




?>