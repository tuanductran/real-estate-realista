<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Duplicate_Listing
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Duplicate Listing
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-duplicate-listing.html
 * Description:       Duplicate any listing in admin backend dashboard
 * Version:           1.0.1
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-duplicate-listing
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_DUPLICATE_LISTING_VERSION', '1.0.1' );
define( 'WDK_DUPLICATE_LISTING_NAME', 'wdk-duplicate-listing' );
define( 'WDK_DUPLICATE_LISTING_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_DUPLICATE_LISTING_URL', plugin_dir_url( __FILE__ ) );

require plugin_dir_path( __FILE__ ) . 'functions.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-duplicate-listing-activator.php
 */
function activate_wdk_duplicate_listing() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-duplicate-listing-activator.php';
	Wdk_Duplicate_Listing_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-duplicate-listing-deactivator.php
 */
function deactivate_wdk_duplicate_listing() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-duplicate-listing-deactivator.php';
	Wdk_Duplicate_Listing_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_duplicate_listing' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_duplicate_listing' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-duplicate-listing.php';

if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    run_wdk_duplicate_listing();
}



