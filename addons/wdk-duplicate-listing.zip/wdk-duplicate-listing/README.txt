=== Plugin Name ===
Contributors: listingthemes
Donate link: https://wpdirectorykit.com/donate/
Tags: comments, spam
Requires at least: 5.2
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Duplicate any listing in admin backend dashboard

== Description ==

Duplicate any listing in admin backend dashboard

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `wdk-duplicate-listing.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently Asked Questions ==

= How to duplicate listing =

In admin dash, when edit listing click on duplicate listing button on top right

== Screenshots ==

1. Duplicate Listing Button

== Changelog ==

= 1.0 =
* Init

