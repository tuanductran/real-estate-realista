<?php __('House','wpdirectorykit');
__('Apartment','wpdirectorykit');
__('Agriculture','wpdirectorykit');
__('Commercial','wpdirectorykit');
__('Industrial','wpdirectorykit');
__('Garage','wpdirectorykit');
__('Parking','wpdirectorykit');

?>