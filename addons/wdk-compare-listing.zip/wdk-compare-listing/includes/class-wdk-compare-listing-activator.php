<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Compare_Listing
 * @subpackage Wdk_Compare_Listing/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Compare_Listing
 * @subpackage Wdk_Compare_Listing/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Compare_Listing_Activator {
	public static $db_version = 1.1;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_compare_listing_';
	}

	public static function plugins_loaded(){
    
		if (get_site_option( 'wdk_compare_listing_db_version' ) === false ||
            get_site_option( 'wdk_compare_listing_db_version' ) < self::$db_version ) {
			self::install();
		}
    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_compare_listing_db_version' ) === false)
        {
            $table_name = $wpdb->prefix . 'wdk_compare_listing';

            $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                        `idcompare_listing` int(11) NOT NULL AUTO_INCREMENT,
                        `user_id` int NULL DEFAULT NULL,
                        `parameters` text DEFAULT NULL,
                        `date` datetime DEFAULT NULL,
                        `date_notify` datetime DEFAULT NULL,
                PRIMARY KEY  (idcompare_listing)
                ) $charset_collate;";

 			dbDelta( $sql );

            // Main table for visited pages
            update_option( 'wdk_compare_listing_db_version', "1" );

        }
        update_option( 'wdk_compare_listing_db_version', "1" );
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_compare_listing_db_version' ) < '1.1' ) {
            $table_name = $wpdb->prefix . 'wdk_compare_listing';
            $sql = "ALTER TABLE `$table_name` ADD `is_enable_email_notify` tinyint(1) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.1;
            /* udpate option with db version */
        }

        update_option( 'wdk_compare_listing_db_version', self::$db_version );
    }

}
