(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	$(function () {
        /* init compare */
        wdk_init_compare_elem();
    });

})(jQuery);


const wdk_init_compare_elem = () => {
	var $ = jQuery;
	let compare_widget_flow = jQuery('.wdk-compare-widget');
	let compare_widget = jQuery('.wdk-compare-listing');
	let compare_action = jQuery('.wdk-compare-listing-button-actions');
	let load_indicator = compare_widget.find('.wdk-compare-listing-button');
	var xhr = false;
	var loading_activate = () => {
		load_indicator.addClass('loading');
	};

	var loading_deactivate = () => {
		load_indicator.removeClass('loading');
	};

	var setCookie = (cname, cvalue, exdays) => {
		var d = new Date();
		d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
		var expires = "expires="+d.toUTCString();
		document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}

	var getCookie = (cname) => {
		var name = cname + "=";
		var ca = document.cookie.split(';');
		for(var i = 0; i < ca.length; i++) {
			var c = ca[i];
			while (c.charAt(0) == ' ') {
				c = c.substring(1);
			}
			if (c.indexOf(name) == 0) {
				return c.substring(name.length, c.length);
			}
		}
		return "";
	};

	/* ajax query, do step by query finish */
	var ajaxQueue = $({});
	$.ajaxQueue = function(ajaxOpts) {
	  // hold the original complete function
	  var oldComplete = ajaxOpts.complete;
  
	  // queue our ajax request
	  ajaxQueue.queue(function(next) {    
  
		// create a complete callback to fire the next event in the queue
		ajaxOpts.complete = function() {
		  // fire the original complete if it was there
		  if (oldComplete) oldComplete.apply(this, arguments);    
		  next(); // run the next query in the queue
		};
  
		// run the query
		$.ajax(ajaxOpts);
	  });
	};

	/* remove */
	var remove_from_compare = function() {

		var event = (e, el) => {
			e.preventDefault();

			var self = el;
			var wdk_post_id = el.attr('data-post_id')
			var conf_link = el.attr('data-url')

			var data = [];
			data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
			data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
			data.push({ name: 'function', value: "remove_from_compare" });
			data.push({ name: 'post_id', value: wdk_post_id });
			
			loading_activate();
			self.addClass('loading');
			$.ajax({
				type: 'POST',
				url: conf_link,
				data: data,
				success: function(data){
					if(data.message)
						box_alert.html(data.message);
		
					if(data.popup_text_success)
						wdk_log_notify(data.popup_text_success);
						
					if(data.popup_text_error)
						wdk_log_notify(data.popup_text_error, 'error');
						
					if(data.success)
					{
					
					} else {
						
					}
				}
			}).done(function( ) {
				loading_deactivate();
				self.removeClass('loading');
				self.parent().remove();
				generate_compare_list();
			});

			return false;
		};

		$(compare_widget).find(".wdk_item_remove").off().on('click', function(e) {
			event(e, $(this));
		});

		if(compare_widget_flow)
			$(compare_widget_flow).find(".wdk_item_remove").off().on('click', function(e) {
				event(e, $(this));
			});
	}

	/* get and generate compare list */
	var get_compare_list = function() {
		var self = $(this);
		var conf_link = compare_widget.find('.config').attr('data-url');

		if(compare_action.length)
			conf_link = compare_action.find('.config').attr('data-url');

		var data = [];
		data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
		data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
		data.push({ name: 'function', value: "get_compare_list" });
					 
		loading_activate();

		//if(xhr)
		//	xhr.abort();

		xhr = $.post(conf_link, data, 
			function (data) {
				
			if(data.message)
				box_alert.html(data.message);

			if(data.popup_text_success)
				wdk_log_notify(data.popup_text_success);
				
			if(data.popup_text_error)
				wdk_log_notify(data.popup_text_error, 'error');
				
			if(data.success)
			{
				$('.wdk-compare-listing-button-actions').find("a.wdk-add-compare-action").removeClass('wdk-hidden');
				$('.wdk-compare-listing-button-actions').find("a.wdk-remove-compare-action").addClass('wdk-hidden');

				if (data.output) {
					var html = '';
					$.each(data.output, function(i, v) {
						html += '<div class="wdk-item" data-post_id="' + v.post_id + '"><a target="_blank" class="value" href="' + v.link + '">' + v.value + '</a> <a class="wdk_item_remove" href="#"  data-post_id="' + v.post_id + '" data-url="' + conf_link + '"> <i class="fa fa-remove"></i><i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking"></i></a></div>'
					
						$('.wdk-compare-listing-button-actions[data-post_id="'+ v.post_id+'"]').find("a.wdk-add-compare-action").addClass('wdk-hidden');
						$('.wdk-compare-listing-button-actions[data-post_id="'+ v.post_id+'"]').find("a.wdk-remove-compare-action").removeClass('wdk-hidden');
					})

					compare_widget.find('.сompare_list').html(html);
					
					if(compare_widget_flow.length) {
						compare_widget_flow.find('.сompare_list').html(html);
					}
				} else {}
				
			} else {
				
			}
		}).always(function(data) {
			loading_deactivate();
			remove_from_compare();

			if(compare_widget.find('.сompare_list').children().length > 1) {
				compare_widget.find('.open_compare_link').removeClass('wdk-hidden');
			} else {
				compare_widget.find('.open_compare_link').addClass('wdk-hidden');
			}

			if(compare_widget_flow.length && compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length) {
				compare_widget_flow.addClass('active').removeClass('wdk-hidden');
				if(compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length >1) {
					compare_widget_flow.find('.open_compare_link').removeClass('wdk-hidden');
				}
				else {
					compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
				}
				compare_widget_flow.find('.no_listings').hide();
			} else {
				compare_widget_flow.find('.no_listings').show();
				compare_widget_flow.addClass('wdk-hidden');
				compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
			}
		});
	}

	/* generate compare list on data */
	var output_compare_list = function(data, ajax_link) {

		$('.wdk-compare-listing-button-actions').find("a.wdk-add-compare-action").removeClass('wdk-hidden');
		$('.wdk-compare-listing-button-actions').find("a.wdk-remove-compare-action").addClass('wdk-hidden');
		var html = '';
		$.each(data, function(i, v) {
			html +='<div class="wdk-item" data-post_id="' + v.post_id + '"><a target="_blank" class="value" href="' + v.link + '">' + v.value + '</a> <a class="wdk_item_remove" href="#"  data-post_id="' + v.post_id + '" data-url="' + ajax_link + '"> <i class="fa fa-remove"></i><i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking"></i></a></div>'
		
			$('.wdk-compare-listing-button-actions[data-post_id="'+ v.post_id+'"]').find("a.wdk-add-compare-action").addClass('wdk-hidden');
			$('.wdk-compare-listing-button-actions[data-post_id="'+ v.post_id+'"]').find("a.wdk-remove-compare-action").removeClass('wdk-hidden');
		})

		compare_widget.find('.сompare_list').html(html);
		
		if(compare_widget_flow.length) {
			compare_widget_flow.find('.сompare_list').html(html);
		}

		remove_from_compare();

		if(compare_widget.find('.сompare_list').children().length > 1) {
			compare_widget.find('.open_compare_link').removeClass('wdk-hidden');
		} else {
			compare_widget.find('.open_compare_link').addClass('wdk-hidden');
		}

		if(compare_widget_flow.length && compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length) {
			compare_widget_flow.addClass('active').removeClass('wdk-hidden');
			if(compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length >1) {
				compare_widget_flow.find('.open_compare_link').removeClass('wdk-hidden');
			}
			else {
				compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
			}
			compare_widget_flow.find('.no_listings').hide();
		} else {
			compare_widget_flow.find('.no_listings').show();
			compare_widget_flow.addClass('wdk-hidden');
			compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
		}
	}

	/* generate compare list */
	var generate_compare_list = function() {

		if(compare_widget_flow.length) {
			$('.wdk-compare-listing-button-actions').find("a.wdk-add-compare-action").removeClass('wdk-hidden');
			$('.wdk-compare-listing-button-actions').find("a.wdk-remove-compare-action").addClass('wdk-hidden');

			compare_widget_flow.find('.wdk-item').each(function(){
				$('.wdk-compare-listing-button-actions[data-post_id="'+ $(this).attr('data-post_id') +'"]').find("a.wdk-add-compare-action").addClass('wdk-hidden');
				$('.wdk-compare-listing-button-actions[data-post_id="'+ $(this).attr('data-post_id') +'"]').find("a.wdk-remove-compare-action").removeClass('wdk-hidden');
			});

			if(compare_widget.find('.сompare_list').children().length > 1) {
				compare_widget.find('.open_compare_link').removeClass('wdk-hidden');
			} else {
				compare_widget.find('.open_compare_link').addClass('wdk-hidden');
			}

			if(compare_widget_flow.length && compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length) {
				compare_widget_flow.addClass('active').removeClass('wdk-hidden');
				if(compare_widget_flow.find('.сompare_list').find('.wdk-item:not(.message)').length >1) {
					compare_widget_flow.find('.open_compare_link').removeClass('wdk-hidden');
				}
				else {
					compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
				}
				compare_widget_flow.find('.no_listings').hide();
			} else {
				compare_widget_flow.find('.no_listings').show();
				compare_widget_flow.addClass('wdk-hidden');
				compare_widget_flow.find('.open_compare_link').addClass('wdk-hidden');
			}

		}
		
	}

	// [START] Add to compare //  
	compare_widget.find(".wdk-compare-listing-button").off().on('click', function(e) {
		e.preventDefault();

		var self = $(this);
		var wdk_post_id = $(this).attr('data-post_id')
		var conf_link = $(this).attr('data-url')

		var data = [];
		data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
		data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
		data.push({ name: 'post_id', value: wdk_post_id });

		if(self.hasClass('wdk-active')) {
			data.push({ name: 'function', value: "remove_from_compare" });
		} else {
			data.push({ name: 'function', value: "add_to_compare" });
		}
		
		loading_activate();
		$.post(conf_link, data, 
			function (data) {
				
			if(data.message)
				box_alert.html(data.message);

			if(data.popup_text_success)
				wdk_log_notify(data.popup_text_success);
				
			if(data.popup_text_error)
				wdk_log_notify(data.popup_text_error, 'error');
				
			if(data.success)
			{
				output_compare_list(data.output, conf_link);
			} else {
				
			}
		}).always(function(data) {
			loading_deactivate();
		
			self.toggleClass('wdk-active');
		});

		return false;
	});

	var compare_actions = (compare_action) => {
		/* add to compare */
		compare_action.find(".wdk-add-compare-action").off().on('click', function(e) {
			e.preventDefault();
			var self,self_parent,wdk_post_id,conf_link,data;

			self = $(this);
			self_parent = self.parent();
			wdk_post_id = $(this).attr('data-post_id')
			conf_link = $(this).attr('data-url')

			data = [];
			data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
			data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
			data.push({ name: 'function', value: "add_to_compare" });
			data.push({ name: 'post_id', value: wdk_post_id });

			self_parent.addClass('loading');

			$.ajaxQueue({
				type: 'POST',
				url: conf_link,
				data: data,
				success: function(data){
					if(data.popup_text_success)
					wdk_log_notify(data.popup_text_success);
					
					if(data.popup_text_error)
						wdk_log_notify(data.popup_text_error, 'error');
						
					if(data.success)
					{
						self_parent.find("a.wdk-add-compare-action").addClass('wdk-hidden');
						self_parent.find("a.wdk-remove-compare-action").removeClass('wdk-hidden');
						output_compare_list(data.output, conf_link);
					} else {
						
					}

					self_parent.removeClass('loading');
				}
			});

			return false;
		});

		/* remove from compare */
		compare_action.find(".wdk-remove-compare-action").off().on('click', function(e) {
			e.preventDefault();
			var self,self_parent,wdk_post_id,conf_link,data;

			self = $(this);
			self_parent = self.parent();
			wdk_post_id = $(this).attr('data-post_id')
			conf_link = $(this).attr('data-url')

			data = [];
			data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
			data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
			data.push({ name: 'function', value: "remove_from_compare" });
			data.push({ name: 'post_id', value: wdk_post_id });
				
			self_parent.addClass('loading');

			$.ajaxQueue({
				type: 'POST',
				url: conf_link,
				data: data,
				success: function(data){
						if(data.popup_text_success)
							wdk_log_notify(data.popup_text_success);
							
						if(data.popup_text_error)
							wdk_log_notify(data.popup_text_error, 'error');
							
						if(data.success)
						{
							self_parent.find("a.wdk-remove-compare-action").addClass('wdk-hidden');
							self_parent.find("a.wdk-add-compare-action").removeClass('wdk-hidden');
						}
						self_parent.removeClass('loading');
						if(compare_widget_flow.length) {
							compare_widget_flow.find('.сompare_list').find('.wdk-item[data-post_id="'+ wdk_post_id +'"]').remove();
						}
	
						generate_compare_list();
				}
			})

			return false;
		});
	}

	compare_widget_flow.find('.wdk-toogle').off().on('click', function(e){
		e.preventDefault();
		$(this).parent().toggleClass('active');
	});
	// [END] Add to compare //  

	compare_widget_flow.find('.open_compare_link').on('click', function(){
		$(this).find('.ajax-indicator-masking').show();
	});

	compare_actions(compare_action);
	remove_from_compare();
	/* ajax list */
	/*get_compare_list();*/
}