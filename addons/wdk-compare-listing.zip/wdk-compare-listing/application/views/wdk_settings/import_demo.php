<?php
/**
 * The template for Demo Import Page.
 *
 * This is the template that form layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">

    <h1 class="wp-heading-inline"><?php echo esc_html__('Demo Import', 'wdk-compare-listing'); ?></h1>
    <div class="wdk-body">
        <?php if($installed):?>
        <div  class="notice notice-success">
            <p>
                <?php echo esc_html__('Some data already exists, please remove all data if you want to full import again','wdk-compare-listing'); ?>
                <a href="<?php echo get_admin_url() . "admin.php?page=wdk_settings&function=remove&redirect_url=on_install"; ?>" onclick="return confirm('<?php echo esc_html__('Are you sure? All Listings, fields, categories, locations will be completely removed', 'wdk-compare-listing');?>')"  class="button button-primary" id="reset_data_field_button">
                    <?php echo esc_html__('Remove all data','wdk-compare-listing'); ?>
                </a>
            </p>
        </div>
        <?php endif;?>
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Demo Data Importer Tool', 'wdk-compare-listing'); ?></h3>
                </div>
                <div class="inside">
                    <div class="">
                        <?php
                        $max_time = ini_get("max_execution_time");
                        if($max_time < 120):?>
                        <div class="alert alert-danger" role="alert"><?php echo esc_html__('For import max_execution_time should be more then 120s, please contact with admin host to increase','wdk-compare-listing'); ?></div>
                        <?php endif;?>
                    </div>
                    <?php echo wmvc_xss_clean($import_log);?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>        
                </div>
            </div>
            <?php if(!$installed || true):?>
                <input type="submit" name="submit" id="submit" class="button button-primary event-ajax-indicator" value="<?php echo esc_html__('Import demo data', 'wdk-compare-listing'); ?>"> <span class="wdk-ajax-indicator wdk-infinity-load color-primary dashicons dashicons-update-alt hidden" style="margin-top: 4px;margin-left: 4px;"></span>
            <?php endif;?>
        </form>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('form input[type="submit"]').on('click', function(){
        var self = $(this);
        setTimeout(function(){
            self.delay(2000).attr("disabled", true)
        },0)
    })
})
</script>

<?php $this->view('general/footer', $data); ?>