<?php
/**
 * The template for Settings.
 *
 * This is the template that settings edit page
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('WDK Compare Listings Settings', 'wdk-compare-listing'); ?></h1>
    <div class="wdk-body">
    <div class="row fields_list">
     <?php 
        if(!wdk_compare_listing_is_option_page('wdk_compare_page')):
        ?>
        <?php wdk_compare_listing_alert('settings-install', 
                                    esc_html__('Demo data for WDK Compare plugin are not imported', 'wdk-compare-listing').' <a href="'.get_admin_url() . 'admin.php?page=wdk-compare-listing-settings&function=import_demo" class="button button-primary" id="">'.esc_html('Import Demo Data','wdk-compare-listing').'</a>',
                                    'notice notice-success');?>
        <?php endif;?>
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('General Settings', 'wdk-compare-listing'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-bookings'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>   

                    <div class="wdk-field-edit">
                        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-compare-listing-settings&function=import_demo"; ?>" class="button button-primary" id="import_demo_field_button"><?php echo esc_html__('Import Demo Data','wdk-compare-listing'); ?></a> 
                    </div>
                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', 'wdk-compare-listing'); ?>">
        </form>
    </div>
</div>

<?php //$this->view('general/footer', $data); ?>