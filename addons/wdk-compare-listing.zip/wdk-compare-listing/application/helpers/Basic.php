<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Add admin alert with save dissmis
* @param (string) $key unique key of alert, prefix included related plugin
* @param (string) $text test of message
* @param (string) $class alert alert class, by default 'notice notice-error'
* @return echo alert
*/
function wdk_compare_listing_alert ($key = '', $message = 'Custom Text of message', $class = 'notice notice-error') {
    $key = 'wdk_compare_listing_alert_'.$key;
    $key_diss = $key.'_dissmiss';

    global $wpdb;
    $user_id = get_current_user_id();
    if (!get_user_meta($user_id, $key_diss)) {

    $url = trim(wdk_url_suffix('//'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], $key_diss), '&');
        printf('<div class="%1$s" style="position:relative;"><p>%2$s</p><a href="'.esc_url($url).'"><button type="button" class="notice-dismiss"></button></a></div>', esc_html($class), ($message));  // WPCS: XSS ok, sanitization ok.
    }

    $user_id = get_current_user_id();
    if (isset($_GET[$key_diss])) {
        add_user_meta($user_id, $key_diss, 'true', true);
        wp_redirect(str_replace($key_diss,'','//'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']));
    }

}

function wdk_compare_listing_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_compare_listing;
    $WMVC = &$Winter_MVC_wdk_compare_listing;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    /* Пet column names from wdk_package and add to allow search + 
        in _GET_clone replace field_#id to field_id_TYPE*/
    $list_fields = $WMVC->db->list_fields( $WMVC->db->prefix.'wdk_compare_listing');


    if(isset($_GET_clone['search_location'])) {
        $column_name ='location_id';
        $_GET_clone[$column_name] = $_GET_clone['search_location'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    if(isset($_GET_clone['search_category'])) {
        $column_name ='category_id';
        $_GET_clone[$column_name] = $_GET_clone['search_category'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {

                if($value == 'post_type' || $value == 'user_id')
                {
                    $value = $WMVC->$model_name->_table_name.'.'.$value;
                }

                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;

                    if($col_name == 'post_type' || $col_name == 'user_id')
                    {
                        $col_name = $WMVC->$model_name->_table_name.'.'.$col_name;
                    }
                  
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_compare_listing.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}


if ( ! function_exists('wdk_compare_listing_recaptcha_field'))
{
    function wdk_compare_listing_recaptcha_field($is_compact=false, $style="", $load_script=true)
    {
        static $counter = 0;
        static $recaptcha_array = array();
        if(
            (get_option('wdk_compare_listing_recaptcha_site_key') && get_option('wdk_compare_listing_recaptcha_secret_key'))
            || (get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key'))
        )
        {
            $recaptcha_site_key = get_option('wdk_compare_listing_recaptcha_site_key');
            if(empty($recaptcha_site_key)) {
                $recaptcha_site_key = get_option('wdk_recaptcha_site_key');
            }

            if($load_script && $counter===0)
            {
                echo "<script src='https://www.google.com/recaptcha/api.js?onload=CaptchaCallback&amp;render=explicit'></script>";
            }
            $counter++;
            
            $compact_tag='';
            $size_tag='';
            if($is_compact)
            {
                $compact_tag='data-size="compact"';
                $size_tag='compact';
            }

            $recaptcha_array[$counter] = array('size'=>$size_tag);
                    
            echo '<div id="wdk_recaptcha_called_'.$counter.'" class="g-recaptcha" style="'.$style.'"  '.$compact_tag.' data-sitekey="'.$recaptcha_site_key.'"></div>';
    ?>

    <script>
    <?php if($counter===1)echo 'var ';?>CaptchaCallback = function(){
    <?php for($j=1;$j<=$counter;$j++): ?>
        grecaptcha.render(document.getElementById('wdk_recaptcha_called_<?php echo $j;?>'), {'size' : '<?php echo $recaptcha_array[$j]['size']; ?>',  'sitekey' : '<?php echo $recaptcha_site_key; ?>'});
    <?php endfor; ?>
    };
    </script>

    <?php
        }
    }
}

function is_wdk_compare_listing_valid_recaptcha()
{
    if(isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])){
        //your site secret key
        if(wdk_compare_listing_valid_recaptcha_curl($_POST['g-recaptcha-response']))
        {
            return TRUE;
        }
    }
    return FALSE;
}

function wdk_compare_listing_valid_recaptcha_curl($g_recaptcha_response='') {

    $recaptcha_secret_key = get_option('wdk_compare_listing_recaptcha_secret_key');

    if(empty($recaptcha_secret_key)) {
        $recaptcha_secret_key = get_option('wdk_recaptcha_secret_key');
    }

    $url = 'https://www.google.com/recaptcha/api/siteverify';
    $args = array(
            'timeout'     => 200,
            'blocking'    => true,
            'headers'     => array(),
            'body'        => array(
                'secret' => $recaptcha_secret_key,
                'response' => $g_recaptcha_response,
                'remoteip' => sanitize_textarea_field($_SERVER['REMOTE_ADDR'])
            ),
            'cookies'     => array()
    );
    $response = wp_remote_post( $url, $args );
 
    if ( is_wp_error( $response ) ) {
       /*$error_message = $response->get_error_message();*/
       return true;
    } else {
        $response = json_decode($response['body']);
        return $response->success;
    }
}


function wdk_compare_listing_is_option_page($option = '')
{
    if((get_option($option)) && get_post_status(get_option($option)) == 'publish'){
        return true;
    }

    return false;
}
?>