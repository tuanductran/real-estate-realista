<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;


	public function __construct(){
        parent::__construct();

        $pages = array('' => __('Not Selected', 'wdk-compare-listing'));
        foreach(get_pages(array('sort_column' => 'post_title')) as $page)
        {
            $pages[$page->ID] = $page->post_title.' #'.$page->ID;
        }

        $this->fields_list = array( 
                array(
                    'field' => 'wdk_compare_page', 
                    'field_label' => __('Compare', 'wdk-compare-listing'), 
                    'hint' => __('Select compare page, will be visible on front end for open compare list', 'wdk-compare-listing'), 
                    'field_type' => 'DROPDOWN_PAGE', 
                    'rules' => '', 
                    'values' => $pages
                ),
                array(
                    'field' => 'wdk_compare_disable_on_result_items', 
                    'field_label' => __('Disable compare on result items', 'wdk-compare-listing'), 
                    'hint' => __('Select option for hide, compare icon on search result listings', 'wdk-compare-listing'), 
                    'field_type' => 'CHECKBOX', 
                    'rules' => '', 
                ),
        );
	}
}
?>