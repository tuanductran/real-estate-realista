<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_compare_listing_frontendajax extends Winter_MVC_Controller {
	private $cookie_key = 'wdk_listings_compare';
	private $max_listings = 4;

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function add_to_compare () {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = array();
		$data['success'] = false;

		/* for load listings data from db */
		global $Winter_MVC_WDK;
		$Winter_MVC_WDK->model('listing_m');
		$Winter_MVC_WDK->load_helper('listing');
		$post_id = false;

		if(isset($_POST['post_id']))
			$post_id = intval($_POST['post_id']);

		if(empty($post_id))
        {
            $data['popup_text_error'] .= __('Missing listing id', 'wdk-compare-listing');
        } 

		if(empty($data['popup_text_error'])) {
			$data_cookie = [];
	
			if(isset($_COOKIE[$this->cookie_key]))
				$data_cookie = unserialize(base64_decode($_COOKIE[$this->cookie_key]));
			if(isset($data_cookie[$post_id]))
				$data['popup_text_error'] .= __('Listing already in compare list', 'wdk-compare-listing');
			else{

				$data_cookie[$post_id] = true;

				if(false) {
					$post_data = get_post($post_id);
					$data_cookie[$post_id] = array(
						'post_id' => $post_id,
						'link' => get_permalink($post_data),
						'value' => wdk_show_data('post_title', $post_data, '', TRUE, FALSE),
					); 
				}

				if(count($data_cookie)>$this->max_listings) {
					reset($data_cookie);
					unset($data_cookie[key($data_cookie)]);
				} 

				$data['success'] = true;
				
				setcookie( $this->cookie_key, base64_encode(serialize($data_cookie)), time() + 48*3600, '/', $_SERVER['SERVER_NAME'], false );

				$data['popup_text_success'] .= __('Listing added in compare list', 'wdk-compare-listing');
				
				/* load from db */
				if(true) {
					$listings_ids = array();
					foreach($data_cookie as $listing_id => $v) {
						if(!isset($listings_ids [$listing_id]))
							$listings_ids [$listing_id] = $listing_id;
					}
				
					/* where in */
					$results = array();
					if(!empty($listings_ids)){
						$Winter_MVC_WDK->db->where( $Winter_MVC_WDK->db->prefix.'wdk_listings.post_id IN(' . implode(',', $listings_ids) . ')', null, false);
						$Winter_MVC_WDK->db->where(array('is_activated' => 1, 'is_approved'=>1));
						$Winter_MVC_WDK->db->order_by('FIELD('.$Winter_MVC_WDK->db->prefix.'wdk_listings.post_id, '. implode(',', $listings_ids) . ')');
						$Winter_MVC_WDK->db->limit($this->max_listings);

						$results = $Winter_MVC_WDK->listing_m->get();
						foreach ($results as $listing) {
							$data['output'][wdk_show_data('post_id', $listing, '', TRUE, TRUE)] = array(
																									'post_id' => wdk_show_data('post_id', $listing, '', TRUE, TRUE),
																									'link' => get_permalink($listing),
																									'value' => wdk_field_value('post_title', $listing),
																									); 
						}
					}
				} else {
					foreach($data_cookie as $listing_id => $v) {
						if(!isset($data['output'] [$listing_id]))
							$data['output'] [$listing_id] =  $v;
					}
				}
			}
		}

		$this->output($data);
    } 

    
    public function get_compare_list () {
	
		$data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = array();
		$data['success'] = false;
		
		global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');
	
		if(empty($data['popup_text_error'])) {
			$data_cookie = [];
			if(isset($_COOKIE[$this->cookie_key]))
				$data_cookie = unserialize(base64_decode($_COOKIE[$this->cookie_key]));
		
			$listings_ids = array();
			foreach($data_cookie as $listing_id => $v) {
				if(!isset($listings_ids [$listing_id]))
					$listings_ids [$listing_id] = $listing_id;
			}

			/* where in */
			$results = array();
			if(!empty($listings_ids)){
				$Winter_MVC_WDK->db->where( $Winter_MVC_WDK->db->prefix.'wdk_listings.post_id IN(' . implode(',', $listings_ids) . ')', null, false);
				$Winter_MVC_WDK->db->where(array('is_activated' => 1, 'is_approved'=>1));
				$Winter_MVC_WDK->db->order_by('FIELD('.$Winter_MVC_WDK->db->prefix.'wdk_listings.post_id, '. implode(',', $listings_ids) . ')');

				$results = $Winter_MVC_WDK->listing_m->get();

				foreach ($results as $listing) {
					$data['output'][wdk_show_data('post_id', $listing, '', TRUE, FALSE)] = array(
																							'post_id' => wdk_show_data('post_id', $listing, '', TRUE, FALSE),
																							'link' => get_permalink($listing),
																							'value' => wdk_field_value('post_title', $listing),
																							); 
				}
			}
			
			$data['success'] = true;
		}
		$this->output($data);

    } 
    
    /* 
    * Use for remove property from compare list, use with Controller propertycompare.php
    * 
    */
    public function remove_from_compare() {
		$data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;

		$post_id = false;

		if(isset($_POST['post_id']))
			$post_id = intval($_POST['post_id']);

		if(empty($post_id))
        {
            $data['popup_text_error'] .= __('Missing listing id', 'wdk-compare-listing');
        } 

		if(empty($data['popup_text_error'])) {
			$data_cookie = [];
			if(isset($_COOKIE[$this->cookie_key])) {
				$data_cookie = unserialize(base64_decode($_COOKIE[$this->cookie_key]));
            
				if(!isset($data_cookie[$post_id]))
					$data['popup_text_error'] .= __('Listing missing in compare list', 'wdk-compare-listing');
				else {
					unset($data_cookie[$post_id]);

					$data['success'] = true;
					setcookie( $this->cookie_key, base64_encode(serialize($data_cookie)), time() + 7200, '/', $_SERVER['SERVER_NAME'], false );

					$data['popup_text_success'] .= __('Listing removed from compare list', 'wdk-compare-listing');
				}
			} else {
				$data['popup_text_error'] .= __('Missing listing in compare list', 'wdk-compare-listing');
			}

			$data['success'] = true;
		}

		$this->output($data);
   } 
     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
