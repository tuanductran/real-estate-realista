<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_compare_listing_settings extends Winter_MVC_Controller {
    public $import_log = '';
    
	public function __construct(){
		parent::__construct();
	}
    
    // Edit listing method
	public function index()
	{
        $this->load->model('settings_m');
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->settings_m->fields_list;
        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
    
            $data = $this->settings_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post
            foreach($data as $key => $val)
            {
                update_option( $key, $val, TRUE);
            }  

            // redirect
            if(empty($listing_post_id) && !empty($id))
            {
                //wp_redirect(admin_url("admin.php?page=wdk_settings&is_updated=true"));
                exit;
            }
                
        }

        // fetch data, after update/insert to get updated last data
        $fields_data = $this->settings_m->get();

        /* slug udpate rules*/
        //flush_rewrite_rules();

        foreach($fields_data as $field)
        {
            $this->data['db_data'][$field->option_name] = $field->option_value;
        }

        $this->load->view('wdk_settings/index', $this->data);
    }

              
    // Import demo data listing method
	public function import_demo()
	{
        $this->data['installed'] = false;

        global $wdk_membership_user_fields_list, $wdk_membership_user_types;

        $this->data['db_data'] = NULL;
        $this->data['fields'] = array( 
            array('field' => 'import_page_compare', 'field_label' => __('Compare Page', 'wdk-compare-listing'), 'hint' => __('Import demo Compare Page', 'wdk-compare-listing'), 'field_type' => 'CHECKBOX', 'rules' => ''),
        );

        $this->data['form'] = &$this->form;

        ini_set('max_execution_time', 900);           
        
        foreach($this->data['fields'] as $field)
        {
            $this->data['db_data'][$field['field']] = 1;
        }
        
        if((get_option('wdk_compare_page')) && get_post_status(get_option('wdk_compare_page')) =='publish'){
            $this->data['db_data']['import_page_compare'] = 0;
        }

        $this->data['import_log'] = '';
        $rules = array(
            array(
                'field' => 'import_page_compare',
                'label' => __('Compare ', 'wdk-compare-listing'),
                'rules' => ''
            ),
        );    
        $this->data['required_plugins'] = false;
              
        $plugin = 'elementor/elementor.php';
        if (in_array( $plugin, apply_filters( 'active_plugins', get_option( 'active_plugins' ))) && !class_exists('Elementor\Plugin') ) {
            $this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Your Elementor Plugin is not fully active, usually this happen because of old PHP version on server, in such case eventually you can try older Elementor Version or Update PHP on your server').'</div>';
            $this->data['required_plugins'] = true;
        }

        if(!$this->data['required_plugins'])
        if($this->form->run($rules))
        {
            // Save procedure for basic data
            $data = $this->input->post();
            
            if( !empty($data['import_page_compare'])) {
                $this->create_page('page-compare.json', __('Compare Page', 'wdk-compare-listing'), 'wdk_compare_page', __('Compare Page', 'wdk-compare-listing'));
            }
            
            $this->replace_content_data();

            update_option('wdk_compare_listing_installed', '1');

        } 
        $this->load->view('wdk_settings/import_demo', $this->data);
    }

    public function api_import()
	{
        ini_set('max_execution_time', 900);
        $this->data['import_log'] = '';

        $this->import_settings();
        $this->create_page('page-compare.json', __('Compare Page', 'wdk-compare-listing'), 'wdk_compare_page', __('Compare Page', 'wdk-compare-listing'));
        
        $this->replace_content_data();
        update_option('wdk_compare_listing_installed', '1');
        return true;
    }

    public function import_settings() {

    //  $this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.esc_html__('Settings imported', 'wdk-compare-listing').'</div>';
        return true;
    }

    /* add demo listing preview page */
    public function create_page($layout_json, $page_title = "New Page", $option = '', $custom_message_title = '') {

        $page_title_message = $page_title;
        if(!empty($custom_message_title)){
            $page_title_message = $custom_message_title;
        }

        if(!empty($option) && (get_option($option)) && get_post_status(get_option($option)) =='publish'){
            $this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.$page_title_message.' '.esc_html__('already exists', 'wdk-compare-listing').'</div>';
            return false;
        }
        
        add_action('wdk_compare_listing/elementor-elements/register_widget', function($self){
            $self->add_widget('WdkCompare_Listing\Elementor\Widgets\WdkCompare_Table');
        });

        // Import elementor templates
        $page = $this->generate_page($page_title, '', 'elementor_canvas');
        $this->elementor_assign($page->ID, $layout_json);

        // Assign page.
        if($page && !empty($option))
            update_option( $option, $page->ID, TRUE);
        
        $this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.$page_title_message.' '.esc_html__('Page imported', 'wdk-compare-listing').'</div>';

        return $page->ID;
    }

    
    /* Create Page */
    private function generate_page($post_title, $post_content = '', $post_template = NULL, $post_parent=0)
    {
        $post = wdk_page_by_title($post_title, 'OBJECT', 'page' );
        
        $post_id = NULL;
        
        // Delete posts and rebuild
        if(!empty($post))
        {
            wp_delete_post($post->ID, true);
            $post=NULL;
        }
        
        if(!empty($post))
            $post_id   = $post->ID;

        if(empty($post_id))
        {
            $error_obj = NULL;
            $post_insert = array(
                'post_title'    => wp_strip_all_tags( $post_title ),
                'post_content'  => $post_content,
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_author'   => get_current_user_id(),
                'post_category' => array(1,2),
                'page_template' => $post_template,
                'post_parent'   => $post_parent
            );
            $post_id = wp_insert_post( $post_insert, $error_obj );
        }

        $post_insert = get_post( $post_id );
        
        return $post_insert;
    }

    /* Elementor Import Template */
    private function elementor_assign($page_id, $json_template_name = '')
    {
        $file = false;

        if(is_child_theme() && file_exists(get_stylesheet_directory().'/elementor-data/wdk-compare-listing/'.$json_template_name))
        {
            $file = get_stylesheet_directory().'/elementor-data/wdk-compare-listing/'.$json_template_name;
        }
        elseif(file_exists(get_template_directory().'/demo-data/wdk-compare-listing/'.$json_template_name))
        {
            $file = get_template_directory().'/demo-data/wdk-compare-listing/'.$json_template_name;
        }
        elseif(file_exists( WDK_COMPARE_LISTINGS_PATH. '/demo-data/'.$json_template_name))
        {
            $file = WDK_COMPARE_LISTINGS_PATH.'demo-data/'.$json_template_name;
        }
        
        if(!$file || !class_exists('Elementor\Plugin'))
        {
            return false;
        }

        $page_template =  get_page_template_slug( $page_id );

        add_post_meta( $page_id, '_elementor_edit_mode', 'builder' );

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            WP_Filesystem();
        }

        $string =  $wp_filesystem->get_contents($file);
        
        $json_template = json_decode($string, true);

        $elements = $json_template['content'];

        $data = array(
            'elements' => $elements,
            'settings' => array('post_status'=>'autosave', 'template'=>$page_template),
        );   
        // @codingStandardsIgnoreStart
        $document = Elementor\Plugin::$instance->documents->get( $page_id, false );
        // @codingStandardsIgnoreEnd
        return $document->save( $data );
    }

    function replace_content_data() {
        /* Replace Links */
        /* login */
        $from = 'https://www.wpdirectorykit.com/nexproperty/wp-admin/wp-login.php/';
        $to = get_admin_url();
        $this->replace_meta($from, $to);
        $from = 'https://www.wpdirectorykit.com/nexproperty/wp-admin/wp-login.php';
        $to = get_admin_url();
        $this->replace_meta($from, $to);
        
        /* login */
        $from = 'https://www.wpdirectorykit.com/nexproperty/login/';
        $to = get_the_permalink(get_option('wdk_membership_login_page'));
        $this->replace_meta($from, $to);
        
        $from = 'https://www.wpdirectorykit.com/nexproperty/login';
        $to = get_the_permalink(get_option('wdk_membership_login_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty/register/';
        $to = get_the_permalink(get_option('wdk_membership_register_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty/register';
        $to = get_the_permalink(get_option('wdk_membership_register_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty';
        $to = get_home_url();
        $this->replace_meta($from, $to);
        
        /* homepage */
        $from = '2020';
        $to = date('Y');
        $this->replace_meta($from, $to);

        return true;
    }

    private function replace_meta($from = '', $to = '') {
        global $wpdb;
        // @codingStandardsIgnoreStart cannot use `$wpdb->prepare` because it remove's the backslashes
        $rows_affected = $wpdb->query(
            "UPDATE ".esc_sql($wpdb->postmeta)." " .
            "SET `meta_value` = REPLACE(`meta_value`, '" . str_replace( '/', '\\\/', esc_sql($from) ) . "', '" . str_replace( '/', '\\\/', esc_sql($to) ) . "') " .
            "WHERE `meta_key` = '_elementor_data' AND `meta_value` LIKE '[%' ;" );
        /* end login */
    }
}
