<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'wpdirectorykit/install/api', 'wdk_compare_install'); 

if(!function_exists('wdk_compare_install')) {
    function wdk_compare_install () {
        global $Winter_MVC_wdk_compare_listing;
        $Winter_MVC_wdk_compare_listing->load_controller('wdk-compare-listing-settings', 'api_import');
    }
}


add_action('wp_footer', function(){

    if(!defined('WPDIRECTORYKIT_URL'))return;

    $compare_page_url = '';
    if (get_option('wdk_compare_page')) {
        $obj_id = get_queried_object_id();
        $compare_page_url = get_permalink(get_option('wdk_compare_page'));
    }

    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->load_helper('listing');

    $results = array();
    $data_cookie = array();

    if(isset($_COOKIE['wdk_listings_compare']))
        $data_cookie = unserialize(base64_decode($_COOKIE['wdk_listings_compare']));


    $listings_ids = array();
    foreach($data_cookie as $listing_id => $v) {
        if(!isset($listings_ids [$listing_id]))
            $listings_ids [$listing_id] = $listing_id;
    }

    /* where in */
    $results = array();
    if(!empty($listings_ids)){
        $Winter_MVC_WDK->db->where( $Winter_MVC_WDK->db->prefix.'wdk_listings.post_id IN(' . implode(',', $listings_ids) . ')', null, false);
        $Winter_MVC_WDK->db->where(array('is_activated' => 1, 'is_approved'=>1));
        $Winter_MVC_WDK->db->order_by('FIELD('.$Winter_MVC_WDK->db->prefix.'wdk_listings.post_id, '. implode(',', $listings_ids) . ')');
        $Winter_MVC_WDK->db->limit(4);

        $results = $Winter_MVC_WDK->listing_m->get();
    }
?>

<div class="wdk-compare-widget <?php if(count($results) < 1):?> wdk-hidden <?php endif;?>">
    <a href="#" class="wdk-toogle"><i aria-hidden="true" class="fas fa-exchange-alt"></i></a>
    <div class="wdk-body">
        <span class="config wdk-hidden" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></span>
        <?php if(!$compare_page_url):?>
            <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Compare Listings Page Not Defined in Settings', 'wdk-compare-listing');?></p>
        <?php endif;?>
        <div class="wdk-compare-title"><?php echo esc_html__('Compare List', 'wdk-compare-listing');?></div>   
        <div class="wdk-hidden config" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>"></div>
        <p class="wdk_alert wdk_alert-info no_listings" style="display:none;"><?php echo esc_html__('Please Add a first listing', 'wdk-compare-listing');?></p>
        <div class="сompare_list">
            <?php if(count($results)):?>
                <?php foreach ($results as $listing):?>
                    <div class="wdk-item" data-post_id="<?php echo esc_attr(wdk_show_data('post_id', $listing, '', TRUE, TRUE));?>">
                    <a target="_blank" class="value" href="<?php echo esc_url(get_permalink($listing));?>"><?php echo esc_html(wdk_field_value('post_title', $listing));?></a>
                    <a class="wdk_item_remove" href="#" data-post_id="<?php echo esc_attr(wdk_show_data('post_id', $listing, '', TRUE, TRUE));?>" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"> <i class="fa fa-remove"></i><i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking"></i></a>
                </div>
                <?php endforeach;?>
            <?php else:?>
                <div class="wdk-item message"><?php echo esc_html__('Please Add a first listing', 'wdk-compare-listing');?></div>
            <?php endif;?>
        </div>
        <a href="<?php echo esc_url($compare_page_url);?>" class="btn-wdk open_compare_link <?php if(count($results) <2):?> wdk-hidden <?php endif;?>">
            <?php echo esc_html__('Compare Now', 'wdk-compare-listing');?>
            <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking" style="display: none;"></i>
        </a>
    </div>
</div>


<?php


});


?>