<?php
/**
 * The template for Element Compare table.
 * This is the template that elementor element table, listings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<?php
    $compare_page_url = '';
    if (!get_option('wdk_compare_page')) {
        $obj_id = get_queried_object_id();
        $compare_page_url = get_permalink(get_option('wdk_compare_page'));
    }
?>

<div class="wdk-compare-listing-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-compare-table" id="wdk_compare_table">
        <?php if(count($listings_compare)>0):?>
            <table class="wdk-table responsive">
                <thead>
                    <th></th>
                    <?php foreach ($listings_compare as $k => $listing):?>
                    <th>
                        <a href='<?php echo esc_url(get_permalink($listing)); ?>'><?php echo esc_html(wdk_field_value('post_title', $listing));?></a>
                    </th>
                    <?php endforeach; ?>
                </thead>
                <tbody>
                    <tr>
                        <th data-label="<?php echo esc_html(wdk_field_value('post_title', $listing));?>">
                            <?php echo esc_html__('Image', 'wdk-compare-listing');?>
                        </th>
                        <?php foreach ($listings_compare as $listing):?>
                        <td data-label="<?php echo esc_html(wdk_field_value('post_title', $listing));?>">
                            <a href='<?php echo esc_url(get_permalink($listing)); ?>'>
                                <img style="max-height: 250px;" src='<?php echo esc_url(wdk_image_src($listing, 'full'));?>'/>
                            </a>
                        </td>
                        <?php endforeach; ?>   
                    </tr>
                    <?php foreach ($fields_list as $field_key => $field_title):?>
                        <?php if($field_key == 'post_title') continue; ?>
                        <?php if(stripos($field_key, 'section') === FALSE):?>
                        <?php
                            $is_show = false;
                            foreach ($listings_compare as $k => $listing){
                                if(wdk_field_value($field_key, $listing))
                                    $is_show = true; 
                            }

                            if(!$is_show) continue;
                            ?>
                            <tr>
                                <th data-label="<?php echo esc_html__('Field', 'wdk-compare-listing'); ?>">
                                    
                                        <?php echo esc_html($field_title);?>
                                
                                </th>
                                <?php foreach ($listings_compare as $listing):?>
                                <td data-label="<?php echo esc_html(wdk_field_value('post_title', $listing));?>">
                                    <?php

                                        if(wdk_field_option($field_key, 'field_type') == "CHECKBOX") {
                                            if(wdk_field_value ($field_key, $listing) == 1){
                                                $field_value = '<span class="label label-success"><span class="dashicons dashicons-saved"></span></span>';
                                            } else {
                                                $field_value = '<span class="label label-success"><span class="dashicons dashicons-unsaved"></span></span>';
                                            } 
                                        } else if(wdk_field_option($field_key,'field_type') == "INPUTBOX") {
                                            $field_value = wdk_field_value ($field_key, $listing);

                                            if(strpos($field_value, 'vimeo.com') !== FALSE)
                                            {
                                                $field_value = wp_oembed_get($field_value, array("width"=>"800", "height"=>"450"));
                                            }
                                            elseif(strpos($field_value, 'watch?v=') !== FALSE)
                                            {
                                                $embed_code = substr($field_value, strpos($field_value, 'watch?v=')+8);
                                                $field_value =  wp_oembed_get('https://www.youtube.com/watch?v='.$embed_code, array("width"=>"800", "height"=>"455"));
                                            }
                                            elseif(strpos($field_value, 'youtu.be/') !== FALSE)
                                            {
                                                $embed_code = substr($field_value, strpos($field_value, 'youtu.be/')+9);
                                                $field_value = wp_oembed_get('https://www.youtube.com/watch?v='.$embed_code, array("width"=>"800", "height"=>"455"));
                                            } 
                                            elseif(filter_var($field_value, FILTER_VALIDATE_URL) !== FALSE && preg_match('/\.(mp4|flv|wmw|ogv|webm|ogg)$/i', $field_value))
                                            {
                                                $field_value  = '<video src="'.$field_value.'" controls></video> ';
                                            }
                                            elseif(filter_var($field_value , FILTER_VALIDATE_URL) !== FALSE) {
                                                $field_value  = '<a href="'.$field_value .'">'.wdk_field_label($field_key) .'</a>';
                                            }
                                        }
                                        elseif($field_key == 'category_id') {
                                            if(wdk_field_value ($field_key, $listing)){
                                                $this->WMVC->model('category_m');
                                                $tree_data = $this->WMVC->category_m->get(wdk_field_value ($field_key, $listing), TRUE);
                                                $field_value = wmvc_show_data('category_title', $tree_data);
                                            }
                                        }
                                        elseif($field_key == 'location_id') {
                                            if(wdk_field_value ($field_key, $listing)){
                                                $this->WMVC->model('location_m');
                                                $tree_data = $this->WMVC->location_m->get(wdk_field_value ($field_key, $listing), TRUE);
                                                $field_value = wmvc_show_data('location_title', $tree_data);
                                            }
                                        }
                                        elseif(
                                            wdk_field_option($field_key, 'field_type') == "TEXTAREA" ||
                                            $field_key == 'post_content'
                                        ) {
                                            global $wp_embed;
                                            $field_value = wpautop(wdk_field_value ($field_key, $listing));
                                            $field_value = $wp_embed->autoembed($field_value );
                                        }
                                        else {
                                            $field_value = wdk_field_value ($field_key, $listing);
                                        }

                                        if(is_numeric($field_value)) {
                                           // $field_value = number_format_i18n(wdk_filter_decimal($field_value));
                                        }
                                    ?>

                                    <?php 
                                        echo esc_html(apply_filters( 'wpdirectorykit/listing/field/prefix', wdk_field_option($field_key,'prefix'), $field_key))
                                            .wp_kses_post(apply_filters( 'wpdirectorykit/listing/field/value', wdk_filter_decimal($field_value), $field_key))
                                            .esc_html(apply_filters( 'wpdirectorykit/listing/field/suffix', wdk_field_option($field_key,'suffix'), $field_key));
                                    ?>

                                </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php else:?>
                            <tr class="section_tr">
                                <td data-label="<?php echo esc_html__('Section', 'wdk-compare-listing'); ?>" colspan="<?php echo esc_attr((count($listings_compare) + 1));?>">
                                    <?php echo $field_title;?>
                                </td>
                            </tr>
                        <?php endif;?>
                    <?php endforeach;?>
                    <tr>
                        <th data-label="<?php echo esc_html(wdk_field_value('post_title', $listing));?>"></th>
                        <?php foreach ($listings_compare as $listing):?>
                            <td data-label="<?php echo esc_html(wdk_field_value('post_title', $listing));?>">
                            <a href='<?php echo esc_url(get_permalink($listing)); ?>' class="btn btn-open"><?php echo esc_html__('Open', 'wdk-compare-listing');?></a>
                            </td>
                        <?php endforeach; ?>   
                    </tr>
                </tbody>
                <tfoot>
                    <th></th>
                    <?php foreach ($listings_compare as $k => $listing):?>
                    <th>
                        <a href='<?php echo esc_url(get_permalink($listing)); ?>'><?php echo esc_html(wdk_field_value('post_title', $listing));?></a>
                    </th>
                    <?php endforeach; ?>
                </tfoot>
            </table>
        <?php else:?>
            <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Listings to compare not selected, please select some first', 'wdk-compare-listing');?></p>
        <?php endif;?>
    </div> 
</div>