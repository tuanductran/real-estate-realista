<?php
/**
 * The template for Element Compare table Demo data.
 * This is the template that elementor element table, listings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-compare-listing-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-compare-table" id="wdk_compare_table">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <th></th>
                    <th>
                        <a href="#"><?php echo esc_html__('Primrose House','wdk-compare-listing');?></a>
                    </th>
                    <th>
                        <a href="#"><?php echo esc_html__('Icy Apartment','wdk-compare-listing');?></a>
                    </th>
                </tr>
            </thead>
            <tbody>
                <tr class="section_tr">
                    <td data-label="<?php echo esc_html__('Section','wdk-compare-listing');?>" colspan="3">
                         <?php echo esc_html__('Section Custom fields','wdk-compare-listing');?>  </td>
                </tr>
                <tr>
                    <th data-label="<?php echo esc_html__('Field','wdk-compare-listing');?>">
                        <?php echo esc_html__('WP Title','wdk-compare-listing');?> </th>
                    <td data-label="Value">
                        <?php echo esc_html__('Primrose House','wdk-compare-listing');?>
                    </td>
                    <td data-label="Value">
                        <?php echo esc_html__('Icy Apartment','wdk-compare-listing');?>
                    </td>
                </tr>
                <tr>
                    <th data-label="<?php echo esc_html__('Field','wdk-compare-listing');?>">
                        <?php echo esc_html__('Address','wdk-compare-listing');?> </th>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">

                        <?php echo esc_html__('Kalhamer Strasse 63','wdk-compare-listing');?>
                    </td>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">

                        <?php echo esc_html__('Mattersburger Strasse 27','wdk-compare-listing');?>
                    </td>
                </tr>
                <tr>
                    <th data-label="Field">
                        <?php echo esc_html__('Category','wdk-compare-listing');?> </th>
                    <td data-label="Value">
                        <?php echo esc_html__('House','wdk-compare-listing');?>
                    </td>
                    <td data-label="Value">
                        <?php echo esc_html__('House','wdk-compare-listing');?>
                    </td>
                </tr>
                <tr>
                    <th data-label="Field">
                        <?php echo esc_html__('Location','wdk-compare-listing');?> </th>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">

                        <?php echo esc_html__('Sheffield','wdk-compare-listing');?>
                    </td>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">

                        <?php echo esc_html__('Manchester','wdk-compare-listing');?>
                    </td>
                </tr>
                <tr class="section_tr">
                    <td data-label="<?php echo esc_html__('Section','wdk-compare-listing');?>" colspan="3">
                         <?php echo esc_html__('Section SEO','wdk-compare-listing');?>  </td>
                </tr>
                <tr>
                    <th data-label="<?php echo esc_html__('Field','wdk-compare-listing');?>">
                        <?php echo esc_html__('Short Description','wdk-compare-listing');?> </th>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">

                        <p><?php echo esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.','wdk-compare-listing');?></p>

                    </td>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">
                        <p><?php echo esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua.','wdk-compare-listing');?></p>
                    </td>
                </tr>
                <tr>
                    <th data-label="Field">
                        <?php echo esc_html__('Keywords','wdk-compare-listing');?> </th>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">
                        <?php echo esc_html__('House,Lux','wdk-compare-listing');?>
                    </td>
                    <td data-label="<?php echo esc_html__('Value','wdk-compare-listing');?>">
                        <?php echo esc_html__('House,Lux','wdk-compare-listing');?>
                    </td>
                </tr>
                <tr>
                    <th>
                         <?php echo esc_html__('Image','wdk-compare-listing');?> </th>
                    <td>
                        <img style="max-height: 250px;"
                            src="<?php echo esc_url(wdk_placeholder_image_src());?>">
                    </td>
                    <td>
                        <img style="max-height: 250px;"
                            src="<?php echo esc_url(wdk_placeholder_image_src());?>">
                    </td>

                </tr>
                <tr>
                    <th>
                    </th>
                    <td>
                        <a href="" class="btn btn-open"> <?php echo esc_html__('Open','wdk-compare-listing');?></a>
                    </td>
                    <td>
                        <a href="" class="btn btn-open"> <?php echo esc_html__('Open','wdk-compare-listing');?></a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>