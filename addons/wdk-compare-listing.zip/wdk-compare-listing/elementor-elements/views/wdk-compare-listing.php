<?php
/**
 * The template for Element Compare Button icon.
 * This is the template that elementor element icon, button
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<?php
    $compare_page_url = '';
    if (get_option('wdk_compare_page')) {
        $obj_id = get_queried_object_id();
        $compare_page_url = get_permalink(get_option('wdk_compare_page'));
    }
?>

<div class="wdk-compare-listing-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-compare-listing" id="wdk_compare_listing">
        <div class="config" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></div>
        <a href="#" class="wdk-compare-listing-button <?php if($compare_added):?> wdk-active <?php endif;?>" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-post_id="<?php echo esc_attr($wdk_listing_id); ?>">
            <?php if(wmvc_show_data('button_add_icon_position', $settings) == 'left') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['button_add_icon'],  [ 'aria-hidden' => 'true', 'class'=>'left' ] ); ?>
                <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator left"></i>
            <?php endif;?>
            <span class='wdk-deactive'><?php echo esc_html(wmvc_show_data('button_remove_text', $settings));?></span>
            <span class='wdk-active'><?php echo esc_html(wmvc_show_data('button_add_text', $settings));?></span>
            <?php if(wmvc_show_data('button_add_icon_position', $settings) == 'right') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['button_add_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
            <?php endif;?>
        </a>
       
        <div class="сompare_list">
            <?php if($is_edit_mode):?>
                <div class="wdk-item">
                    <a target="_blank" href="#"><?php echo esc_html__('Kingston House', 'wdk-compare-listing');?></a> 
                    <a class="wdk_item_remove" href="#"><i class="fa fa-remove"></i></a>
                </div>
                <div class="wdk-item">
                    <a target="_blank" href="#"><?php echo esc_html__('Primrose House', 'wdk-compare-listing');?></a> 
                    <a class="wdk_item_remove" href="#"><i class="fa fa-remove"></i></a>
                </div>
            <?php endif;?>
        </div>
        
        <?php if(!$compare_page_url):?>
            <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Compare Listings Page Not Defined in Settings', 'wdk-compare-listing');?></p>
        <?php endif;?>

        <a href="<?php echo esc_url($compare_page_url);?>" class="btn btn-primary open_compare_link <?php if(!$is_edit_mode):?> wdk-hidden <?php endif;?>" >
            <?php if(wmvc_show_data('button_page_icon_position', $settings) == 'left') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['button_page_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php endif;?>
            
            <?php echo esc_html(wmvc_show_data('button_page_text', $settings));?>

            <?php if(wmvc_show_data('button_page_icon_position', $settings) == 'right') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['button_page_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <?php endif;?>
        </a>
    </div> 
</div>