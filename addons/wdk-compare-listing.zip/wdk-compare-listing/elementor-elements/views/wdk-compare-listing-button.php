<?php
/**
 * The template for Element Compare Add / remove widget.
 * This is the template that elementor element form, button, list
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<?php
    $compare_page_url = '';
    if (get_option('wdk_compare_page')) {
        $obj_id = get_queried_object_id();
        $compare_page_url = get_permalink(get_option('wdk_compare_page'));
    }
    
?>

<div class="wdk-compare-listing-button-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <?php if(!$compare_page_url):?>
        <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Compare Listings Page Not Defined in Settings', 'wdk-compare-listing');?></p>
    <?php endif;?>
    <div class="wdk-compare-listing-button">
        <span class="wdk-compare-listing-button-actions" data-post_id="<?php echo esc_attr($wdk_listing_id);?>">
            <div class="config wdk-hidden" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></div>
            <a href="#" data-post_id="<?php echo esc_attr($wdk_listing_id);?>" class="wdk-add-compare-action <?php echo (esc_attr($compare_added))?'wdk-hidden':''; ?>"  data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['compare_notadded_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
            <a href="#" data-post_id="<?php echo esc_attr($wdk_listing_id);?>" class="wdk-remove-compare-action <?php echo (!esc_attr($compare_added))?'wdk-hidden':''; ?>" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['compare_added_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
            <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
        </span>
    </div>
</div>