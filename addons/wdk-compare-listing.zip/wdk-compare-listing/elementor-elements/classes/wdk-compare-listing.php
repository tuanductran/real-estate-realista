<?php

namespace WdkCompare_Listing\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkCompare_Listing extends WdkCompare_ListingElementorBase {


    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-compare-listing')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-compare-listing';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Compare Listings', 'wdk-compare-listing');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-kit-details';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['wdk_listing_id'] = $wdk_listing_id;
        $this->data['is_edit_mode']= false;  

        $this->data['compare_added']=false;
        if(isset($_COOKIE['wdk_listings_compare']))
        {
            $data_cookie = unserialize(base64_decode($_COOKIE['wdk_listings_compare']));

            if(isset($data_cookie[$wdk_listing_id]))
                $this->data['compare_added']=true;
        }
        

        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        } else {
          
        }

        echo $this->view('wdk-compare-listing', $this->data); 
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-compare-listing'),
                'tab' => '1',
            ]
        );

        $this->add_responsive_control(
            'hide_list_compare',
            [
                    'label' => esc_html__( 'Hide List Compare / LInk', 'wdk-compare-listing' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-compare-listing' ),
                    'block' => esc_html__( 'Show', 'wdk-compare-listing' ),
                    'return_value' => 'none',
                    'default' => 'none',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-compare-listing .сompare_list' => 'display: {{VALUE}};',
                        '{{WRAPPER}} .wdk-compare-listing .open_compare_link' => 'display: {{VALUE}};',
                    ],
            ]
        );

        $this->add_control(
            'button_add_text',
            [
                'label' => __('Text', 'wdk-compare-listing'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Add to Compare', 'wdk-compare-listing'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_remove_text',
            [
                'label' => __('Text Remove', 'wdk-compare-listing'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Remove from Compare', 'wdk-compare-listing'),
                'separator' => 'before',
            ]
        );
       
        $this->add_control(
            'button_add_icon',
            [
                'label' => esc_html__('Icon', 'wdk-compare-listing'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-compress-alt',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'button_add_icon_position',
            [
                'label' => esc_html__('icon Position', 'wdk-compare-listing'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'wdk-compare-listing'),
                    'right' => esc_html__('Right', 'wdk-compare-listing'),
                ],
                'default' => 'right',
            ]
        );

        $this->add_responsive_control(
            'button_page_header',
            [
                'label' => esc_html__('Button Open Compare Page', 'wdk-compare-listing'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'button_page_text',
            [
                'label' => __('Text', 'wdk-compare-listing'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Compare Page open', 'wdk-compare-listing'),
                'separator' => 'before',
            ]
        );
       
        $this->add_control(
            'button_page_icon',
            [
                'label' => esc_html__('Icon', 'wdk-compare-listing'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'button_page_icon_position',
            [
                'label' => esc_html__('icon Position', 'wdk-compare-listing'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'wdk-compare-listing'),
                    'right' => esc_html__('Right', 'wdk-compare-listing'),
                ],
                'default' => 'left',
            ]
        );
        
        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'btn_add_section',
            [
                'label' => esc_html__('Button Add To Compare', 'wdk-compare-listing'),
                'tab' => 'tab_layout'
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button%1$s'
        );
        $this->generate_renders_tabs($selectors, 'btn_add_section_dynamic', 'full');

        $this->add_responsive_control(
            'btn_add_icon_header',
            [
                'label' => esc_html__('Icon', 'wdk-compare-listing'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
           'btn_add_icon_size',
            [
                'label' => esc_html__('Size', 'wdk-favorites'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 3,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button i,{{WRAPPER}}.wdk-compare-listing .wdk-compare-listing-button svg',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button%1$s i,{{WRAPPER}} .wdk-compare-listing .wdk-compare-listing-button%1$s svg'
        );
        $this->generate_renders_tabs($selectors, 'btn_add_icon_dynamic', ['margin','color','background','border','border_radius','padding','shadow','transition']);

        $this->end_controls_section();
        /* END special for some elements */

         /* special for open compare page element */
        $this->start_controls_section(
            'button_page_section',
            [
                'label' => esc_html__('Button Open Compare Page', 'wdk-compare-listing'),
                'tab' => 'tab_layout'
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing .open_compare_link',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing .open_compare_link%1$s'
        );
        $this->generate_renders_tabs($selectors, 'button_page_section_dynamic', 'full');

        $this->add_responsive_control(
            'button_page_icon_header',
            [
                'label' => esc_html__('Icon', 'wdk-compare-listing'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
           'button_page_icon_size',
            [
                'label' => esc_html__('Size', 'wdk-favorites'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 3,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-compare-listing .open_compare_link i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing .open_compare_link i,{{WRAPPER}}.wdk-compare-listing .open_compare_link svg',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing .open_compare_link%1$s i,{{WRAPPER}} .wdk-compare-listing .open_compare_link%1$s svg'
        );
        $this->generate_renders_tabs($selectors, 'button_page_icon_dynamic', ['margin','color','background','border','border_radius','padding','shadow','transition']);

        $this->end_controls_section();
        /* END special for some elements */

         /* special for list element */
        $this->start_controls_section(
            'list_style_section',
            [
                'label' => esc_html__('List Style', 'wdk-compare-listing'),
                'tab' => 'tab_layout'
            ]
        );

        $items = [
            [
                'key'=>'list_item',
                'label'=> esc_html__('List Item', 'wdk-report-abuse'),
                'selector'=>'.wdk-compare-listing .сompare_list .wdk-item',
                'options'=>'block',
            ],
            [
                'key'=>'list_item_title',
                'label'=> esc_html__('Title', 'wdk-report-abuse'),
                'selector'=>'.wdk-compare-listing .сompare_list .wdk-item .value',
                'options'=>'full',
            ],
            [
                'key'=>'list_item_close',
                'label'=> esc_html__('Close Button', 'wdk-report-abuse'),
                'selector'=>'.wdk-compare-listing .сompare_list .wdk-item .wdk_item_remove',
                'options'=>'full',
            ],
        ];

        foreach ($items as $item) {
     
            $this->add_responsive_control (
                $item['key'].'_header',
                [
                    'label' => $item['label'],
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );

            if($item['key'] == 'list_item_close') {
                $this->add_responsive_control(
                    $item['key'].'_icon_size',
                    [
                        'label' => esc_html__('Size', 'wdk-favorites'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 3,
                                'max' => 60,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'].' i' => 'font-size: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
            }

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);
        }

        $this->end_controls_section();
        /* END special for some elements */

    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-compare-listing');

        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
    }
}
