<?php

namespace WdkCompare_Listing\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkCompare_Table extends WdkCompare_ListingElementorBase {


    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-compare-listing')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-compare-table';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Compare Table', 'wdk-compare-listing');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-shape';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['listings_compare'] = array();
        
        $data_cookie = [];
        if(isset($_COOKIE['wdk_listings_compare']))
            $data_cookie = unserialize(base64_decode($_COOKIE['wdk_listings_compare']));

        $listings_ids = array();
        foreach($data_cookie as $listing_id => $v) {
            if(!isset($listings_ids [$listing_id]))
                $listings_ids [$listing_id] = $listing_id;
        }

        /* where in */
        $results = array();
        if(!empty($listings_ids)){
            $Winter_MVC_WDK->db->where( $Winter_MVC_WDK->db->prefix.'wdk_listings.post_id IN(' . implode(',', $listings_ids) . ')', null, false);
            $Winter_MVC_WDK->db->where(array('is_activated' => 1, 'is_approved'=>1));
            $Winter_MVC_WDK->db->order_by('FIELD('.$Winter_MVC_WDK->db->prefix.'wdk_listings.post_id, '. implode(',', $listings_ids) . ')');

            $this->data['listings_compare'] = $Winter_MVC_WDK->listing_m->get();
           
        }

        $Winter_MVC_WDK->model('field_m');
		$fields_data = $Winter_MVC_WDK->field_m->get();

        $this->data['fields_list'] = array('' => esc_html__('Not Selected', 'wdk-compare-listing'));
        $this->data['fields_list']['post_title'] = esc_html__('WP Title', 'wdk-compare-listing');
        $this->data['fields_list']['address'] = esc_html__('Address', 'wdk-compare-listing');
        $this->data['fields_list']['category_id'] = esc_html__('Category', 'wdk-compare-listing');
        $this->data['fields_list']['location_id'] = esc_html__('Location', 'wdk-compare-listing');

        foreach($fields_data as $field)
        {
            if(wmvc_show_data('field_type', $field) == 'SECTION') {
                $this->data['fields_list']['section__'.wmvc_show_data('idfield', $field)] = wmvc_show_data('field_label', $field).'';
            } else {
                $this->data['fields_list'][wmvc_show_data('idfield', $field)] = wmvc_show_data('field_label', $field);
            }
        }
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()) {
            $this->data['is_edit_mode']= true;
        } else {
          
        }

        if (Plugin::$instance->editor->is_edit_mode()) {
            echo $this->view('wdk-compare-table-demo', $this->data);
        } else {
            echo $this->view('wdk-compare-table', $this->data);
        }
    }

    private function generate_controls_conf() {
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'colors_sections',
            [
                    'label' => esc_html__('Styles', 'wdk-compare-listing'),
                    'tab' => '1'
                ]
        );

        $this->add_control(
            'primary_color',
            [
                    'label' => __('Color Primary', 'wdk-bookings'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-compare-table  ' => '--color_primary:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'border_color',
            [
                    'label' => __('Border Color', 'wdk-compare-listing'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-compare-table ' => '--border_color:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'table_row_hover',
            [
                    'label' => __('Hover Row color', 'wdk-compare-listing'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-compare-table table.wdk-table tbody > *:hover' => 'background-color:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'border_width',
            [
                    'label' => __('Border Width', 'wdk-compare-listing'),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 5,
                            'step' => 1,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-compare-table ' => '--border_width: {{SIZE}}{{UNIT}};',
                    ],
                ]
        );
        
        $items = [
            [
                'key'=>'text',
                'label'=> esc_html__('Content', 'wdk-compare-listing'),
                'selector'=>'.wdk-compare-table table.wdk-table td',
                'options'=>['typo','color','align'],
            ],
            [
                'key'=>'action',
                'label'=> esc_html__('Button', 'wdk-compare-listing'),
                'selector'=>'.btn.btn-open',
                'selector_hover'=>'.btn.btn-open%1$s',
                'options'=>['typo','color','background','border','border_radius','padding','shadow','transition'],
            ],
        ];
        $this->add_control(
			'more_options',
			[
				'label' => __( 'Additional Options', 'wdk-compare-listing' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        foreach ($items as $item) {
            $this->add_control(
                $item['key'].'_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
            );

            if(isset($item['selector_hover']))
                $selectors['hover'] ='{{WRAPPER}} '.$item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

           }

        /* END special for some elements */
        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-compare-table');
        wp_enqueue_style( 'dashicons' );
    }
}
