<?php

namespace WdkCompare_Listing\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkCompare_Button extends WdkCompare_ListingElementorBase {


    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-compare-listing')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-compare-listing')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-compare-listing-button';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Compare Listing Button', 'wdk-compare-listing');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-kit-upload-alt';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['wdk_listing_id'] = $wdk_listing_id;
        /* settings from atts */
   
        $compare_added=false;
        if(isset($_COOKIE['wdk_listings_compare']))
        {
            $data_cookie = unserialize(base64_decode($_COOKIE['wdk_listings_compare']));

            if(isset($data_cookie[$wdk_listing_id]))
                $compare_added=true;
        }
        
        $this->data ['compare_added'] = $compare_added;

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }
 
        echo $this->view('wdk-compare-listing-button', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-compare-listing'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'compare_notadded_icon',
            [
                'label' => esc_html__('Icon when not in compare', 'wdk-compare-listing'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-exchange-alt',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'compare_added_icon',
            [
                'label' => esc_html__('Icon added in compare', 'wdk-compare-listing'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-exchange-alt',
                    'library' => 'solid',
                ],
            ]
        );

        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'colors_sections_basic',
            [
                    'label' => esc_html__('Basic', 'wdk-compare-listing'),
                    'tab' =>'tab_layout',
                ]
        );

        $this->add_responsive_control(
            'compare_basic_size',
            [
                'label' => esc_html__('Size', 'wdk-compare-listing'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 3,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-compare-listing-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing-button .wdk-remove-compare-action',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing-button .wdk-remove-compare-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'compare_basic_dynamic', ['padding']);

        $this->end_controls_section();

        $this->start_controls_section(
            'colors_sections_notadd_compare',
            [
                    'label' => esc_html__('Syle not active button', 'wdk-compare-listing'),
                    'tab' => 'tab_layout',
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing-button .wdk-add-compare-action',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing-button .wdk-add-compare-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'compare_notadded_dynamic', ['color','padding','background']);


        $this->end_controls_section();

        $this->start_controls_section(
            'colors_sections_add_compare',
            [
                    'label' => esc_html__('Syle active button', 'wdk-compare-listing'),
                    'tab' => 'tab_layout'
                ]
        );


        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-compare-listing-button .wdk-remove-compare-action',
            'hover'=>'{{WRAPPER}} .wdk-compare-listing-button .wdk-remove-compare-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'compare_added_dynamic', ['color','padding','background']);

        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-compare-listing-button');
    }
}
