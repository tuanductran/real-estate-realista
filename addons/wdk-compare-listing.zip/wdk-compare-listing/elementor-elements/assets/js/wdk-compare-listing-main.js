(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	jQuery('.wdk-compare-table table.wdk-table tr.section_tr + tr.section_tr').prev().remove()
	
	const wdk_init_compare_elem = () => {
		let compare_widget = jQuery('.wdk-compare-listing');
		let load_indicator = compare_widget.find('.wdk-compare-listing-button');

        var loading_activate = () => {
			load_indicator.addClass('loading');
		};

        var loading_deactivate = () => {
			load_indicator.removeClass('loading');
		};

		/* remove */
		var remove_from_compare = function() {
			compare_widget.find(".wdk_item_remove").off().on('click', function(e) {
				e.preventDefault();

				var self = $(this);
				var wdk_post_id = $(this).attr('data-post_id')
				var conf_link = $(this).attr('data-url')
	
				var data = [];
				data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
				data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
				data.push({ name: 'function', value: "remove_from_compare" });
				data.push({ name: 'post_id', value: wdk_post_id });
							 
				loading_activate();
	
				$.post(conf_link, data, 
					function (data) {
						
					if(data.message)
						box_alert.html(data.message);
		
					if(data.popup_text_success)
						wdk_log_notify(data.popup_text_success);
						
					if(data.popup_text_error)
						wdk_log_notify(data.popup_text_error, 'error');
						
					if(data.success)
					{
					
					} else {
						
					}
				}).always(function(data) {
					loading_deactivate();
					get_compare_list();
				});

				return false;
			});
		}

		/* remove */
		var get_compare_list = function() {
			var self = $(this);
		var conf_link = compare_widget.find('.config').attr('data-url');

		if(compare_action.length)
			conf_link = compare_action.find('.config').attr('data-url');

		var data = [];
		data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
		data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
		data.push({ name: 'function', value: "get_compare_list" });
					 
		loading_activate();

		if(xhr)
			xhr.abort();

		xhr = $.post(conf_link, data, 
			function (data) {
				
			if(data.success)
			{
				
			} else {
				
			}
		}).always(function(data) {
		
		});
		}

		// [START] Add to compare //  
		compare_widget.find(".wdk-compare-listing-button").off().on('click', function(e) {
			e.preventDefault();
			var self = $(this);
			var wdk_post_id = $(this).attr('data-post_id')
			var conf_link = $(this).attr('data-url')

			var data = [];
			data.push({ name: 'action', value: "wdk_compare_listing_public_action" });
			data.push({ name: 'page', value: "wdk-compare-listing-frontendajax" });
			data.push({ name: 'function', value: "add_to_compare" });
			data.push({ name: 'post_id', value: wdk_post_id });
						 
			loading_activate();

			$.post(conf_link, data, 
				function (data) {
					
				if(data.message)
					box_alert.html(data.message);
	
				if(data.popup_text_success)
					wdk_log_notify(data.popup_text_success);
					
				if(data.popup_text_error)
					wdk_log_notify(data.popup_text_error, 'error');
					
				if(data.success)
				{
				
				} else {
					
				}
			}).always(function(data) {
				loading_deactivate();
				get_compare_list()
			});
	
			return false;
		});
		// [END] Add to compare //  

		get_compare_list();
	}
	/* moved in public */
	//wdk_init_compare_elem();
})(jQuery);