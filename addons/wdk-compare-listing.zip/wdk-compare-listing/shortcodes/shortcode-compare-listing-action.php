<?php

/*
* Widget [wdk-compare-listing-action], show action add/remove compare-listing
*
* Layout path : 
* get_template_directory().'/wdk-compare-listing/shortcodes/views/shortcode-compare-listing-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-compare-listing-action.php'
*/

add_shortcode('wdk-compare-listing-button', 'wdk_compare_listing_action_button');
function wdk_compare_listing_action_button($atts, $content) {
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'wdk_listing_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = $atts;

    global $wdk_listing_id;
    if(isset($wdk_listing_id) && empty($data['wdk_listing_id']))
        $data['wdk_listing_id'] = $wdk_listing_id;
    
    if(!isset($data['wdk_listing_id']) || empty($data['wdk_listing_id'])) 
        return false;

    $data['compare_added']=false;
    
    if(isset($_COOKIE['wdk_listings_compare']))
    {
        $data_cookie = unserialize(base64_decode($_COOKIE['wdk_listings_compare']));
        if(isset($data_cookie[$data['wdk_listing_id']]))
            $data['compare_added']=true;
    }
    wp_enqueue_style('wdk-compare-listing-button');
    /* End Favorite module */
    return wdk_compare_listing_shortcodes_view('shortcode-compare-listing-action', $data);
}

?>