<?php
    $compare_page_url = '';
    if (get_option('wdk_compare_page')) {
        $obj_id = get_queried_object_id();
        $compare_page_url = get_permalink(get_option('wdk_compare_page'));
    }

    if(!$compare_page_url)
        return false;
?>
   
<?php if(!$compare_page_url):?>
    <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Compare Listings Page Not Defined in Settings', 'wdk-compare-listing');?></p>
<?php endif;?>

<span class="wdk-compare-listing-button-actions" data-post_id="<?php echo esc_attr($wdk_listing_id);?>">
    <span class="config wdk-hidden" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></span>
    <a href="#" data-post_id="<?php echo esc_attr($wdk_listing_id);?>" class="wdk-add-compare-action <?php echo (esc_attr($compare_added))?'wdk-hidden':''; ?>"  data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
        <i aria-hidden="true" class="fas fa-exchange-alt"></i>
    </a>
    <a href="#" data-post_id="<?php echo esc_attr($wdk_listing_id);?>" class="wdk-remove-compare-action <?php echo (!esc_attr($compare_added))?'wdk-hidden':''; ?>" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
        <i aria-hidden="true" class="fas fa-exchange-alt"></i>
    </a>
    <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
</span>