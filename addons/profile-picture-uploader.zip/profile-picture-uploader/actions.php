<?php

// Adding fields to edit user
add_action( 'edit_user_profile', 'ppu_custom_user_profile_fields' );
add_action( 'show_user_profile', 'ppu_custom_user_profile_fields' );
 
function ppu_custom_user_profile_fields( $user )
{

    echo '<div class="wdk_postbox" style="display: block;">';
        echo '<div class="wdk_postbox-header">';
            echo '<h3 class="heading ">'.esc_html__('Profile Picture Uploader', 'ppu').'</h3>';
        echo '</div>';
        echo '<div class="wdk_inside">';
    ?>
        
        <table class="form-table">
        <tr>
                <th><label for="contact"><?php echo esc_html__('Profile Picture', 'ppu'); ?></label></th>
    
            <td><?php 

            $profile_picture_id = get_user_meta( $user->ID, 'profile_picture_id', true );
            
            echo ppu_upload_media('profile_picture_id', $profile_picture_id); ?></td>
    
        </tr>
        </table>
        </div>
    </div>
    <?php
}

// saving functionality
add_action( 'personal_options_update', 'ppu_save_extra_user_profile_fields' );
add_action( 'edit_user_profile_update', 'ppu_save_extra_user_profile_fields' );

function ppu_save_extra_user_profile_fields( $user_id ) {
    if(is_object($user_id)) {
        $user_id = $user_id ->ID;
    }

    if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-user_' . $user_id ) ) {
        return;
    }
    
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }
    update_user_meta( $user_id, 'profile_picture_id', (int) $_POST['profile_picture_id'] );
}

// filter images to show only own images
add_filter( 'ajax_query_attachments_args', 'ppu_show_current_user_attachments' );
 
function ppu_show_current_user_attachments( $query ) {
    $user_id = get_current_user_id();
    if ( $user_id && !current_user_can('activate_plugins') && !current_user_can('edit_others_posts
') ) {
        $query['author'] = $user_id;
    }

    return $query;
} 

add_action('pre_get_posts','users_own_attachments');
function users_own_attachments( $wp_query_obj ) {

    global $current_user, $pagenow;

    $is_attachment_request = ($wp_query_obj->get('post_type')=='attachment');

    if( !$is_attachment_request )
        return;

    if( !is_a( $current_user, 'WP_User') )
        return;

    if( !in_array( $pagenow, array( 'upload.php', 'admin-ajax.php' ) ) )
        return;

    if( !current_user_can('delete_pages') )
        $wp_query_obj->set('author', $current_user->ID );

    return;
}

// Add ability to upload files

add_action( 'admin_init', 'ppu_admin_init' );
 
function ppu_admin_init() {

    if( is_user_logged_in() ) {
	 
        $user = wp_get_current_user();
        $roles = ( array ) $user->roles;

        if(isset($roles[0]))
        {
            $contributor = get_role($roles[0]);
            $contributor->add_cap('upload_files');
        }

        // if not admin disable bulk features since bulk delete doesn't work properly in such cases and is not suggested
        $styles_not_admin = '
        body.upload-php .media-toolbar button.media-button.select-mode-toggle-button,
        body.upload-php .media-toolbar .view-switch a.view-list
        {
            display:none;
        }
        ';

        if(!current_user_can('administrator'))
            wp_add_inline_style( 'buttons' , $styles_not_admin );
        

        // disable showing standard gravatar related image feature in edit used/profile page
        $styles_all = '
        tr.user-profile-picture
        {
            display: none;
        }

        .postbox-upload
        {
            max-width: 200px;
        }
        ';

        wp_add_inline_style( 'buttons' , $styles_all );

    }

    load_plugin_textdomain(
        'ppu',
        false,
        dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
    );
}

// if picture uploaded show it as avatar picture, otherwise standard one from gravatar

add_filter('get_avatar_url', 'ppu_profile_avatar_url', 10, 5);
function ppu_profile_avatar_url( $avatar, $id_or_email, $size ) {
  
    $user = '';
    // Get user by id or email
    if ( is_numeric( $id_or_email ) ) {
  
        $id   = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
  
    } elseif ( is_object( $id_or_email ) ) {
  
        if ( ! empty( $id_or_email->user_id ) ) {
            $id   = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }
  
    } else {
        $user = get_user_by( 'email', $id_or_email );
    }
  
    if ( ! $user ) {
        return $avatar;
    }
  
    // Get the user id
    $user_id = $user->ID;
  
    // Get the file id
    $avatar_picture_id = get_user_meta($user_id, 'profile_picture_id', true);
    // Get the img markup

    if(!empty($avatar_picture_id))
    {
        $avatar_url = wp_get_attachment_image_src($avatar_picture_id, array($size, $size), true );
        $avatar_url = $avatar_url[0];

        $avatar = $avatar_url;
    }
  
    // Return our new avatar
    return $avatar;
}

add_filter('get_avatar', 'ppu_profile_avatar', 10, 5);
function ppu_profile_avatar( $avatar, $id_or_email, $size, $default, $alt ) {
  
    $user = '';
    // Get user by id or email
    if ( is_numeric( $id_or_email ) ) {
  
        $id   = (int) $id_or_email;
        $user = get_user_by( 'id' , $id );
  
    } elseif ( is_object( $id_or_email ) ) {
  
        if ( ! empty( $id_or_email->user_id ) ) {
            $id   = (int) $id_or_email->user_id;
            $user = get_user_by( 'id' , $id );
        }
  
    } else {
        $user = get_user_by( 'email', $id_or_email );
    }
  
    if ( ! $user ) {
        return $avatar;
    }
  
    // Get the user id
    $user_id = $user->ID;

    return $avatar; // this for now seems like works fine
  
    // Get the file id
    $avatar_picture_id = get_user_meta($user_id, 'profile_picture_id', true);
    // Get the img markup

    if(!empty($avatar_picture_id))
    {
        $avatar_url = wp_get_attachment_image_src($avatar_picture_id, array($size, $size), true );
        $avatar_url = $avatar_url[0];

        $avatar = '<img alt="' . $alt . '" src="' . $avatar_url . '" class="avatar avatar-' . $size . '" height="' . $size . '" width="' . $size . '"/>';
    }
  
    // Return our new avatar
    return $avatar;
}

// functions for upload images

function ppu_upload_media($field_name, $image_id)
{
    static $media_element_counter = 0;
        
    $media_element_counter++;
    
    $img_field = $field_name.'_'.$media_element_counter;
    
    wp_enqueue_script(  'wpmediaelement',  plugins_url(dirname(plugin_basename( __FILE__ )) .'/assets/js/jquery.wpmediaelement.js'), false, false, false );
    wp_enqueue_media();

    ?>
    <div id="<?php echo esc_attr($field_name); ?>meta-box-id" class="postbox-upload">
    <?php
    // Get WordPress' media upload URL
    $upload_link = '#';
    
    // Get the image src
    $your_img_src = wp_get_attachment_image_src( $image_id, 'full' );

    // For convenience, see if the array is valid
    $you_have_img = is_array( $your_img_src );
    ?>
    
    <!-- Your image container, which can be manipulated with js -->
    <div class="custom-img-container">
        <?php if ( $you_have_img ) : ?>
            <img src="<?php echo esc_html($your_img_src[0]); ?>" alt="..." style="max-width:100%;" />
        <?php endif; ?>
    </div>
    
    <?php //if(sw_user_in_role('administrator')): ?>
    <!-- Your add & remove image links -->
    <p class="hide-if-no-js">
        <a class="button button-primary upload-custom-img <?php if ( $you_have_img  ) { echo 'hidden'; } ?>" 
        href="<?php echo esc_url($upload_link) ?>">
            <?php echo esc_html__('Select image','ppu') ?>
        </a>
        <a class="button button-secondary delete-custom-img <?php if ( ! $you_have_img  ) { echo 'hidden'; } ?>" 
        href="#">
            <?php echo esc_html__('Remove image','ppu') ?>
        </a>
    </p>
    <?php //endif; ?>
    
    <!-- A hidden input to set and post the chosen image id -->
    <input class="logo_image_id" type="hidden" id="<?php echo esc_html(esc_html($field_name)); ?>" name="<?php echo esc_html($field_name); ?>" value="<?php echo esc_html($image_id); ?>" />
    </div>
    
    <?php
    $custom_js ='';
    $custom_js .=" jQuery(function($) {
                        if( typeof jQuery.fn.wpMediaElement == 'function')
                            $('#".esc_js($field_name)."meta-box-id.postbox-upload').wpMediaElement();
                    });";
    
    echo "<script>".$custom_js."</script>";

    ?>

    <?php
}



?>