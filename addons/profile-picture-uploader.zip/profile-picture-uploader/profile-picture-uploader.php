<?php

/**
 * Plugin Name: Profile Picture Uploader
 * Description: WordPress support only Gravatar, with this plugin visitors will be able to upload own image directly from Dashboard.
 * Plugin URI:  https://wpdirectorykit.com/plugins/wp-directory-profile-picture-uploader.html
 * Version:     1.0.1
 * Author:      wpdirectorykit.com
 * Author URI:  https://wpdirectorykit.com
 * Text Domain: ppu
 * Domain Path: /languages/
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

function ppu_load() {
	// Load tranlsate file
	load_plugin_textdomain( 'ppu' , false, basename( dirname( __FILE__ ) ) . '/languages' );
}

add_action( 'plugins_loaded', 'ppu_load' );

if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    require_once plugin_dir_path( __FILE__ ) . 'actions.php';
}


?>