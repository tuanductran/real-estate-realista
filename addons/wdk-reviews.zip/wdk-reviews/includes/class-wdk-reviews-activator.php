<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Reviews
 * @subpackage Wdk_Reviews/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Reviews
 * @subpackage Wdk_Reviews/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Reviews_Activator {

	public static $db_version = 1.0;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$prefix = 'wdk_reviews_';
	}

	
    public static function plugins_loaded()
    {
		if ( get_site_option( 'wdk_reviews_db_version' ) === false ||
		     get_site_option( 'wdk_reviews_db_version' ) < self::$db_version ) {
			self::install();
		}
    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0
        if(get_site_option( 'wdk_reviews_db_version' ) === false)
        {
            // Main table for reviews calendar

            $table_name = $wpdb->prefix . 'wdk_reviews_type';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreviews_type` int(11) NOT NULL AUTO_INCREMENT,
                    `review_post_type` varchar(50) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
					`stars_total` decimal(12,1) DEFAULT NULL,
					`reviewers_total` int(11) DEFAULT NULL,
                    `is_activated` tinyint(1) DEFAULT NULL,
					`star_icon_active` int(11) DEFAULT NULL,
					`star_icon_inactive` int(11) DEFAULT NULL,
					`star_icon_half_active` int(11) DEFAULT NULL,
					`star_icon_half_inactive` int(11) DEFAULT NULL,
                PRIMARY KEY  (idreviews_type)
            ) $charset_collate COMMENT='reviews type';";
        
            dbDelta( $sql );

            // Main table for reviews calendar

            $table_name = $wpdb->prefix . 'wdk_reviews_option';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreviews_option` int(11) NOT NULL AUTO_INCREMENT,
					`date` datetime DEFAULT NULL,
                    `reviews_type_id` int(11) DEFAULT NULL,
                    `option_name` varchar(160) DEFAULT NULL,
					`option_hint` varchar(160) DEFAULT NULL,
                    `order_index` int(11) DEFAULT NULL,
                    `is_activated` tinyint(1) DEFAULT NULL,
                    `stars_total` decimal(12,1) DEFAULT NULL,
					`reviewers_total` int(11) DEFAULT NULL,
                PRIMARY KEY  (idreviews_option)
            ) $charset_collate COMMENT='reviews options';";

            dbDelta( $sql );

            $table_name = $wpdb->prefix . 'wdk_reviews_data';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreviews_data` int(11) NOT NULL AUTO_INCREMENT,
                    `review_id` int(11) DEFAULT NULL,
                    `review_option_id` int(11) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `review_comment` text,
					`stars_total` decimal(12,1) DEFAULT NULL,
                    `review_images` text,
                PRIMARY KEY  (idreviews_data)
            ) $charset_collate COMMENT='reviews data';";
        
            dbDelta( $sql );

            $table_name = $wpdb->prefix . 'wdk_reviews';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreviews` int(11) NOT NULL AUTO_INCREMENT,
                    `post_id` int(11) DEFAULT NULL,
                    `reviews_type_id` int(11) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `user_id` int DEFAULT NULL,
                    `is_confirmed` tinyint(1) DEFAULT NULL,
                    `review_comment` text,
					`stars` decimal(3,1) DEFAULT NULL,
                    `review_images` text,
                PRIMARY KEY  (idreviews)
            ) $charset_collate COMMENT='reviews';";
        
            dbDelta( $sql );

            update_option( 'wdk_reviews_db_version', "1" );

        }

        //update_option( 'wdk_wdk_reviews_db_version', self::$wdk_reviews_db_version );
    }

}
