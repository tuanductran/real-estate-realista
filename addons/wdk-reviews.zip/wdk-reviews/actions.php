<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'wpdirectorykit/install/api', 'wdk_reviews_install'); 

if(!function_exists('wdk_reviews_install')) {
    function wdk_reviews_install () {
        global $Winter_MVC_wdk_reviews;
        global $Winter_MVC_WDK;
        $Winter_MVC_wdk_reviews->model('reviews_option_m');
        $Winter_MVC_wdk_reviews->model('reviews_m');
        $Winter_MVC_wdk_reviews->model('reviews_type_m');
        $Winter_MVC_wdk_reviews->model('reviews_data_m');

        if($Winter_MVC_wdk_reviews->reviews_m->get()){
            //$this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Booking already imported', 'wdk-reviews').'</div>';
            return false;
        }

        /* remove data */
        $Winter_MVC_wdk_reviews->db->delete($Winter_MVC_wdk_reviews->reviews_m->_table_name);
        $Winter_MVC_wdk_reviews->db->delete($Winter_MVC_wdk_reviews->reviews_option_m->_table_name);
        $Winter_MVC_wdk_reviews->db->delete($Winter_MVC_wdk_reviews->reviews_type_m->_table_name);
        $Winter_MVC_wdk_reviews->db->delete($Winter_MVC_wdk_reviews->reviews_data_m->_table_name);
        /* end remove data */

        /* reset autoincrement */
        $Winter_MVC_wdk_reviews->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_reviews->reviews_m->_table_name.'`');
        $Winter_MVC_wdk_reviews->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_reviews->reviews_option_m->_table_name.'`');
        $Winter_MVC_wdk_reviews->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_reviews->reviews_type_m->_table_name.'`');
        $Winter_MVC_wdk_reviews->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_reviews->reviews_data_m->_table_name.'`');
        // Save currency_m
        
        /* generated listings reviews */
        if (true) {
            /* type */
            $data = array();
            $data['review_post_type'] = 'wdk-listing';
            $data['is_activated'] = 1;
            $idreviews_type = $Winter_MVC_wdk_reviews->reviews_type_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Owner Listing', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about owner of listing from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_1 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Location', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about place near listing from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_2 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Indoor Listing', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about indoor of listing from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_3 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Condition Listing', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about condition from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_4 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);



            $Winter_MVC_WDK->model('listing_m');
            $listings = $Winter_MVC_WDK->listing_m->get();

            $dbusers =  get_users(array( 'search' => '',
                                        'order_by' => 'ID', 'order' => 'DESC'));

            $users = array();
            foreach ($dbusers as $dbuser) {
                $users[] = wmvc_show_data('ID', $dbuser);
            }

            if(count( $users) > 2)
                foreach ($listings as $listing) {
                    $rand_users_keys = array_rand($users, 2);
                    /* review */
                    /* first review */
                    $data = array();
                    $data['reviews_type_id'] = $idreviews_type;
                    $data['post_id'] = wmvc_show_data('post_id', $listing);
                    $data['user_id'] = $users[$rand_users_keys[0]];
                    $data['review_comment'] = esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'wdk-reviews');
                    $data['is_confirmed'] = 1;
                        
                    $data_options = array();
                    $data_options['option_'.$idreviews_option_1] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_2] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_3] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_4] = rand(1, 5);

                    $Winter_MVC_wdk_reviews->reviews_m->save_with_options($data, $data_options);

                    /* second review */
                    $data = array();
                    $data['reviews_type_id'] = $idreviews_type;
                    $data['post_id'] = wmvc_show_data('post_id', $listing);
                    $data['user_id'] =  $users[$rand_users_keys[1]];
                    $data['review_comment'] = esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'wdk-reviews');
                    $data['is_confirmed'] = 1;
                        
                    $data_options = array();
                    $data_options['option_'.$idreviews_option_1] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_2] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_3] = rand(1, 5);
                    $data_options['option_'.$idreviews_option_4] = rand(1, 5);

                    $Winter_MVC_wdk_reviews->reviews_m->save_with_options($data, $data_options);
                }
                
        }

        /* generated profile reviews */
       
        if (true) {
            /* type */
            $data = array();
            $data['review_post_type'] = 'profile';
            $data['is_activated'] = 1;
            $idreviews_type = $Winter_MVC_wdk_reviews->reviews_type_m->insert($data, null);


            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Responsiveness', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about responsive from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_1 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Quality Service', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about quality service from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_2 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            /* option */
            $data = array();
            $data['reviews_type_id'] = $idreviews_type;
            $data['option_name'] = esc_html__('Quick answer', 'wdk-reviews');
            $data['option_hint'] = esc_html__('Set your opinion about quick of answer from 1 to 5', 'wdk-reviews');
            $data['is_activated'] = 1;
            $idreviews_option_3 = $Winter_MVC_wdk_reviews->reviews_option_m->insert($data, null);

            $dbusers =  get_users(array( 'search' => '',
                                        'order_by' => 'ID', 'order' => 'DESC'));

            $users = array();
            foreach ($dbusers as $dbuser) {
                $users[] = wmvc_show_data('ID', $dbuser);
            }

            if(count( $users) > 3)
            foreach ($users as $user_id) {

                $temp_users = $users;
                unset($temp_users[array_flip($users)[$user_id]]);
                $rand_users_keys = array_rand($temp_users, 2);

                /* first review */
                $data = array();
                $data['reviews_type_id'] = $idreviews_type;
                $data['post_id'] = $user_id;
                $data['user_id'] = $users[$rand_users_keys[0]];
                $data['review_comment'] = esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'wdk-reviews');
                $data['is_confirmed'] = 1;
                    
                $data_options = array();
                $data_options['option_'.$idreviews_option_1] = rand(1, 5);
                $data_options['option_'.$idreviews_option_2] = rand(1, 5);
                $data_options['option_'.$idreviews_option_3] = rand(1, 5);

                $Winter_MVC_wdk_reviews->reviews_m->save_with_options($data, $data_options);

                /* second review */
                $data = array();
                $data['reviews_type_id'] = $idreviews_type;
                $data['post_id'] = $user_id;
                $data['user_id'] = $users[$rand_users_keys[1]];
                $data['review_comment'] = esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.', 'wdk-reviews');
                $data['is_confirmed'] = 1;
                    
                $data_options = array();
                $data_options['option_'.$idreviews_option_1] = rand(1, 5);
                $data_options['option_'.$idreviews_option_2] = rand(1, 5);
                $data_options['option_'.$idreviews_option_3] = rand(1, 5);

                $Winter_MVC_wdk_reviews->reviews_m->save_with_options($data, $data_options);
            }
                
        }
        return true;
    }
}

add_action('wdk-membership/dash/homepage/widgets', function(){
    global $Winter_MVC_wdk_reviews;
    $Winter_MVC_wdk_reviews->model('reviews_m');
    $total_items = $Winter_MVC_wdk_reviews->reviews_m->total();

    if(function_exists('wdk_dash_url')) {
    ?>
    <div class="wdk-col-12 wdk-col-md-3  wdk-membership-dash-widget_reviews"> 
        <a href="<?php echo esc_url(wdk_dash_url('dash_page=reviews'));?>" class="wdk-membership-dash-widget">
            <span class="wdk-content">
                <span class="icon"><span class="dashicons dashicons-star-half"></span></span>
            </span>
            <span class="wdk-side">
                <span class="title"><?php echo esc_html__('Reviews','wdk-reviews');?></span>
                <span class="wdk-count"><?php echo esc_html($total_items);?></span>
            </span>
        </a>
    </div>
    <?php
    }
});
