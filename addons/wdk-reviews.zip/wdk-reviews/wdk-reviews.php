<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Reviews
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Reviews
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-review-system.html
 * Description:       Users will be able to rate listing or profiles based on configurable multiple criterias/options individually.
 * Version:           1.0.2
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-reviews
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_REVIEWS_VERSION', '1.0.2' );
define( 'WDK_REVIEWS_NAME', 'wdk-reviews' );
define( 'WDK_REVIEWS_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_REVIEWS_URL', plugin_dir_url( __FILE__ ) );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-reviews-activator.php
 */
function activate_wdk_reviews() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-reviews-activator.php';
	Wdk_Reviews_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-reviews-deactivator.php
 */
function deactivate_wdk_reviews() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-reviews-deactivator.php';
	Wdk_Reviews_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_reviews' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_reviews' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-reviews.php';

if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    run_wdk_reviews();
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wdk_reviews() {

	$plugin = new Wdk_Reviews();
	$plugin->run();

}

