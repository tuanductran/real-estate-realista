<?php
/**
 * The template for Shortcode Reviews Average
 * This is the template that Shortcode stars
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<span class="wdk-reviews-shortcode wdk-review-avg">
    <span class="wdk-reviews-average-basic">
        <ul class="rating-lst">
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <?php if ($i <= $stars_total): ?>
                    <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                    <?php else:?>
                        <li><i class="fas fa-star"></i></li>
                    <?php endif;?>
                <?php elseif( abs($stars_total - $i) < 1): ?>
                    <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                    <?php else:?>
                        <li><i class="fas fa-star-half-alt"></i></li>
                    <?php endif;?>
                <?php else: ?>
                    <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                    <?php else:?>
                        <li><i class="far fa-star innactive"></i></li>
                    <?php endif;?>
                <?php endif; ?>
            <?php endfor; ?>
        </ul><!--rating-lst end-->
    </span>
</span>