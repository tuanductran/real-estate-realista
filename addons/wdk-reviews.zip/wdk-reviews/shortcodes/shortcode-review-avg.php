<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-review-avg], show avg add/remove review
*
* Layout path : 
* get_template_directory().'/wdk-reviews/shortcodes/views/shortcode-review-avg.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-review-avg.php'
*/

add_shortcode('wdk-review-avg', 'wdk_review_avg');
function wdk_review_avg($atts, $content){
    $atts = shortcode_atts(array(
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;

    /* Favorite module */
    global $Winter_MVC_wdk_reviews; 
    global $wdk_listing_id;
  
        
    $Winter_MVC_wdk_reviews->model('reviews_m');
    $Winter_MVC_wdk_reviews->model('reviews_type_m');

    if (isset($wdk_listing_id)) {
        $data['post_id'] = $wdk_listing_id;
        $data['post_type'] = 'wdk-listing';
    }
    elseif(wdk_get_profile_page_id()){
        $data['post_id'] = wdk_get_profile_page_id();
        $data['post_type'] = 'profile';
    } else {
        $post_object_id = get_queried_object_id();
        if($post_object_id)
            $data['post_id'] = $post_object_id;

        $data['post_type'] = get_post_type();

        if(get_option('wdk_listing_page') == $data['post_id']){
            $data['post_type'] = 'wdk-listing';
        }

        if(get_option('wdk_membership_profile_preview_page') == $data['post_id']){
            $data['post_type'] = 'profile';
        }
    }

    $data['reviews_type_id'] = $Winter_MVC_wdk_reviews->reviews_type_m->get_type_id($data['post_type']);
    $data['reviews_type'] =  $Winter_MVC_wdk_reviews->reviews_type_m->get($data['reviews_type_id'], TRUE);

    $data['stars_total'] = 0; 
    $data['reviewers_total'] = 0;

    $generate_avg_total = $Winter_MVC_wdk_reviews->reviews_m->generate_avg_total($data['post_id']);
    if($generate_avg_total && is_intval(wmvc_show_data('stars_total',$generate_avg_total))) {
        $data['stars_total'] = round(floatval(wmvc_show_data('stars_total',$generate_avg_total)),2);
        $data['reviewers_total'] = wmvc_show_data('reviewers_total',$generate_avg_total);
    }
    
    wp_enqueue_style('wdk-reviews-average-basic');

    if(empty($data['stars_total'])) return false;
    return wdkreviews_shortcodes_view('shortcode-review-avg', $data);
}

?>