(function( $ ) {
	'use strict';
	$(document).on('ready', function () { 
		if (window.location.hash.indexOf('wdk_review') !== -1) {
			$(window.location.hash).addClass('active');
			$('html, body').animate({
				scrollTop: $(window.location.hash).offset().top - 100
			}, 500);
		}

		$('.wdk-reviews-list .wdk-click-load-animation').on('click',function(e){
			e.preventDefault();
			var _this = jQuery(this);
			var loading_el = _this.find('.fa-ajax-indicator');

			var data = [];
			data.push({ name: 'action', value: "wdk_reviews_public_action" });
			data.push({ name: 'page', value: "wdk_reviews_frontendajax" });
			data.push({ name: 'function', value: "pagination_reviews" });
			data.push({ name: 'post_id', value: _this.attr('data-post_id')});
			data.push({ name: 'offset', value: _this.attr('data-offset')});
			data.push({ name: 'limit', value: _this.attr('data-limit')});
			data.push({ name: 'reviews_type_id', value: _this.attr('data-reviews_type_id')});
	
			loading_el.show();
			
			var placeholder = () => {
				var html = '<div class="review-item placeholder"><div class="side side-thumb"><span class="wdk_loading_animation" style="height: 90px;width: 90px;display: block;"></span></div>\n\
				<div class="side side-content"><div class="review-header"><div class="side-left"><h4 class="title"><span class="wdk_loading_animation" style="height: 20px; width: 90px;"></span><span class="wdk_loading_animation" style="height: 20px; width: 90px; margin-left: 15px"></span></h4>\n\
				<span class="subtitle"><span class="date"><span style="height: 20px; width: 90px;"></span></span></span>\n\
				</div></div><div class="text"><span class="wdk_loading_animation" style="height:18px; width:100%;margin-bottom:10px; display: block"></span><span class="wdk_loading_animation" style="height:18px; width:100%;margin-bottom:10px; display: block"></span><span class="wdk_loading_animation" style="height:18px; width:100%;margin-bottom:10px; display: block"></span></div>\n\
				<div class="options"><div class="item"><div class="item-content"><h5 class="title"><span class="wdk_loading_animation" style="height: 18px; width: 90px;"></span></h5><div class="rating"><span class="wdk_loading_animation" style="height: 22px; width: 85px;"></span></div></div></div><div class="item"><div class="item-content"><h5 class="title"><span class="wdk_loading_animation" style="height: 18px; width: 90px;"></span></h5><div class="rating"><span class="wdk_loading_animation" style="height: 22px; width: 85px;"></span></div></div></div><div class="item"><div class="item-content"><h5 class="title"><span class="wdk_loading_animation" style="height: 18px; width: 90px;"></span></h5><div class="rating"><span class="wdk_loading_animation" style="height: 22px; width: 85px;"></span></div></div></div></div>\n\
				</div></div>';

				jQuery(html).appendTo(_this.closest('.wdk-reviews-list').find('.reviews-comments .placeholders'));
			};

			jQuery('<div class="placeholders" style="display: none"></div>').appendTo(_this.closest('.wdk-reviews-list').find('.reviews-comments'));
			for(var i = 0; i<_this.attr('data-placeholderslimit'); i++) {
				placeholder()
			}

			_this.closest('.wdk-reviews-list').find('.reviews-comments .placeholders').slideDown(400);

			$.post(wdk_reviews_list_parameters.ajax_url, data, 
				function(data){
					
					if(data.popup_text_success)
						wdk_log_notify(data.popup_text_success);
						
					if(data.popup_text_error)
						wdk_log_notify(data.popup_text_error, 'error');
					
				if(data.success)
				{
					_this.closest('.wdk-reviews-list').find('.reviews-comments .placeholders').remove();

					_this.closest('.wdk-reviews-list').find('.reviews-comments').append(data.output);
					_this.attr('data-offset',data.offset); 
					_this.attr('data-placeholderslimit',data.placeholderslimit); 

					if(!data.load_more) {
						_this.remove();
					}
				} else {

				}
			}).always(function() {
				loading_el.hide();
			});
		});
	})
})(jQuery);