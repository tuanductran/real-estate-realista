<?php

namespace WdkReviews\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkReviewsList extends WdkReviewsElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

	const REVIEW_SENT = 'sent';
	const REVIEW_ADDED = 'added';
	const REVIEW_LOGIN = 'login';
	const REVIEW_FORM = 'form';

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-reviews')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-reviews')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-reviews')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-reviews-list';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Reviews List', 'wdk-reviews');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-review';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        global $Winter_MVC_WDK;
        $this->WMVC_Reviews->model('reviews_option_m');
        $this->WMVC_Reviews->model('reviews_m');
        $this->WMVC_Reviews->model('reviews_type_m');

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['reviews_bottom'] = self::REVIEW_FORM;
        $this->data['validation_messages'] = false;

        if (isset($wdk_listing_id)) {
            $this->data['post_id'] = $wdk_listing_id;
            $this->data['post_type'] = 'wdk-listing';
        }
        elseif(wdk_get_profile_page_id()){
            $this->data['post_id'] = wdk_get_profile_page_id();
            $this->data['post_type'] = 'profile';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $this->data['post_id'] = $post_object_id;

            $this->data['post_type'] = get_post_type();

            if(get_option('wdk_listing_page') == $this->data['post_id']){
                $this->data['post_type'] = 'wdk-listing';
            }

            if(get_option('wdk_membership_profile_preview_page') == $this->data['post_id']){
                $this->data['post_type'] = 'profile';
            }
        }

        $this->data['reviews_type_id'] = $this->WMVC_Reviews->reviews_type_m->get_type_id($this->data['post_type']);
        $this->data['reviews_type'] =  $this->WMVC_Reviews->reviews_type_m->get($this->data['reviews_type_id'], TRUE);
        
        if(!is_user_logged_in()) {
            $this->data['reviews_bottom'] = self::REVIEW_LOGIN;
        }

        if(is_user_logged_in() && $this->WMVC_Reviews->reviews_m->check_if_exists(get_current_user_id(),$this->data['post_id'])) {
            if ($this->WMVC_Reviews->reviews_m->check_if_confirmed(get_current_user_id(), $this->data['post_id'])) {
                $this->data['reviews_bottom'] = self::REVIEW_ADDED;
            } else {
                $this->data['reviews_bottom'] = self::REVIEW_SENT;
            }
        }
      
        $this->data['options'] = $this->WMVC_Reviews->reviews_option_m->get_options($this->data['reviews_type_id']);

        $this->data['reviews_total']= $this->WMVC_Reviews->reviews_m->total(array('post_id'=>$this->data['post_id'], 'is_confirmed'=>1), FALSE);
        $this->data['reviews_list']= array();
        if(!Plugin::$instance->editor->is_edit_mode()){
            $this->data['reviews_list'] = $this->WMVC_Reviews->reviews_m->get_pagination( $this->data['settings']['reviews_limit'], NULL, array('post_id'=>$this->data['post_id'], 'is_confirmed'=>1), NULL, FALSE);
        }
                
        if(isset($_POST[$this->data['id_element'].'_review_form'])) {
			// it clears all the cache
			if(function_exists('wpfc_clear_all_cache'))
				wpfc_clear_all_cache();
			
			// it clears cache of all sites
			if(function_exists('wpfc_clear_all_site_cache'))
				wpfc_clear_all_site_cache();
			
			// it clears all the cache with the minified sources
			if(function_exists('wpfc_clear_all_cache'))
				wpfc_clear_all_cache(true);
            				
            // another way
            if (class_exists('\LiteSpeed\Purge')) {
              do_action('litespeed_purge_all');
            }
        }
        
        if(is_user_logged_in() && isset($_POST[$this->data['id_element'].'_review_form'])) {

            $this->WMVC_Reviews->input = new \MVC_Input();
            $this->WMVC_Reviews->form = new \MVC_Form();
            
            $_POST['reviews_type_id'] = $this->data['reviews_type_id'];
            /* save review */
            $fields_list = array(
                array(
                    'field' => 'review_comment',
                    'field_label' => __('Review', 'wdk-reviews'),
                    'label' => __('Review', 'wdk-reviews'),
                    'hint' => '', 
                    'field_type' => 'TEXTAREA', 
                    'rules' => 'required|wdk_reviewed_byself_front'
                )
            );
            $options = $this->WMVC_Reviews->reviews_option_m->get_options_list($this->data['reviews_type_id']);
            foreach($options as $option) {
                $option['rules'] = 'required';
                $fields_list[] = $option;
            }

            $this->WMVC_Reviews->form->add_error_message('wdk_reviewed_byself_front', __('Can\'t reviewed by themself', 'wdk-reviews'));
            if($this->WMVC_Reviews->form->run($fields_list))
            {
                // Save procedure for basic data
                $data = array();
                $data['review_comment'] = sanitize_text_field($this->WMVC_Reviews->input->post('review_comment'));
                $data['post_id'] = intval($this->data['post_id']);
                $data ['user_id'] = get_current_user_id();
                $data ['reviews_type_id'] = intval($this->data['reviews_type_id']);

                $insert_id = $this->WMVC_Reviews->reviews_m->save_with_options($data);
                $this->data['reviews_bottom'] = self::REVIEW_SENT;

                $subject = __('New review', 'wdk-reviews');
                
                $data_message = array();
                $data_message['user'] = get_userdata( wmvc_show_data('user_id', $data) );
                $data_message['review'] = $data; /* review data */
                $data_message['review_id']= $insert_id;
                
                $ret =  wdk_mail( get_bloginfo('admin_email'), $subject, $data_message, 'new_review_approve');

                unset($_POST['review_comment']);
                unset($_POST['user_id']);
                unset($_POST['post_id']);
                unset($_POST['reviews_type_id']);

                wp_redirect((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http").'://'.$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
                exit;

            } else {
                $this->data['form'] = $this->WMVC_Reviews->form;
                $this->data['validation_messages'] = true;
            }
        }

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
            $this->data['reviews_bottom'] = 'form';
        }

        echo $this->view('wdk-reviews-list', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-reviews'),
                'tab' => '1',
            ]
        );

        $this->add_responsive_control(
            'fields_labels',
                [
                    'label' => esc_html__( 'Hide Labels', 'wdk-reviews' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-reviews' ),
                    'block' => esc_html__( 'Show', 'wdk-reviews' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-register-form .wdk-form-group label' => 'display: {{VALUE}};',
                    ],
                ]
        );
        /* Message field */
        $this->add_control(
            'field_message',
            [
                'label' => __( 'Label Message', 'wdk-reviews' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Review', 'wdk-reviews' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'form_title',
            [
                'label' => __( 'Title Reviews Form', 'wdk-reviews' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Write a Review', 'wdk-reviews' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_message_placeholder',
            [
                'label' => __( 'Placeholder Message', 'wdk-reviews' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Write your review', 'wdk-reviews' ),
            ]
        );

        $this->add_control(
            'field_submit',
            [
                'label' => __( 'Text Submit Button', 'wdk-reviews' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Submit Review', 'wdk-reviews' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'reviews_limit',
            [
                'label' => __( 'Limit Reviews', 'wdk-reviews' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 20,
                'step' => 1,
                'default' => 3,
            ]
        );

        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'styles_comments',
            [
                    'label' => esc_html__('Styles Reviews', 'wdk-reviews'),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $items = [
            [
                'key'=>'comment_name',
                'label'=> esc_html__('Name', 'wdk-reviews'),
                'selector'=>'.review-item .side-content.side .review-header .side-left .title',
                'hover'=>'.review-item .side-content.side .review-header .side-left .title',
                'options'=>'text',
            ],
            [
                'key'=>'comment_subname',
                'label'=> esc_html__('Sub Title', 'wdk-reviews'),
                'selector'=>'.review-item .side-content.side .review-header .side-left .subtitle',
                'options'=>'text',
            ],
            [
                'key'=>'comment_text',
                'label'=> esc_html__('Text', 'wdk-reviews'),
                'selector'=>'.review-item .side-content.side .text',
                'options'=>'text',
            ],
            [
                'key'=>'comment_option',
                'label'=> esc_html__('Options', 'wdk-reviews'),
                'selector'=>'.review-item .side-content.side .options .title',
                'options'=>'text',
            ],
            [
                'key'=>'comment_reply',
                'label'=> esc_html__('Reply Link', 'wdk-reviews'),
                'selector'=>'.review-item .side-content.side .review-header .side-right a',
                'selector_hover'=>'.review-item .side-content.side .review-header .side-right a%1$s',
                'options'=>['typo','color','align','background'],
            ],
        ];

        $this->add_control(
            'stars_icons',
            [
                'label' => esc_html__('Rating icons', 'wdk-reviews'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'stars_icons_margin',
            [
                    'label' => esc_html__( 'Margin', 'wpdirectorykit' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .review-item .side-content.side .rating-lst' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .review-item .side-content.side .rating-lst li.icon-active *',
            'halfactive' => '{{WRAPPER}} .review-item .side-content.side .rating-lst li.icon-halfactive *',
            'innactive' => '{{WRAPPER}} .review-item .side-content.side .rating-lst li.icon-innactive *',
        );

        $this->generate_renders_tabs($selectors, 'stars_icons_dynamic', ['color']);


        foreach ($items as $item) {
            $this->add_control(
                $item['key'].'_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

        
            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
            );

            if(isset($item['selector_hover']))
                $selectors['hover'] ='{{WRAPPER}} '.$item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

        }

        $this->end_controls_section();

        $this->start_controls_section(
            'colors_sections',
            [
                    'label' => esc_html__('Styles Form', 'wdk-reviews'),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_responsive_control(
            'row_gap',
            [
                'label' => esc_html__('Rows Gap', 'wdk-reviews'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-reviews-form .wdk-form-group' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wdk-reviews-form' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $items = [
            [
                'key'=>'form_title',
                'label'=> esc_html__('Title Form', 'wdk-reviews'),
                'selector'=>'.wdk-reviews-form .w-title',
                'options'=>'text',
            ],
            [
                'key'=>'form_label',
                'label'=> esc_html__('Label', 'wdk-reviews'),
                'selector'=>'.wdk-reviews-form .wdk-form-group label',
                'options'=>'text',
            ],
            [
                'key'=>'form_controll',
                'label'=> esc_html__('Field', 'wdk-reviews'),
                'selector'=>'.wdk-reviews-form .wdk-form-group .wdk-control:not([type="checkbox"])',
                'options'=>'full',
            ],
            [
                'key'=>'form_button',
                'label'=> esc_html__('Button', 'wdk-reviews'),
                'selector'=>'.wdk-reviews-form .wdk-btn',
                'selector_hover'=>'.wdk-reviews-form .wdk-btn%1$s',
                'options'=>'full',
            ],
            [
                'key'=>'form_hint',
                'label'=> esc_html__('Hint', 'wdk-reviews'),
                'selector'=>'.wdk-reviews-form .wdk-hint',
                'selector_hover'=>'.wdk-reviews-form .wdk-hint%1$s',
                'options'=>'full',
            ],

        ];
        
        foreach ($items as $item) {
            $this->add_control(
                $item['key'].'_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

        
            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
            );

            if(isset($item['selector_hover']))
                $selectors['hover'] ='{{WRAPPER}} '.$item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

        }


        $this->add_control(
           'list_option_header',
            [
                'label' => esc_html__('Reviews Items Options', 'wdk-reviews'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
    
        $this->add_responsive_control(
            'list_option_hide',
                [
                    'label' => esc_html__( 'Hide Element', 'wdk-reviews' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-reviews' ),
                    'block' => esc_html__( 'Show', 'wdk-reviews' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .review-item .side-content.side .options' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .review-item .side-content.side .options',
        );

        $this->generate_renders_tabs($selectors, 'list_option_dynamic', ['padding','margin']);
        
        $this->end_controls_section();

        $this->start_controls_section(
            'button_load_more_section',
            [
                    'label' => esc_html__('Button Load More', 'wdk-reviews'),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_responsive_control(
            'button_load_more_hide',
                [
                    'label' => esc_html__( 'Hide Element', 'wdk-reviews' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-reviews' ),
                    'block' => esc_html__( 'Show', 'wdk-reviews' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-reviews-list .wdk-btn.wdk_ajax_load_more_reviews' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-reviews-list .more-div',
        );

        $this->generate_renders_tabs($selectors, 'button_load_more_div_dynamic', ['margin','background','padding','align']);
        
        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-reviews-list .wdk-btn.wdk_ajax_load_more_reviews',
            'hover' => '{{WRAPPER}} .wdk-reviews-list .wdk-btn.wdk_ajax_load_more_reviews%1$s',
        );

        $this->generate_renders_tabs($selectors, 'button_load_more_dynamic', ['margin','typo','color','border','border_radius','padding','shadow','transition','background_group']);
        
        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-reviews-list');
        wp_enqueue_script('wdk-reviews-list');
        wp_enqueue_style( 'dashicons' );
    }
}
