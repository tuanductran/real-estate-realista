<?php
/**
 * The template for Element Reviews List and Form.
 * This is the template that elementor element stars, options, reviews, form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-reviews-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-reviews-list">
        <div class="reviews-comments">
        <?php if($is_edit_mode):?>
            <?php for($rev_num = 0; $rev_num < (int) wmvc_show_data('reviews_limit', $settings); $rev_num++):?>
                <?php
                    $demo_stars = rand(1, 5);
                ?>
                <div class="review-item">
                    <div class="side side-thumb">
                        <img src="<?php echo esc_url(wdk_placeholder_image_src());?>" alt="" class="thumb">
                    </div>
                    <div class="side side-content">
                        <div class="review-header">
                            <div class="side-left">
                                <h4 class="title">
                                    <?php echo esc_html__('Kety', 'wdk-reviews');?>
                                    <ul class="rating-lst">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <?php if ($i <= $demo_stars): ?>
                                                <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                                    <li class="icon-active"><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                                <?php else:?>
                                                    <li class="icon-active"><i class="fas fa-star"></i></li>
                                                <?php endif;?>
                                            <?php elseif(abs($demo_stars - $i) < 1): ?>
                                                <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                                    <li class="icon-halfactive"><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                                    <li class="icon-halfactive"><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                                <?php else:?>
                                                    <li class="icon-halfactive"><i class="fas fa-star-half-alt"></i></li>
                                                <?php endif;?>
                                            <?php else: ?>
                                                <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                                    <li class="icon-innactive"><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                                <?php else:?>
                                                    <li class="icon-innactive"><i class="far fa-star innactive"></i></li>
                                                <?php endif;?>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </ul><!--rating-lst end-->
                                </h4>
                                <span class="subtitle"><span class="date"><?php echo esc_html__('December', 'wdk-reviews');?> 27, 2021 3:07 pm</span></span>
                            </div>
                            <div class="side-right"><a href="" class="reply"><?php echo esc_html__('reply', 'wdk-reviews');?></a></div>
                        </div>
                        <div class="text">
                            <?php echo esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.','wdk-reviews');?>
                        </div>
                    </div>
                </div>
            <?php endfor;?>
            <div class="more-div">
                <a href="#" data-reviews_type_id="<?php echo esc_attr($reviews_type_id);?>" data-post_id="<?php echo esc_attr($post_id);?>"
                    data-limit="<?php echo esc_attr($settings['reviews_limit']);?>" data-offset="<?php echo esc_attr($settings['reviews_limit']);?>" 
                    class="wdk-btn wdk-click-load-animation wdk_ajax_load_more_reviews">
                    <?php echo esc_html__('Load more', 'wdk-reviews');?><i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>
                </a>
            </div>
        <?php else:?>
            <?php if(count($reviews_list) >0):?>
                <?php foreach($reviews_list as $review):?>
                    <?php
                        $userdata = get_userdata(wmvc_show_data('user_id', $review));
                        $user_avatar = get_avatar_url( wmvc_show_data('user_id', $review));

                        if(!$user_avatar)
                            $user_avatar = wdk_placeholder_image_src();

                        $profile_url = '';
                        if(function_exists('wdk_generate_profile_permalink'))
                            $profile_url = wdk_generate_profile_permalink($userdata);
                    ?>

                    <div class="review-item" id="wdk_review_<?php echo wmvc_show_data('idreviews', $review);?>">
                        <div class="side side-thumb">
                        <?php if(!empty($profile_url)) :?>
                                <a href="<?php echo esc_url($profile_url);?>"><img src="<?php echo esc_url($user_avatar);?>" alt="" class="thumb"></a>
                            <?php else:?>
                                <img src="<?php echo esc_url($user_avatar);?>" alt="" class="thumb">
                            <?php endif;?>
                        </div>
                        <div class="side side-content">
                            <div class="review-header">
                                <div class="side-left">
                                    <h4 class="title">
                                        <?php if(!empty($profile_url)) :?>
                                            <a href="<?php echo esc_url($profile_url);?>"><?php echo esc_html__(wmvc_show_data('display_name', $userdata), 'wdk-reviews');?></a>
                                        <?php else:?>
                                            <?php echo esc_html__(wmvc_show_data('display_name', $userdata), 'wdk-reviews');?>
                                        <?php endif;?>
                                        <ul class="rating-lst">
                                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                                <?php if ($i <= wmvc_show_data('stars', $review)): ?>
                                                    <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                                    <?php else:?>
                                                        <li><i class="fas fa-star"></i></li>
                                                    <?php endif;?>
                                                <?php elseif( abs(wmvc_show_data('stars', $review) - $i) < 1): ?>
                                                    <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                                    <?php else:?>
                                                        <li><i class="fas fa-star-half-alt"></i></li>
                                                    <?php endif;?>
                                                <?php else: ?>
                                                    <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                                    <?php else:?>
                                                        <li><i class="far fa-star innactive"></i></li>
                                                    <?php endif;?>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </ul><!--rating-lst end-->
                                    </h4>
                                    <span class="subtitle"><span class="date"><?php echo esc_html(wmvc_get_date(wmvc_show_data('date', $review)));?></span></span>
                                </div>
                                <div class="side-right"><a href="" class="reply"><?php echo esc_html__('reply', 'wdk-reviews');?></a></div>
                            </div>
                            <div class="text">
                                <?php echo wp_kses_post(__(wmvc_show_data('review_comment', $review), 'wdk-reviews'));?>
                            </div>
                            <?php
                                $review_options = $this->WMVC_Reviews->reviews_m->get_options(wmvc_show_data('idreviews', $review));
                            ?>
                            <div class="options">
                                <?php foreach ($review_options as $option_key => $option_value):?>
                                    <?php if(!isset($options[$option_key])) continue;?>
                                    <div class="item">
                                        <div class="item-content">
                                            <h5 class="title"><?php echo esc_html__(wmvc_show_data('option_name', $options[$option_key]), 'wdk-reviews') ?></h5>
                                            <div class="rating">
                                                <ul class="rating-lst">
                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                        <?php if ($i <= wmvc_show_data('post_stars_total', $option_value)): ?>
                                                            <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                                                <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                                            <?php else:?>
                                                                <li><i class="fas fa-star"></i></li>
                                                            <?php endif;?>
                                                        <?php elseif( abs(wmvc_show_data('post_stars_total', $option_value) - $i) < 1): ?>
                                                            <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                                                <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                                                <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                                            <?php else:?>
                                                                <li><i class="fas fa-star-half-alt"></i></li>
                                                            <?php endif;?>
                                                        <?php else: ?>
                                                            <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                                                <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                                            <?php else:?>
                                                                <li><i class="far fa-star innactive"></i></li>
                                                            <?php endif;?>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </ul><!--rating-lst end-->
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach;?>
                            </div>
                        </div>
                    </div>
                <?php endforeach;?>
                <?php else:?>
                    <p class="wdk_alert wdk_alert-success"><?php echo esc_html__('Reviews not found', 'wdk-reviews');?></p>
                <?php endif;?>
                 
            <?php endif;?>
        </div>
        <?php if(count($reviews_list) >0 && $reviews_total > $settings['reviews_limit']):?>
        <div class="more-div">
            <a href="#" data-reviews_type_id="<?php echo esc_attr($reviews_type_id);?>" data-post_id="<?php echo esc_attr($post_id);?>"
                data-limit="<?php echo esc_attr($settings['reviews_limit']);?>" 
                data-offset="<?php echo esc_attr($settings['reviews_limit']);?>" 
                data-placeholderslimit="<?php echo ( ($reviews_total - $settings['reviews_limit']) < $settings['reviews_limit']) ? esc_attr($reviews_total - $settings['reviews_limit']) : esc_attr($settings['reviews_limit']);?>" 
                class="wdk-btn wdk-click-load-animation wdk_ajax_load_more_reviews">
                <?php echo esc_html__('Load more', 'wdk-reviews');?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;
            </a>
        </div>
        <?php endif;?>
        <?php if($reviews_bottom == 'added'):?>
            <p id="wdk_reviews" class="wdk_alert wdk_alert-success"><?php echo esc_html__('Thanks, you already reviewed!', 'wdk-reviews');?></p>
        <?php elseif($reviews_bottom == 'sent'):?>
            <p id="wdk_reviews" class="wdk_alert wdk_alert-success"><?php echo esc_html__('Review sent to approvement', 'wdk-reviews');?></p>
        <?php elseif($reviews_bottom == 'login'):?>
            <?php
                $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            ?>

            <form id="" action="<?php echo esc_url($current_url);?>#wdk_reviews_form" id="wdk_reviews_form" method="post" class="wdk-reviews-form wdk-form-animation">
                <h2 class="w-title"><?php echo esc_html(wmvc_show_data('form_title',$settings));?></h2>
                <?php
                foreach ($_GET as $key => $value):
                    if(!in_array($key, $_GET)):?>
                        <input type="hidden" name="<?php echo esc_attr($key);?>" value="<?php echo esc_attr($value);?>">
                    <?php endif;?>
                <?php endforeach;?>
                <input type="hidden" name="<?php echo esc_html($id_element);?>_review_form" value="1">
                    <?php if(isset($_POST[$id_element.'_review_form'])):?>
                    <p class="wdk_alert wdk_alert-success"><?php echo esc_html__('Please Login for leave review', 'wdk-reviews');?>, 
                        <?php
                            $login_link = wp_login_url(wdk_current_url());
                            if(get_option('wdk_membership_login_page')) {
                                $login_link = wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')));
                            } 
                        ?>
                        <a href="<?php echo esc_url($login_link);?>"><?php echo esc_html__('Click for Login', 'wdk-reviews');?> </a>
                    </p>
                    <?php endif;?>
                <div class="alert_box">
                </div>
                <?php foreach($options as $option):?>
                <div class="wdk-form-group">
                    <label for="<?php echo esc_html($id_element);?>_review_option"><?php echo esc_html__(wmvc_show_data('option_name',$option), 'wdk-reviews');?></label>
                    <fieldset class="wdk-rating-field">
                        <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star5" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="5"  <?php if(isset($_POST['review_stars'], $default_rating)=='5') echo 'checked="checked"';?>/>
                        <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star5" title="<?php echo esc_attr__('Awesome - 5 stars', 'wdk-reviews');?>"></label>
                        <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star4" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="4"  <?php if(isset($_POST['review_stars'], $default_rating)=='4') echo 'checked="checked"';?>/>
                        <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star4" title="<?php echo esc_attr__('Pretty good - 4 stars ', 'wdk-reviews');?>"></label>
                        <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star3" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="3"  <?php if(isset($_POST['review_stars'], $default_rating)=='3') echo 'checked="checked"';?>/>
                        <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star3" title="<?php echo esc_attr__('Meh - 3 stars', 'wdk-reviews');?>"></label>
                        <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star2" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="2"  <?php if(isset($_POST['review_stars'], $default_rating)=='2') echo 'checked="checked"';?>/>
                        <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star2" title="<?php echo esc_attr__('Kinda bad - 2 stars', 'wdk-reviews');?>"></label>
                        <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star1" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="1" required="required" <?php if(isset($_POST['review_stars'], $default_rating)=='1') echo 'checked="checked"';?>/>
                        <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star1" title="<?php echo esc_attr__('Very bad - 1 star', 'wdk-reviews');?>"></label>
                        <input type="radio" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value=""  class="hidden" checked="checked" />
                    </fieldset>
                    <div class="wdk-hint"><?php echo esc_html__(wmvc_show_data('option_hint', $option), 'wdk-reviews');?></div>
                </div>
                <?php endforeach;?>
                <div class="wdk-form-group">
                    <label for="<?php echo esc_html($id_element);?>_review_message"><?php echo esc_html(wmvc_show_data('field_message',$settings));?>*</label>
                    <textarea name="review_comment" id="<?php echo esc_html($id_element);?>_review_message" rows="4" class="wdk-control" required="required" placeholder="<?php echo esc_html(wmvc_show_data('field_message_placeholder',$settings));?>*"></textarea>
                </div>
                <div class="wdk-form-group">
                    <button type="submit" class="wdk-btn wdk-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?><i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i></button>
                </div>
            </form>
        <?php elseif($reviews_bottom == 'form'):?>
        <?php
            $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        ?>
        <form action="<?php echo esc_url($current_url);?>#wdk_reviews" id="wdk_reviews" method="post" class="wdk-reviews-form wdk-form-animation">
            <h2 class="w-title"><?php echo esc_html(wmvc_show_data('form_title',$settings));?></h2>
            <?php
            foreach ($_GET as $key => $value):
                if(!in_array($key, $_GET)):?>
                    <input type="hidden" name="<?php echo esc_attr($key);?>" value="<?php echo esc_attr($value);?>">
                <?php endif;?>
            <?php endforeach;?>
            <input type="hidden" name="<?php echo esc_html($id_element);?>_review_form" value="1">
            <div class="alert_box">
                <?php
                    if($validation_messages) {
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-reviews'));
                    }
                ?>
            </div>
            <?php foreach($options as $option):?>
            <div class="wdk-form-group">
                <label for="<?php echo esc_html($id_element);?>_review_option"><?php echo esc_html__(wmvc_show_data('option_name',$option), 'wdk-reviews');?></label>
                <fieldset class="wdk-rating-field">
                    <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star5" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="5"  <?php if(isset($_POST['review_stars'], $default_rating)=='5') echo 'checked="checked"';?>/>
                    <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star5" title="<?php echo esc_attr__('Awesome - 5 stars', 'wdk-reviews');?>"></label>
                    <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star4" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="4"  <?php if(isset($_POST['review_stars'], $default_rating)=='4') echo 'checked="checked"';?>/>
                    <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star4" title="<?php echo esc_attr__('Pretty good - 4 stars ', 'wdk-reviews');?>"></label>
                    <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star3" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="3"  <?php if(isset($_POST['review_stars'], $default_rating)=='3') echo 'checked="checked"';?>/>
                    <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star3" title="<?php echo esc_attr__('Meh - 3 stars', 'wdk-reviews');?>"></label>
                    <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star2" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="2"  <?php if(isset($_POST['review_stars'], $default_rating)=='2') echo 'checked="checked"';?>/>
                    <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star2" title="<?php echo esc_attr__('Kinda bad - 2 stars', 'wdk-reviews');?>"></label>
                    <input type="radio" id="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star1" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value="1" required="required" <?php if(isset($_POST['review_stars'], $default_rating)=='1') echo 'checked="checked"';?>/>
                    <label class="full" for="<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>_star1" title="<?php echo esc_attr__('Very bad - 1 star', 'wdk-reviews');?>"></label>
                    <input type="radio" name="option_<?php echo esc_attr(wmvc_show_data('idreviews_option',$option));?>" value=""  class="hidden" checked="checked" />
                </fieldset>
                <div class="wdk-hint"><?php echo esc_html__(wmvc_show_data('option_hint', $option),'wdk-reviews');?></div>
            </div>
            <?php endforeach;?>
            <?php if(!empty($options)):?>
            <div class="wdk-form-group">
                <label for="<?php echo esc_html($id_element);?>_review_message"><?php echo esc_html(wmvc_show_data('field_message',$settings));?>*</label>
                <textarea name="review_comment" id="<?php echo esc_html($id_element);?>_review_message" rows="4" class="wdk-control" required="required" placeholder="<?php echo esc_html(wmvc_show_data('field_message_placeholder',$settings));?>*"></textarea>
            </div>
            <div class="wdk-form-group">
                <button type="submit" class="wdk-btn wdk-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?><i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i></button>
            </div>
            <?php else:?>
                <p class="alert alert-info"><?php echo esc_html__("We working on reviews configuration, options missing", 'wdk-reviews');?></p>
            <?php endif;?>
        </form>
        <?php endif;?>
    </div>
</div>

