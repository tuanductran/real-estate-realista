<?php
/**
 * The template for Element Reviews Average List Options.
 * This is the template that elementor element stars
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-reviews-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-reviews-average-list">
        <div class="list">
            <?php foreach ($options as $option):?>
                <div class="item">
                    <div class="item-content">
                        <h4 class="title"><?php echo esc_html(wmvc_show_data('option_name',$option)) ?></h4>
                        <div class="rating">
                            <ul class="rating-lst">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= wmvc_show_data('post_stars_total', $option)): ?>
                                        <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                        <?php else:?>
                                            <li><i class="fas fa-star"></i></li>
                                        <?php endif;?>
                                    <?php elseif( abs(wmvc_show_data('post_stars_total', $option) - $i) < 1): ?>
                                        <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                        <?php else:?>
                                            <li><i class="fas fa-star-half-alt"></i></li>
                                        <?php endif;?>
                                    <?php else: ?>
                                        <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                        <?php else:?>
                                            <li><i class="far fa-star innactive"></i></li>
                                        <?php endif;?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </ul><!--rating-lst end-->
                        </div>
                    </div>
                    <div class="item-avg"><?php echo esc_html(wmvc_show_data('post_stars_total',$option)) ?> / 5 (<?php echo esc_html(wmvc_show_data('post_reviewers_total',$option)) ?>)</div>
                </div>
            <?php endforeach;?>
            <div class="item">
                <div class="item-content">
                    <h4 class="title"><?php echo esc_html__('Average', 'wdk-reviews') ?></h4>
                    <div class="rating"> 
                        <ul class="rating-lst">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <?php if ($i <= $stars_total): ?>
                                    <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                    <?php else:?>
                                        <li><i class="fas fa-star"></i></li>
                                    <?php endif;?>
                                <?php elseif( abs($stars_total - $i) < 1): ?>
                                    <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                    <?php else:?>
                                        <li><i class="fas fa-star-half-alt"></i></li>
                                    <?php endif;?>
                                <?php else: ?>
                                    <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                        <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                    <?php else:?>
                                        <li><i class="far fa-star innactive"></i></li>
                                    <?php endif;?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </ul><!--rating-lst end-->
                    </div>
                </div>
                <div class="item-avg"><?php echo esc_html($stars_total) ?> / 5 (<?php echo esc_html($reviewers_total) ?>)</div>
            </div>
        </div>
    </div>
</div>
 