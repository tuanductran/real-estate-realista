<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_reviews_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('reviews_type_m');
        $this->load->model('reviews_m');

        $this->data['post_types'] = $this->reviews_type_m->post_types;

        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                    break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                    break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                    break;
                default:
                } 
        }

        /* [Search Form] */

        $this->data['order_by']   = array(  'idreviews DESC' => __('ID', 'wdk-reviews').' DESC', 
                                            'idreviews ASC' => __('ID', 'wdk-reviews').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-reviews').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-reviews').' DESC',
                                            'post_title ASC' => __('Post Title', 'wdk-reviews').' ASC',
                                            'post_title DESC' => __('Post Title', 'wdk-reviews').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'post_type',
                'label' => __('Post Type', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'label' => __('Category', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'label' => __('User', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'review_post_type',
                'label' => __('Post Type', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-reviews'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->reviews_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'reviews';
        $columns = array('idreviews', 'post_title','order_by', 'post_type','user_id', 'review_post_type', 'display_name');
        $external_columns = array('post_title', 'post_type', 'review_post_type', 'display_name');
        
        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reviews_m->total( array(), FALSE);

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['reviews'] = $this->reviews_m->get_pagination($per_page, $offset, array(), NULL, FALSE);

        // Load view
        $this->load->view('wdk-reviews/index', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('reviews_m');
        
        $this->reviews_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-reviews&paged=$paged"));
    }
    
    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_m');
    
            $this->reviews_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_m', $post_id);
            $this->reviews_m->insert(array('is_confirmed'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_m', $post_id);
            $this->reviews_m->insert(array('is_confirmed'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews"));
    }
}
