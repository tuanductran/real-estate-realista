<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_reviews_type extends Winter_MVC_Controller {
	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('reviews_type_m');

        $this->data['post_types'] = $this->reviews_type_m->post_types;
        
        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                    break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                    break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                    break;
                default:
            } 
        }

        /* [Search Form] */
        $this->data['order_by']   = array(  'idreviews_type DESC' => __('ID', 'wdk-reviews').' DESC', 
                                            'idreviews_type ASC' => __('ID', 'wdk-reviews').' ASC', 
                                            'stars_total ASC' => __('Stars total', 'wdk-reviews').' ASC',
                                            'stars_total DESC' => __('Stars total', 'wdk-reviews').' DESC',
                                            'reviewers_total ASC' => __('Reviewers total total', 'wdk-reviews').' ASC',
                                            'reviewers_total DESC' => __('Reviewers total total', 'wdk-reviews').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'post_type',
                'label' => __('Post Type', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'label' => __('Category', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-reviews'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->reviews_type_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'reviews_type';
        $columns = array('idreviews_type', 'order_by', 'review_post_type');
        $external_columns = array('idreviews_type', 'review_post_type ');

        wdk_reviewstype_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reviews_type_m->total();

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_reviewstype_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['reviews_type'] = $this->reviews_type_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-reviews-type/index', $this->data);
    }

    public function edit()
	{

        $this->load->model('reviews_type_m');
        $this->load->model('reviews_option_m');
        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('reviews_type_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->reviews_type_m->fields_list;

        //exit($this->db->last_query());
        $this->form->add_error_message('wdk_reviews_unique_type', __('Review Type For this post type, already exists', 'wdk-reviews'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->reviews_type_m->prepare_data($this->input->post(), $this->data['fields']);

            $insert_id = $this->reviews_type_m->insert($data, $id);
            
            if($this->input->post('inputjson_options')) {
                $inputjson_options = $this->input->post('inputjson_options');

                foreach (json_decode($inputjson_options) as $key => $value) {
                    if(!wmvc_show_data('option_name', $value, false)) continue;

                    $data_save = array();
                    $data_save['reviews_type_id'] = $insert_id;
                    $data_save['option_name'] = sanitize_text_field(wmvc_show_data('option_name', $value, ''));
                    $data_save['option_hint'] = sanitize_text_field(wmvc_show_data('option_hint', $value, ''));
                    $data_save['stars_total'] = sanitize_text_field(wmvc_show_data('stars_total', $value, ''));
                    $data_save['reviewers_total'] = sanitize_text_field(wmvc_show_data('reviewers_total', $value, ''));
                    $data_save['is_activated'] = intval(sanitize_text_field(wdk_show_data('is_activated', $value, 0, TRUE, TRUE)));
                    $this->reviews_option_m->insert($data_save, sanitize_text_field(wmvc_show_data('idreviews_option', $value, NULL)));
                }
            }

            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-reviews-type&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        $this->data['reviews_option'] = $this->reviews_option_m->get_pagination(NULL, NULL, array('reviews_type_id'=>$id));
        /* clear empty options */
        foreach($this->data['reviews_option'] as $key => $option) {
            if(wmvc_show_data('option_name', $option, false)) continue;
            $this->reviews_option_m->delete(wmvc_show_data('idreviews_option', $option));
            unset($this->data['reviews_option'][$key]);
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->reviews_type_m->get($id, TRUE);
        } else {
            $this->data['reviews_option'] = json_decode($this->input->post('inputjson_options'));
            if(empty($this->data['reviews_option'] ))
                $this->data['reviews_option'] = array();
        }
        
        // Load view
        $this->load->view('wdk-reviews-type/edit', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('reviews_type_m');
        
        $this->reviews_type_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-reviews-type&paged=$paged"));
    }

        
    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_type_m');
    
            $this->reviews_type_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews-type"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_type_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_type_m', $post_id);
            $this->reviews_type_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews-type"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_type_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_type_m', $post_id);
            $this->reviews_type_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews"));
    }


}
