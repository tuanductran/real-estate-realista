<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_reviews_option extends Winter_MVC_Controller {
	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('reviews_option_m');
        $this->load->model('reviews_type_m');

        $this->data['post_types'] = $this->reviews_type_m->post_types;
        
        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                    break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                    break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                    break;
                default:
                } 
        }

        /* [Search Form] */
        $this->data['order_by']   = array(  'idreviews DESC' => __('ID', 'wdk-reviews').' DESC', 
                                            'idreviews ASC' => __('ID', 'wdk-reviews').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-reviews').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-reviews').' DESC',
                                            'post_title ASC' => __('Post Title', 'wdk-reviews').' ASC',
                                            'post_title DESC' => __('Post Title', 'wdk-reviews').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'post_option',
                'label' => __('Post Type', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'label' => __('Category', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-reviews'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-reviews'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->reviews_option_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'reviews_option';
        $columns = array('idreviews', 'post_title','order_by', 'post_option');
        $external_columns = array('post_title', 'post_option');

        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reviews_option_m->total();

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['reviews_option'] = $this->reviews_option_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-reviews-option/index', $this->data);
    }

    public function edit()
	{
        $this->load->model('reviews_option_m');
        $this->load->model('reviews_type_m');
        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('reviews_option_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->reviews_option_m->fields_list;

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->reviews_option_m->prepare_data($this->input->post(), $this->data['fields']);

            $insert_id = $this->reviews_option_m->insert($data, $id);

            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-reviews-option&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->reviews_option_m->get($id, TRUE);
        }

        // Load view
        $this->load->view('wdk-reviews-option/edit', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('reviews_option_m');
        
        $this->reviews_option_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-reviews-option&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_option_m');
    
            $this->reviews_option_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews-option"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_option_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_option_m', $post_id);
            $this->reviews_option_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews-option"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reviews_option_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reviews_option_m', $post_id);
            $this->reviews_option_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-reviews"));
    }
}
