<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_reviews_add extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}

    public function index()
	{
        $this->load->model('reviews_m');
        $this->load->model('reviews_option_m');
        $this->load->model('reviews_type_m');

        $this->data['post_types'] = $this->reviews_type_m->post_types;

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('reviews_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['db_data_options'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields_rules'] = $this->data['fields'] = $this->reviews_m->fields_list;

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-reviews'));
        $this->form->add_error_message('wdk_reviewed', __('Listing/Profile already reviewed by selected user', 'wdk-reviews'));
        $this->form->add_error_message('wdk_reviewed_byself', __('Can\'t reviewed by themself', 'wdk-reviews'));
        $this->form->add_error_message('wdk_reviewed_options_exists', __('Missing any options for current type, please first add options', 'wdk-reviews'));

        if(wmvc_show_data('reviews_type_id', $data, false)){
            $options = $this->reviews_option_m->get_options_list(wmvc_show_data('reviews_type_id', $data));
            foreach($options as $option) {
                $option['rules'] = 'required';
                $this->data['fields_rules'][] = $option;
            }
        }

        if ($this->form->run($this->data['fields_rules'])) {
            // Save procedure for basic data
            $data = $this->reviews_m->prepare_data(wdk_get_post(), $this->data['fields'], FALSE);
            $reviews_type = $this->reviews_type_m->get(wmvc_show_data('reviews_type_id', $data), true);

            if (wmvc_show_data('review_post_type', $reviews_type) == 'profile') {
                $_POST['post_id'] = $data['post_id'] = $this->input->post('post_id_profile');
            }

            /* if approved */
            if (!empty($id)) {
                $review = $this->reviews_m->get($id, true);
            }

            $insert_id = $this->reviews_m->save_with_options($data, array(), $id);

            /* if approved message */
            if (!empty($insert_id) && !empty($id) && wmvc_show_data('user_id', $data, false)) {
                if( $review ->is_confirmed != 1 && wmvc_show_data('is_confirmed', $data) == 1) {
                    if (wmvc_show_data('review_post_type', $reviews_type) == 'profile') {
                        $link = wdk_generate_profile_permalink(wmvc_show_data('post_id', $data));
                    } else {
                        $link = get_permalink(wmvc_show_data('post_id', $data));
                    }
                    
                    $user = get_userdata( wmvc_show_data('user_id', $data) );

                    $data_message = array();
                    $data_message['user'] = $user;
                    $data_message['review'] = $review;  /* review data */
                    $data_message['review_id']= $insert_id;
                    $data_message['link_review'] = $link.'#wdk_review_'.$insert_id;

                    $ret = wdk_mail($user->user_email, __('Review Approved', 'wdk-reviews'), $data_message, 'new_review_approved');
                }
            }

            if (!empty($insert_id) && empty($id)) {
                wp_redirect(admin_url("admin.php?page=wdk-reviews-add&id=$insert_id&is_updated=true"));
                exit;
            }
        }

        if (!empty($id)) {
            $this->data['db_data'] = $this->reviews_m->get($id, true);
            $this->data['db_data_options'] = $this->reviews_m->get_options($id);
        } else {
            //unset($this->data['fields']['1']);
        }
        
        $this->data['options'] = $this->reviews_option_m->get_options_list();
        
        // Load view
        $this->load->view('wdk-reviews-add/index', $this->data);
    }

}
