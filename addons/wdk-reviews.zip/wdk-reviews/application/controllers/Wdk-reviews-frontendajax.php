<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_reviews_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    
    public function editoption($output="", $atts=array(), $instance=NULL)
    {

        $this->load->model('reviews_option_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();
		if(empty($user_id))
        {
            $data['popup_text_error'] .= __('Please login to use reviews', 'wdk-reviews');
        } 

        if (empty($data['popup_text_error'])) {
            $idreviews_option = sanitize_key(wmvc_show_data('idreviews_option', $_POST, NULL));
            if(!intval($idreviews_option)) {
                $idreviews_option = NULL;
            }
            $data_save = array();
            $data_save['reviews_type_id'] = sanitize_text_field(wmvc_show_data('reviews_type_id', $_POST, ''));
            $data_save['option_name'] = sanitize_text_field(wmvc_show_data('option_name', $_POST, ''));
            $data_save['option_hint'] = sanitize_text_field(wmvc_show_data('option_hint', $_POST, ''));
            $data_save['is_activated'] = 0;

            if(wmvc_show_data('is_activated', $_POST, false) && wmvc_show_data('is_activated', $_POST) != 'false')
                $data_save['is_activated'] = 1;

            $idreviews_option = $this->reviews_option_m->insert($data_save, $idreviews_option);

            $data['popup_text_success'] = __('Updated option!', 'wdk-reviews');
            $data['success'] = true;
            $data['idreviews_option'] = $idreviews_option;
        }

		$this->output($data);
    }

    public function removeoption($output="", $atts=array(), $instance=NULL)
    {

        $this->load->model('reviews_option_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();
		if(empty($user_id))
        {
            $data['popup_text_error'] .= __('Please login to use reviews', 'wdk-reviews');
        } 

        if (empty($data['popup_text_error'])) {
            $id = (int) wmvc_show_data('idreviews_option', $_POST, '');
            $this->reviews_option_m->delete($id);
    
            $data['popup_text_success'] = __('Option removed', 'wdk-reviews');
            $data['success'] = true;
        }

		$this->output($data);
    }

    public function pagination_reviews($output="", $atts=array(), $instance=NULL) 
    {

        $this->load->model('reviews_m');
        $this->load->model('reviews_option_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;
		$data['output'] = '';
		$data['load_more'] = true;
		$data['offset'] = 0;
		$data['total'] = 0;
		$data['placeholderslimit'] = 0;

        if (empty($data['popup_text_error'])) {
            $id = (int) wmvc_show_data('idreviews_option', $_POST, '');

            $options = $this->reviews_option_m->get_options(sanitize_text_field(wmvc_show_data('reviews_type_id', $_POST, )));

            $total = $this->reviews_m->total(array('post_id'=>intval(wmvc_show_data('post_id', $_POST, 3)), 'is_confirmed'=>1), FALSE);
            $results = $this->reviews_m->get_pagination( intval(wmvc_show_data('limit', $_POST, 3)), intval(wmvc_show_data('offset', $_POST, 3)), array('post_id'=>intval(wmvc_show_data('post_id', $_POST, 3)), 'is_confirmed'=>1), NULL, FALSE);
           
            foreach($results as $item) {
                $data['output'] .= wdk_reviews_result_item_card($item, array('options'=>$options));
            }

            $data['offset'] = intval(wmvc_show_data('offset', $_POST, 3)) + intval(wmvc_show_data('limit', $_POST, 3));
            $data['total'] = $total;

            $data['placeholderslimit'] = (($total - $data['offset']) < intval(wmvc_show_data('limit', $_POST, 3))) ? ($total - $data['offset']) : intval(wmvc_show_data('limit', $_POST, 3));

            if($total <= $data['offset'])
                $data['load_more'] = false;

            $data['success'] = true;
        }

		$this->output($data);
    }
     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
