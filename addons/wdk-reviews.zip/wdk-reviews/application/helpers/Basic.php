<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function wdk_reviews_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_reviews;
    $WMVC = &$Winter_MVC_wdk_reviews;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if($value == 'user_id')
                {
                    $value = $WMVC->$model_name->_table_name.'.'.$value;
                }
              
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if($col_name == 'user_id')
                    {
                        $col_name = $WMVC->$model_name->_table_name.'.'.$col_name;
                    }

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_booking_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_reviews.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}


function wdk_reviewstype_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_reviews;
    $WMVC = &$Winter_MVC_wdk_reviews;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if($value == 'user_id')
                {
                    $value = $WMVC->$model_name->_table_name.'.'.$value;
                }
              
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if($col_name == 'user_id')
                    {
                        $col_name = $WMVC->$model_name->_table_name.'.'.$col_name;
                    }

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_booking_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

if ( ! function_exists('is_wdk_reviews_unique_type'))
{
    function is_wdk_reviews_unique_type($param)
    {

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_reviews;

        $Winter_MVC_wdk_reviews->model('reviews_type_m');

        $additional_sql = '';
        if(isset($_GET['id']))
        {
            $current_id = intval($_GET['id']);
            $additional_sql = " AND idreviews_type != $current_id";
        }


        $results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_reviews->reviews_type_m->_table_name." WHERE `review_post_type` = '$param' $additional_sql ;");

        return count($results) == 0;
    }
}

if ( ! function_exists('is_wdk_reviewed'))
{
    function is_wdk_reviewed($param)
    {

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_reviews;

        $Winter_MVC_wdk_reviews->model('reviews_m');

        $additional_sql = '';
        if(isset($_GET['id']))
        {
            $current_id = intval($_GET['id']);
            $additional_sql .= " AND idreviews != $current_id";
        } elseif(isset($_POST['id']))
        {
            $current_id = intval($_POST['id']);
            $additional_sql .= " AND idreviews != $current_id";
        }

        if(isset($_POST['reviews_type_id']))
        {
            $post_type = intval($_POST['reviews_type_id']);
            $additional_sql .= " AND reviews_type_id = $post_type";
        }

        if(isset($_POST['user_id']))
        {
            $post_type = intval($_POST['user_id']);
            $additional_sql .= " AND user_id = $post_type";
        } else {
            $additional_sql .= " AND user_id = ".get_current_user_id();
        }

        $results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_reviews->reviews_m->_table_name." WHERE `post_id` = '".intval($_POST['post_id'])."' $additional_sql ;");
        
        return count($results) == 0;
    }
}

if ( ! function_exists('is_wdk_reviewed_byself'))
{
    function is_wdk_reviewed_byself($param)
    {

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_reviews;

        $Winter_MVC_wdk_reviews->model('reviews_type_m');
       
        if(isset($_POST['reviews_type_id']))
        {
            $reviews_type = $Winter_MVC_wdk_reviews->reviews_type_m->get(wmvc_show_data('reviews_type_id', $data), true);
            if (wmvc_show_data('review_post_type', $reviews_type) == 'profile') {
                $user_id = get_current_user_id();
                if(isset($_POST['user_id']))
                {
                    $user_id = intval($_POST['user_id']);
                }

                return $user_id != wmvc_show_data('post_id', $_POST);
            }
        }

        return TRUE;
    }
}

if ( ! function_exists('is_wdk_reviewed_byself_front'))
{
    function is_wdk_reviewed_byself_front($param)
    {

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_reviews;

        $Winter_MVC_wdk_reviews->model('reviews_type_m');
       
        if(isset($_POST['reviews_type_id']))
        {
            $reviews_type = $Winter_MVC_wdk_reviews->reviews_type_m->get(wmvc_show_data('reviews_type_id', $data), true);
            if (wmvc_show_data('review_post_type', $reviews_type) == 'profile') {

                return get_current_user_id() != wdk_get_profile_page_id();
            }
        }

        return TRUE;
    }
}

if ( ! function_exists('is_wdk_reviewed_options_exists'))
{
    function is_wdk_reviewed_options_exists($param)
    {

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_reviews;

        $Winter_MVC_wdk_reviews->model('reviews_option_m');

        if(isset($_POST['reviews_type_id']))
        {
            $reviews_options = $Winter_MVC_wdk_reviews->reviews_option_m->get_options_list(wmvc_show_data('reviews_type_id', $data));
            return count($reviews_options) != 0;
        }

        return FALSE;
    }
}

if(!function_exists('wdk_reviews_result_item_card')) {
    /**
	 * Generate listing card html
	 *
	 * @param      array    $listing        The review data.
	 * @param      array    $settings       The settings.
	 * @param      bool   	$json_output    Encode for json, default false
	 * @param      string   $html           Html for sprintf(), where
  	 * 										%1$s - content		
	 * @return     string
	 */

	function wdk_reviews_result_item_card($item = array(), $settings = array(), $json_output = FALSE, $html_sprintf = '%1$s', $template = 'review_item') {
		$data = ['review'=>$item] +  $settings;
        
        global $Winter_MVC_wdk_reviews;

		$output = $Winter_MVC_wdk_reviews->view('frontend/'.$template, $data, FALSE);

		$output = sprintf($html_sprintf, $output);
		if($json_output) {
			$output = str_replace("'", "\'", $output);
			$output = str_replace('"', '\"', $output);
			$output = str_replace(array("\n", "\r"), '', $output);
		}
		
		return ($output);
	}
}

?>