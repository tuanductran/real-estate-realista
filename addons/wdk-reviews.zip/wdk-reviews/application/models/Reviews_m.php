<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Reviews_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_reviews';
	public $_order_by = 'idreviews DESC';
    public $_primary_key = 'idreviews';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();
        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_type_m');
        $reviews_types_list = $Winter_MVC_wdk_reviews->reviews_type_m->get_list();
        $post_types = $Winter_MVC_wdk_reviews->reviews_type_m->post_types;
        foreach ($reviews_types_list as $key => $value) {
            if(isset($post_types[$value]))
                $reviews_types_list[$key] = $post_types[$value];
        }

        $reviews_type_id_listings = $Winter_MVC_wdk_reviews->reviews_type_m->get_type_id('wdk-listing');
        $reviews_type_id_profiles = $Winter_MVC_wdk_reviews->reviews_type_m->get_type_id('profile');
        
        $this->fields_list = array(
            array(
                'field' => 'reviews_type_id',
                'field_label' => __('Review type ', 'wdk-reviews'),
                'hint' => '', 
                'values' => array('' =>__('Not Selected', 'wdk-reviews') ) + $reviews_types_list,
                'field_type' => 'DROPDOWN', 
                'rules' => 'required|numeric|wdk_reviewed|wdk_reviewed_byself|wdk_reviewed_options_exists'
            ),
            array(
                'field' => 'post_id',
                'field_label' => __('Listing', 'wdk-reviews'),
                'hint' => '', 
                'class' => 'reviews_type_id_'.$reviews_type_id_listings, 
                'field_type' => 'LISTING', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'post_id',
                'field_label' => __('Profile', 'wdk-reviews'),
                'hint' => '', 
                'class' => 'reviews_type_id_'.$reviews_type_id_profiles, 
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'user_id',
                'field_label' => __('Reviewer', 'wdk-reviews'),
                'hint' => '',
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'review_comment',
                'field_label' => __('Comment', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'TEXTAREA_WYSIWYG', 
                'rules' => ''
            ),
            array(
                'field' => 'stars',
                'field_label' => __('Stars', 'wdk-reviews'),
                'hint' => __('Average rating based on options below', 'wdk-reviews'),
                'field_type' => 'STARS_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_confirmed',
                'field_label' => __('Is Confirmed', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }
        
        
        $this->fields_list_dash = array(
            array(
                'field' => 'reviews_type_id',
                'field_label' => __('Review type ', 'wdk-reviews'),
                'hint' => '', 
                'values' => array('' =>__('Not Selected', 'wdk-reviews') ) + $reviews_types_list,
                'field_type' => 'DROPDOWN_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'post_id',
                'field_label' => __('Listing', 'wdk-reviews'),
                'hint' => '', 
                'class' => 'reviews_type_id_'.$reviews_type_id_listings, 
                'field_type' => 'LISTING_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'post_id',
                'field_label' => __('Profile', 'wdk-reviews'),
                'hint' => '', 
                'class' => 'reviews_type_id_'.$reviews_type_id_profiles, 
                'field_type' => 'USERS_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'review_comment',
                'field_label' => __('Comment', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'TEXTAREA_WYSIWYG', 
                'rules' => ''
            ),
            array(
                'field' => 'stars',
                'field_label' => __('Stars', 'wdk-reviews'),
                'hint' => __('Average rating based on options below', 'wdk-reviews'),
                'field_type' => 'STARS_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_confirmed',
                'field_label' => __('Is Confirmed', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list_dash as $key=>$field)
        {
            $this->fields_list_dash[$key]['label'] = $field['field_label'];
        }
        
	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE)
    {
        global $wpdb;

        $this->load->model('reviews_type_m');
        $post_table = $this->db->prefix.'posts';
        $reviews_type_table = $this->reviews_type_m->_table_name;

        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID', NULL, 'LEFT');

        $wp_usermeta_table = $wpdb->users;
        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.post_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');

        $this->db->join($reviews_type_table.' ON '.$this->_table_name.'.reviews_type_id = '.$reviews_type_table.'.idreviews_type', NULL,  'LEFT');

        $this->db->where($where);

        /* show only for current user */
        if($user_check)
           $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = TRUE)
    {
        global $wpdb;

        $this->load->model('reviews_type_m');

        $post_table = $this->db->prefix.'posts';
        $reviews_type_table = $this->reviews_type_m->_table_name;

        $this->db->select($this->_table_name.'.*, '.$reviews_type_table.'.review_post_type,'.$post_table.'.*');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID', NULL, 'LEFT');

        $wp_usermeta_table = $wpdb->users;
        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.post_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');


        $this->db->join($reviews_type_table.' ON '.$this->_table_name.'.reviews_type_id = '.$reviews_type_table.'.idreviews_type', NULL,  'LEFT');
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }

    public function get_options ($review_id = NULL) {
        $this->load->model('reviews_data_m');

        $this->db->select('*');
        $this->db->where('review_id', $review_id);
        $this->db->from($this->reviews_data_m->_table_name);
        $query = $this->get();

        $fields_list = array();
        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            foreach( $result as $option) {
                $fields_list['option_'.wmvc_show_data('review_option_id',$option)] =  wmvc_show_data('stars_total', $option);
            }
        }

        return $fields_list;
    }

    public function save_options($review_id = NULL, $data_options = array()) {
        $this->load->model('reviews_data_m');
        $this->load->model('reviews_option_m');

        /* remove */
        $this->db->where('review_id', $review_id);
        $this->db->delete($this->reviews_data_m->_table_name);
        
        foreach ($data_options as $key_option => $data_option) {
            list($prefix, $option_id) = explode('_', $key_option);

            $data_save = array();
            $data_save['review_id'] = $review_id;
            $data_save['review_option_id'] = $option_id;
            $data_save['stars_total'] = intval($data_option); 
            
            $insert_id = $this->reviews_data_m->insert($data_save, NULL);

            /* total for option field */
            $avg_rating = $this->reviews_option_m->generate_avg($option_id);
            if($avg_rating)
                $this->reviews_option_m->insert($avg_rating, $option_id);
        }
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;

        if(empty($user_id))
            $user_id = get_current_user_id();

        $row = $this->get($id, TRUE);
        if(wmvc_show_data('user_id', $row) == $user_id)
            return true;
            
        return false;
    }
    
    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function check_if_exists($user_id, $post_id)
    {
        $this->db->select('*');
        $this->db->where(array('user_id'=> $user_id, 
                               'post_id'=>$post_id));
        $this->db->from($this->_table_name);
        $query = $this->get();
        if ($this->db->num_rows() > 0) {
           return true;
        }

        return false;
    }

    public function check_if_confirmed($user_id, $post_id)
    {
        $this->db->select('*');
        $this->db->where(array('user_id'=> $user_id, 
                               'is_confirmed'=> 1, 
                               'post_id'=>$post_id));
        $this->db->from($this->_table_name);
        $query = $this->get();
        if ($this->db->num_rows() > 0) {
           return true;
        }

        return false;
    }

    public function save_with_options($data, $data_options = array(), $insert_id = NULL)
    {
        $this->load->model('reviews_option_m');
        $this->load->model('reviews_type_m');
        $insert_id = $this->insert($data, $insert_id);
                
        if ($insert_id && wmvc_show_data('reviews_type_id', $data, false)) {
            if (empty($data_options)) {
                $options = $this->reviews_option_m->get_options_list(wmvc_show_data('reviews_type_id', $data));
                $data_options = $this->reviews_option_m->prepare_data($_POST, $options);
            }
            
            $this->reviews_m->save_options($insert_id, $data_options);

            $avg_rating = $this->reviews_m->generate_avg($insert_id);
            if($avg_rating)
            $this->insert(array('stars'=>(round($avg_rating * 2) / 2)), $insert_id);
            
            /* total for type field */
            $avg_rating = $this->reviews_type_m->generate_avg(wmvc_show_data('reviews_type_id', $data));
            if($avg_rating)
                $this->reviews_type_m->insert($avg_rating, wmvc_show_data('reviews_type_id', $data));

        }

        return $insert_id;
    }

    public function generate_avg ($review_id = NULL) {
        $rating = NULL;
        $this->load->model('reviews_data_m');

        $this->db->select('AVG(`stars_total`) as avg');

        $this->db->where('review_id', $review_id);
        $this->db->from($this->reviews_data_m->_table_name);
        $query = $this->get();

        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            $rating = wmvc_show_data('avg', $result[0]);
        }

        return $rating;
    }

    public function generate_avg_total ($post_id = NULL) {
        $rating = array();

        $this->db->select('AVG(`stars`) as avg, COUNT(*) as count');

        $this->db->where('post_id', $post_id);
        $this->db->where('is_confirmed', 1);
        $this->get($this->_table_name);

        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            $rating = array('stars_total'=> wmvc_show_data('avg', $result[0]),
                            'reviewers_total'=> wmvc_show_data('count', $result[0]));
        }

        return $rating;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $row = $this->get($item_id, TRUE);
        if(wmvc_show_data('user_id', $row) == $user_id)
            return true;
            
        return false;
    }

}
?>