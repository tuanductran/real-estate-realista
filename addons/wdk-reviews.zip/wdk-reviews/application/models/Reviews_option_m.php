<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Reviews_option_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_reviews_option';
	public $_order_by = 'order_index';
    public $_primary_key = 'idreviews_option';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_type_m');
        $reviews_types_list = $Winter_MVC_wdk_reviews->reviews_type_m->get_list();
        $post_types = $Winter_MVC_wdk_reviews->reviews_type_m->post_types;
        foreach ($reviews_types_list as $key => $value) {
            if(isset($post_types[$value]))
                $reviews_types_list[$key] = $post_types[$value];
        }

           $this->fields_list = array(
            array(
                'field' => 'reviews_type_id',
                'field_label' => __('Reviews Type', 'wdk-reviews'),
                'hint' => '', 
                'values' => $reviews_types_list,
                'field_type' => 'DROPDOWN', 
                'rules' => 'required|numeric'
            ),
            array(
                'field' => 'option_name',
                'field_label' => __('Option Name', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'option_hint',
                'field_label' => __('Hint', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'order_index',
                'field_label' => __('Order', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'NUMBER', 
                'rules' => ''
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array())
    {
        $this->load->model('reviews_type_m');
        $reviews_type_table = $this->reviews_type_m->_table_name;

        $this->db->select('COUNT(*) as total_count');
        $this->db->join($reviews_type_table.' ON '.$this->_table_name.'.reviews_type_id = '.$reviews_type_table.'.idreviews_type', NULL,  'LEFT');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL)
    {
        
        $this->load->model('reviews_type_m');
        $reviews_type_table = $this->reviews_type_m->_table_name;

        $this->db->select($this->_table_name.'.*, '.$reviews_type_table.'.review_post_type,'.$reviews_type_table.'.idreviews_type,
                                                  '.$reviews_type_table.'.star_icon_active,'.$reviews_type_table.'.star_icon_inactive,
                                                  '.$reviews_type_table.'.star_icon_half_active,'.$reviews_type_table.'.star_icon_half_inactive');
        $this->db->join($reviews_type_table.' ON '.$this->_table_name.'.reviews_type_id = '.$reviews_type_table.'.idreviews_type', NULL,  'LEFT');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;

        return false;
    }

        
    public function get_options_list($review_type_id = NULL)
    {
        $this->db->select('*');
        $this->db->where('reviews_type_id', $review_type_id);
        $this->db->where('is_activated', 1);
        $this->db->from($this->_table_name);
        $this->db->order_by($this->_order_by);
        $query = $this->get();

        $fields_list = array();
        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            foreach( $result as $option) {
                $fields_list[] =  array(
                    'field' => 'option_'.wmvc_show_data('idreviews_option',$option),
                    'field_label' => wmvc_show_data('option_name',$option),
                    'label' => wmvc_show_data('option_name',$option),
                    'hint' => wmvc_show_data('option_hint',$option),
                    'class' => 'reviews_type_id_'.esc_html($option->reviews_type_id),
                    'field_type' => 'STARS', 
                    'rules' => ''
                );
            }

        }
        
        return $fields_list;
    }
        
    public function get_options($review_type_id = NULL)
    {

        $this->load->model('reviews_type_m');
        $reviews_type_table = $this->reviews_type_m->_table_name;

        $this->db->select('*');
        $this->db->where('reviews_type_id', $review_type_id);
        $this->db->where($this->_table_name.'`.`is_activated', 1);
        $this->db->join($reviews_type_table.' ON '.$this->_table_name.'.reviews_type_id = '.$reviews_type_table.'.idreviews_type', NULL,  'LEFT');
      
        $this->db->from($this->_table_name);
        $this->db->order_by($this->_order_by);
        $query = $this->get();

        $fields_list = array();
        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            foreach( $result as $option) {
                $fields_list['option_'.wmvc_show_data('idreviews_option',$option)] = $option;
            }
        }
        
        return $fields_list;
    }

    public function generate_avg ($option_id = NULL) {
        $rating = array();
        $this->load->model('reviews_m');
        $this->load->model('reviews_data_m');
        $reviews_table = $this->reviews_m->_table_name;

        $this->db->select('AVG(`stars_total`) as avg, COUNT(*) as count');
        $this->db->join($reviews_table.' ON '.$this->reviews_data_m->_table_name.'.review_id = '.$reviews_table.'.idreviews');
        
        $this->db->where('is_confirmed', 1);
        $this->db->where('review_option_id', $option_id);
        $this->db->get($this->reviews_data_m->_table_name);

        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            $rating = array('stars_total'=> wmvc_show_data('avg', $result[0]),
                            'reviewers_total'=> wmvc_show_data('count', $result[0]));
        }
        
        return $rating;
    }

    public function generate_avg_by_post_id ($option_id = NULL, $post_id = NULL) {
        $rating = array();

        $this->load->model('reviews_m');
        $this->load->model('reviews_data_m');

        $reviews_table = $this->reviews_m->_table_name;
        $this->db->select('AVG(`'.$this->reviews_data_m->_table_name.'`.`stars_total`) as avg, COUNT(*) as count');

        $this->db->join($reviews_table.' ON '.$this->reviews_data_m->_table_name.'.review_id = '.$reviews_table.'.idreviews');
        
        if(!empty($option_id))
            $this->db->where($this->reviews_data_m->_table_name.'`.`review_option_id', $option_id);

        if(!empty($post_id))
            $this->db->where($this->reviews_m->_table_name.'`.`post_id', $post_id);

        $this->db->where('is_confirmed', 1);
        $this->db->get($this->reviews_data_m->_table_name);

        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            $rating = array('stars_total'=> wmvc_show_data('avg', $result[0]),
                            'reviewers_total'=> wmvc_show_data('count', $result[0]));
        }

        return $rating;
    }
    
    /* only admin can edit */
    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        return false;
    }
}
?>