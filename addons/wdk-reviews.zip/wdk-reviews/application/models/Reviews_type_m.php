<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Reviews_type_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_reviews_type';
	public $_order_by = 'idreviews_type';
    public $_primary_key = 'idreviews_type';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $post_types = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        $this->post_types = array();
        /*foreach(get_post_types() as $type_key => $type_name) {
            $post_types[$type_key] = $type_name;
        }*/

        $this->post_types['profile'] =  __('Profile', 'wdk-reviews');
        $this->post_types['wdk-listing'] =  __('Listing', 'wdk-reviews');

           $this->fields_list = array(
            array(
                'field' => 'review_post_type',
                'field_label' => __('Post Type', 'wdk-reviews'),
                'hint' => '', 
                'values' => $this->post_types,
                'field_type' => 'DROPDOWN', 
                'rules' => 'required|wdk_reviews_unique_type'
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'star_icon_active',
                'field_label' => __('Star icon active ', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'UPLOAD', 
                'rules' => ''
            ),
            array(
                'field' => 'star_icon_inactive',
                'field_label' => __('Star iconinactive ', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'UPLOAD', 
                'rules' => ''
            ),
            array(
                'field' => 'star_icon_half_active',
                'field_label' => __('Star icon half active', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'UPLOAD', 
                'rules' => ''
            ),
            array(
                'field' => 'star_icon_half_inactive',
                'field_label' => __('Star icon half inactive', 'wdk-reviews'),
                'hint' => '', 
                'field_type' => 'UPLOAD', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array())
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL)
    {
        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function get_list()
    {
        $this->db->select('*');

        $query = $this->get();

        $list_with_keys = array();
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();

            foreach($results as $result)
            {
                $list_with_keys[$result->idreviews_type] = $result->review_post_type;
            }

        }

        return $list_with_keys;
    }

    public function get_type_id($post_type = NULL)
    {
        if(empty($post_type)) return NULL;
        $idreviews_type = NULL;

        $this->db->select('idreviews_type');
        $this->db->where(array('review_post_type'=>$post_type, 'is_activated' =>1));

        $query = $this->get();

        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->row();
            $idreviews_type = wmvc_show_data('idreviews_type', $results);
        }

        return $idreviews_type;
    }

    public function generate_avg ($idreviews_type = NULL) {
        $rating = array();

        $this->load->model('reviews_type_m');
        $this->load->model('reviews_m');

        $reviews_table = $this->reviews_m->_table_name;
        $this->load->model('reviews_data_m');
        $this->db->select('AVG(`'.$this->reviews_data_m->_table_name.'`.`stars_total`) as avg, COUNT(*) as count');
        $this->db->join($reviews_table.' ON '.$this->reviews_data_m->_table_name.'.review_id = '.$reviews_table.'.idreviews');
        $this->db->where($this->reviews_m->_table_name.'`.`reviews_type_id', $idreviews_type);
        $this->db->where('is_confirmed', 1);

        $this->db->get($this->reviews_data_m->_table_name);

        if ($this->db->num_rows() > 0) {
            $result = $this->db->results();
            $rating = array('stars_total'=> wmvc_show_data('avg', $result[0]),
                            'reviewers_total'=> wmvc_show_data('count', $result[0]));
        }

        return $rating;
    }

    public function check_deletable($id)
    {
        if(wmvc_user_in_role('administrator')) return true;

        return false;
    }
    
    public function delete($id) {

        if(!$this->check_deletable($id)) return false;

        parent::delete($id);

        /* delete reviews by type */
        $this->load->model('reviews_m');
        $this->db->where('reviews_type_id', $id);
        $this->db->delete($this->reviews_m->_table_name);

        /* delete options by type */
        $this->load->model('reviews_option_m');
        $this->db->where('reviews_type_id', $id);
        $this->db->delete($this->reviews_option_m->_table_name);

        return true;
    }

    /* only admin can edit */
    public function is_related($item_id, $user_id, $method = 'edit')
    {	         
        return false;
    }


}
?>