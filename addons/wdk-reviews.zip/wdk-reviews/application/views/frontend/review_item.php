<?php
/**
 * The template for Result Item.
 *
 * This is the template that for result listing of listings preview
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<?php
    global $Winter_MVC_wdk_reviews;
    $Winter_MVC_wdk_reviews->model('reviews_m');

    $userdata = get_userdata(wmvc_show_data('user_id', $review));
    $user_avatar = get_avatar_url( wmvc_show_data('user_id', $review));

    if(!$user_avatar)
        $user_avatar = wdk_placeholder_image_src();

    $profile_url = '';
    if(function_exists('wdk_generate_profile_permalink'))
        $profile_url = wdk_generate_profile_permalink($userdata);
?>

<div class="review-item" id="wdk_review_<?php echo wmvc_show_data('idreviews', $review);?>">
    <div class="side side-thumb">
    <?php if(!empty($profile_url)) :?>
            <a href="<?php echo esc_url($profile_url);?>"><img src="<?php echo esc_url($user_avatar);?>" alt="" class="thumb"></a>
        <?php else:?>
            <img src="<?php echo esc_url($user_avatar);?>" alt="" class="thumb">
        <?php endif;?>
    </div>
    <div class="side side-content">
        <div class="review-header">
            <div class="side-left">
                <h4 class="title">
                    <?php if(!empty($profile_url)) :?>
                        <a href="<?php echo esc_url($profile_url);?>"><?php echo esc_html(wmvc_show_data('display_name', $userdata));?></a>
                    <?php else:?>
                        <?php echo esc_html(wmvc_show_data('display_name', $userdata));?>
                    <?php endif;?>
                    <ul class="rating-lst">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <?php if ($i <= wmvc_show_data('stars', $review)): ?>
                                <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                    <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                <?php else:?>
                                    <li><i class="fas fa-star"></i></li>
                                <?php endif;?>
                            <?php elseif( abs(wmvc_show_data('stars', $review) - $i) < 1): ?>
                                <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                    <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                    <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                <?php else:?>
                                    <li><i class="fas fa-star-half-alt"></i></li>
                                <?php endif;?>
                            <?php else: ?>
                                <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                    <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                <?php else:?>
                                    <li><i class="far fa-star innactive"></i></li>
                                <?php endif;?>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </ul><!--rating-lst end-->
                </h4>
                <span class="subtitle"><span class="date"><?php echo esc_html(wmvc_get_date(wmvc_show_data('date', $review)));?></span></span>
            </div>
            <div class="side-right"><a href="" class="reply"><?php echo esc_html__('reply', 'wdk-reviews');?></a></div>
        </div>
        <div class="text">
            <?php echo esc_html(wmvc_show_data('review_comment', $review));?>
        </div>
        <?php
            $review_options = $Winter_MVC_wdk_reviews->reviews_m->get_options(wmvc_show_data('idreviews', $review));
        ?>
        <div class="options">
            <?php foreach ($review_options as $option_key => $option_value):?>
                <?php if(!isset($options[$option_key])) continue;?>
                <div class="item">
                    <div class="item-content">
                        <h5 class="title"><?php echo esc_html(wmvc_show_data('option_name', $options[$option_key])) ?></h5>
                        <div class="rating">
                            <ul class="rating-lst">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= wmvc_show_data('post_stars_total', $option_value)): ?>
                                        <?php if(wmvc_show_data('star_icon_active', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_active'));?>"></li>
                                        <?php else:?>
                                            <li><i class="fas fa-star"></i></li>
                                        <?php endif;?>
                                    <?php elseif( abs(wmvc_show_data('post_stars_total', $option_value) - $i) < 1): ?>
                                        <?php if(wmvc_show_data('star_icon_half_active', $reviews_type) && wmvc_show_data('star_icon_half_inactive', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_active'));?>"></li>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_half_inactive'));?>"></li>
                                        <?php else:?>
                                            <li><i class="fas fa-star-half-alt"></i></li>
                                        <?php endif;?>
                                    <?php else: ?>
                                        <?php if(wmvc_show_data('star_icon_inactive', $reviews_type)):?>
                                            <li><img src="<?php echo esc_url(wdk_image_src($reviews_type, 'full', NULL, 'star_icon_inactive'));?>"></li>
                                        <?php else:?>
                                            <li><i class="far fa-star innactive"></i></li>
                                        <?php endif;?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </ul><!--rating-lst end-->
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
        </div>
    </div>
</div>