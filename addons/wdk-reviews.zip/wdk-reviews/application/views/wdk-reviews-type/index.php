<?php
/**
 * The template for Reviews Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Reviews Type Management', 'wdk-reviews'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=edit"; ?>" class="button button-primary" id="add_review_button"><?php echo esc_html__('Add Review Type', 'wdk-reviews'); ?></a></h1>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-reviews-type" />

                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-reviews'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-reviews'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-reviews'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-reviews')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-reviews'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-reviews'); ?></label><input id="cb-select-all-1" type="checkbox"></td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Post Type', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Date', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Stars total ', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Reviews total ', 'wdk-reviews'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-reviews'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($reviews_type) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No Reviews types found.', 'wdk-reviews'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($reviews_type as $review_type) : ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input id="cb-select-<?php echo wmvc_show_data('idreviews_type', $review_type, '-'); ?>" type="checkbox" name="post[]" value="<?php echo wmvc_show_data('idreviews_type', $review_type, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-reviews'); ?></span>
                            </div>
                        </th>
                        <td>
                            <?php echo wmvc_show_data('idreviews_type', $review_type, '-'); ?>
                        </td>
                        <td class="title column-title has-row-actions column-primary page-title" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=edit&id=" . wmvc_show_data('idreviews_type', $review_type, '-'); ?>">
                                <?php if(isset($post_types[wmvc_show_data('review_post_type', $review_type)])):?>
                                    <?php echo esc_html($post_types[wmvc_show_data('review_post_type', $review_type)]); ?>
                                <?php else:?>
                                    <?php echo esc_html(wmvc_show_data('review_post_type', $review_type, '-')); ?>
                                <?php endif;?>
                            </a>
                                <?php if(!wmvc_show_data('is_activated', $review_type, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Not activated', 'wdk-reviews'); ?></span>
                                <?php endif; ?>
                            </strong>
                            <div class="row-actions">
                                <span class="edit"><a href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=edit&id=" . wmvc_show_data('idreviews_type', $review_type, '-'); ?>"><?php echo esc_html__('Edit', 'wdk-reviews'); ?></a> | </span>
                                <span class="trash "><a href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idreviews_type', $review_type, '-'); ?>" class="submitdelete question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-reviews');?>" ><?php echo esc_html__('Delete', 'wdk-reviews'); ?></a></span>
                            </div>
                        </td>
                        <td>
                            <?php echo wdk_get_date(wmvc_show_data('date', $review_type), false); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('stars_total', $review_type, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('reviewers_total', $review_type, '-'); ?>
                        </td>
                        <td class="actions_column">
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=edit&id=" . wmvc_show_data('idreviews_type', $review_type, '-'); ?>" title="<?php echo esc_attr__('Edit','wdk-reviews');?>"><span class="dashicons dashicons-edit"></span></a>
                            <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-reviews');?>"  href="<?php echo get_admin_url() . "admin.php?page=wdk-reviews-type&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idreviews_type', $review_type, '-'); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-reviews'); ?></label><input id="cb-select-all-1" type="checkbox"></td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Post Type', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Date', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Stars total ', 'wdk-reviews'); ?></th>
                    <th><?php echo esc_html__('Reviews total ', 'wdk-reviews'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-reviews'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <div class="alignleft actions bulkactions">
                <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-reviews'); ?></label>
                <select name="action" id="bulk-action-selector-bottom">
                    <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-reviews'); ?></option>
                    <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-reviews'); ?></option>
                    <option value="deactivate" class="hide-if-no-js"><?php echo esc_html__('Deactivate', 'wdk-reviews'); ?></option>
                    <option value="activate" class="hide-if-no-js"><?php echo esc_html__('Activate', 'wdk-reviews'); ?></option>
                </select>
                <input type="hidden" name="page" value="wdk-reviews-type" />
                <input type="submit" id="table_action" class="button action" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-reviews'); ?>">
            </div>

            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">

        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item and all reviews related will be completely removed!', 'wdk-reviews')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>