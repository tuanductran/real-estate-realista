<?php
/**
 * The template for Edit Review.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Reviews Type Management','wdk-reviews'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Add/Edit Reviews Type','wdk-reviews'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-reviews'));
                    ?>

                    <?php echo wdk_generate_fields($fields, $db_data); ?> 
                    <?php if(true || empty(wmvc_show_data('idreviews_type', $db_data))):?>
                        <div class="wdk-field-edit hidden">
                            <label for="star_icon_half_active"><?php echo esc_html__('json','wdk-reviews'); ?></label>
                            <div class="wdk-field-container">
                                <textarea readonly="readonly" name="inputjson_options" type="text" id="inputjson_options" class="regular-text"><?php echo esc_textarea(wmvc_show_data('inputjson_options', $db_data, '')); ?></textarea>
                            </div>
                        </div>
                    <?php endif;?>
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-reviews'); ?>">
                </form>
            </div>
        </div>
    </div>
    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Options','wdk-reviews'); ?></h3>
            </div>
            <div class="inside">
                <table class="wp-list-table widefat fixed striped table-view-list pages wdk-table-options">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Option Name', 'wdk-reviews'); ?></th>
                            <th><?php echo esc_html__('Hint', 'wdk-reviews'); ?></th>
                            <th><?php echo esc_html__('is Activated', 'wdk-reviews'); ?></th>
                            <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-reviews'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="pattern hidden">
                            <td>
                                <input class="hidden" name="idreviews_option" type="text" value="" placeholder="<?php echo esc_html__('Option Id', 'wdk-reviews'); ?>">
                                <input class="skip hidden" name="reviews_type_id" type="text" value="<?php echo wmvc_show_data('idreviews_type', $db_data, '-'); ?>" placeholder="<?php echo esc_html__('Option Type', 'wdk-reviews'); ?>">
                                <input class="" name="option_name" type="text" value="" placeholder="<?php echo esc_html__('Option Name', 'wdk-reviews'); ?>">
                            </td>
                            <td>
                                <input class="" name="option_hint" type="text" value="" placeholder="<?php echo esc_html__('Hint', 'wdk-reviews'); ?>">
                            </td>
                            <td>
                                <label>
                                    <input name="is_activated" type="checkbox" value="1">
                                    <?php echo esc_html__('is activated', 'wdk-reviews'); ?>
                                </label>
                            </td>
                            <td class="actions_column">
                                <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                                <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                            </td>
                        </tr>
                        <tr class="skip">
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="actions_column">
                                <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                            </td>
                        </tr>
                        <?php foreach ($reviews_option as $review_option) :?>
                            <tr>
                                <td>
                                    <input class="hidden" name="idreviews_option" type="text" value="<?php echo wmvc_show_data('idreviews_option', $review_option, '-'); ?>" placeholder="<?php echo esc_html__('Option Id', 'wdk-reviews'); ?>">
                                    <input class="skip hidden" name="reviews_type_id" type="text" value="<?php echo wmvc_show_data('reviews_type_id', $review_option, '-'); ?>" placeholder="<?php echo esc_html__('Option Type', 'wdk-reviews'); ?>">
                                    <input class="" name="option_name" type="text" value="<?php echo wmvc_show_data('option_name', $review_option, '-'); ?>" placeholder="<?php echo esc_html__('Option Name', 'wdk-reviews'); ?>">
                                </td>
                                <td>
                                    <input class="" name="option_hint" type="text" value="<?php echo wmvc_show_data('option_hint', $review_option, '-'); ?>" placeholder="<?php echo esc_html__('Hint', 'wdk-reviews'); ?>">
                                </td>
                                <td>
                                    <label>
                                        <input name="is_activated" type="checkbox" value="1" <?php echo !empty(wdk_show_data('is_activated', $review_option, false, TRUE, TRUE))?'checked':''; ?>>
                                        <?php echo esc_html__('is activated', 'wdk-reviews'); ?>
                                    </label>
                                </td>
                                <td class="actions_column">
                                    <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                                    <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>    
                </table>
            </div>
        </div>
    </div>
</div>

<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>

<script>
var wdk_timerOut;
jQuery(document).ready(function($) {

<?php if(!empty(wmvc_show_data('idreviews_type', $db_data))):?>
    const wdk_reveiws_add_option = (this_form) => {
        wdk_reveiws_json_update(this_form);

        var conf_link = '<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>';
        var load_indicator = this_form.find('.fa-ajax-indicator');
        var box_alert = this_form.find('.alert_box').html('');
        load_indicator.css('display', 'inline-block');

        var data = [];
        data.push({ name: 'action', value: "wdk_reviews_public_action" });
        data.push({ name: 'page', value: "wdk_reviews_frontendajax" });
        data.push({ name: 'function', value: "editoption" });

        data.push({ name: 'idreviews_option', value: this_form.find('[name="idreviews_option"]').val() });
        data.push({ name: 'reviews_type_id', value: this_form.find('[name="reviews_type_id"]').val() });
        data.push({ name: 'option_name', value: this_form.find('[name="option_name"]').val() });
        data.push({ name: 'option_hint', value: this_form.find('[name="option_hint"]').val() });
        data.push({ name: 'is_activated', value: this_form.find('[name="is_activated"]').prop('checked')});

        $.post(conf_link, data, 
            function(data){
            if(data.message)
                box_alert.html(data.message)
                
            if(false && data.popup_text_success)
                wdk_log_notify(data.popup_text_success);
                
            if(false && data.popup_text_error)
                wdk_log_notify(data.popup_text_error, 'error');
                
            if(data.success)
            {
                this_form.find('[name="idreviews_option"]').val(data.idreviews_option);
            } else {
                
            }
        }).always(function(data) {
            load_indicator.css('display', 'none');
        });
    };
    
    const wdk_reveiws_remove_option = (idreviews_option) => {
        wdk_reveiws_json_update();

        var conf_link = '<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>';
        var data = [];
        data.push({ name: 'action', value: "wdk_reviews_public_action" });
        data.push({ name: 'page', value: "wdk_reviews_frontendajax" });
        data.push({ name: 'function', value: "removeoption" });

        data.push({ name: 'idreviews_option', value: idreviews_option});

        $.post(conf_link, data, 
            function(data){
            if(data.message)
                box_alert.html(data.message)
                
            if(false && data.popup_text_success)
                wdk_log_notify(data.popup_text_success);
                
            if(false && data.popup_text_error)
                wdk_log_notify(data.popup_text_error, 'error');
                
            if(data.success)
            {
            } else {
            }
        }).always(function(data) {
        });
    };

    const wdk_reveiws_json_update = (this_form) => {
        var json_gen = '';
        $('table.wdk-table-options tr:not(.pattern):not(.skip)').each(function(index, tr) { 
            if(index==0)return;
            json_gen += '{';
            $(this).find('input').each(function(){
                var el_name = $(this).attr('name');
                if(el_name)
                {
                    json_gen += '"'+el_name+'"';
                    if($(this).attr('type') == 'checkbox') {
                        if($(this).prop('checked')){
                            json_gen += ': "'+1+'" ';
                        } else {
                            json_gen += ': "'+0+'" ';
                        }
                    } else {
                        json_gen += ': "'+$(this).val()+'" ';
                    }
                    json_gen += ', ';
                }
            });
            json_gen = json_gen.substr(0, json_gen.length-2);
            json_gen += '}, ';
        });

        if(json_gen.length > 0)
            json_gen = json_gen.substr(0, json_gen.length-2);

        if(json_gen.length > 0)
                $('#inputjson_options').val('[ ' + json_gen + ' ]');
    };

<?php else :?>

    const wdk_reveiws_add_option = (this_form) => {
        var json_gen = '';
        $('table.wdk-table-options tr:not(.pattern):not(.skip)').each(function(index, tr) { 
            if(index==0)return;
            json_gen += '{';
            $(this).find('input').each(function(){
                var el_name = $(this).attr('name');
                if(el_name)
                {
                    json_gen += '"'+el_name+'"';
                    if($(this).attr('type') == 'checkbox') {
                        if($(this).prop('checked')){
                            json_gen += ': "'+1+'" ';
                        } else {
                            json_gen += ': "'+0+'" ';
                        }
                    } else {
                        json_gen += ': "'+$(this).val()+'" ';
                    }
                    json_gen += ', ';
                }
            });
            json_gen = json_gen.substr(0, json_gen.length-2);
            json_gen += '}, ';
        });

        if(json_gen.length > 0)
            json_gen = json_gen.substr(0, json_gen.length-2);

        if(json_gen.length > 0)
                $('#inputjson_options').val('[ ' + json_gen + ' ]');
    };
    
    const wdk_reveiws_remove_option = (idreviews_option) => {
        wdk_reveiws_add_option();
    };
    <?php endif;?>

    const wdk_reveiws_actions = () => {
        $('.wdk-table-options').find('input').off().on('input', function(){
            //clearTimeout(wdk_timerOut);
            var tr = $(this).closest('tr');
            wdk_timerOut = setTimeout(function () {
                wdk_reveiws_add_option(tr);
            }, 1000);
        });

        $('button.add_btn').off().on('click', function()
        {
            var table = $(this).closest('table');
            var clone = table.find('.pattern').clone();
            clone.removeClass('hidden pattern');
            table.find('tbody').append(clone);

            wdk_reveiws_add_option(clone);
            wdk_reveiws_actions();
        });

        $('button.remove_btn').off().on('click', function()
        {
            $(this).parent().parent().remove();
            wdk_reveiws_remove_option($(this).parent().parent().find('[name="idreviews_option"]').val());
            wdk_reveiws_actions();
        });

    };


    wdk_reveiws_actions();

});

</script>
<?php $this->view('general/footer', $data); ?>