<script>
	(function( $ ) {
		'use strict';
		$( window ).load(function() {

		});
	})( jQuery );
</script>