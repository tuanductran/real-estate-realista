<?php
/**
 * The template for Review Edit.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Reviews Management','wdk-reviews'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Add/Edit Review','wdk-reviews'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-reviews'));
                    ?>

                    <?php echo wdk_generate_fields($fields, $db_data); ?> 

                    <h2><?php echo esc_html__('Options','wdk-reviews'); ?>:</h2>
                    <hr>
                    <?php if(empty($options)) :?>
                        <p class="alert alert-info"><?php echo esc_html__('Any options missing for current review type', 'wdk-reviews');?>, <a href="<?php get_admin_url();?>admin.php?page=wdk-reviews-type"><?php echo esc_html__('Add Options per type', 'wdk-reviews');?></a></p>
                    <?php else :?>
                        <?php echo wdk_generate_fields($options, $db_data_options); ?> 
                    <?php endif;?>
                        
                    <p class="alert alert-info reviews_type_id_empty" style="margin: 15px 0px;"><?php echo esc_html__('Please select Review type', 'wdk-reviews');?></p>
                    
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-reviews'); ?>">
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

<script>

jQuery(document).ready(function($) {

    $('.wdk-field-edit.USERS [name="post_id"], .reviews_type_id_empty').attr('name','post_id_profile');

    const option_depends = (review_type_id) => {
        $('.wdk-field-edit[class*="reviews_type_id"],.reviews_type_id_empty').hide();
        if(typeof review_type_id != 'undefined' && review_type_id != '') {
            $('.wdk-field-edit[class*="reviews_type_id_'+review_type_id+'"]').show();
        } else {
            $('.reviews_type_id_empty').show();
        }
    };

    option_depends("<?php echo wmvc_show_data('reviews_type_id', $db_data);?>");
    $('select[name="reviews_type_id"]').on('change', function(){
        option_depends($(this).val());
    });
})

</script>