<?php
/**
 * The template for Element Report Abuse Form
 * This is the template that elementor element button and form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-pdf-export-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-pdf-export-button" id="wdk_pdf_export">
        <a href="<?php echo esc_url($link);?>" class="wdk-btn" target="_blank">
            <?php if(wmvc_show_data('link_icon_position', $settings) == 'left') :?>
                <span class="far fa-file-pdf"></span> 
            <?php endif;?>
            <?php echo esc_html(wmvc_show_data('btn_text',$settings));?>
            <?php if(wmvc_show_data('link_icon_position', $settings) == 'right') :?>
                <span class="far fa-file-pdf"></span> 
            <?php endif;?>
        </a>
    </div> 
</div>

