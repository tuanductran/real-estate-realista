<?php

namespace WdkPdf_Export\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkPdfExport extends WdkPdf_ExportElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-pdf-export')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-pdf-export')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-pdf-export')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-pdf-export-button';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Export Pdf', 'wdk-pdf-export');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-export-kit';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['post_id'] = $wdk_listing_id;
        $this->data['post_type'] = 'wdk-listing';

        $this->data['validation_messages'] = false;
        $this->data['link'] = wdk_url_suffix(get_home_url(),'wdk_pdf_export_print='.$wdk_listing_id);

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-pdf-export-button', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-pdf-export'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'btn_text',
            [
                'label' => __( 'Text Button', 'wdk-pdf-export' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'PDF Download', 'wdk-pdf-export' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'link_icon_position',
            [
                'label' => esc_html__('icon Position', 'wdk-save-search'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'wdk-save-search'),
                    'right' => esc_html__('Right', 'wdk-save-search'),
                ],
                'default' => 'right',
            ]
        );
        
        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-pdf-export'),
                'selector'=>'{{WRAPPER}} .wdk-pdf-export-button .wdk-btn',
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => '1'
                ]
            );

            if( $item ['key'] == 'style_label'){
                $selectors = array(
                    'normal' => $item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if ($item ['key'] == 'style_button') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Height', 'wdk-pdf-export'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            $item['selector'] => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }
            $selectors = array(
                'normal' => $item['selector'],
                'hover'=>$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-pdf-export-button');
        wp_enqueue_script('wdk-modal');
        wp_enqueue_style('wdk-modal');

        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
    }
}
