<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Pdf_Export
 * @subpackage Wdk_Pdf_Export/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Pdf_Export
 * @subpackage Wdk_Pdf_Export/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Pdf_Export_Activator {
	public static $db_version = 1.1;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_pdf_export_';
	}

	public static function plugins_loaded(){
      
		if ( get_site_option( 'wdk_pdf_export_db_version' ) === false ||
		     get_site_option( 'wdk_pdf_export_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_pdf_export_db_version' ) === false)
        {
            // Main table for visited pages
           
            //update_option('wdk_pdf_export_map_key','c9MNDPFQVui453XfIl7RBH1FxXkVW9sd');
            update_option('wdk_pdf_export_map_key','');

			require_once(ABSPATH . 'wp-admin/includes/file.php');
            global $wp_filesystem;
            if (empty($wp_filesystem)) {
                WP_Filesystem();
            }

            update_option('wdk_pdf_export_custom_layout',$wp_filesystem->get_contents(WDK_PDF_EXPORT_PATH.'layouts/listing.html'));
            self::$db_version = "1.1";
        }

        update_option( 'wdk_pdf_export_db_version', self::$db_version );
    }

}
