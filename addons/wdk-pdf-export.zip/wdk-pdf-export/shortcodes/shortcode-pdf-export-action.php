<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-pdf-export-action], show action add/remove pdf-export
*
* Layout path : 
* get_template_directory().'/wdk-pdf-export/shortcodes/views/shortcode-pdf-export-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-pdf-export-action.php'
*/

//add_shortcode('wdk-pdf-export-action', 'wdk_pdf_export_action');
function wdk_pdf_export_action($atts, $content){
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'post_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;
    
    if(!wmvc_show_data('post_id', $data, false)){
        global $wdk_listing_id;
        if(isset($wdk_listing_id)){
            $data['post_id'] = $wdk_listing_id;
            $data['post_type'] = 'wdk-listing';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $data['post_id'] = $post_object_id;

            $data['post_type'] = get_post_type();
        }
    }

    /* Favorite module */
    $pdf_export_added=false;
    global $Winter_MVC_wdk_pdf_export; 
    if(get_current_user_id() != 0 && isset($Winter_MVC_wdk_pdf_export) && wmvc_show_data('post_id', $data, false))
    {
        $Winter_MVC_wdk_pdf_export->model('pdf_export_m');
        $pdf_export_added = $Winter_MVC_wdk_pdf_export->pdf_export_m->check_if_exists(get_current_user_id(), 
                                                                wmvc_show_data('post_id', $data));
        if($pdf_export_added>0)$pdf_export_added = true;
    }
    
    $data ['pdf-export_added'] = $pdf_export_added;
    /* End Favorite module */
    
    return wdkpdf_export_shortcodes_view('shortcode-pdf-export-action', $data);
}

?>