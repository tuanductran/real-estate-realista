<?php
/**
 * The template for Settings
 *
 * This is the template that form edit
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('WDK PDF Settings', 'wdk-pdf-export'); ?></h1>
    <br /><br />
    <div class="wdk-body">
    <div class="row fields_list">
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('General Settings', 'wdk-pdf-export'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-pdf-export'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>   

                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', 'wdk-pdf-export'); ?>">
        </form>
    </div>
</div>

<?php //$this->view('general/footer', $data); ?>