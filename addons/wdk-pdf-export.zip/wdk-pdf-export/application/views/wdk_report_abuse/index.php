<?php
/**
 * The template for Report Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Report Abuse','wdk-pdf-export'); ?></h1>
    <br />
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-pdf-export" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-pdf-export'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-pdf-export'); ?>" />
                
                <label class="screen-reader-text" for="category_id"><?php echo __('Filter by category', 'wdk-pdf-export'); ?></label>
                <?php echo wmvc_select_option('status',array( ''=>__('Select status', 'wdk-pdf-export')) + $this->pdf_export_m->statuses_list, wmvc_show_data('status', $db_data, ''), NULL, __('Status', 'wdk-pdf-export')); ?>

                <label class="screen-reader-text" for="post_id"><?php echo esc_html__('Post Id', 'wdk-pdf-export'); ?></label>
                <span class="wdk-unwrapp-field">
                    <?php echo wdk_treefield_option('post_id', 'listing_m', wmvc_show_data('post_id', $db_data, ''), 'post_title', '', __('Not Selected', 'wdk-pdf-export'));?>
                </span>

                <label class="screen-reader-text" for="user_id"><?php echo esc_html__('Filter by user name', 'wdk-pdf-export'); ?></label>
                <input type="text" name="name" id="name" class="postform left" value="<?php echo wmvc_show_data('name', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Name', 'wdk-pdf-export'); ?>" />

                <label class="screen-reader-text" for="address"><?php echo esc_html__('Filter by user address', 'wdk-pdf-export'); ?></label>
                <input type="text" name="address" id="address" class="postform left" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-pdf-export'); ?>" />

                <label class="screen-reader-text" for="email"><?php echo esc_html__('Filter by user email', 'wdk-pdf-export'); ?></label>
                <input type="text" name="email" id="email" class="postform left" value="<?php echo wmvc_show_data('email', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Email', 'wdk-pdf-export'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-pdf-export'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-pdf-export')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-pdf-export'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Title','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Full Name','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Email','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Date','wdk-pdf-export'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-pdf-export'); ?></th>
            </tr>
        </thead>
        <?php if(count($pdf_export) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="7"><?php echo esc_html__('No Report Abuse found.','wdk-pdf-export'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $pdf_export as $pdf_export ):?>
            <tr>
                <td>
                    <?php echo wmvc_show_data('idreportabuse', $pdf_export, '-'); ?>
                    <?php
                        $class="label-danger";
                        if(wmvc_show_data('status', $pdf_export) == 'NEW'){
                            $class="label-warning";
                        } else if(wmvc_show_data('status', $pdf_export) == 'IN PROGRESS') {
                            $class="label-info";
                        } else if(wmvc_show_data('status', $pdf_export) == 'DECLINED') {
                            $class="label-danger";
                        } else if(wmvc_show_data('status', $pdf_export) == 'APPROVED' || wmvc_show_data('status', $pdf_export) == 'COMPLETED') {
                            $class="label-success";
                        }
                    ?>

                    <?php if(wmvc_show_data('status', $pdf_export, false) && isset($this->pdf_export_m->statuses_list[wmvc_show_data('status', $pdf_export, '-')])):?>
                        <span class="label <?php echo esc_attr($class);?>"><?php echo esc_html($this->pdf_export_m->statuses_list[wmvc_show_data('status', $pdf_export, '-')]); ?></span>
                    <?php endif;?>

                </td>
                <td>
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $pdf_export, '-')); ?>" title="<?php echo esc_attr__('Edit', 'wdk-pdf-export');?>">
                        <?php echo wmvc_show_data('post_title', $pdf_export, '-'); ?>
                    </a>
                </td>
                <td>
                    <?php echo wmvc_show_data('name', $pdf_export, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('address', $pdf_export, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('email', $pdf_export, '-'); ?>
                </td>
                <td>
                    <?php echo wdk_get_date(wmvc_show_data('date', $pdf_export), false); ?>
                </td>
          
                <td class="actions_column">
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $pdf_export, '-')); ?>" target="_blank" title="<?php echo esc_attr__('View', 'wdk-pdf-export');?>"><span class="dashicons dashicons-visibility"></span></a>
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-pdf-export&function=edit&id=" . wmvc_show_data('idreportabuse', $pdf_export, '-'); ?>" title="<?php echo esc_attr__('Edit', 'wdk-pdf-export');?>"><span class="dashicons dashicons-edit"></span></a>
                    <a class="question_sure" href="<?php echo get_admin_url() . "admin.php?page=wdk-pdf-export&function=delete&id=".wmvc_show_data('idreportabuse', $pdf_export, '-'); ?>" title="<?php echo esc_attr__('Remove', 'wdk-pdf-export');?>"><><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Title','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Name', 'wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Email','wdk-pdf-export'); ?></th>
                <th><?php echo esc_html__('Date','wdk-pdf-export'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-pdf-export'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-pdf-export')); ?>");
        });
    });
</script>

<?php $this->view('general/footer', $data); ?>
