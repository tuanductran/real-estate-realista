<div class="section">
    <h3 class="section-title"><?php echo esc_html($section_label);?></h3>
    <div class="wdk-row">
        <?php foreach($section_data['fields'] as $field):?>
        <?php 
            if(wmvc_show_data('is_visible_frontend', $field) != 1) {
                continue;
            }

            if(wmvc_show_data('field_type', $field) == "CHECKBOX") {
                if(wdk_field_value (wmvc_show_data('idfield', $field), $listing) != 1)
                    if(wmvc_show_data('hide_onempty_checkbox', $settings)) continue;
            } else {
                if((empty(wdk_field_value (wmvc_show_data('idfield', $field), $listing)) || wdk_field_value (wmvc_show_data('idfield', $field), $listing) == '0.00' ))
                    continue;
            } 
        ?>
        <div class="wdk-col">
            <?php if(wmvc_show_data('field_group_icon_enable', $settings, false) && wmvc_show_data('icon_id', $field, false)):?>
                <span class="field_icon"> 
                    <img src="<?php echo esc_url(wdk_image_src($field, 'full',NULL,'icon_id'));?>" alt="<?php echo wmvc_show_data('field_label', $value);?>" class="wdk-icon">
                </span>
            <?php endif;?>
            <span class="field_label"> 
                <?php echo esc_html(wmvc_show_data('label_prefix', $settings));?><?php echo esc_html(wmvc_show_data('field_label', $field));?><?php echo esc_html(wmvc_show_data('label_suffix', $settings));?>
            </span>
            <span class="field_value">
                <?php echo esc_html(apply_filters( 'wpdirectorykit/listing/field/prefix',wmvc_show_data('prefix', $field), wmvc_show_data('idfield', $field)));?>
                <?php
                    $field_value = wdk_field_value (wmvc_show_data('idfield', $field), $listing);
                 
                    if(wmvc_show_data('field_type', $field) == "CHECKBOX") {
                        if(wdk_field_value (wmvc_show_data('idfield', $field), $listing) == 1){
                            $field_value = '<span class="field_checkbox_success">'.esc_html__('Yes','wdk-pdf-export').'</span>';
                        } else {
                            $field_value = '<span class="field_checkbox_unsuccess">'.esc_html__('No','wdk-pdf-export').'</span>';
                        } 
                    } else if(wmvc_show_data('field_type', $field) == "INPUTBOX") {
                        $field_value = wdk_field_value (wmvc_show_data('idfield', $field), $listing);

                        if(strpos($field_value, 'vimeo.com') !== FALSE)
                        {
                            $field_value = wp_oembed_get($field_value, array("width"=>"800", "height"=>"450"));
                        }
                        elseif(strpos($field_value, 'watch?v=') !== FALSE)
                        {
                            $embed_code = substr($field_value, strpos($field_value, 'watch?v=')+8);
                            $field_value =  wp_oembed_get('https://www.youtube.com/watch?v='.$embed_code, array("width"=>"800", "height"=>"455"));
                        }
                        elseif(strpos($field_value, 'youtu.be/') !== FALSE)
                        {
                            $embed_code = substr($field_value, strpos($field_value, 'youtu.be/')+9);
                            $field_value = wp_oembed_get('https://www.youtube.com/watch?v='.$embed_code, array("width"=>"800", "height"=>"455"));
                        }
                        elseif(filter_var($field_value, FILTER_VALIDATE_URL) !== FALSE && preg_match('/\.(mp4|flv|wmw|ogv|webm|ogg)$/i', $field_value))
                        {
                            $field_value  = '<video src="'.$field_value.'" controls></video> ';
                        }
                        elseif(filter_var($field_value , FILTER_VALIDATE_URL) !== FALSE) {
                            $field_value  = '<a href="'.$field_value .'">'.$field_value .'</a>';
                        }
                    }
                    elseif(wmvc_show_data('idfield', $field) == 'category_id') {
                        if(wdk_field_value (wmvc_show_data('idfield', $field), $listing)){
                            $this->WMVC->model('category_m');
                            $tree_data = $this->WMVC->category_m->get(wdk_field_value (wmvc_show_data('idfield', $field), $listing), TRUE);
                            $field_value = wmvc_show_data('category_title', $tree_data);
                        }
                    }
                    elseif(wmvc_show_data('idfield', $field) == 'location_id') {
                        if(wdk_field_value (wmvc_show_data('idfield', $field), $listing)){
                            $this->WMVC->model('location_m');
                            $tree_data = $this->WMVC->location_m->get(wdk_field_value (wmvc_show_data('idfield', $field), $listing), TRUE);
                            $field_value = wmvc_show_data('location_title', $tree_data);
                        }
                    }
                    elseif(wmvc_show_data('field_type', $field) == 'DATE') {
                        $field_value = wdk_field_value (wmvc_show_data('idfield', $field), $listing);
                        $field_value = mysql2date( wdk_get_option( 'date_format' ), $field_value );
                    } elseif(wmvc_show_data('field_type', $field) == 'NUMBER') {

                        /* price format implement */
                        if(function_exists('run_wdk_currency_conversion') && wdk_currencies_is_price_field(wmvc_show_data('idfield', $field))) {
                            /* if currency_conversion and field is price */
                            $value = strip_tags(apply_filters( 'wpdirectorykit/listing/field/value', wdk_filter_decimal($field_value), wmvc_show_data('idfield', $field), FALSE));
                            $value = filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                            $value = (float)str_replace(array(","," ",'&nbsp;'), "", $value);
                            $field_value = esc_html(wdk_number_format_i18n($value));
                        } elseif(wdk_field_option(wmvc_show_data('idfield', $field), 'is_price_format')) {
                            /* if field enabled is_price_format and field type is number*/
                            $field_value = strip_tags(apply_filters( 'wpdirectorykit/listing/field/value', wdk_number_format_i18n(wdk_filter_decimal($field_value)), wmvc_show_data('idfield', $field)));
                        } else {
                            /* without number format */
                            $field_value = apply_filters( 'wpdirectorykit/listing/field/value', $field_value, wmvc_show_data('idfield', $field));
                        }
                        
                    } else {
                        $field_value = apply_filters( 'wpdirectorykit/listing/field/value', $field_value, wmvc_show_data('idfield', $field));
                    } 
                    
                    echo wp_kses_post(wdk_filter_decimal($field_value));
                ?>
                <?php echo esc_html(apply_filters( 'wpdirectorykit/listing/field/suffix',wmvc_show_data('suffix', $field), wmvc_show_data('idfield', $field)));?>
            </span>
        </div>
        <?php endforeach;?>
    </div>

</div>