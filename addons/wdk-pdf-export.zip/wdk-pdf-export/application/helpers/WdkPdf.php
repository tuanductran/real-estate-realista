<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include(WDK_PDF_EXPORT_PATH.'mpdf/vendor/autoload.php');
class WDK_Mpdf extends \Mpdf\Mpdf
{
    
}

class Wdk_Pdf {

    public function __construct($orientation = 'P', $unit = 'mm', $size = 'A4') {

        global $Winter_MVC_WDK,$Winter_MVC_wdk_pdf_export;
        $this->Winter_MVC_WDK = $Winter_MVC_WDK;
        $this->Winter_MVC_wdk_pdf_export = $Winter_MVC_wdk_pdf_export;

        $this->Winter_MVC_WDK->model('listingusers_m');
        $this->Winter_MVC_WDK->model('listing_m');
        $this->Winter_MVC_WDK->model('field_m');
        $this->Winter_MVC_WDK->load_helper('listing');

        /* end  include */
        $upload_dir = wp_get_upload_dir();

        if(!is_dir($upload_dir['basedir'].'/wdk/'))
            mkdir($upload_dir['basedir'].'/wdk/');

        $this->prefix =  $upload_dir['basedir'].'/wdk/';
        $this->prefix_url =  $upload_dir['baseurl'].'/wdk/';
    }

    /*
     * Put remote image 
     * 
     * @param $url_img string link with img
     * @param $x string/int position X
     * @param $y string/int position Y
     * @param $w string/int width of image
     * @param $h string/int height of image
     *      
     */

    public function set_image_by_link($url_img, $filename=NULL) {
        
        if($filename === NULL)
            $filename = time() . rand(000, 999) . '.jpg';
        else {
            $same = explode(', ', $filename);
            $rand_lat = round($same[0], 3);
            $rand_lan = round($same[1], 3);
            $filename = $rand_lat.'x'.$rand_lan;
            $filename = str_replace('.', '_', $filename);
            $filename .='.jpg';
        }
        if(filesize($this->prefix.'/'.$filename) < 60 || !file_exists($this->prefix.'/'.$filename)) {
            $f = $this->file_get_contents_curl($url_img);
            
            if(strpos($f, 'request is invalid') !== false)
            {
                echo 'In WDK PDF Settings check https://developer.mapquest.com/plans API key and use yourself, api returning: <br />';
                exit($f);
            }
            
            file_put_contents($this->prefix.'/'.$filename, $f);
        }

        return $this->prefix_url.$filename;
    }
    
    
    /*
     * Function convert string to requested character encoding
     * 
     * @param string $lang code lang
     * @param string $str string for character encoding
     * retur encoded string;
     */
    public function charset_prepare($lang = 'en', $str = '') {
        $_str = ' ';
        return $str;
    }

    public function generate_by_listing($listing_id = '') {

        $lang_code = get_locale();
        
        /* end data */

        /* listing */
        $listing = $this->Winter_MVC_WDK->listing_m->get($listing_id, TRUE);

        if (empty($listing)) {
            exit(__('Listing not found','wdk'));
        }

        foreach ($listing as $key => $value) {
            if (is_string($value))
                $listing->$key = $this->charset_prepare($lang_code, $value);
        }
        

        // START CREATE PDF

        $html = array();
        
        $html['blog_name'] = get_bloginfo('name');
        $html['blog_description'] = get_bloginfo('description');
        $html['blog_email'] = get_bloginfo('admin_email');
        $html['blog_wpurl'] = get_bloginfo('wpurl');

        $html['title'] = wdk_field_value('post_title', $listing);
        $html['address'] = wdk_field_value('address', $listing);
        $html['gps'] = wdk_field_value('lat', $listing).', '.wdk_field_value('lng', $listing);
        
        //$html['description'] = nl2br(wdk_field_value('post_content', $listing));
        
        $html['description'] = nl2br(   strip_tags(wdk_field_value('post_content', $listing), '<p><img><b><strong><h1><h2><h3>')); // allow only p and img tags in content
        
        $html['listing_link'] = get_permalink($listing);
        $html['images'] = '';
        $html['images_1x'] = '';
        $html['images_2x'] = '';
        $html['images_3x'] = '';
        $html['images_4x'] = '';
        $html['images_5x'] = '';
        $html['images_6x'] = '';
        $html['sections'] = '';
        $html['contact_name'] = '';
        $html['contact_address'] = '';
        $html['contact_email'] = '';
        $html['contact_phone'] = '';

        $images = wdk_listing_images (array('listing_images'=>wdk_field_value ('listing_images', $listing)), 'full');
        $images = array_slice($images, 0, 3);

        /* images */
        $count_i = 0;
        foreach ($images as $key => $image) {
            $html['images'] .='<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            if($count_i < 1) {
                $html['images_1x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_2x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_3x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_4x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_5x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            } elseif($count_i < 2) {
                $html['images_2x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_3x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_4x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_5x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            } elseif($count_i < 3) {
                $html['images_3x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_4x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_5x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            } elseif($count_i < 4) {
                $html['images_4x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_5x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            } elseif($count_i < 5) {
                $html['images_5x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            } elseif($count_i < 6) {
                $html['images_6x'] .= '<div><a href="#"><img src="'.esc_url($image).'" alt=""></a></div>';
            }

            $count_i++;
        }

        /* sections all and per section*/
        $sections_data =  $this->Winter_MVC_WDK->field_m->get_fields_section();
        foreach($this->Winter_MVC_WDK->field_m->get_sections() as $section_id => $section_label)
        {
            $html['section_'.$section_id] = '';
            if(!isset($sections_data[$section_id]))
                continue;
                
            /* enable for section type
            if(wmvc_show_data('is_visible_frontend', $sections_data[$section_id]) != 1) {
                continue;
            }*/

            $complete_empty = true;
            foreach($sections_data[$section_id]['fields'] as $field) {
                if(wmvc_show_data('is_visible_frontend', $field) != 1) {
                    continue;
                }
                if(!empty(wdk_field_value (wmvc_show_data('idfield', $field, '',TRUE, TRUE), $listing))){
                    $complete_empty = false;
                    break;
                }
            }

            if($complete_empty) 
                continue;

            $section_data = array();
            $section_data ['section_label'] = wdk_field_label($section_id);
            $section_data ['section_data'] = $sections_data[$section_id];
            $section_data ['listing_id'] = $listing_id;
            $section_data ['listing'] = $listing;
            
            $html['section_'.$section_id] = $this->Winter_MVC_wdk_pdf_export->view('frontend_pdf/part_section', $section_data, FALSE);
            $html['sections'] .= $html['section_'.$section_id] ;
        }

        /* fields and labels*/
        $fields =  $this->Winter_MVC_WDK->field_m->get();
        foreach($fields as $field)
        {
            $html['field_value_'.$field->idfield] = '';
            $html['field_label_'.$field->idfield] = '';

            $value = '';
            if(wdk_field_option($field->idfield, 'field_type') == "CHECKBOX") {
                if(wdk_field_value ($field->idfield, $listing) == 1){
                    $value = '<span class="field_checkbox_success">yes</span>';
                } else {
                    $value = '<span class="field_checkbox_unsuccess">no</span>';
                } 
            } else if(wdk_field_option($field->idfield,'field_type') == "INPUTBOX") {
                $value = wdk_field_value ($field->idfield, $listing);
            }
            elseif($field->idfield == 'category_id') {
                if(wdk_field_value ($field->idfield, $listing)){
                    $this->Winter_MVC_WDK->model('category_m');
                    $tree_data = $this->Winter_MVC_WDK->category_m->get(wdk_field_value ($field->idfield, $listing), TRUE);
                    $value = wmvc_show_data('category_title', $tree_data);
                }
            }
            elseif($field->idfield == 'location_id') {
                if(wdk_field_value ($field->idfield, $listing)){
                    $this->Winter_MVC_WDK->model('location_m');
                    $tree_data = $this->Winter_MVC_WDK->location_m->get(wdk_field_value ($field->idfield, $listing), TRUE);
                    $value = wmvc_show_data('location_title', $tree_data);
                }
            }
            elseif(strpos($field->idfield,'date') !== FALSE) {
                $value =wdk_get_date(wdk_field_value ($field->idfield, $listing));
            }
            elseif(
                wdk_field_option($field->idfield, 'field_type') == "TEXTAREA" ||
                $field->idfield == 'post_content'
            ) {
                global $wp_embed;
                $value = wpautop(wdk_field_value ($field->idfield, $listing));
                $value = $wp_embed->autoembed($value );
            }
            else {
                $value = wdk_field_value ($field->idfield, $listing);
            }

            if(!empty($value)) {
                $html['field_label_'.$field->idfield] = wdk_field_label($field->idfield);

                /* price format implement */
                if(function_exists('run_wdk_currency_conversion') && wdk_currencies_is_price_field($field->idfield)) {
                    /* if currency_conversion and field is price */
                    $value = strip_tags(apply_filters( 'wpdirectorykit/listing/field/value', wdk_filter_decimal($field->idfield), $field->idfield, FALSE));
                    $value = filter_var($value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                    $value = (float)str_replace(array(","," ",'&nbsp;'), "", $value);
                    $value = esc_html(wdk_number_format_i18n($value));
                } elseif(wdk_field_option($field->idfield, 'is_price_format') && wdk_field_option($field->idfield, 'field_type') == 'NUMBER') {
                    /* if field enabled is_price_format and field type is number*/
                    $value = strip_tags(apply_filters( 'wpdirectorykit/listing/field/value', wdk_number_format_i18n(wdk_filter_decimal($field->idfield)), $field->idfield));
                } else {
                    /* without number format */
                    $value = apply_filters( 'wpdirectorykit/listing/field/value', $value, $field->idfield);
                }

                $html['field_value_'.$field->idfield] = apply_filters( 'wpdirectorykit/listing/field/prefix', strpos($field->idfield,'field_prefix'), $field->idfield)
                                                        .$value
                                                        .apply_filters( 'wpdirectorykit/listing/field/suffix', strpos($field->idfield,'field_suffix'), $field->idfield);
            }

        }
        
        /* map */
        $html['map_img'] =''; 
        if (wdk_get_option('wdk_pdf_export_map_key') && wdk_field_value('lat', $listing)) {
            $src = $this->set_image_by_link('http://www.mapquestapi.com/staticmap/v4/getmap?key=' . wdk_get_option('wdk_pdf_export_map_key') . '&zoom=13&center=' . wdk_field_value('lat', $listing).','.wdk_field_value('lng', $listing) . '&zoom=10&size=715,300&type=map&imagetype=jpeg&pois=1,' . wdk_field_value('lat', $listing).','.wdk_field_value('lng', $listing) . '', wdk_field_value('lat', $listing).', '.wdk_field_value('lng', $listing));
            $html['map_img'] = '<img src="'.$src.'" class="map-img" alt="">';
        }

        /*contact data */

        $user_data = false;
        if(wmvc_show_data('user_id_editor', $listing)) {
            $user_data = get_userdata(wmvc_show_data('user_id_editor', $listing));
    
            // Get user data by user id
            if($user_data) {
                $html['contact_name'] = wmvc_show_data('display_name', $user_data, false, TRUE, TRUE);
                $html['contact_address'] = wmvc_show_data('wdk_address', $user_data, false, TRUE, TRUE);
                $html['contact_email'] = wmvc_show_data('user_email', $user_data, false, TRUE, TRUE);
                $html['contact_phone'] = wmvc_show_data('wdk_phone', $user_data, false, TRUE, TRUE);
            }
        }
        if(!$user_data) {
            $html['contact_email'] = get_bloginfo('admin_email');
            $html['contact_phone'] = '';
        }

        
        $html['contact_details'] = '';
        $html['contact_details'] .= '<h3 class="t_title"><b>'.__('Contact Details', 'sw_win').'</b></h3><br/>';

        if(!empty($html['contact_name']))
            $html['contact_details'] .= '<div class="t_items">'.$html['contact_name'].'</div><br/>';

        if(!empty($html['contact_address']))
            $html['contact_details'] .= '<div class="t_items">'.$html['contact_address'].'</div><br/>';
        
        if(!empty($html['contact_email']))
            $html['contact_details'] .= '<div class="t_items"><a href="mailto:'.$html['contact_email'].'" >'. $html['contact_email'].'</a></div><br/>';
        
        if(!empty($html['contact_phone']))
            $html['contact_details'] .= '<div class="t_items"><a href="tel:.'.str_replace(array(' ','-','(',')'),'',$html['contact_phone']).'" >'. $html['contact_phone'].'</a></div><br/>';


        $this->Winter_MVC_WDK->model('listingusers_m');

        $listing_alt_agents = array();
        $listing_alt_agents = $this->Winter_MVC_WDK->listingusers_m->get($listing_id);

        if(!empty($listing_alt_agents)) {
            foreach ($listing_alt_agents as $alt_agent) {
                $user_data = get_userdata(wmvc_show_data('user_id', $alt_agent));

                $html['contact_details'] .= '<br/>';
                $html['contact_details'] .= '<div class="t_items"><b>'.esc_html__('Agent', 'wdk-pdf-export').' '.esc_html(wmvc_show_data('display_name', $user_data)).'</div></b><br/>';
                if(!empty( wmvc_show_data('wdk_address', $user_data, false, TRUE, TRUE)))
                    $html['contact_details'] .= '<div class="t_items">'. wmvc_show_data('wdk_address', $user_data, false, TRUE, TRUE).'</div><br/>';

                if(!empty( wmvc_show_data('user_email', $user_data, false, TRUE, TRUE)))
                    $html['contact_details'] .= '<div class="t_items"><a href="mailto:'.wmvc_show_data('user_email', $user_data, false, TRUE, TRUE).'" >'. wmvc_show_data('user_email', $user_data, false, TRUE, TRUE).'</a></div><br/>';
               
                if(!empty( wmvc_show_data('wdk_phone', $user_data, false, TRUE, TRUE)))
                    $html['contact_details'] .= '<div class="t_items"><a href="tel:.'.str_replace(array(' ','-','(',')'),'',wmvc_show_data('wdk_phone', $user_data, false, TRUE, TRUE)).'" >'. wmvc_show_data('wdk_phone', $user_data, false, TRUE, TRUE).'</a></div><br/>';
            }
        }

        $settings['website_logo_url'] = '';
        $html['portal_details'] = '';
        $html['portal_details'] .= '<h3 class="t_title"><b>'.get_bloginfo('name').'</b></h3><br/>';
        if(has_custom_logo()) {
            $settings['website_logo'] = get_custom_logo();
            $html['portal_details'] .= '<div class="t_items">'.$settings['website_logo'].'</div><br/>';
        }

        $output = $this->get_layout('listing');
        foreach ($html as $key => $value) {
            $output = str_replace('{'.$key.'}', $value, $output);
        }
        
        // uncomment for use only utf-8
        //$mpdf = new WDK_Mpdf(['mode' => 'utf-8', 'format' => 'A4','default_font' => 'XBRiyaz']);
        
        /* uncomment if output return PDF error
         ob_clean();
        header('Content-type: application/pdf');
        header('Content-Transfer-Encoding: binary');
        header('Accept-Ranges: bytes');
         */
        
        $enable_arabic = ['ar','ar-dz','ar-bh','ar-eg','ar-iq','ar-jo','ar-kw','ar-lb','ar-ly','ar-ma','ar-om','ar-qa','ar-sa','ar-sy','ar-tn','ar-ae','ar-ye','kw','pa','ur','fa', 'tr'];
        $enable_chines = ['zh','zh_HK','zh_TW','zh-HK','zh-TW'];
        $enable_cyrillic = ['ru','ru_RU','ua','ua_UA'];
        if(in_array($lang_code, $enable_arabic) !== FALSE ) {
            $mpdf = new WDK_Mpdf(['autoArabic' => true]);
            $mpdf->SetDirectionality('rtl');
        } elseif(in_array($lang_code, $enable_chines) !== FALSE ) {
            $mpdf = new WDK_Mpdf(['format' => 'A4','default_font' => 'XBRiyaz']);
            $mpdf->autoScriptToLang = true;
            $mpdf->autoLangToFont = true;
            $mpdf->useAdobeCJK = true;
        } elseif(in_array($lang_code, $enable_cyrillic) !== FALSE ) {
            $mpdf = new WDK_Mpdf(['mode' => 'UTF-8', 'format' => 'A4','default_font' => 'XBRiyaz']);
        } else {
            $mpdf = new WDK_Mpdf(['mode' => 'UTF-8', 'format' => 'A4','default_font' => 'XBRiyaz']);
        }

        $filename='listing_'.$listing_id.'.pdf';

        $mpdf->curlAllowUnsafeSslRequests = true;
        $mpdf->autoScriptToLang = true;
        $mpdf->baseScript = 1;
        $mpdf->autoVietnamese = true;
        $mpdf->autoLangToFont = true;
        $mpdf->autoArabic = true;
        $mpdf->WriteHTML($output);
        $mpdf->Output($filename, 'I');
        exit();
    }
    
    private function get_layout( $view_file = '') {

        if(wdk_get_option('wdk_pdf_export_custom_layout_enable')) {
            return wdk_get_option('wdk_pdf_export_custom_layout');
        } else {
            if(empty($view_file)) return false;
            $file = false;
            if(is_child_theme() && file_exists(get_stylesheet_directory().'/wdk-pdf-export/layouts/'.$view_file.'.html'))
            {
                $file = get_stylesheet_directory().'/wdk-pdf-export/layouts/'.$view_file.'.html';
            }
            elseif(file_exists(get_template_directory().'/wdk-pdf-export/layouts/'.$view_file.'.html'))
            {
                $file = get_template_directory().'/wdk-pdf-export/layouts/'.$view_file.'.html';
            }
            elseif(file_exists(WDK_PDF_EXPORT_PATH.'layouts/'.$view_file.'.html'))
            {
                $file = WDK_PDF_EXPORT_PATH.'layouts/'.$view_file.'.html';
            }
            
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            global $wp_filesystem;
            if (empty($wp_filesystem)) {
                WP_Filesystem();
            }
            
            return $wp_filesystem->get_contents($file);
        }
    }
    
    public function file_get_contents_curl($url) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set cURL to return the data instead of printing it to the browser.
        curl_setopt($ch, CURLOPT_URL, $url);

        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

}
