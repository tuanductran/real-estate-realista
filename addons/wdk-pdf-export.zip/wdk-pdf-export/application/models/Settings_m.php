<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;


	public function __construct(){
        parent::__construct();

        $this->fields_list = array( 
            array(
                'field' => 'wdk_pdf_export_map_key', 
                'field_label' => __('Mapquest.com API key', 'wdk-pdf-export'), 
                'hint' => sprintf(__('Please get your key (FREE) %1$s https://developer.mapquest.com/plans %2$s ', 'wdk-pdf-export'), '<a href="https://developer.mapquest.com/plans" target="_blank">', '</a>'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),

            array(
                'field' => 'wdk_pdf_export_custom_layout_enable', 
                'field_label' => __('Enable custom layout', 'wdk-pdf-export'), 
                'hint' => __('Please enable for use custom layout', 'wdk-pdf-export'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),

            array(
                'field' => 'wdk_pdf_export_custom_layout', 
                'field_label' => __('Custom Layout', 'wdk-pdf-export'), 
                'field_type' => 'TEXTAREA_CODE', 
                'hint' => __('Special vars:', 'wdk-pdf-export') .'</br>' 
                        . __('{title} - Listing Title', 'wdk-pdf-export').'</br>' 
                        . __('{address} - Listing Address', 'wdk-pdf-export').'</br>' 
                        . __('{gps} - Listing Gps', 'wdk-pdf-export').'</br>' 
                        . __('{description} - Listing Description', 'wdk-pdf-export').'</br>' 
                        . __('{images_1x} {images_6x} - Listing First 1x - 6x Images', 'wdk-pdf-export').'</br>' 
                        . __('{sections} - Listing Sections', 'wdk-pdf-export').'</br>' 
                        . __('{section_n} - Listing Section, where n is section id', 'wdk-pdf-export').'</br>' 
                        . __('{field_value_n} - Listing Field value, where n is field id', 'wdk-pdf-export').'</br>' 
                        . __('{field_label_n} - Listing Field value, where n is field id', 'wdk-pdf-export').'</br>' 
                        . __('{map_img} - Listing Map', 'wdk-pdf-export').'</br>' 
                        . __('{contact_details} - Listing Contact Details', 'wdk-pdf-export').'</br>' 
                        . __('{portal_details} - Portal Details', 'wdk-pdf-export').'</br>' 
                        . __('{map_img} - Listing Map', 'wdk-pdf-export').'</br>' 
                        . __('{contact_name} - Listing Contact Name', 'wdk-pdf-export').'</br>' 
                        . __('{contact_address} - Listing Contact Address', 'wdk-pdf-export').'</br>' 
                        . __('{contact_email} - Listing Contact Email', 'wdk-pdf-export').'</br>' 
                        . __('{contact_phone} - Listing Contact Phone', 'wdk-pdf-export').'</br>' 
                        . __('{blog_name} - Blog Name', 'wdk-pdf-export').'</br>' 
                        . __('{blog_description} - Blog Description', 'wdk-pdf-export').'</br>' 
                        . __('{blog_email} - Blog Email', 'wdk-pdf-export').'</br>' 
                        . __('{blog_wpurl} - Blog Link', 'wdk-pdf-export').'</br>' 
                        . __('{website_logo_url} - Portal Logo', 'wdk-pdf-export').'</br>',
                'rules' => '', 
            ),
        );
	}
}
?>