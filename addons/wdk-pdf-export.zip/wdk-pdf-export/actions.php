<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


function wdk_pdf_export_print()
{
    if(isset($_GET['wdk_pdf_export_print']) && !empty($_GET['wdk_pdf_export_print'])) {
        global $Winter_MVC_wdk_pdf_export;

        $Winter_MVC_wdk_pdf_export->load_helper('WdkPdf');

        $pdf = new Wdk_Pdf();
        $pdf->generate_by_listing(intval($_GET['wdk_pdf_export_print']));
        ?>

        <?php
        exit();
    }
}

add_action( 'init', 'wdk_pdf_export_print', 10, 2 );


?>