<?php
/**
 * The template for Element Mortgage Calculator
 * This is the template that elementor element calculator, form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-mortgage-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-affordability-calculator">
        <form action="" class="wdk-affordability">
            <div class="alert_box"></div>
            <div class="config" 
            data-currency='<?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol',wmvc_show_data('field_currency',$settings)));?> '
            data-errorempty='<?php echo esc_attr__('Please populate required fields', 'wdk-mortgage');?>'
            ></div>
            <div class="wdk-form-group group-monthly-income">
                <label for="<?php echo esc_html($id_element);?>_monthly_income"><?php echo esc_html(wmvc_show_data('field_monthly_income_label',$settings));?></label>
                <div class="input">
                    <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_income_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', $field_monthly_income_value)));?>" 
                            oninput="this.form.field_monthly_income_range.value=this.value" 
                            name="field_monthly_income" id="<?php echo esc_html($id_element);?>_monthly_income" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_monthly_income_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_monthly_income_range" class="range" min="0" 
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_income_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', $field_monthly_income_value)));?>" 
                        oninput="this.form.field_monthly_income.value=this.value" />
            </div>
            <div class="wdk-form-group group-monthly-saving">
                <label for="<?php echo esc_html($id_element);?>_monthly_saving"><?php echo esc_html(wmvc_show_data('field_monthly_saving_label',$settings));?></label>
                <div class="input">
                <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_saving_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_saving_value_default',$settings))));?>" 
                            oninput="this.form.field_monthly_saving_range.value=this.value" name="field_monthly_saving" 
                            id="<?php echo esc_html($id_element);?>_monthly_saving" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_monthly_saving_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_monthly_saving_range" class="range" min="0"
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_saving_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_saving_value_default',$settings))));?>" 
                        oninput="this.form.field_monthly_saving.value=this.value" />
            </div>
            <div class="wdk-form-group group-monthly-expenses">
                <label for="<?php echo esc_html($id_element);?>_monthly_expenses"><?php echo esc_html(wmvc_show_data('field_monthly_expenses_label',$settings));?></label>
                <div class="input">
                <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_expenses_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_expenses_value_default',$settings))));?>" 
                            oninput="this.form.field_monthly_expenses_range.value=this.value" name="field_monthly_expenses" 
                            id="<?php echo esc_html($id_element);?>_monthly_expenses" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_monthly_expenses_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_monthly_expenses_range" class="range" min="0"
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_expenses_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_expenses_value_default',$settings))));?>" 
                        oninput="this.form.field_monthly_expenses.value=this.value" />
            </div>
            <div class="wdk-form-group group-monthly-debts">
                <label for="<?php echo esc_html($id_element);?>_monthly_debts"><?php echo esc_html(wmvc_show_data('field_monthly_debts_label',$settings));?></label>
                <div class="input">
                <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_debts_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_debts_value_default',$settings))));?>" 
                            oninput="this.form.field_monthly_debts_range.value=this.value" name="field_monthly_debts" 
                            id="<?php echo esc_html($id_element);?>_monthly_debts" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_monthly_debts_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_monthly_debts_range" class="range" min="0"
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_debts_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_monthly_debts_value_default',$settings))));?>" 
                        oninput="this.form.field_monthly_debts.value=this.value" />
            </div>
            <div class="wdk-form-group group-dti">
                <label for="<?php echo esc_html($id_element);?>_dti"><?php echo esc_html(wmvc_show_data('field_dti_label',$settings));?></label>
                <div class="input">
                    <input type="number" step="any" min="0" max="100" value="<?php echo esc_html(wmvc_show_data('field_dti_value_default',$settings));?>" oninput="this.form.field_dti_range.value=this.value" name="field_dti" id="<?php echo esc_html($id_element);?>_monthly_debts" placeholder="<?php echo esc_html(wmvc_show_data('field_dti_placeholder',$settings));?>" class="wdk-control">
                    <span class="suffix">%</span>
                </div>
                <input type="range" min="0" max="100" value="<?php echo esc_html(wmvc_show_data('field_dti_value_default',$settings));?>" name="field_dti_range" class="range" min="0" max="20000" value="0" oninput="this.form.field_dti.value=this.value" />
            </div>

            <div class="wdk-form-group payments_monthly" style="display: none">
                <h3><?php echo esc_html__('Monthly afford', 'wdk-mortgage'); ?></h3>
                <p class="results_monthly"> 0 <?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol',wmvc_show_data('field_currency',$settings)));?> </p>
            </div>
            <div class="wdk-form-group">
                <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
            </div>
        </form>
    </div>
</div>

