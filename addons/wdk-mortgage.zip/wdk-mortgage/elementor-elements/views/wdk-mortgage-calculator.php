<?php
/**
 * The template for Element Mortgage Calculator
 * This is the template that elementor element calculator, form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-mortgage-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-mortgage-calculator">
        <form action="" class="wdk-mortgage">
            <div class="alert_box"></div>
            <div class="config" 
            data-currency='<?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol',wmvc_show_data('field_currency',$settings)));?> '
            data-errorempty='<?php echo esc_attr__('Please populate empty fields', 'wdk-mortgage');?>'
            data-errorempty_price='<?php echo esc_attr__('Down Payment can\'t be higher then Price', 'wdk-mortgage');?>'
            ></div>
            <div class="wdk-form-group group-home-price">
                <label for="<?php echo esc_html($id_element);?>_product_price"><?php echo esc_html(wmvc_show_data('field_product_price_label',$settings));?></label>
                <div class="input">
                    <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_product_price_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', $field_product_price_value)));?>" 
                            oninput="this.form.field_product_price_range.value=this.value" 
                            name="field_product_price" id="<?php echo esc_html($id_element);?>_product_price" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_product_price_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_product_price_range" class="range" min="0" 
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_product_price_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', $field_product_price_value)));?>" 
                        oninput="this.form.field_product_price.value=this.value" />
            </div>
            <div class="wdk-form-group group-down-payment">
                <label for="<?php echo esc_html($id_element);?>_down_payment"><?php echo esc_html(wmvc_show_data('field_down_payment_label',$settings));?></label>
                <div class="input">
                <span class="prefix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_prefix',wmvc_show_data('field_currency',$settings)));?> </span>
                    <input type="number" step="any" min="0"
                            max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_down_payment_value_max',$settings))));?>"  
                            value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_down_payment_value_default',$settings))));?>" 
                            oninput="this.form.field_down_payment_range.value=this.value" name="field_down_payment" 
                            id="<?php echo esc_html($id_element);?>_down_payment" 
                            placeholder="<?php echo esc_html(wmvc_show_data('field_down_payment_placeholder',$settings));?>" 
                            class="wdk-control">
                    <span class="suffix"><?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol_suffix',wmvc_show_data('field_currency',$settings)));?></span>
                </div>
                <input type="range" name="field_down_payment_range" class="range" min="0"
                        max="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_down_payment_value_max',$settings))));?>"  
                        value="<?php echo esc_html($this->int_format(apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('field_down_payment_value_default',$settings))));?>" 
                        oninput="this.form.field_down_payment.value=this.value" />
            </div>
            <div class="wdk-form-group group-rate">
                <label for="<?php echo esc_html($id_element);?>_mortgage_rate"><?php echo esc_html(wmvc_show_data('field_mortgage_rate_label',$settings));?></label>
                <div class="input">
                    <input type="number" step="any" min="0" max="100" value="<?php echo esc_html(wmvc_show_data('field_mortgage_rate_value_default',$settings));?>" oninput="this.form.field_mortgage_rate_range.value=this.value" name="field_mortgage_rate" id="<?php echo esc_html($id_element);?>_down_payment" placeholder="<?php echo esc_html(wmvc_show_data('field_mortgage_rate_placeholder',$settings));?>" class="wdk-control">
                    <span class="suffix">%</span>
                </div>
                <input type="range" min="0" max="100" value="<?php echo esc_html(wmvc_show_data('field_mortgage_rate_value_default',$settings));?>" name="field_mortgage_rate_range" class="range" min="0" max="20000" value="0" oninput="this.form.field_mortgage_rate.value=this.value" />
            </div>
            <div class="wdk-form-group group-years">
                <label for="<?php echo esc_html($id_element);?>_years"><?php echo esc_html(wmvc_show_data('field_years_label',$settings));?></label>
                <input type="number" step="any" min="1" max="100" value="<?php echo esc_html(wmvc_show_data('field_years_value_default',$settings));?>" name="field_mortgage_year" id="<?php echo esc_html($id_element);?>_years" placeholder="<?php echo esc_html(wmvc_show_data('field_years_placeholder',$settings));?>" class="wdk-control">
            </div>
            <div class="wdk-form-group payments_monthly" style="display: none">
                <h3><?php echo esc_html__('Monthly Repayments', 'wdk-mortgage'); ?></h3>
                <p class="results_monthly"> 0 <?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol',wmvc_show_data('field_currency',$settings)));?> </p>
            </div>
            <div class="wdk-form-group payments_weekly" style="display: none">
                <h3><?php echo esc_html__('Weekly Repayments', 'wdk-mortgage');?> </h3>
                <p class="results_weekly"> 0 <?php echo esc_html(apply_filters('wdk-currency-conversion/convert/symbol',wmvc_show_data('field_currency',$settings)));?> </p>
            </div>
            <div class="wdk-form-group">
                <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
            </div>
        </form>
    </div>
</div>

