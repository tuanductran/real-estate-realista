(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	$(function () {

		$('.wdk-mortgage').find('input').on('keypress', function (key) {
			if (key.charCode < 45 || key.charCode > 57) return false;
		});

		$('.wdk-mortgage').on('submit', function(e) {
			e.preventDefault();
			var this_form,$config,$params,load_indicator;
			
			this_form = $(this);
			$config = this_form.find('.config');
			var $currency = $config.attr('data-currency');
			load_indicator = this_form.find('.fa-ajax-indicator');
			load_indicator.css('display', 'inline-block');
			$params = {
				balance: parseFloat(this_form.find('[name="field_product_price"]').val()) - parseFloat(this_form.find('[name="field_down_payment"]').val()),
				rate: parseFloat(this_form.find('[name="field_mortgage_rate"]').val()),
				term: parseFloat(this_form.find('[name="field_mortgage_year"]').val()),
				period: 12,
				currency_prefix: $config.attr('data-currency'),
				currency_suffix: '',
				message_error_empty: $config.attr('data-errorempty') || 'Please fill empty fields',
				message_error_empty: $config.attr('data-errorempty_price') || 'Price can not be less then Down Payment'
			};

			$(this).calculateMortgage({
				params: $params,
				results_weekly: this_form.find('.results_weekly'),
				results_monthly: this_form.find('.results_monthly')
			})
			load_indicator.css('display', 'none');
		});	
		
		$.fn.calculateMortgage = function(options) {
			var defaults = {
				params: {
							currency_prefix: '$',
							currency_suffix: '',
						}
			};
			var options = $.extend(defaults, options);
			var calculate = function(params) {
				var N,I,v,t,result;
				params = $.extend({
					balance: 0,
					rate: 0,
					term: 0,
					period: 0,
					results_weekly: null,
					results_monthly: null
				}, params);
				
				N = params.term * params.period;
				I = (params.rate / 100) / params.period;
				v = Math.pow((1 + I), N);
				t = (I * v) / (v - 1);
				result = params.balance * t;
				
				return result;
			};
			
			return this.each(function () {
				let $element, $result_custom, $result_month, $result_week, output_week, output_month;
				$element = $(this);
				$result_custom = calculate(options.params);
				$result_month = calculate($.extend(options.params, { period: 12 }));
				$result_week = calculate($.extend(options.params, { period: 52 }));
				
				$element.find('div.alert').remove();

				output_week = options.params.currency_prefix + ' ' + $result_week.toFixed(2) + ' ' + options.params.currency_suffix;

				if (options.params.balance < 0) { 
					$element.prepend('<div class=\"alert alert-danger\" role=\"alert\">' + options.params.message_error_empty + '</div>');
					$('html,body').animate({scrollTop: $element.offset().top-170}, 'slow');
					options.results_weekly.parent().slideUp();
					return true;
				}

				if(wdk_mortgage_is_numeric($result_week.toFixed(2)) && wdk_mortgage_is_numeric($result_month.toFixed(2)))
				{
					options.results_weekly.html(output_week);
					options.results_weekly.parent().slideDown();
				}
				else
				{
					$element.prepend('<div class=\"alert alert-danger\" role=\"alert\">'+options.params.message_error_empty+'</div>');
					$('html,body').animate({scrollTop: $element.offset().top-170}, 'slow');
						options.results_weekly.parent().slideUp();
				}
					
			
				output_month = options.params.currency_prefix + ' ' + $result_month.toFixed(2) + ' ' + options.params.currency_suffix;
				if(wdk_mortgage_is_numeric($result_month.toFixed(2))){
								options.results_monthly.html(output_month);
								options.results_monthly.parent().slideDown();
							}
			});

		};


		/* wdk-affordability-calculator */
		$('.wdk-affordability').find('input').on('keypress', function (key) {
			if (key.charCode < 45 || key.charCode > 57) return false;
		});

		$('.wdk-affordability').on('submit', function(e) {
			e.preventDefault();
			var this_form,$config,$params,load_indicator;
			
			this_form = $(this);
			$config = this_form.find('.config');
			var $currency = $config.attr('data-currency');
			load_indicator = this_form.find('.fa-ajax-indicator');
			load_indicator.css('display', 'inline-block');
			$params = {
				monthly_income: parseFloat(this_form.find('[name="field_monthly_income"]').val()) - parseFloat(this_form.find('[name="field_monthly_saving"]').val()) - parseFloat(this_form.find('[name="field_monthly_expenses"]').val()),
				dti: parseFloat(this_form.find('[name="field_dti"]').val()),
				debts: parseFloat(this_form.find('[name="field_monthly_debts"]').val()),
				currency_prefix: $config.attr('data-currency'),
				currency_suffix: '',
				message_error_empty: $config.attr('data-errorempty') || 'Please fill empty fields',
			};

			$(this).calculateAffordability({
				params: $params,
				results_monthly: this_form.find('.results_monthly')
			})
			load_indicator.css('display', 'none');
		});	

		$.fn.calculateAffordability = function(options) {
			var defaults = {
				params: {
							currency_prefix: '$',
							currency_suffix: '',
						}
			};
			var options = $.extend(defaults, options);

			var calculate = function(params) {
				params = $.extend({
					monthly_income: 0,
					dti: 0,
					debts: 0,
					results_monthly: null
				}, params);
				
				return parseFloat(params.monthly_income) * (parseFloat(params.dti) / 100);
			};
			
			return this.each(function () {
				let $element, $result_custom, $result_month, output_month;
				$element = $(this);
				$result_month = calculate(options.params);
				console.log($result_month);
				$element.find('div.alert').remove();
			
				output_month = options.params.currency_prefix + ' ' + $result_month.toFixed(2) + ' ' + options.params.currency_suffix;
				if(wdk_mortgage_is_numeric($result_month.toFixed(2))){
								options.results_monthly.html(output_month);
								options.results_monthly.parent().slideDown();
							}
			});

		};
	});


	const wdk_mortgage_is_numeric = (mixed_var) => {
		var whitespace =
				" \n\r\t\f\x0b\xa0\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u200b\u2028\u2029\u3000";
			return (typeof mixed_var === 'number' || (typeof mixed_var === 'string' && whitespace.indexOf(mixed_var.slice(-1)) === -
				1)) && mixed_var !== '' && !isNaN(mixed_var);
	}

})(jQuery);