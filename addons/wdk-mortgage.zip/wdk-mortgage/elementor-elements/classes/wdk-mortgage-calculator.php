<?php

namespace WdkMortgage\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMortgageCalculator extends WdkMortgageElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-mortgage')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-mortgage')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-mortgage')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-mortgage-calculator';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Mortgage Calculator', 'wdk-mortgage');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-export-kit';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        if(isset($wdk_listing_id) &&  !empty($wdk_listing_id)){
            $price_part = wdk_resultitem_fields_section_value(1, 5, $wdk_listing_id);
            $this->data['field_product_price_value'] = '10000000';
            if(!empty($price_part) && isset($price_part[0])) {
                $this->data['field_product_price_value'] = intval(wdk_filter_decimal(wmvc_show_data('value',$price_part[0],10000000)));
            }
        } else {
            $this->data['field_product_price_value'] = wmvc_show_data('field_product_price_value', $this->data['settings'],10000000);
        }

        $this->data['post_id'] = '';
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-mortgage-calculator', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-mortgage'),
                'tab' => '1',
            ]
        );

        $this->add_responsive_control(
            'field_labels',
                [
                    'label' => esc_html__( 'Hide Labels', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator label' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'field_range',
                [
                    'label' => esc_html__( 'Hide Range', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .range' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'hide_weekly_repayments',
                [
                    'label' => esc_html__( 'Hide Weekly Repayments', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .wdk-form-group.payments_weekly' => 'display: {{VALUE}} !important;',
                    ],
                ]
        );
        
        $this->add_control(
            'field_currency',
            [
                'label' => __( 'Label Currency', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( '$', 'wdk-mortgage' ),
            ]
        );

        
        $this->add_responsive_control(
            'field_product_price_hide',
                [
                    'label' => esc_html__( 'Hide Product Price', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'separator' => 'before',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .wdk-form-group.group-home-price' => 'display: {{VALUE}} !important;',
                    ],
                ]
        );

        $this->add_control(
            'field_product_price_label',
            [
                'label' => __( 'Label Product Price', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Home Price', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_product_price_placeholder',
            [
                'label' => __( 'Placeholder Product Price', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Home Price', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_product_price_value',
            [
                'label' => __( 'Value Product Price', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 1000000000,
				'step' => 1,
				'default' => 1000000,
            ]
        );

        $this->add_control(
            'field_product_price_value_max',
            [
                'label' => __( 'Max Value Product Price', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 100,
				'max' => 100000000,
				'step' => 1,
				'default' => 1000000,
            ]
        );

        $this->add_responsive_control(
            'field_down_payment_hide',
                [
                    'label' => esc_html__( 'Hide Down Payment', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'separator' => 'before',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .wdk-form-group.group-down-payment' => 'display: {{VALUE}} !important;',
                    ],
                ]
        );
        
        $this->add_control(
            'field_down_payment_label',
            [
                'label' => __( 'Label Down Payment', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Down Payment', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_down_payment_placeholder',
            [
                'label' => __( 'Placeholder Down Payment', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Down Payment', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_down_payment_value_max',
            [
                'label' => __( 'Max value Down Payment', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100000000,
				'step' => 1,
				'default' => 200000,
            ]
        );

        $this->add_control(
            'field_down_payment_value_default',
            [
                'label' => __( 'Default Value Down Payment', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100000000,
				'step' => 1,
				'default' => 20000,
            ]
        );

        $this->add_responsive_control(
            'field_mortgage_rate_hide',
                [
                    'label' => esc_html__( 'Hide Mortgage Rate', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'separator' => 'before',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .wdk-form-group.group-rate' => 'display: {{VALUE}} !important;',
                    ],
                ]
        );
        
        $this->add_control(
            'field_mortgage_rate_label',
            [
                'label' => __( 'Label Mortgage Rate', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Mortgage Interest Rate', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_mortgage_rate_placeholder',
            [
                'label' => __( 'Placeholder Mortgage Rate', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Mortgage Rate', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_mortgage_rate_value_default',
            [
                'label' => __( 'Default Value Mortgage Rate', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 5,
            ]
        );

        $this->add_responsive_control(
            'field_years_hide',
                [
                    'label' => esc_html__( 'Hide Years', 'wdk-mortgage' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-mortgage' ),
                    'block' => esc_html__( 'Show', 'wdk-mortgage' ),
                    'return_value' => 'none',
                    'default' => '',
                    'separator' => 'before',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-mortgage-calculator .wdk-form-group.group-years' => 'display: {{VALUE}} !important;',
                    ],
                ]
        );
        
        $this->add_control(
            'field_years_label',
            [
                'label' => __( 'Label Years', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Years', 'wdk-mortgage' ),
            ]
        );

        $this->add_control(
            'field_years_placeholder',
            [
                'label' => __( 'Placeholder Years', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Loan Years', 'wdk-mortgage' ),
            ]
        );
        
        $this->add_control(
            'field_years_value_default',
            [
                'label' => __( 'Default Value Mortgage Rate', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 20,
            ]
        );

        $this->add_control(
            'field_submit',
            [
                'label' => __( 'Text Submit Button', 'wdk-mortgage' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Calculate', 'wdk-mortgage' ),
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();

    }


    private function generate_controls_layout() {
        $this->start_controls_section(
            'section_thumb_properties',
            [
                'label' => __('Thumb Properties','wdk-mortgage'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'thumb_properties_color',
			[
				'label' => __( 'Thumb Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_color:{{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'thumb_properties_height',
            [
                'label' => esc_html__('Thumb Height', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_height:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumb_properties_width',
            [
                'label' => esc_html__('Thumb Width', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_height:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumb_properties_radius',
            [
                'label' => esc_html__('Thumb Radius', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_radius:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'thumb_properties_border_header',
            [
                'label' => esc_html__('Thumb Border', 'wdk-mortgage'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
			'thumb_properties_border_color',
			[
				'label' => __( 'Thumb Border Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_border_color:{{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'thumb_properties_border_width',
            [
                'label' => esc_html__('Thumb Border Width', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_border_width:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'thumb_properties_border_shcolor',
			[
				'label' => __( 'Thumb Shadow Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_border_shcolor:{{VALUE}}',
				],
			]
		);
        
        $this->add_responsive_control(
            'thumb_properties_border_shsize',
            [
                'label' => esc_html__('Thumb Shadow Size', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_border_shsize:{{SIZE}}{{UNIT}}',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'thumb_properties_border_shblur',
            [
                'label' => esc_html__('Thumb Shadow Blur', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--thumb_properties_border_shblur:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();
        /* END special for some elements */

        /*Track */
        $this->start_controls_section(
            'section_track_properties',
            [
                'label' => __('Track Properties','wdk-mortgage'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'track_properties_color',
			[
				'label' => __( 'Track Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_color:{{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'track_properties_height',
            [
                'label' => esc_html__('Track Height', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_height:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'track_properties_radius',
            [
                'label' => esc_html__('Track Radius', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_radius:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'track_properties_border_header',
            [
                'label' => esc_html__('Track Border', 'wdk-mortgage'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
			'track_properties_border_color',
			[
				'label' => __( 'Track Border Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_border_color:{{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'track_properties_border_width',
            [
                'label' => esc_html__('Track Border Width', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_border_width:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
			'track_properties_border_shcolor',
			[
				'label' => __( 'Track Shadow Color', 'wdk-mortgage' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_border_shcolor:{{VALUE}}',
				],
			]
		);
        
        $this->add_responsive_control(
            'track_properties_border_shsize',
            [
                'label' => esc_html__('Track Shadow Size', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_border_shsize:{{SIZE}}{{UNIT}}',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'track_properties_border_shblur',
            [
                'label' => esc_html__('Track Shadow Blur', 'wdk-mortgage'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-mortgage-calculator .range' => '--track_properties_border_shblur:{{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();
        /* END special for some elements */

    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'form_group',
                'label'=> esc_html__('Form group', 'wdk-mortgage'),
                'selector'=>'.wdk-mortgage-calculator .wdk-form-group',
                'options'=>'block',
            ],
            [
                'key'=>'style_label',
                'label'=> esc_html__('Label', 'wdk-mortgage'),
                'selector'=>'.wdk-mortgage-calculator .wdk-form-group label:not(.remember_btn)',
                'options'=>'full',
            ],
            [
                'key'=>'style_field',
                'label'=> esc_html__('Fields', 'wdk-mortgage'),
                'selector'=>'.wdk-mortgage-element .wdk-mortgage-calculator .wdk-form-group .wdk-control:not([type="checkbox"])',
                'options'=>'full',
            ],
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-mortgage'),
                'selector'=>'.wdk-mortgage-element .wdk-mortgage-calculator .wdk-btn',
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if( $item ['key'] == 'style_label'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} '.$item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if ($item ['key'] == 'style_field' || $item ['key'] == 'style_button') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Height', 'wdk-mortgage'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'] => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }
            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-mortgage-calculator');
    }
            
    public function int_format($price = NULL) {
        $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        return (int)str_replace(array(","," ",'&nbsp;'), "", $price);
    }
}
