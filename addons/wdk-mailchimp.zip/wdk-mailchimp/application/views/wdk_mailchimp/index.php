<?php
/**
 * The template for Mailchimp Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Mailchimp','wdk-mailchimp'); ?>   
    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-mailchimp&function=export&search=".wmvc_show_data('search', $db_data, '')."&meta_value=".wmvc_show_data('meta_value', $db_data, '')."&order_by=".wmvc_show_data('order_by', $db_data, '')."&limit=".wmvc_show_data('limit', $db_data, '').""; ?>" 
    class="button button-primary" id="add_listing_button" title="<?php echo esc_attr__('Export For MailChimp', 'wdk-mailchimp');?>" ><?php echo esc_html__('Export For MailChimp', 'wdk-mailchimp'); ?></a>
    </h1>
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-mailchimp" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-mailchimp'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-mailchimp'); ?>" />
               
                
                <label class="screen-reader-text" for="meta_value"><?php echo esc_html__('Filter by Role', 'wdk-mailchimp'); ?></label>
                <?php echo wmvc_select_option('meta_value', $wp_roles, wmvc_show_data('meta_value', $db_data, ''), NULL, __('Role', 'wdk-mailchimp')); ?>
                
                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-mailchimp'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-mailchimp')); ?>
                
                <input type="number" name="limit" id="limit" class="postform left" value="<?php echo wmvc_show_data('limit', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Limit Export', 'wdk-mailchimp'); ?>" />
                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-mailchimp'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Login','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Role','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Name', 'wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Email','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('User registered','wdk-mailchimp'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-mailchimp'); ?></th>
            </tr>
        </thead>
        <?php if(count($mailchimp) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="7"><?php echo esc_html__('No Users found.','wdk-mailchimp'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $mailchimp as $mailchimp ):?>
            <tr>
                <td>
                   <?php echo wmvc_show_data('ID', $mailchimp, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('user_login', $mailchimp, '-'); ?>
                </td>
                <td>
                    <?php
                        $user_meta = get_userdata(wmvc_show_data('ID', $mailchimp, '-'));
                        $user_roles = $user_meta->roles;
                        echo join(',', $user_roles);
                    ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('display_name', $mailchimp); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('user_email', $mailchimp); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('user_registered', $mailchimp, '-'); ?>
                </td>
                <td class="actions_column">
                    <a href="<?php echo get_admin_url() . "user-edit.php?user_id=".wmvc_show_data('ID', $mailchimp, ''); ?>" title="<?php echo esc_attr__('Edit','wdk-mailchimp');?>"><span class="dashicons dashicons-edit"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Login','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Role','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Name', 'wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('Email','wdk-mailchimp'); ?></th>
                <th><?php echo esc_html__('User registered','wdk-mailchimp'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-mailchimp'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>
<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-mailchimp')); ?>");
        });
    });
</script>
<?php $this->view('general/footer', $data); ?>