<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
function wdk_mailchimp_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_WDK;
    $WMVC = &$Winter_MVC_WDK;

    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    $WMVC->model($model_name);
    
    $smart_search = '';
    if(isset($_GET_clone['profile_search']))
        $smart_search = sanitize_text_field($_GET_clone['profile_search']);
        
    $available_fields = array('user_login','user_nicename','user_email','user_url','display_name');

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {

                if($value == 'post_type')
                {
                    $value = $WMVC->$model_name->_table_name.'.'.$value;
                }

                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;

                    if($col_name == 'post_type')
                    {
                        $col_name = $WMVC->$model_name->_table_name.'.'.$col_name;
                    }
                   
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_favorite.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

?>