<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_mailchimp_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        global $Winter_MVC_WDK;
        $controller = 'user';
        $model_name = $controller.'_m';
        $Winter_MVC_WDK->model($model_name);
        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));
                                      $this->data['users'] = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new WP_Roles();
        }
 
        $this->data['wp_roles'] = $wp_roles->role_names;


        $this->data['post_types'] = array();
        $this->data['post_types']['profile'] = __('Profile', 'wdk-mailchimp');
        $this->data['post_types']['wdk-listing'] = __('Listing', 'wdk-mailchimp');

        $this->data['order_by']   = array(  'ID DESC' => __('ID', 'wdk-mailchimp').' DESC', 
                                            'ID ASC' => __('ID', 'wdk-mailchimp').' ASC', 
                                            'user_nicename ASC' => __('Name Id', 'wdk-mailchimp').' ASC',
                                            'user_nicename DESC' => __('Name Id', 'wdk-mailchimp').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search', 'wdk-mailchimp'),
                'rules' => ''
            ),
            array(
                'field' => 'meta_value',
                'label' => __('Role', 'wdk-mailchimp'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-mailchimp'),
                'rules' => ''
            ),
            array(
                'field' => 'limit',
                'label' => __('Limit', 'wdk-mailchimp'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->$model_name->prepare_data($this->input->get(), $rules);
        /* end filters */
                
        $max_limit = NULL;
        if(isset($_GET['limit']))
            $max_limit = intval($_GET['limit']);

        $columns = array('ID', 'user_login','order_by', 'user_nicename', 'user_email', 'meta_value');
        $external_columns = array('user_login', 'user_nicename','user_email', 'meta_value');

        wdk_mailchimp_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $Winter_MVC_WDK->$model_name->total( array(), FALSE);

        if(!empty($max_limit) && $total_items > $max_limit)
            $total_items = $max_limit;
        
        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;
        
        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);
        
        wdk_mailchimp_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['mailchimp'] = $Winter_MVC_WDK->$model_name->get_pagination($per_page, $offset, array(), NULL, FALSE);
        
        // Load view
        $this->load->view('wdk_mailchimp/index', $this->data);
    }
    
	public function export()
	{
        ob_clean();

        global $Winter_MVC_WDK;
        $controller = 'user';
        $model_name = $controller.'_m';

        $Winter_MVC_WDK->model($model_name);
        
        $columns = array('ID', 'user_login','order_by', 'user_nicename', 'user_email', 'meta_value');
        $external_columns = array('user_login', 'user_nicename','user_email', 'meta_value');

        $limit = NULL;
        if(isset($_GET['limit']) && !empty($_GET['limit']))
            $limit = intval($_GET['limit']);

        wdk_mailchimp_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $users = $Winter_MVC_WDK->$model_name->get_pagination($limit, NULL, array(), NULL, FALSE);
        $csv_list = '';
        foreach($users as $row)
        {
            if(strpos($row->user_email, '@') > 1)
            {
                $csv_list.= $row->user_email."\r\n";
            }
        } 
        
        if(strlen($csv_list) > 2)
            $csv_list = substr($csv_list,0,-1);

       
        
        header('Content-Type: application/csv');
        header("Content-Length:".strlen($csv_list));
        header("Content-Disposition: attachment; filename=user_email_export_".date('Y-m-d-H-i-s', time()+get_option('gmt_offset')*60*60).".csv");

        echo $csv_list;
        exit();
    }

}
