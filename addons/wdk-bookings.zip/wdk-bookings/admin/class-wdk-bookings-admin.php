<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/admin
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Bookings_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Bookings_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Bookings_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

        if(defined('WPDIRECTORYKIT_URL'))
            wp_register_style( 'wdk-treefield', WPDIRECTORYKIT_URL . 'public/js/wdk_treefield/treefield.css', array(), '1.0.0' );

		wp_register_style( 'wdk-booking-rates', plugin_dir_url( __FILE__ ) . 'css/wdk-booking-rates.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-calendar', plugin_dir_url( __FILE__ ) . 'css/wdk-booking-calendar.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wdk-bookings-admin.css', array(), $this->version, 'all' );
		
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Bookings_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Bookings_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

        if(defined('WPDIRECTORYKIT_URL'))
            wp_register_script( 'wdk-treefield', WPDIRECTORYKIT_URL . 'public/js/wdk_treefield/treefield.js', array( 'jquery' ), false, false );
            
		wp_register_script( 'wdk-booking-calendar', plugin_dir_url( __FILE__ ) . 'js/wdk-booking-calendar.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'wdk-booking-rates', plugin_dir_url( __FILE__ ) . 'js/wdk-booking-rates.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wdk-bookings-admin.js', array( 'jquery' ), $this->version, false );

	}

    /**
	 * Admin Page Display
	 */
	public function admin_page_display() {
		global $Winter_MVC_wdk_bookings;

		$page = '';
		$function = '';

		if(isset($_GET['page']))$page = wmvc_xss_clean($_GET['page']);
		if(isset($_GET['function']))$function = wmvc_xss_clean($_GET['function']);

		$Winter_MVC_wdk_bookings->load_controller($page, $function, array());
	}

    /**
     * To add Plugin Menu and Settings page
     */
    public function plugin_menu() {

        if(!function_exists('run_wpdirectorykit'))
            return;

        ob_start();

        add_menu_page(__('WDK Bookings', 'wdk-bookings'), __('WDK Bookings', 'wdk-bookings'), 
            'manage_options', 'wdk-bookings', array($this, 'admin_page_display'),
            'dashicons-calendar-alt',
            30 );

        add_submenu_page('wdk-bookings', 
            __('Manage Reservations','wdk-bookings'), 
            __('Manage Reservations','wdk-bookings'),
            'manage_options', 'wdk-bookings', array($this, 'admin_page_display'));

        
        add_submenu_page('wdk-bookings', 
            __('Add Reservation','wdk-bookings'), 
            __('Add Reservation','wdk-bookings'),
            'manage_options', 'wdk-bookings-add', array($this, 'admin_page_display'));

        add_submenu_page('wdk-bookings', 
            __('Availability / Prices','wdk-bookings'), 
            __('Availability / Prices','wdk-bookings'),
            'manage_options', 'wdk-bookings-prices', array($this, 'admin_page_display'));

        add_submenu_page('wdk-bookings', 
            __('Listings Calendar','wdk-bookings'), 
            __('Listings Calendar','wdk-bookings'),
            'manage_options', 'wdk-bookings-calendar', array($this, 'admin_page_display'));


        add_submenu_page('wdk-bookings', 
            __('Settings','wdk-bookings'), 
            __('Settings','wdk-bookings'),
            'manage_options', 'wdk-bookings-settings', array($this, 'admin_page_display'));

        if(get_option('wdk_bookings_enable_woocommerce_payments') == 1 && class_exists( 'woocommerce' ) )
        add_submenu_page('wdk-bookings', 
            __('Payout Reports','wdk-bookings'), 
            __('Payout Reports','wdk-bookings'),
            'manage_options', 'wdk-bookings-payouts', array($this, 'admin_page_display'));
    }
}
