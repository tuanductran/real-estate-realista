<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'wpdirectorykit/install/api', 'wdk_booking_install'); 

if(!function_exists('wdk_booking_install')) {
    function wdk_booking_install () {
        global $Winter_MVC_wdk_bookings;
        global $Winter_MVC_WDK;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('listingusers_m');

        if($Winter_MVC_wdk_bookings->calendar_m->get()){
            //$this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Booking already imported', 'wdk-bookings').'</div>';
            return false;
        }

        if(!function_exists('run_wdk_bookings')){
            //$this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Addon WDK Booking missing', 'wdk-bookings').'</div>';
            return false;
        }
        
        /* remove data */
        $Winter_MVC_wdk_bookings->db->delete($Winter_MVC_wdk_bookings->calendar_m->_table_name);
        $Winter_MVC_wdk_bookings->db->delete($Winter_MVC_wdk_bookings->price_m->_table_name);
        /* end remove data */

        /* reset autoincrement */
        $Winter_MVC_wdk_bookings->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_bookings->calendar_m->_table_name.'`');
        $Winter_MVC_wdk_bookings->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_bookings->price_m->_table_name.'`');
        // Save currency_m

        $Winter_MVC_WDK->model('listing_m');
        $listings = $Winter_MVC_WDK->listing_m->get();

        $date_from = date("Y-m-d H:i:s");
        $date_to = date("Y-m-d H:i:s", strtotime("+2 years"));
        
        foreach ($listings as $listing) {
            if(wdk_field_value('5', $listing) !='Rent') continue;

            /* calendar */
            $data = array();
            $data['post_id'] = wmvc_show_data('post_id', $listing);
            $data['is_activated'] = 1;
            $data['is_hour_enabled'] = rand(0,1);
            $data['currency_code'] = '$';
            // $data['min_hours'] = '';
             $data['changeover_day'] = '';
            // $data['guests'] = '';
             $data['is_children_acceptable'] = rand(0,1);
             $data['is_pets_acceptable'] = rand(0,1);
             $data['payment_info'] = esc_html__('Hi,','wdk-bookings').PHP_EOL.esc_html__('Please transfer payment to account','wdk-bookings')
                                     .' '.wmvc_show_data('display_name',  $user_data_owner, '', TRUE, TRUE).PHP_EOL
                                     .esc_html__('Thanks','wdk-bookings');
            $insert_id = $Winter_MVC_wdk_bookings->calendar_m->insert($data, NULL);


            $user_data_owner = NULL;
            if(wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE )) {
                $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE ) );
            }
    
            if(empty($user_data_owner)) {
                $user_data_owner = array(
                    'display_name' => __('Administrator', 'wdk-bookings'),
                    'user_email' => get_bloginfo('admin_email'),
                );
            }

            /* price */
            $data = array();
            $data['calendar_id'] = $insert_id;
            $data['post_id'] = wmvc_show_data('post_id', $listing);
            $data['date_from'] = $date_from;
            $data['date_to'] =  $date_to;
            $data['is_activated'] = 1;
            $data['price_hour'] = rand(1,5);
            $data['price_day'] = rand(10,20);
            $data['price_week'] = rand(40,60);
            $data['price_month'] = rand(80,100);
            $data['price_year'] = rand(1000,3700);
            $data['currency_code'] = '$';
           // $data['min_hours'] = '';
            $data['changeover_day'] = '';
           // $data['guests'] = '';
            $data['is_children_acceptable'] = rand(0,1);
            $data['is_pets_acceptable'] = rand(0,1);
            $data['payment_info'] = esc_html__('Hi,','wdk-bookings').PHP_EOL.esc_html__('Please transfer payment to account','wdk-bookings')
                                    .' '.wmvc_show_data('display_name',  $user_data_owner, '', TRUE, TRUE).PHP_EOL
                                    .esc_html__('Thanks','wdk-bookings');
            $insert_id = $Winter_MVC_wdk_bookings->price_m->insert($data, NULL);
        }
        
        //$this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.esc_html__('Booking imported').'</div>';
        return true;
    }
}

/* is_enable_public_url */

if(isset($_GET['wdk_booking_public_calendar'])) {

    global $Winter_MVC_wdk_bookings;
    $Winter_MVC_wdk_bookings->model('calendar_m');
    $Winter_MVC_wdk_bookings->model('reservation_m');
    $Winter_MVC_wdk_bookings->db->where(array('md5(CONCAT(idcalendar, "'.NONCE_KEY.'", "wdk-booking")) = "'.trim(sanitize_text_field($_GET['wdk_booking_public_calendar'])).'"'=>NULL));
    $calendar = $Winter_MVC_wdk_bookings->calendar_m->get(NULL, TRUE);

    if($calendar && wdk_show_data('is_enable_public_url', $calendar, '', TRUE, TRUE) == 1) {
        ob_clean();

        $calendar_id = wdk_show_data('idcalendar', $calendar, '', TRUE, TRUE);

        $reservations= $Winter_MVC_wdk_bookings->reservation_m->get_pagination(NULL, NULL, array('calendar_id'=>$calendar_id, 'is_approved' =>1));
 
		$print_data = [];
		$print_data [] = 'BEGIN:VCALENDAR';
		$print_data [] = 'VERSION:2.0';
		$print_data [] = 'PRODID:-//'.get_bloginfo("name").'//EN';
		$print_data [] = 'X-WR-CALNAME:'.get_bloginfo("name").'';
		$print_data [] = 'X-WR-CALDESC:Public '.get_bloginfo("name").' Reservations Provided by '.site_url();
		$print_data [] = 'X-PUBLISHED-TTL:PT1H';
		$print_data [] = 'REFRESH-INTERVAL;VALUE=DURATION:P1H';
		$print_data [] = 'NAME:'.get_bloginfo("name").'';
		$print_data [] = 'CALSCALE:GREGORIAN';
		$print_data [] = 'METHOD:PUBLISH';
		
		foreach ($reservations as $key => $reservation) {
				$print_data [] = 'BEGIN:VEVENT';
				$print_data [] = 'DTEND;VALUE=DATE:'. date('YmdTHis', strtotime(wmvc_show_data('date_to', $reservation)));
				$print_data [] = 'DTSTART;VALUE=DATE:'.date('YmdTHis', strtotime(wmvc_show_data('date_from', $reservation)));
				$print_data [] = 'URL;VALUE=URI:' . admin_url('admin.php?page=wdk-bookings-add&id='.wmvc_show_data('idreservation', $reservation));
				$print_data [] = 'UID:reservation_' .wmvc_show_data('idreservation', $reservation);
				$print_data [] = 'SUMMARY:'.get_bloginfo("name").' Reservation Id '.wmvc_show_data('idreservation', $reservation); 
				$print_data [] = 'DESCRIPTION:<strong>Price</strong> '.wmvc_show_data('price', $reservation).wdk_booking_currency_symbol().'\n'.wmvc_show_data('notes', $reservation) ;
				$print_data [] = 'END:VEVENT';
			
		}
        
		$print_data [] = 'END:VCALENDAR';

		$print_data = preg_replace('/^[ \t]*[\r\n]+/m', '', $print_data);
        echo '<pre>';
        echo implode(PHP_EOL, $print_data);
        
        exit();
    }
    
}

/* end is_enable_public_url */

add_action('wdk-membership/dash/homepage/widgets', function(){
    global $Winter_MVC_wdk_bookings;
    $Winter_MVC_wdk_bookings->model('calendar_m');
    $Winter_MVC_wdk_bookings->model('reservation_m');
    $total_my_reservations = $Winter_MVC_wdk_bookings->reservation_m->total_visitor();
    $total_listings_reservations = $Winter_MVC_wdk_bookings->reservation_m->total();
    $total_calendars = $Winter_MVC_wdk_bookings->calendar_m->total(array(), TRUE, get_current_user_id());
    
   
    if(function_exists('wdk_dash_url')) {
    ?>
        <div class="wdk-col-12 wdk-col-md-3 wdk-membership-dash-widget_booking"> 
            <a href="<?php echo esc_url(wdk_dash_url('dash_page=booking-myreservations'));?>" class="wdk-membership-dash-widget">
                <span class="wdk-content">
                    <span class="icon"><span class="dashicons dashicons-calendar-alt"></span></span>
                </span>
                <span class="wdk-side">
                    <span class="title"><?php echo esc_html__('My Bookings','wdk-bookings');?></span>
                    <span class="wdk-count"><?php echo esc_html($total_my_reservations);?></span>
                </span>
            </a>
        </div>

        <?php if(!empty($total_calendars)):?>
            <?php  if(!wdk_get_option('wdk_bookings_disable_bookings_by_default') || (wdk_get_option('wdk_bookings_disable_bookings_by_default') && wdk_membership_subscription_booking_enabled())):?>
            <div class="wdk-col-12 wdk-col-md-4 wdk-membership-dash-widget_booking"> 
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=booking-reservations'));?>" class="wdk-membership-dash-widget">
                    <span class="wdk-content">
                        <span class="icon"><span class="dashicons dashicons-calendar"></span></span>
                    </span>
                    <span class="wdk-side">
                        <span class="title"><?php echo esc_html__('Reservations','wdk-bookings');?></span>
                        <span class="wdk-count"><?php echo esc_html($total_listings_reservations);?></span>
                    </span>
                </a>
            </div>
            <?php endif;?>
        <?php endif;?>
    <?php
    }
});


/* woo */

remove_action( 'woocommerce_order_details_after_order_table', 'woocommerce_order_again_button' );


// When payment is completed or status completed, then auto activate order/package
//add_action( 'woocommerce_payment_complete', 'wdk_bookings_after_payment' );

//add_action( 'woocommerce_order_status_completed', 'wdk_bookings_woocommerce_order_status_completed', 10, 1 );

add_action( 'woocommerce_order_status_changed', 'wdk_bookings_woocommerce_order_status_completed', 99, 4 );

function wdk_bookings_woocommerce_order_status_completed(  $order_id, $old_status, $new_status, $order ) {
    if( $new_status == "completed" ) {
        wdk_bookings_after_payment( $order_id );
    }
}

/* test
add_action( 'init', 'wdk_bookings_disable_reservations_cron1' , 10, 1 ); 
function wdk_bookings_disable_reservations_cron1()
{
   wdk_bookings_after_payment( 3507 );
}
*/

function wdk_bookings_after_payment( $order_id )
{
    $order = wc_get_order( $order_id );

    $user_id = $order->get_user_id();
    $items = $order->get_items();

    global $Winter_MVC_wdk_bookings;

    $Winter_MVC_wdk_bookings->model('reservation_m');
    $Winter_MVC_wdk_bookings->model('calendar_m');
  
    foreach ( $items as $item ) {
        $product_id = (int) $item['product_id'];
        $item_data    = $item->get_data();
        $reservation_id = (int) $item->get_meta( 'reservation_id', true );
        $product = wc_get_product( $product_id );
        //$price = $product->get_price(); - $product can be NULL here if removed and generate errors!
        $price = $item['subtotal'];
      
        if(empty($reservation_id))continue;

        $reservation = $Winter_MVC_wdk_bookings->reservation_m->get($reservation_id, TRUE); // date_package_expire package_id
        $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>$reservation->post_id), TRUE); // date_package_expire package_id

        if(empty($reservation) || empty($calendar))
        {
            continue;
        }

        $calendar_fees = array();
        if($calendar && !empty($calendar->json_data_fees))
            $calendar_fees = json_decode($calendar->json_data_fees );

        $update_data = array();
        $update_data['is_paid'] = 1;
        $update_data['is_approved'] = 1;
        $update_data['is_booked'] = 1;
        $update_data['price_paid'] = $price;

        /* messages */ 

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $listing_data =  $Winter_MVC_WDK->listing_m->get($reservation->post_id, TRUE);
        $user_client = get_userdata( $user_id );

        /* send message to owner */
        $owner_email = get_bloginfo('admin_email');
        $user_data_owner = NULL;
        if(wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE )) {
            $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE ) );
            if($user_data_owner)
                $owner_email = $user_data_owner->user_email;
        }

        if(empty($user_data_owner)) {
            $user_data_owner = array(
                'display_name' => __('Administrator', 'wdk-bookings'),
                'user_email' => get_bloginfo('admin_email'),
            );
        }
        
        $data_message = array();
        $data_message['user_owner'] = $user_data_owner;
        $data_message['user_client'] = $user_client;
        $data_message['reservation'] = $reservation;
        $data_message['listing'] =  $listing_data;
        $data_message['reservation_id'] = $reservation_id;
        $data_message['data'] = array (
            __('Reservation ID', 'wdk-bookings')=> $reservation_id,
            __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $reservation)),
            __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $reservation)),
        );

        foreach ($calendar_fees as $fee) {
            if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
            $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
        }

        $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

        $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));

        $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));
        wdk_mail($owner_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_owner');
        

        /* send message to visitor */
        $user = get_userdata( wmvc_show_data('user_id', $reservation, '', TRUE, TRUE) );
        $data_message = array();
        $data_message['user_owner'] = $user_data_owner;
        $data_message['user_client'] = $user_client;
        $data_message['reservation'] = $reservation;
        $data_message['reservation_id'] = $reservation_id;
        $data_message['listing'] =  $listing_data;
        $data_message['data'] = array (
            __('Reservation ID', 'wdk-bookings')=> $reservation_id,
            __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $reservation)),
            __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $reservation)),
        );

        foreach ($calendar_fees as $fee) {
            if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
            $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
        }

        $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

        $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));
        $ics_file = wp_upload_bits('reservation_'.$reservation_id.'.ics', NULL, wdk_calendar_ical_export($reservation_id));

        $attachments  = array();
        if($ics_file)
            $attachments[] = $ics_file['file'];

        if( $user_client )
            $ret = wdk_mail($user->user_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_visitor', NULL, $attachments);


        // update reservation_m
        $Winter_MVC_wdk_bookings->reservation_m->insert($update_data, $reservation_id);
    }

    //exit('END wdk_after_payment');
}


// http://localhost:8080/?page_id=2633&add-to-cart=2637&reservation_id=1234

// Store custom data in cart item
add_action( 'woocommerce_add_cart_item_data','wdk_bookings_save_custom_data_in_cart', 20, 2 );

function wdk_bookings_save_custom_data_in_cart( $cart_item_data, $product_id ) {
    if( isset( $_REQUEST['reservation_id'] ) )
        $cart_item_data['reservation_id'] = esc_attr( $_REQUEST['reservation_id'] );
        
    return $cart_item_data;
}

// Display item custom data in cart and checkout pages
add_filter( 'woocommerce_get_item_data', 'wdk_bookings_render_custom_data_on_cart_and_checkout', 20, 2 );
function wdk_bookings_render_custom_data_on_cart_and_checkout( $cart_data, $cart_item ){
    $custom_items = array();

    if( !empty( $cart_data ) )
        $custom_items = $cart_data;

    if( isset( $cart_item['reservation_id'] ) )
        $custom_items[] = array(
            'name'  => 'reservation_id',
            'value' => $cart_item['reservation_id'],
        );
    return $custom_items;
}

// Save and display product note in orders and email notifications (everywhere)
add_action( 'woocommerce_checkout_create_order_line_item', 'wdk_bookings_add_reservation_id_order_item_meta', 20, 4 );

function wdk_bookings_add_reservation_id_order_item_meta( $item, $cart_item_key, $values, $order ) {
    if ( isset( $values['reservation_id'] ) ){
        $item->update_meta_data( 'reservation_id',  $values['reservation_id'] );
    }
}

/* CRON Reservations */
function wdk_bookings_add_every_two_minutes( $schedules ) {
    $schedules['every_30_minutes'] = array(
      'interval'  => 60*30,
      'display'   => __( 'Every 30 Minutes', 'wdk-bookings' )
    );   
    return $schedules;
  }
  add_filter( 'cron_schedules', 'wdk_bookings_add_every_two_minutes' );

add_action( 'init', 'wdk_bookings_disable_reservations_cron' , 10, 1 ); 
function wdk_bookings_disable_reservations_cron()
{
    if(isset($_GET['wdk_bookings_disable_reservations_sync_cron'])) {
        wdk_bookings_disable_reservations_sync(TRUE);
        exit();
    }

    if ( ! wp_next_scheduled( 'wdk_bookings_disable_reservations' ) ) {
        wp_schedule_event( time(), 'every_30_minutes', 'wdk_bookings_disable_reservations' );
    }
}

add_action( 'wdk_bookings_disable_reservations', 'wdk_bookings_disable_reservations_sync', 10, 2 );


/**
 * Get All orders IDs for a given product ID.
 *
 * @param  integer  $product_id (required)
 * @param  array    $order_status (optional) Default is 'wc-completed'
 *
 * @return array
 */
if(!function_exists('wdk_get_orders_ids_by_product_id')) {
    function wdk_get_orders_ids_by_product_id( $product_id ){
        global $wpdb;

        $results = $wpdb->get_col("
            SELECT order_items.order_id
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
        ");

        return $results;
    }
}

function wdk_bookings_disable_reservations_sync($print = TRUE)
{
    global $Winter_MVC_wdk_bookings;
    global $Winter_MVC_WDK;

    if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments'))  {
        if($print){
            echo esc_html__('Woocommerce For Payments Disabled', 'wdk-bookings').'<br />';   
        }
        return false;
    }

    if(!class_exists( 'WooCommerce' )) {
        if($print){
            echo esc_html__('CRON Disabled, WooCommerce Not installed', 'wdk-bookings').'<br />';   
        }
        return false;
    }

    $Winter_MVC_wdk_bookings->model('calendar_m');
    $Winter_MVC_wdk_bookings->model('reservation_m');
    $users_table = $Winter_MVC_wdk_bookings->db->prefix.'users';
    $post_table = $Winter_MVC_wdk_bookings->db->prefix.'posts';

    $Winter_MVC_wdk_bookings->db->select($Winter_MVC_wdk_bookings->reservation_m->_table_name.'.*,'
                                        .$users_table.'.user_nicename, '.$users_table.'.user_email,'.$post_table.'.*');

    $Winter_MVC_WDK->db->join($post_table.' ON '.$Winter_MVC_wdk_bookings->reservation_m->_table_name.'.post_id = '.$post_table.'.ID', TRUE, 'LEFT');
    $Winter_MVC_wdk_bookings->db->join($Winter_MVC_wdk_bookings->db->prefix.'users ON '.$Winter_MVC_wdk_bookings->reservation_m->_table_name.'.user_id = '.$Winter_MVC_wdk_bookings->db->prefix.'users.ID', 'left');
    $Winter_MVC_wdk_bookings->db->join($Winter_MVC_wdk_bookings->calendar_m->_table_name.' ON '.$Winter_MVC_wdk_bookings->reservation_m->_table_name.'.post_id = '.$Winter_MVC_wdk_bookings->calendar_m->_table_name.'.post_id');
    $Winter_MVC_wdk_bookings->db->where(array( 
                                 $Winter_MVC_wdk_bookings->reservation_m->_table_name.'.date_expire < \''.esc_sql(date("Y-m-d H:i:s")).'\'' => NULL,
                                '('.$Winter_MVC_wdk_bookings->reservation_m->_table_name.'.date_expire IS NOT NULL)'=> NULL,
                                '(is_booked IS NULL OR is_booked !=1)'=> NULL,
                                '(is_paid IS NULL OR is_paid !=1)'=> NULL,
                                '(price_paid IS NULL OR price_paid = "")'=> NULL,
                                '(is_approved = 1)'=> NULL,
                                '(is_enable_noapprovements = 1)'=> NULL
                                ));                       
                                
                             
    $expired_reservations = $Winter_MVC_wdk_bookings->reservation_m->get();

    if($print)
        echo esc_html__('CRON START', 'wdk-bookings').'<br />';

    if($print)
        echo esc_html__('Expired Reservation found', 'wdk-bookings').': '.count($expired_reservations).'<br />';
   
    $messages_count = 0;
    foreach($expired_reservations as $expired_reservation)
    {
        /* remove is_booked */
        $update_data = array('is_approved'=>NULL,'is_booked'=>NULL, 'is_payment_expired' => 1);
        $Winter_MVC_wdk_bookings->reservation_m->insert($update_data, $expired_reservation->idreservation);

        /* remove woo ordere if exists */
        if(!empty($expired_reservation->woocommerce_product_id)) {
           // woocommerce_product_id
           //wp_delete_post($expired_reservation->woocommerce_product_id); - this is bad, cause unpredictable issues when product is removed

            // here change order status to failed
            $orders_ids = wdk_get_orders_ids_by_product_id($expired_reservation->woocommerce_product_id);

            update_post_meta($expired_reservation->woocommerce_product_id, '_manage_stock', 'yes');
            update_post_meta($expired_reservation->woocommerce_product_id, '_stock', 0);

            foreach ($orders_ids as $order_id) {
                $order = wc_get_order( $order_id );
                $order->update_status( 'failed', '', true );
                $order->save();
            }
        }
        
        if(wdk_show_data('user_email', $expired_reservation)) {
                        
            $subject = esc_html__('Expired Reservations', 'wdk-bookings');
            $subject .= ' #'.$expired_reservation->post_id;

            $user_info = get_userdata($expired_reservation->user_id);

            $data_message = array();
            $data_message['user'] = get_userdata( wmvc_show_data('user_id', $expired_reservation) );
            $data_message['listing'] = $expired_reservation;
            $data_message['subject']= $subject;
            $data_message['reservation_id'] = $expired_reservation->idreservation;

            if($print)
                echo '<br /><br />'.esc_html__('Sending Email', 'wdk-bookings').'<br />';

            if($print) {
                echo esc_html__('Reservation id', 'wdk-bookings').': '.$expired_reservation->idreservation.' '.wmvc_show_data('post_title', $expired_reservation).' <br />';
                echo esc_html__('User', 'wdk-bookings').': #'.$expired_reservation->user_id.', '.$user_info->display_name.' '.$user_info->user_email.'<br />';
                echo esc_html__('Subject', 'wdk-bookings').': '.$subject.'<br />';

                $Winter_MVC_WDK->view('email/reservation_expired', $data_message, TRUE);
            }

            /* message */
            $ret = wdk_mail(wdk_show_data('user_email', $expired_reservation), __('Reservation Expired by', 'wdk-bookings').' '.html_entity_decode(get_bloginfo('name')), $data_message, 'reservation_expired');

            // Save info about notified user
            if($ret === TRUE)
            {
                echo '<br />'.esc_html__('Sending Message SUCCESSFULLY', 'wdk-bookings').'<br />';
            }
            else
            {
                echo '<br /><b style="color:red;">'.esc_html__('Sending Message FAILED', 'wdk-bookings').'</b><br />';
            }

            $messages_count++;
        }

    }
        
    if($print)
        echo '<br /><br />'.esc_html__('Total Expired Reservations Emails sent', 'wdk-bookings').': '.$messages_count.'<br />';

    if($print)
        echo esc_html__('CRON END', 'wdk-bookings').'<br />';

    exit('END wdk_bookings_disable_reservations_sync');
}


function wdk_booking_reservation_approved()
{
    if(isset($_GET['wdk_reservation_id_approve']) && isset($_GET['wdk_reservation_id_approve'])) {
        global $Winter_MVC_wdk_bookings,$Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->db->where(array(
                                        'idreservation = "'.intval($_GET['wdk_reservation_id_approve']).'"'=>NULL
                                        ));
        $reservation = $Winter_MVC_wdk_bookings->reservation_m->get(NULL, TRUE);
        ?>

        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">

        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <title><?php echo esc_html__('Quickly Approve Reservation', 'wdk-bookings'); ?></title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        </head>

        <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="padding: 48px 0;width: 100%; background-color: #f7f7f7; -webkit-text-size-adjust: none;">
            <div id="wrapper" dir="ltr" style="width: 600px; background-color: #fff; margin: 0 auto;border: 1px solid #dedede;box-shadow: 0 1px 4px rgb(0 0 0 / 10%);">
                <?php

                    if($reservation && substr(md5(wdk_show_data('idreservation', $reservation, false, TRUE, TRUE).NONCE_KEY.'wdk-booking'),0,5) == trim(sanitize_text_field($_GET['hash']))) {
                        if(!wdk_show_data('is_approved', $reservation, false, TRUE, TRUE)) {
                            $insert_id = $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_approved' => 1), wdk_show_data('idreservation', $reservation, false, TRUE, TRUE));
                            if($insert_id) {
                                $listing = $Winter_MVC_WDK->listing_m->get(wdk_show_data('post_id', $reservation, false, TRUE, TRUE), TRUE);
                                $user_client = get_userdata( wmvc_show_data ('user_id', $reservation, false, TRUE, TRUE));

                                $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>wmvc_show_data ('post_id', $reservation, false, TRUE, TRUE)), TRUE); // date_package_expire package_id
                                $calendar_fees = array();
                                if($calendar && !empty($calendar->json_data_fees))
                                    $calendar_fees = json_decode($calendar->json_data_fees );

                                ?>
                                <!-- header -->
                                <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                    <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                            echo esc_html__('Reservation approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                </div>

                                <!-- Body -->
                                <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                    <h2 style="margin-top:0">
                                        <?php
                                            echo esc_html__('Reservation approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                    <?php
                                       
                                    echo '<strong>'.esc_html__('Reservation details', 'wdk-bookings').':</strong>';

                                    echo '<br><strong>'.esc_html__('Date From', 'wdk-bookings').'</strong>: '.esc_html(wdk_get_date(wmvc_show_data ('date_from', $reservation, false, TRUE, TRUE)));
                                    echo '<br><strong>'.esc_html__('Date To', 'wdk-bookings').'</strong>: '.esc_html(wdk_get_date(wmvc_show_data ('date_to', $reservation, false, TRUE, TRUE)));
                                    echo '<br>';
                                    foreach ($calendar_fees as $fee) {
                                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                                        echo '<br><strong>'.__('Price', 'wdk-bookings').' '.esc_html(wmvc_show_data('title', $fee, '-', TRUE, TRUE)).'</strong>: '.esc_html(wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol());
                                    }
                
                                    echo '<br><strong>'.esc_html__('Total Price', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('price', $reservation, false, TRUE, TRUE).wdk_booking_currency_symbol());
                                    

                                    echo '<br><br><strong>'.esc_html__('Listing details', 'wdk-bookings').':</strong>';
                                    echo '<br><strong>'.esc_html__('Listing', 'wdk-bookings').'</strong>: ' 
                                            .'<a href="'.esc_url(get_permalink($listing)).'">'.esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'</a>';

                                    if(wmvc_show_data('address', $listing, false, TRUE, TRUE)) {
                                        echo '<br><strong>'.esc_html__('Address', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('address', $listing, false, TRUE, TRUE));
                                    }

                                    echo '<br><br><strong>'.esc_html__('Client Contact Details', 'wdk-bookings').':</strong>';
                                
                                    if(wmvc_show_data('display_name', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Name', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('display_name', $user_client, false, TRUE, TRUE));
                                    }
                                
                                    if(wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Name', 'wdk-bookings').'</strong>:  <a href="tel:'.esc_attr(str_replace(array(' ','-','(',')'),'',wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE))).'">'.esc_html(wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE)).'</a>';
                                    }
                                
                                    if(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Email', 'wdk-bookings').'</strong>:  <a href="mailto:'.esc_attr(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)).'">'.esc_html(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)).'</a>';
                                    }
                                    
                                    if(wmvc_show_data('wdk_address', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Address', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('wdk_address', $user_client, false, TRUE, TRUE));
                                    }

                                /* send messages */
                                global $Winter_MVC_WDK;
                                $Winter_MVC_WDK->model('listing_m');
                                $Winter_MVC_WDK->load_helper('listing');

                                $Winter_MVC_wdk_bookings->db->where("date_from <='". wmvc_show_data ('date_from', $reservation, false, TRUE, TRUE)."'");
                                $Winter_MVC_wdk_bookings->db->where("date_to >= '". wmvc_show_data ('date_to', $reservation, false, TRUE, TRUE)."'");
                                $price = $Winter_MVC_wdk_bookings->price_m->get_by(array('post_id'=> wmvc_show_data ('post_id', $reservation, false, TRUE, TRUE)), TRUE);

                                $user_owner_id = NULL;
                                $user_data_owner = NULL;

                                if($listing) {
                                    $user_owner_id = wmvc_show_data('user_id_editor', $listing, '', TRUE, TRUE );
                                    if(wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE )) {
                                        $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE ) );
                                    }
                                }
                                    
                                if(empty($user_data_owner)) {
                                    $user_data_owner = array(
                                        'display_name' => __('Administrator', 'wdk-bookings'),
                                        'user_email' => get_bloginfo('admin_email'),
                                    );
                                }

                                /* message */
                                $data_message = array();
                                $data_message['user'] = $user_client;
                                $data_message['user_owner'] = $user_data_owner;
                                $data_message['reservation'] = $reservation;
                                $data_message['listing'] =  $listing;
                                $data_message['reservation_id'] = $insert_id;
                                $data_message['data'] = array(
                                    __('Reservation ID', 'wdk-bookings')=> $insert_id,
                                    __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $reservation,'',TRUE, TRUE)),
                                    __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $reservation,'',TRUE, TRUE)),
                                );

                                foreach ($calendar_fees as $fee) {
                                    if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                                    $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                                }
            
                                $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

                                $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));

                                if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments') && wmvc_show_data('payment_info', $calendar, false)) {
                                    $data_message['data'][__('Payment info', 'wdk-bookings')] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('payment_info', $calendar, '-'));
                                }
                            
                                if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
                                    $ret = wdk_mail(wdk_show_data('user_email', $user_data_owner, '' , TRUE, TRUE), __('New Reservation approved, please confirm as paid when you receive payment', 'wdk-bookings'), $data_message, 'reservation_approved_owner');
                                    $ret = wdk_mail($user_client->user_email, __('Reservation approved, waiting for payment', 'wdk-bookings'), $data_message, 'reservation_approved_visitor');
                                } else {
                                    /* auto create woo only if is_enable_noapprovements enabled */
                                
                                    /* auto create woo item and redirect to order */
                                    if(class_exists( 'WooCommerce' )) {
                                        $url_pay = '';
                                        $title = __('Reservation for', 'wdk-bookings').' '.wdk_field_value ('post_title', $listing).' #'.wmvc_show_data('post_id', $listing);
                                        if($user_owner_id) {
                                            $title .= ' A'.$user_owner_id;
                                        }
                                        $title .= ' '.wmvc_show_data ('date_from', $reservation, false, TRUE, TRUE).' - '.wmvc_show_data ('date_to', $reservation, false, TRUE, TRUE); // The product's Title
                                        
                                        $post_args = array (
                                            'post_author' => $user_owner_id, // The user's ID
                                            'post_title' => $title, // The product's Title
                                            'post_content' => str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-')), // The product's Title
                                            'post_type' => 'product',
                                            'post_status' => 'publish' // This could also be $data['status'];
                                        );
                                    
                                        $woo_id = wp_insert_post( $post_args );
                                        // If the post was created okay, let's try update the WooCommerce values.
                                        if ( ! empty( $woo_id ) && function_exists( 'wc_get_product' ) ) {
                                            $product = wc_get_product( $woo_id );
                                            $product->set_virtual(true);
                                            $product->set_downloadable(true);
                                            $product->set_sold_individually(true);
                                            $product->set_sku( 'wdk-booking-' . $woo_id ); // Generate a SKU with a prefix. (i.e. 'pre-123') 
                                            $product->set_regular_price(wmvc_show_data('price', $reservation,'0')); // Be sure to use the correct decimal price.
                                            $product->save(); // Save/update the WooCommerce order object.

                                            $terms = array( 'exclude-from-catalog', 'exclude-from-search' );
                                            wp_set_object_terms( $woo_id, $terms, 'product_visibility' );

                                            update_post_meta($woo_id, '_manage_stock', 'yes');
                                            update_post_meta($woo_id, '_stock', 1);
                                            
                                            $wdk_attach_id = NULL;
                                            $image_ids = explode(',', trim(wdk_show_data('listing_images' , $listing, '', TRUE, TRUE), ','));

                                            if(is_array($image_ids))
                                                $wdk_attach_id = $image_ids[0];
                                    
                                            set_post_thumbnail( $woo_id, $wdk_attach_id );

                                            /* set woo product id for reservation */
                                            $update_data = array('woocommerce_product_id'=>$woo_id);
                                            $Winter_MVC_wdk_bookings->reservation_m->insert($update_data, wmvc_show_data ('idreservation', $reservation, false, TRUE, TRUE));

                                            if(function_exists('wc_get_cart_url')) {
                                                $url_pay = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($woo_id).'&reservation_id='.esc_attr(wmvc_show_data ('idreservation', $reservation, false, TRUE, TRUE)));
                                            }
                                        }
                                        /* message */
                                        $data_message['pay_link'] = $url_pay;
                                        $ret = wdk_mail(wdk_show_data('user_email', $user_client, '' , TRUE, TRUE), __('Reservation approved, waiting for payment', 'wdk-bookings'), $data_message, 'reservation_user_payment_notify_not_expired');
                                    }
                                    
                                }
                            
                                
                            } else {
                                ?>
                                <!-- header -->
                                <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                    <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                            echo esc_html__('Reservation not updated, please contact with admin', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                </div>

                                <!-- Body -->
                                <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                    <h2 style="margin-top:0">
                                        <?php
                                            echo esc_html__('Reservation not updated, please contact with admin', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                    <?php
                                
                            }

                        } elseif($reservation && wdk_show_data('is_approved', $reservation, false, TRUE, TRUE)) {
                            ?>
                            <!-- header -->
                            <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                         echo esc_html__('Reservation already approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                    ?>
                                </h2>
                            </div>

                            <!-- Body -->
                            <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                <h2 style="margin-top:0">
                                    <?php
                                         echo esc_html__('Reservation already approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                    ?>
                                </h2>
                            <?php
                        } 
                    }
                    else {
                        ?>
                        <!-- header -->
                        <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                            <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                <?php
                                    echo esc_html__('Reservation not found', 'wdk-bookings');
                                ?>
                            </h2>
                        </div>

                        <!-- Body -->
                        <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                            <h2 style="margin-top:0">
                                <?php
                                    echo esc_html__('Reservation not found', 'wdk-bookings');
                                ?>
                            </h2>
                        <?php
                        echo esc_html__('Reservation not found', 'wdk-bookings');
                    }

                    echo '<br><br><strong><a href="'.esc_url(get_home_url()).'">'.esc_html__('Return To Home Page', 'wdk-bookings').'</a></strong>';

                ?>
                </div>
                <!-- Footer -->
            </div>
        </body>

        </html>

        <?php
        exit();
    }
}

add_action( 'init', 'wdk_booking_reservation_approved', 10, 2 );


function wdk_booking_reservation_paid()
{
    if(isset($_GET['wdk_reservation_id_paid']) && isset($_GET['wdk_reservation_id_paid'])) {
        global $Winter_MVC_wdk_bookings,$Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->db->where(array(
                                        'idreservation = "'.intval($_GET['wdk_reservation_id_paid']).'"'=>NULL
                                        ));
        $reservation = $Winter_MVC_wdk_bookings->reservation_m->get(NULL, TRUE);
        ?>

        <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">

        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
            <title><?php echo esc_html__('Quickly Approve Reservation', 'wdk-bookings'); ?></title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        </head>

        <body leftmargin="0" marginwidth="0" topmargin="0" marginheight="0" offset="0" style="padding: 48px 0;width: 100%; background-color: #f7f7f7; -webkit-text-size-adjust: none;">
            <div id="wrapper" dir="ltr" style="width: 600px; background-color: #fff; margin: 0 auto;border: 1px solid #dedede;box-shadow: 0 1px 4px rgb(0 0 0 / 10%);">
                <?php

                    if($reservation && substr(md5(wdk_show_data('idreservation', $reservation, false, TRUE, TRUE).NONCE_KEY.'wdk-booking'),0,5) == trim(sanitize_text_field($_GET['hash']))) {
                        if( !wdk_show_data('is_paid', $reservation, false, TRUE, TRUE)) {
                            $insert_id = $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_paid' => 1,'is_booked' => 1), wdk_show_data('idreservation', $reservation, false, TRUE, TRUE));
                            if($insert_id) {
                                $listing = $Winter_MVC_WDK->listing_m->get(wdk_show_data('post_id', $reservation, false, TRUE, TRUE), TRUE);
                                $user_client = get_userdata( wmvc_show_data ('user_id', $reservation, false, TRUE, TRUE));
                                $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>wmvc_show_data ('post_id', $reservation, false, TRUE, TRUE)), TRUE); // date_package_expire package_id
                                $calendar_fees = array();
                                if($calendar && !empty($calendar->json_data_fees))
                                    $calendar_fees = json_decode($calendar->json_data_fees );

                                ?>
                                <!-- header -->
                                <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                    <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                            echo esc_html__('Reservation paid', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                </div>

                                <!-- Body -->
                                <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                    <h2 style="margin-top:0">
                                        <?php
                                            echo esc_html__('Reservation paid', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                    <?php
                                       
                                    echo '<strong>'.esc_html__('Reservation details', 'wdk-bookings').':</strong>';

                                    echo '<br><strong>'.esc_html__('Date From', 'wdk-bookings').'</strong>: '.esc_html(wdk_get_date(wmvc_show_data ('date_from', $reservation, false, TRUE, TRUE)));
                                    echo '<br><strong>'.esc_html__('Date To', 'wdk-bookings').'</strong>: '.esc_html(wdk_get_date(wmvc_show_data ('date_to', $reservation, false, TRUE, TRUE)));
                                    echo '<br>';
                                    foreach ($calendar_fees as $fee) {
                                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                                        echo '<br><strong>'.__('Price', 'wdk-bookings').' '.esc_html(wmvc_show_data('title', $fee, '-', TRUE, TRUE)).'</strong>: '.esc_html(wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol());
                                    }
                
                                    echo '<br><strong>'.esc_html__('Total Price', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('price', $reservation, false, TRUE, TRUE).wdk_booking_currency_symbol());
                                    
                                    echo '<br><br><strong>'.esc_html__('Listing details', 'wdk-bookings').':</strong>';
                                    echo '<br><strong>'.esc_html__('Listing', 'wdk-bookings').'</strong>: ' 
                                            .'<a href="'.esc_url(get_permalink($listing)).'">'.esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)).'</a>';

                                    if(wmvc_show_data('address', $listing, false, TRUE, TRUE)) {
                                        echo '<br><strong>'.esc_html__('Address', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('address', $listing, false, TRUE, TRUE));
                                    }

                                    echo '<br><br><strong>'.esc_html__('Client Contact Details', 'wdk-bookings').':</strong>';
                                
                                    if(wmvc_show_data('display_name', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Name', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('display_name', $user_client, false, TRUE, TRUE));
                                    }
                                
                                    if(wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Name', 'wdk-bookings').'</strong>:  <a href="tel:'.esc_attr(str_replace(array(' ','-','(',')'),'',wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE))).'">'.esc_html(wmvc_show_data('wdk_phone', $user_client, false, TRUE, TRUE)).'</a>';
                                    }
                                
                                    if(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Email', 'wdk-bookings').'</strong>:  <a href="mailto:'.esc_attr(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)).'">'.esc_html(wmvc_show_data('user_email', $user_client, false, TRUE, TRUE)).'</a>';
                                    }
                                    
                                    if(wmvc_show_data('wdk_address', $user_client, false, TRUE, TRUE)){
                                        echo '<br><strong>'.esc_html__('Address', 'wdk-bookings').'</strong>: '.esc_html(wmvc_show_data ('wdk_address', $user_client, false, TRUE, TRUE));
                                    }

                                /* send messages */
                                global $Winter_MVC_WDK;
                                $Winter_MVC_WDK->model('listing_m');
                                $Winter_MVC_WDK->load_helper('listing');
                                $Winter_MVC_WDK->model('listingusers_m');

                                $Winter_MVC_wdk_bookings->db->where("date_from <='". wmvc_show_data ('date_from', $reservation, false, TRUE, TRUE)."'");
                                $Winter_MVC_wdk_bookings->db->where("date_to >= '". wmvc_show_data ('date_to', $reservation, false, TRUE, TRUE)."'");
                                $price = $Winter_MVC_wdk_bookings->price_m->get_by(array('post_id'=> wmvc_show_data ('post_id', $reservation, false, TRUE, TRUE)), TRUE);
            
                                /* send message to owner */
                                $owner_email = get_bloginfo('admin_email');
                                $user_data_owner = NULL;
                                if($listing) {
                                    if(wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE )) {
                                        $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE ) );
                                        if($user_data_owner)
                                            $owner_email = $user_data_owner->user_email;
                                    }
                                }
            
                                if(empty($user_data_owner)) {
                                    $user_data_owner = array(
                                        'display_name' => __('Administrator', 'wdk-bookings'),
                                        'user_email' => get_bloginfo('admin_email'),
                                    );
                                }
                                
                                $data_message = array();
                                $data_message['user_owner'] = $user_data_owner;
                                $data_message['user_client'] = $user_client;
                                $data_message['reservation'] = $reservation;
                                $data_message['reservation_id'] = $insert_id;
                                $data_message['listing'] =  $listing;
                                $data_message['data'] = array(
                                    __('Reservation ID', 'wdk-bookings')=> $insert_id,
                                    __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $reservation)),
                                    __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $reservation))
                                );

                                foreach ($calendar_fees as $fee) {
                                    if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                                    $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                                }
            
                                $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

                                $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));
                                wdk_mail($owner_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_owner');
                                
            
                                /* send message to visitor */
                                $user = get_userdata( wmvc_show_data('user_id', $reservation) );
                                $data_message = array();
                                $data_message['user_owner'] = $user_data_owner;
                                $data_message['user_client'] = $user_client;
                                $data_message['reservation'] = $reservation;
                                $data_message['listing'] =  $listing;
                                $data_message['reservation_id'] = $insert_id;
                                $data_message['data'] = array(
                                    __('Reservation ID', 'wdk-bookings')=> $insert_id,
                                    __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $reservation)),
                                    __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $reservation))
                                );

                                foreach ($calendar_fees as $fee) {
                                    if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                                    $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                                }
            
                                $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

                                $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));
                                $ics_file = wp_upload_bits('reservation_'.$insert_id.'.ics', NULL, wdk_calendar_ical_export($insert_id));
                             
                                $attachments  = array();
                                if($ics_file)
                                    $attachments[] = $ics_file['file'];
            
                                if( $user )
                                    $ret = wdk_mail($user_client->user_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_visitor', NULL, $attachments);
                            
                                
                            } else {
                                ?>
                                <!-- header -->
                                <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                    <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                            echo esc_html__('Reservation not updated, please contact with admin', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                </div>

                                <!-- Body -->
                                <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                    <h2 style="margin-top:0">
                                        <?php
                                            echo esc_html__('Reservation not updated, please contact with admin', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                        ?>
                                    </h2>
                                    <?php
                                
                            }

                        } elseif(wdk_show_data('is_approved', $reservation, false, TRUE, TRUE)) {
                            
                            ?>
                            <!-- header -->
                            <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                                <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                    <?php
                                         echo esc_html__('Reservation already approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                    ?>
                                </h2>
                            </div>

                            <!-- Body -->
                            <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                                <h2 style="margin-top:0">
                                    <?php
                                         echo esc_html__('Reservation already approved', 'wdk-bookings').' #'.wdk_show_data('idreservation', $reservation, false, TRUE, TRUE);
                                    ?>
                                </h2>
                            <?php
                        } 
                    }
                    else {
                        ?>
                        <!-- header -->
                        <div class="header" style="background-color: #2671cb;padding: 48px 48px;color: #FFF;">
                            <h2 style="margin:0;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 30px; font-weight: 300; line-height: 150%; margin: 0; text-align: left; text-shadow: 0 1px 0 #ab79a1; color: #ffffff; background-color: inherit;"">
                                <?php
                                    echo esc_html__('Reservation not found', 'wdk-bookings');
                                ?>
                            </h2>
                        </div>

                        <!-- Body -->
                        <div class=" body" style="padding: 48px 48px;color: #636363; font-size: 14px;font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                            <h2 style="margin-top:0">
                                <?php
                                    echo esc_html__('Reservation not found', 'wdk-bookings');
                                ?>
                            </h2>
                        <?php
                        echo esc_html__('Reservation not found', 'wdk-bookings');
                    }

                    echo '<br><br><strong><a href="'.esc_url(get_home_url()).'">'.esc_html__('Return To Home Page', 'wdk-bookings').'</a></strong>';

                ?>
                </div>
                <!-- Footer -->
            </div>
        </body>

        </html>

        <?php
        exit();
    }
}

add_action( 'init', 'wdk_booking_reservation_paid', 10, 2 );


?>