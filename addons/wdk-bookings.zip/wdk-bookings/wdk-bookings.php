<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Bookings
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Bookings
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-booking-calendar.html
 * Description:       Calendar and Availability Rates/Prices per Hour/Day/Week... Reservations from Listing Page based on Availability.
 * Version:           1.0.4
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-bookings
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

use Mpdf\Tag\Tr;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_BOOKINGS_VERSION', '1.0.4' );
define( 'WDK_BOOKING_NAME', 'wdk-bookings' );
define( 'WDK_BOOKING_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_BOOKING_URL', plugin_dir_url( __FILE__ ) );

// [WGumroad]
require_once plugin_dir_path( __FILE__  ) . 'vendor/WGumroad/init.php';

global $WGumroad;

$WGumroad->activate_plugin(array(
    'plugin_name' => 'WDK Bookings',
    'plugin_slug' => 'wdk-bookings',
    'plugin_path' => plugin_dir_path( __FILE__ ),
    'plugin_version' => WDK_BOOKINGS_VERSION,
    'gumroad_product_permalink' => 'wp-directory-booking-calendar',
    'gumroad_subscription_permalink' => 'wp-directory-kit-addons',
    'product_website_link' => 'https://swit.gumroad.com/l/wp-directory-booking-calendar',
    'grace_period_days' => 30,
    'support_email' => 'support@wpdirectorykit.com',
    'license_uses_limit' => 2
));

if(!$WGumroad->is_plugin_active('wdk-bookings'))
    return;
// [/WGumroad]

require plugin_dir_path( __FILE__ ) . 'functions.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-bookings-activator.php
 */
function activate_wdk_bookings() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-bookings-activator.php';
	Wdk_Bookings_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-bookings-deactivator.php
 */
function deactivate_wdk_bookings() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-bookings-deactivator.php';
	Wdk_Bookings_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_bookings' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_bookings' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-bookings.php';


if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    run_wdk_bookings();
}


/* enable cron */
add_action( 'wdk_bookings_cron_calendar_import', 'wdk_bookings_cron_calendar_import_sync', 10, 2 );

/* test event
add_filter( 'cron_schedules', 'cron_add_five_min' );
function cron_add_five_min( $schedules ) {
	$schedules['five_min'] = array(
		'interval' => 60 * 1,
	);
	return $schedules;
}
wp_schedule_event( time(), 'daily', 'wdk_bookings_cron_calendar_import' );
*/

if(true)
{
	if ( ! wp_next_scheduled( 'wdk_bookings_cron_calendar_import' ) ) {
		$interval = 'daily';
		if(get_option('wdk_bookings_cron_interval'))
			$interval = get_option('wdk_bookings_cron_interval');
		wp_schedule_event( time(), $interval, 'wdk_bookings_cron_calendar_import' );
	}
}
else
{
	wp_clear_scheduled_hook( 'wdk_bookings_cron_calendar_import' );
}

function wdk_bookings_cron_calendar_import_sync()
{
	global $wpdb;

	$query = "SELECT idcalendar, import_public_url, post_id FROM ".$wpdb->prefix."wdk_booking_calendar 
			  WHERE is_enable_auto_import = '1' AND import_public_url !='' AND is_activated = '1'";
	$calendars = $wpdb->get_results($query);

	foreach ($calendars as $key => $calendar) {
		if(filter_var($calendar->import_public_url, FILTER_VALIDATE_URL) == FALSE) continue;
		if(stripos($calendar->import_public_url, '.ics') === FALSE) continue;

		$name_ics = basename($calendar->import_public_url);
		$name_ics = substr ($name_ics, 0, stripos($name_ics, '.ics')).'.ics';

		/* remove old */
		if(wmvc_show_data('is_import_remove_old_dates', $calendar, false)) {
			$query = "DELETE FROM `".$wpdb->prefix."wdk_booking_reservation` 
			WHERE `source` = '".$name_ics."'";
			$wpdb->query($query);	
		}
		
		require_once(ABSPATH . 'wp-admin/includes/file.php');
		global $wp_filesystem;
		if (empty($wp_filesystem)) {
			WP_Filesystem();
		}

		$string =  $wp_filesystem->get_contents($calendar->import_public_url);
		$reservations = wdk_bookings_parse_icl($string);
		if($reservations && !empty($reservations['reservations'])) {
			$date = date("Y-m-d H:i:s");

			$import_availability_to_date = '+1 year';
			if(wmvc_show_data('import_availability_to_date', $calendar, false))    
				$import_availability_to_date = wmvc_show_data('import_availability_to_date', $calendar);
			
			$import_availability_to_date = date("Y-m-d H:i:s", strtotime($import_availability_to_date)) ;

			foreach ($reservations['reservations'] as $reservation) {
				/* price */
				if($import_availability_to_date < date('Y-m-d H:i:s', strtotime($reservation['dateEnd']))){
					continue;
				}

				//if(stripos(wmvc_show_data('summary', $reservation), 'Not available') !== FALSE) continue;
				
				$data_res = array();
				$data_res['calendar_id'] = $calendar->idcalendar;
				$data_res['post_id'] = $calendar->post_id;
				$data_res['user_id'] = NULL;
				$data_res['date'] = $date;
				$data_res['date_from'] = $reservation['dateStart'];
				//$data_res['date_to'] =  date('Y-m-d H:i:s', strtotime("-1 day", strtotime($reservation['dateEnd'])));
				$data_res['date_to'] =  date('Y-m-d H:i:s', strtotime($reservation['dateEnd']));
				$data_res['is_approved'] = 1;
				$data_res['is_paid'] = NULL;
				$data_res['is_booked'] = 1;
				$data_res['source'] = $name_ics;
				$data_res['is_imported'] = 1;
				$data_res['external_uid'] = (!isset($reservation['uid'])) ? $reservation['uid'] : '';

				$data_res['notes'] = 'UID:'.((!isset($reservation['uid'])) ? $reservation['uid'] : '') .' '.((!isset($reservation['description'])) ? $reservation['description'] : '');
				
				$query = "SELECT * FROM `".$wpdb->prefix."wdk_booking_reservation` 
						  WHERE is_approved = '1' AND post_id = '".$calendar->post_id."'
						  AND `date_from` <= '".$data_res['date_to']."' AND `date_to` >= '".$data_res['date_from']."'
						  ";
				$is_booked = $wpdb->get_results($query);
				if( count($is_booked) !=0 ) {
					continue;
				}

				/* insert */
				$wpdb->insert( $wpdb->prefix."wdk_booking_reservation", $data_res );
			}
		}
	}
}

function wdk_bookings_parse_icl ($content = '') {
	$icl_data = array(
		'title'=>'',
		'description'=>'',
		'reservations'=>array(),
	);
	try {
		//code...
		$content = str_replace("\r\n ", '', $content);

		// Title
		preg_match('`^X-WR-CALNAME:(.*)$`m', $content, $m);
		$icl_data['title'] = $m ? trim($m[1]) : null;

		// Description
		preg_match('`^X-WR-CALDESC:(.*)$`m', $content, $m);
		$icl_data['description'] = $m ? trim($m[1]) : null;

		// Events
		preg_match_all('`BEGIN:VEVENT(.+)END:VEVENT`Us', $content, $m);
		foreach ((array)$m[0] as $c) {
			$event = _wdk_bookings_parse_icl_event($c);
			$icl_data['reservations'][] = $event;
		}
	} catch (\Throwable $th) {
		var_dump('error');
		return false;
	} 

	return $icl_data;
}

function _wdk_bookings_parse_icl_event($content)
{
	$content = str_replace("\r\n ", '', $content);
	$event = array();
	// UID
	if (preg_match('`^UID:(.*)$`m', $content, $m))
		$event['uid'] = trim($m[1]);

	// Summary
	if (preg_match('`^SUMMARY:(.*)$`m', $content, $m))
		$event['summary'] = trim($m[1]);

	// Description
	if (preg_match('`^DESCRIPTION:(.*)$`m', $content, $m))
		$event['description'] = trim($m[1]);

	// Date start
	if (preg_match('`^DTSTART(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
		$event['_timeStart'] = strtotime($m[1]);
		$event['dateStart'] = date('Y-m-d H:i:s', $event['_timeStart']);
	}

	// Date end
	if (preg_match('`^DTEND(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
		$event['_timeEnd'] = strtotime($m[1]);
		$event['dateEnd'] = date('Y-m-d H:i:s', $event['_timeEnd']);
	}

	// Recurrence-Id
	if (preg_match('`^RECURRENCE-ID(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
		$event['_recurrenceId'] = strtotime($m[1]);
		$event['recurrenceId'] = date('Y-m-d H:i:s', $event['_recurrenceId']);
	}

	// Recurrence
	if (preg_match('`^RRULE:(.*)`m', $content, $m)) {
		$rules = (object) array();
		$rule = trim($m[1]);

		$rule = explode(';', $rule);
		foreach ($rule as $r) {
			list($key, $value) = explode('=', $r);
			$rules->{ strtolower($key) } = $value;
		}

		if (isset($rules->until)) {
			$rules->until = date('Y-m-d H:i:s', strtotime($rules->until));
		}
		if (isset($rules->count)) {
			$rules->count = intval($rules->count);
		}
		if (isset($rules->interval)) {
			$rules->interval = intval($rules->interval);
		}
		if (isset($rules->byday)) {
			$rules->byday = explode(',', $rules->byday);
		}

		// Avoid infinite recurrences
		if (! isset($rules->until) && ! isset($rules->count)) {
			$rules->count = 500;
		}

		$event['recurrence'] = $rules;
	}

	// Location
	if (preg_match('`^LOCATION:(.*)$`m', $content, $m))
		$event['location'] = trim($m[1]);

	// Status
	if (preg_match('`^STATUS:(.*)$`m', $content, $m))
		$event['status'] = trim($m[1]);


	// Created
	if (preg_match('`^CREATED:(.*)`m', $content, $m))
		$event['created'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

	// Updated
	if (preg_match('`^LAST-MODIFIED:(.*)`m', $content, $m))
		$event['updated'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

	return $event;
}

function _filter_icl_data($data = '') {
	return str_replace('','',($data));
}
