<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/public
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Bookings_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Bookings_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Bookings_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_register_style( 'daterangepicker', plugin_dir_url( __FILE__ ) . 'js/daterangepicker/daterangepicker.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-listing-table', WDK_BOOKING_URL. 'elementor-elements/assets/css/widgets/wdk-booking-listing-table.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-listing-calendar', WDK_BOOKING_URL. 'elementor-elements/assets/css/widgets/wdk-booking-listing-calendar.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-quick-submission', WDK_BOOKING_URL. 'elementor-elements/assets/css/widgets/wdk-booking-quick-submission.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-listing-no_booking', WDK_BOOKING_URL. 'public/css/wdk-booking-listing-no_booking.css', array(), $this->version, 'all' );


		$custom_css = '
			.daterangepicker .calendar-table::after {
					content: "'.__('Please select end date/time','wdk-bookings').'";
					display: block;
					text-align: center;
					padding-top: 5px;
				}

			.daterangepicker .calendar-table.from_picker::after {
					content: "'.__('Please select start date/time','wdk-bookings').'";
					display: block;
					text-align: center;
					padding-top: 5px;
				}
				
			';

		wp_add_inline_style( 'daterangepicker', $custom_css);

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wdk-bookings-public.css', array(), $this->version, 'all' );


	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Bookings_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Bookings_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_script( 'daterangepicker-moment', plugin_dir_url( __FILE__ ) . 'js/daterangepicker/moment.min.js', array(), $this->version );
		wp_register_script( 'daterangepicker', plugin_dir_url( __FILE__ ) . 'js/daterangepicker/daterangepicker.js', array(), $this->version);

		$params = array(
			'start_of_week' => get_option('start_of_week'),
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'text' => array(
				'select_listing' => esc_html__('Please Select Listing','wdk-bookings'),
				'price' => esc_html__('Price', 'wdk-bookings'),
				'total_price' => esc_html__('Total', 'wdk-bookings'),
				'loading' => esc_html__('Price loading...', 'wdk-bookings'),
				"applyLabel"=> esc_html__("Apply", 'wdk-bookings'),
				"cancelLabel"=> esc_html__("Cancel", 'wdk-bookings'),
				"fromLabel"=> esc_html__("From", 'wdk-bookings'),
				"toLabel"=> esc_html__("To", 'wdk-bookings'),
				"customRangeLabel"=> esc_html__("Custom", 'wdk-bookings'),
				"daysOfWeek_Su"=> esc_html__("Su", 'wdk-bookings'),
				"daysOfWeek_Mo"=> esc_html__("Mo", 'wdk-bookings'),
				"daysOfWeek_Tu"=> esc_html__("Tu", 'wdk-bookings'),
				"daysOfWeek_We"=> esc_html__("We", 'wdk-bookings'),
				"daysOfWeek_Th"=> esc_html__("Th", 'wdk-bookings'),
				"daysOfWeek_Fr"=> esc_html__("Fr", 'wdk-bookings'),
				"daysOfWeek_Sa"=> esc_html__("Sa", 'wdk-bookings'),
				"monthNames_January"=> esc_html__("January", 'wdk-bookings'),
				"monthNames_February"=> esc_html__("February", 'wdk-bookings'),
				"monthNames_April"=> esc_html__("April", 'wdk-bookings'),
				"monthNames_March"=> esc_html__("March", 'wdk-bookings'),
				"monthNames_May"=> esc_html__("May", 'wdk-bookings'),
				"monthNames_June"=> esc_html__("June", 'wdk-bookings'),
				"monthNames_July"=> esc_html__("July", 'wdk-bookings'),
				"monthNames_August"=> esc_html__("August", 'wdk-bookings'),
				"monthNames_September"=> esc_html__("September", 'wdk-bookings'),
				"monthNames_October"=> esc_html__("October", 'wdk-bookings'),
				"monthNames_December"=> esc_html__("December", 'wdk-bookings'),
				"monthNames_November"=> esc_html__("November", 'wdk-bookings'),
			),
		);
		if(function_exists('wdk_convert_date_format_js')) {
			$params ['format_date'] = wdk_convert_date_format_js(get_option('date_format'));
			$params ['format_datetime'] = wdk_convert_date_format_js(get_option('date_format').' '.get_option('time_format'));
		}


		
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wdk-bookings-public.js', array( 'jquery' ), $this->version, false );
        wp_localize_script( $this->plugin_name, 'wdk_bookings_script_parameters', $params);

	}

	
	public function ajax_public()
	{
		global $Winter_MVC_wdk_bookings;

		$page = '';
		$function = '';

		if(isset($_POST['page']))$page = wmvc_xss_clean($_POST['page']);
		if(isset($_POST['function']))$function = wmvc_xss_clean($_POST['function']);

		/* protect access only to ajax controller */
		if($page == 'wdk_bookings_frontendajax') {
			$page = 'wdk-bookings-frontendajax';
		} 

		if($page != 'wdk-bookings-frontendajax') {
			exit(esc_html__('Access denied','wdk-bookings'));
		} 

		$Winter_MVC_wdk_bookings = new MVC_Loader(plugin_dir_path( __FILE__ ).'../');
		$Winter_MVC_wdk_bookings->load_helper('basic');
		$Winter_MVC_wdk_bookings->load_controller($page, $function, array());
	}

}
