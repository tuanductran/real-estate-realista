(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	$(function () {
		if (typeof $.fn.daterangepicker == 'function') {
			$('.wdk-fielddate_range').each(function(){
				var opens = 'left';
				var _that = $(this);
				if (_that.hasClass('center'))
					opens = 'center';
				
				var date_format = wdk_bookings_script_parameters.format_date;
				if (_that.attr('date-format'))
					date_format = _that.attr('date-format');
				
				var isinvaliddates = '';
				if (_that.attr('data-isinvaliddates'))
					isinvaliddates = _that.attr('data-isinvaliddates');
				
				var isallowdates = '';
				if (_that.attr('data-allowdates')) {
					isallowdates = _that.attr('data-allowdates');
				}
				
				var singleDatePicker = false;
				if (_that.attr('data-wdksingle')) {
					singleDatePicker = true;
				}
				_that.daterangepicker({
					timePicker: false,
					opens: opens,
					autoApply: true,
					drops: 'auto',
					minDate: new Date(),
					"minSpan": {
						"hours": 25
					},
					isInvalidDate: function (date) {
						if (typeof isinvaliddates != 'undefined' && isinvaliddates != '') {
							if (isinvaliddates.indexOf(date.format('YYYY-MM-DD')) != -1)
								return true;
							
							return false;
						}
						
						if (typeof isallowdates != 'undefined' && isallowdates != '') {
							if (isallowdates.indexOf(date.format('YYYY-MM-DD')) != -1)
								return false;
							
							return true;
						}

						return false;
					},
					autoUpdateInput: false,
					"timePickerSeconds": false,
					timePicker24Hour: true,
					locale: {
						firstDay: parseInt(wdk_bookings_script_parameters.start_of_week),
						format: date_format,
						"applyLabel": wdk_bookings_script_parameters.text.applyLabel,
						"cancelLabel": wdk_bookings_script_parameters.text.cancelLabel,
						"fromLabel": wdk_bookings_script_parameters.text.fromLabel,
						"toLabel": wdk_bookings_script_parameters.text.toLabel,
						"customRangeLabel": wdk_bookings_script_parameters.text.customRangeLabel,
						"daysOfWeek": [
							wdk_bookings_script_parameters.text.daysOfWeek_Su,
							wdk_bookings_script_parameters.text.daysOfWeek_Mo,
							wdk_bookings_script_parameters.text.daysOfWeek_Tu,
							wdk_bookings_script_parameters.text.daysOfWeek_We,
							wdk_bookings_script_parameters.text.daysOfWeek_Th,
							wdk_bookings_script_parameters.text.daysOfWeek_Fr,
							wdk_bookings_script_parameters.text.daysOfWeek_Sa
						],
						"monthNames": [
							wdk_bookings_script_parameters.text.monthNames_January,
							wdk_bookings_script_parameters.text.monthNames_February,
							wdk_bookings_script_parameters.text.monthNames_March,
							wdk_bookings_script_parameters.text.monthNames_April,
							wdk_bookings_script_parameters.text.monthNames_May,
							wdk_bookings_script_parameters.text.monthNames_June,
							wdk_bookings_script_parameters.text.monthNames_July,
							wdk_bookings_script_parameters.text.monthNames_August,
							wdk_bookings_script_parameters.text.monthNames_September,
							wdk_bookings_script_parameters.text.monthNames_October,
							wdk_bookings_script_parameters.text.monthNames_November,
							wdk_bookings_script_parameters.text.monthNames_December
						],
					},

				}).on('showCalendar.daterangepicker', function(ev, picker) {
					//do something, like clearing an input
					$('.calendar-table').each(function(){
						var el = $(this).find(".table-condensed .month").first().parent().children().last();
						if (!el.hasClass('next available')) {
							el.addClass('next available');
							el.append('<span></span>');
						}
					})

					var picker_el = $(picker.container);
					picker_el.find('.calendar-table').removeClass('from_picker to_picker');
					if(picker_el.find('.drp-calendar.left').length && picker_el.find('.drp-calendar.right').length && picker_el.find('.drp-calendar.right').css('display') != 'none') {
						picker_el.find('.drp-calendar.left .calendar-table').addClass('from_picker');
						picker_el.find('.drp-calendar.right .calendar-table').addClass('to_picker');
					} else {
						if (ev.currentTarget.classList.contains('date_from')) {
							picker_el.find('.calendar-table').addClass('from_picker');
						} else if (ev.currentTarget.classList.contains('date_to')) {
							picker_el.find('.calendar-table').addClass('to_picker');
						} 
					}
				
				});

				if (singleDatePicker && !$('body').hasClass('wdk-single-calendar')) {
					$('body').addClass('wdk-single-calendar');
				}

			});

			$('.wdk-fielddatetime_range').each(function(){
				var opens = 'left';
				if ($(this).hasClass('center'))
					opens = 'center';
				
				var date_format = wdk_bookings_script_parameters.format_datetime;
				if ($(this).attr('date-format'))
					date_format = $(this).attr('date-format');
				
				var isinvaliddates = '';
				if ($(this).attr('data-isinvaliddates'))
					isinvaliddates = $(this).attr('data-isinvaliddates');
				
				var isallowdates = '';
				if ($(this).attr('data-allowdates')) {
					isallowdates = $(this).attr('data-allowdates');
				}

				
				var singleDatePicker = false;
				if ($(this).attr('data-wdksingle')) {
					singleDatePicker = true;
				}

				$(this).daterangepicker({
					timePicker: true,
					opens: opens,
					autoApply: true,
					minDate: new Date(),
					"minSpan": {
						"hours": 1
					},
					isInvalidDate: function (date) {
						if (typeof isinvaliddates != 'undefined' && isinvaliddates != '') {
							if (isinvaliddates.indexOf(date.format('YYYY-MM-DD')) != -1)
								return true;
							
							return false;
						}
						
						if (typeof isallowdates != 'undefined' && isallowdates != '') {
							if (isallowdates.indexOf(date.format('YYYY-MM-DD')) != -1)
								return false;
							
							return true;
						}

						return false;
					},
					autoUpdateInput: false,
					"timePickerSeconds": false,
					timePicker24Hour: true,
					locale: {
						firstDay: parseInt(wdk_bookings_script_parameters.start_of_week),
						format: date_format,
						"applyLabel": wdk_bookings_script_parameters.text.applyLabel,
						"cancelLabel": wdk_bookings_script_parameters.text.cancelLabel,
						"fromLabel": wdk_bookings_script_parameters.text.fromLabel,
						"toLabel": wdk_bookings_script_parameters.text.toLabel,
						"customRangeLabel": wdk_bookings_script_parameters.text.customRangeLabel,
						"daysOfWeek": [
							wdk_bookings_script_parameters.text.daysOfWeek_Su,
							wdk_bookings_script_parameters.text.daysOfWeek_Mo,
							wdk_bookings_script_parameters.text.daysOfWeek_Tu,
							wdk_bookings_script_parameters.text.daysOfWeek_We,
							wdk_bookings_script_parameters.text.daysOfWeek_Th,
							wdk_bookings_script_parameters.text.daysOfWeek_Fr,
							wdk_bookings_script_parameters.text.daysOfWeek_Sa
						],
						"monthNames": [
							wdk_bookings_script_parameters.text.monthNames_January,
							wdk_bookings_script_parameters.text.monthNames_February,
							wdk_bookings_script_parameters.text.monthNames_March,
							wdk_bookings_script_parameters.text.monthNames_April,
							wdk_bookings_script_parameters.text.monthNames_May,
							wdk_bookings_script_parameters.text.monthNames_June,
							wdk_bookings_script_parameters.text.monthNames_July,
							wdk_bookings_script_parameters.text.monthNames_August,
							wdk_bookings_script_parameters.text.monthNames_September,
							wdk_bookings_script_parameters.text.monthNames_October,
							wdk_bookings_script_parameters.text.monthNames_November,
							wdk_bookings_script_parameters.text.monthNames_December
						],
					},
				}).on('showCalendar.daterangepicker', function(ev, picker) {
					//do something, like clearing an input
					$('.calendar-table').each(function(){
						var el = $(this).find(".table-condensed .month").first().parent().children().last();
						if (!el.hasClass('next available')) {
							el.addClass('next available');
							el.append('<span></span>');
						}
					})
				});
				if (singleDatePicker && !$('body').hasClass('wdk-single-calendar')) {
					$('body').addClass('wdk-single-calendar');
				}
				
			});

			$('.wdk-fielddate_range').on('apply.daterangepicker', function (ev, picker) {
				let parent = $(ev.target).closest('form')
				parent.find('.wdk-fielddate_range.date_from').val(picker.startDate.format(wdk_bookings_script_parameters.format_date));
				parent.find('.wdk-fielddate_range.date_to').val(picker.endDate.format(wdk_bookings_script_parameters.format_date));

				parent.find('.wdk-fielddate_range.date_from').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_date));
				parent.find('.wdk-fielddate_range.date_from').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_date));

				parent.find('.wdk-fielddate_range.date_to').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_date));
				parent.find('.wdk-fielddate_range.date_to').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_date));

				parent.find('.wdk-fielddate_range.date_to').trigger('change');
				parent.find('.wdk-fielddate_range.date_from').trigger('change');
			});
		
			$('.wdk-fielddate_range').on('cancel.daterangepicker', function (ev, picker) {
				let parent = $(ev.target).closest('form')
				parent.find('.wdk-fielddate_range[name="date_from]"').val('');
				parent.find('.wdk-fielddate_range.date_to').val('');
			});
			
			$('.wdk-fielddatetime_range').on('apply.daterangepicker', function (ev, picker) {
				let parent = $(ev.target).closest('form')
				parent.find('.wdk-fielddatetime_range.date_from').val(picker.startDate.format(wdk_bookings_script_parameters.format_datetime));
				parent.find('.wdk-fielddatetime_range.date_to').val(picker.endDate.format(wdk_bookings_script_parameters.format_datetime));

				parent.find('.wdk-fielddatetime_range.date_from').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_datetime));
				parent.find('.wdk-fielddatetime_range.date_from').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_datetime));

				parent.find('.wdk-fielddatetime_range.date_to').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_datetime));
				parent.find('.wdk-fielddatetime_range.date_to').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_datetime));

				parent.find('.wdk-fielddatetime_range.date_to').trigger('change');
				parent.find('.wdk-fielddatetime_range.date_from').trigger('change');
			});
		
			$('.wdk-fielddatetime_range').on('cancel.daterangepicker', function(ev, picker) {
				let parent = $(ev.target).closest('form')
				parent.find('.wdk-fielddatetime_range.date_from').val('');
				parent.find('.wdk-fielddatetime_range.date_to').val('');
			});

			$('.anchor_date_from').on('click', function (e) {
				e.preventDefault();
			    $([document.documentElement, document.body]).animate({
					scrollTop: $("#date_from").offset().top - 100
				}, 500, function () { 
					$('#date_from').focus().data('daterangepicker').show();
				});
			});
		}

		if ($('#date_from').length || $('.wdk-booking-quick-submission').length) {
			const wdk_booking_calendar = () => {
				var class_active = 'active';
				var list_days = $('.wdk-booking-listing-calendar table tbody td[data-order]');

				$('.wdk-booking-listing-calendar table td.bg-available a,.wdk-booking-listing-calendar').off();
				$('.wdk-booking-listing-calendar table td.bg-available a').on('click', function (e) {
					e.preventDefault();
					var self, order_from, order_to, date_from;
					self = $(this);
					self.addClass(class_active);
					order_from = self.parent().attr('data-order');
					date_from = self.attr('title');
					$('.wdk-booking-listing-calendar table td a').removeClass(class_active);
					
					$('.wdk-booking-listing-calendar:hover').on('mouseover', function (e) {
					
						var related = e.target ? e.target : "unknown";
						if ($(related).is("a"))
							related = $(related).parent();
						
						if ($(related).hasClass('bg-available')) {
							order_to = parseInt($(related).attr('data-order'));
							if (order_to >= order_from) {
								$('.wdk-booking-listing-calendar table td a').removeClass(class_active);
								while (order_to >= order_from) {
									$(list_days[order_to]).find('a').addClass(class_active);
									order_to--;
								}
							}
						}
					});

					/* finish */
					$('.wdk-booking-listing-calendar table td.bg-available a').off().on('click', function (e) {
						e.preventDefault();
						$('.wdk-booking-listing-calendar:hover').off();
					
						var related = $(this);
						var order_to = parseInt(related.parent().attr('data-order'));
						if(order_from == order_to) {
							related.addClass(class_active);
						} else {
							if (order_to >= order_from) {
								$('.wdk-booking-listing-calendar table td a').removeClass(class_active);
								while (order_to >= order_from) {
									$(list_days[order_to]).find('a').addClass(class_active);
									order_to--;
								}
							}
						}

						var error = false;
						while (order_to >= order_from) {
							if ($(list_days[order_to]).hasClass('bg-booked')) {
								error = true;
								break;
							}
							order_to--;
						}

						if (error) {
							$('.wdk-booking-listing-calendar table td a').removeClass(class_active);
							wdk_log_notify($('.wdk-booking-listing-calendar .js_message_error_date').text(), 'error');
						} else {
							var momentObj = moment(date_from, 'YYYY-MM-DD');
							var date_from_format = momentObj.format( wdk_bookings_script_parameters.format_date);

							$('#date_from, .wdk-booking-quick-submission input[name="date_from"]').val(date_from_format).trigger('change');

							if(!$('.wdk-booking-listing-calendar').hasClass('is_hour') && order_from ==  parseInt(related.parent().attr('data-order')) && $('.wdk-booking-listing-calendar table td[data-order="'+(parseInt(related.parent().attr('data-order')) + 1)+'"]').length) {
								var date_to_format = $('.wdk-booking-listing-calendar table td[data-order="'+(parseInt(related.parent().attr('data-order')) + 1)+'"]').find('a').attr('title');
								var momentObj = moment(date_to_format, 'YYYY-MM-DD');
								date_to_format = momentObj.format( wdk_bookings_script_parameters.format_date);
								
								$('#date_to, .wdk-booking-quick-submission input[name="date_to"]').val($('.wdk-booking-listing-calendar table td[data-order="'+(parseInt(related.parent().attr('data-order')) + 1)+'"]').find('a').attr('title'));
								if($('#date_to_mask').length) {
									$('#date_to_mask').val(date_to_format);
								} else {
									$('#date_to, .wdk-booking-quick-submission input[name="date_to"]').val(date_to_format);
								}
							} else {
								$('#date_to, .wdk-booking-quick-submission input[name="date_to"]').val($(this).attr('title')).trigger('change');
								var date_to_format = $(this).attr('title');
								var momentObj = moment(date_to_format, 'YYYY-MM-DD');
								date_to_format = momentObj.format( wdk_bookings_script_parameters.format_date);
								if($('#date_to_mask').length) {
									$('#date_to_mask').val(date_to_format);
								} else {
									$('#date_to, .wdk-booking-quick-submission input[name="date_to"]').val(date_to_format);
								}
							}

							$('#date_from_mask').val(date_from_format);

							if ($('#date_from').length) {

								var $form = $('.elementinvader_addons_for_elementor_f');
								var $nameInput = $form.find('input[name="Name"]');
								var $dateInput = $form.find('#date_from');
								var $firstInput = $form.find('input:not([type="hidden"])').first();
								
								var $targetInput = $nameInput.length ? $nameInput : ($dateInput.length ? $dateInput : $firstInput);
								

								$([document.documentElement, document.body]).animate({
									scrollTop: $targetInput.offset().top - 100
								}, 500, function () {
									if ($('.elementinvader_addons_for_elementor_f input[name="Name"]').length) {
										$('.elementinvader_addons_for_elementor_f input[name="Name"]').focus();
									} else if ($('.elementinvader_addons_for_elementor_f #date_from').length) {
										$('.elementinvader_addons_for_elementor_f #date_from').focus();
									} else if ($('.elementinvader_addons_for_elementor_f input:not([type="hidden"])').length) {
										$('.elementinvader_addons_for_elementor_f input:not([type="hidden"])').first().focus();
									}
								});
							}
						}

						wdk_booking_calendar();
					});

				});
			};
			wdk_booking_calendar();
		} else {
			$('.wdk-booking-listing-calendar table td.bg-available a,.wdk-booking-listing-calendar').off();
			$('.wdk-booking-listing-calendar table td.bg-available a').on('click', function (e) {
				e.preventDefault();
				wdk_log_notify($('.wdk-booking-listing-calendar .js_message').text(), 'error');
			});
		}

	}) 

	$(document).on('ready', function () {
		if ($('.wdk-booking-listing-table .wdk-booking-login').length && !$('#date_from').length && $('.wdk-booking-quick-submission').length) {
			$('.wdk-booking-listing-table .wdk-booking').addClass('wdk-hidden');
			$('.wdk-booking-listing-table .wdk-booking-login').removeClass('wdk-hidden');
		}
	});

})( jQuery );
