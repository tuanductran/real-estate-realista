<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Report_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_booking_report';
	public $_order_by = 'idreport DESC';
    public $_primary_key = 'idreport';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $fields_list_visitor = NULL;
    
	public function __construct(){
        parent::__construct();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        $this->fields_list = array(
            array(
                'field' => 'year',
                'field_label' => __('Year', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DROPDOWN', 
                'values' => array(
                    wp_date("Y") => wp_date("Y"), 
                    wp_date("Y", strtotime("-1 year")) => wp_date("Y", strtotime("-1 year")), 
                ),
                'rules' => 'required'
            ),
            array(
                'field' => 'month',
                'field_label' => __('Month', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DROPDOWN', 
                'default' => wp_date("m"),
                'values' => array(
                    '01'=>__('01', 'wdk-bookings'), 
                    '02'=>__('02', 'wdk-bookings'), 
                    '03'=>__('03', 'wdk-bookings'), 
                    '04'=>__('04', 'wdk-bookings'), 
                    '05'=>__('05', 'wdk-bookings'), 
                    '06'=>__('06', 'wdk-bookings'), 
                    '07'=>__('07', 'wdk-bookings'), 
                    '08'=>__('08', 'wdk-bookings'), 
                    '09'=>__('09', 'wdk-bookings'), 
                    '10'=>__('10', 'wdk-bookings'), 
                    '11'=>__('11', 'wdk-bookings'), 
                    '12'=>__('12', 'wdk-bookings'), 
                ),
                'rules' => 'required'
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*');
        $this->db->from($this->_table_name);
        
        $this->db->where($where);

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }

    public function get_payouts($limit, $offset, $where = array(), $order_by = NULL)
    {
        global $wpdb;
        $this->_table_user_name = $wpdb->users;
        $this->_table_user_name_meta = $wpdb->usermeta;
        $post_table = $this->db->prefix.'posts';
        $postmeta_table = $this->db->prefix.'postmeta';
        $reservation_table = $this->db->prefix.'wdk_booking_reservation';
        $order_itemmeta_table = $this->db->prefix.'woocommerce_order_itemmeta';
        $order_items_table = $this->db->prefix.'woocommerce_order_items';
        
        $this->db->select('*, CAST(paid_date_table.meta_value AS DATETIME) as paid_date, CAST(total_paid_table.meta_value AS UNSIGNED) as total_paid, CAST(tax_paid_table.meta_value AS UNSIGNED) as tax_paid');
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        $this->db->join($this->db->prefix.'wdk_listings ON '.$reservation_table.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
        $this->db->join($this->_table_user_name.' ON '.$this->db->prefix.'wdk_listings.user_id_editor  = '.$this->_table_user_name.'.ID', 'left');
        $this->db->join($order_itemmeta_table.' ON '.$reservation_table.'.idreservation  = '.$order_itemmeta_table.'.meta_value AND '.$order_itemmeta_table.'.meta_key = \'reservation_id\'', 'left');
        $this->db->join($order_items_table.' ON '.$order_itemmeta_table.'.order_item_id  = '.$order_items_table.'.order_item_id', 'left');
        $this->db->join($postmeta_table.' paid_date_table  ON paid_date_table.post_id = '.$order_items_table.'.order_id AND paid_date_table.meta_key = \'_paid_date\' ');
        $this->db->join($postmeta_table.' total_paid_table ON total_paid_table.post_id = '.$order_items_table.'.order_id AND total_paid_table.meta_key = \'_order_total\' ');
        $this->db->join($postmeta_table.' tax_paid_table   ON tax_paid_table.post_id = '.$order_items_table.'.order_id AND tax_paid_table.meta_key = \'_order_tax\' ');



        //woocommerce_product_id


        //$this->db->where($where);
        //$this->db->limit($limit);
        //$this->db->offset($offset);

        /*
        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }*/
        
        $query = $this->get();

        echo ($this->db->last_query());

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
        
        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        $this->load->model('reportdata_m');

        $this->reportdata_m->delete_by_report($post_id);

        parent::delete($id);

        return true;
    }

}
?>