<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Price_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_booking_price';
	public $_order_by = 'idprice DESC';
    public $_primary_key = 'idprice';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        $this->fields_list = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => sprintf(__('You can only define rates for listings which have %1$s calendar defined %2$s', 'wdk-bookings'),'<a href="'.admin_url("admin.php?page=wdk-bookings-calendar").'">','</a>'),
                'field_type' => 'LISTING_CALENDAR', 
                'rules' => 'required|numeric|post_exists'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_FROM', 
                'rules' => 'required|price_date_exists'
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_TO', 
                'rules' => 'required'
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'price_hour',
                'field_label' => __('Price per Hour', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_day',
                'field_label' => __('Price per Day', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric|required'
            ),
            array(
                'field' => 'price_week',
                'field_label' => __('Price per Week', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_month',
                'field_label' => __('Price per Month', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_year',
                'field_label' => __('Price per Year', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'changeover_day',
                'field_label' => __('Changeover day', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'DROPDOWN', 
                'rules' => 'numeric',
                'values' => array(
                    ''=>__('Not Selected', 'wdk-bookings'),
                    '1'=>__('Monday', 'wdk-bookings'),
                    '2'=>__('Tuesday', 'wdk-bookings'),
                    '3'=>__('Wednesday', 'wdk-bookings'),
                    '4'=>__('Thursday', 'wdk-bookings'),
                    '5'=>__('Friday', 'wdk-bookings'),
                    '6'=>__('Saturday', 'wdk-bookings'),
                    '7'=>__('Sunday', 'wdk-bookings'),
                )
            ),
            array(
                'field' => 'min_hours',
                'field_label' => __('Min. hours', 'wdk-bookings'),
                'hint' => __('If you need for days, just multiply with 24, so for example, for 2 days is 48', 'wdk-bookings'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'max_hours',
                'field_label' => __('Max hours', 'wdk-bookings'),
                'hint' => __('If you need for days, just multiply with 24, so for example, for 2 days is 48', 'wdk-bookings'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }


        $this->fields_list_calendar = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => sprintf(__('You can only define rates for listings which have %1$s calendar defined %2$s', 'wdk-bookings'),'<a href="'.admin_url("admin.php?page=wdk-bookings-calendar").'">','</a>'),
                'field_type' => 'LISTING_CALENDAR', 
                'rules' => 'required|numeric|post_exists'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_FROM', 
                'rules' => 'required|price_date_exists'
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_TO', 
                'rules' => 'required'
            ),
            array(
                'field' => 'calendar_dates',
                'field_label' => __('Calendar', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CALENDAR_DATES_VIEW', 
                'rules' => ''
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'price_hour',
                'field_label' => __('Price per Hour', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_day',
                'field_label' => __('Price per Day', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric|required'
            ),
            array(
                'field' => 'price_week',
                'field_label' => __('Price per Week', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_month',
                'field_label' => __('Price per Month', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_year',
                'field_label' => __('Price per Year', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'changeover_day',
                'field_label' => __('Changeover day', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'DROPDOWN', 
                'rules' => 'numeric',
                'values' => array(
                    ''=>__('Not Selected', 'wdk-bookings'),
                    '1'=>__('Monday', 'wdk-bookings'),
                    '2'=>__('Tuesday', 'wdk-bookings'),
                    '3'=>__('Wednesday', 'wdk-bookings'),
                    '4'=>__('Thursday', 'wdk-bookings'),
                    '5'=>__('Friday', 'wdk-bookings'),
                    '6'=>__('Saturday', 'wdk-bookings'),
                    '7'=>__('Sunday', 'wdk-bookings'),
                )
            ),
            array(
                'field' => 'min_hours',
                'field_label' => __('Min. hours', 'wdk-bookings'),
                'hint' => __('If you need for days, just multiply with 24, so for example, for 2 days is 48', 'wdk-bookings'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'max_hours',
                'field_label' => __('Max hours', 'wdk-bookings'),
                'hint' => __('If you need for days, just multiply with 24, so for example, for 2 days is 48', 'wdk-bookings'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
        );

        foreach($this->fields_list_calendar as $key=>$field)
        {
            $this->fields_list_calendar[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*, '.$this->_table_name.'.is_activated AS price_is_activated');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }

        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
            
        $row = $this->get($id, TRUE);
        if(!$row) return false;
           
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
        if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
            return true;
            
        return false;
    }
   
    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $row = $this->get($item_id, TRUE);
        if(!$row) return false;
        
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
        if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
            return true;

        return false;
    }

    public function get_prices_dates($post_id)
    {
        $dates = array();
        
        $this->db->select('*');
        $this->db->from($this->_table_name);

        $this->db->where('post_id', $post_id);
        //$this->db->where("date_from >'".date('Y-m-01 00:00:00')."'");
        //$this->db->where('is_approved', 1);

        $query = $this->db->get();
      
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();
            
            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));

                foreach ($period as $date) {
                    $dates[$date->format("Y-m-d")] = wdk_show_data('idprice', $row,'', TRUE, TRUE);
                }
            }

        }

        return $dates;
    }

    
    public function delete_where($where)
    {
        $this->db->where($where);
        $this->db->delete($this->_table_name);
    }

}
?>