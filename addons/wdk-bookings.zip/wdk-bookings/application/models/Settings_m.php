<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;

	public function __construct(){
        parent::__construct();

        $this->fields_list = array( 
            array('field' => 'wdk_bookings_calendar_single', 'field_label' => __('Enable Single Calendar Box', 'wdk-bookings'), 'hint' => __('If you want show only one calendar (month) on date input box', 'wdk-bookings'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'wdk_bookings_is_hours_enabled', 'field_label' => __('Enable Hours for booking search', 'wdk-bookings'), 'hint' => __('If you want show hours in booking search field, please select here', 'wdk-bookings'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array(
                'field' => 'wdk_bookings_cron_interval', 
                'field_label' => __('Cron interval', 'wdk-bookings'), 
                'hint' => __('Custom cron interval (for calendar imports), default Daily (Once Daily)', 'wdk-bookings'), 
                'field_type' => 'DROPDOWN', 
                'values' => array(
                                ''=>__('Select interval', 'wdk-bookings'), 
                                'hourly'=>__('Once Hourly', 'wdk-bookings'), 
                                'twicedaily'=>__('Twice Daily', 'wdk-bookings'), 
                                'daily'=>__('Once Daily', 'wdk-bookings'), 
                                'weekly'=>__('Once Weekly', 'wdk-bookings'), 
                            ),
                'rules' => ''
            ),
            array(
                'field' => 'wdk_bookings_enable_woocommerce_payments', 
                'field_label' => __('Enable Woocommerce For Payments', 'wdk-bookings'), 
                'hint' => __('Enable woocommerce for payments, login will be required or auto registered', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'wdk_bookings_time_for_payment', 
                'field_label' => __('Time for payment', 'wdk-bookings'), 
                'hint' => __('How many hours reservation will be active and wait for payment, if not paid in this hour interval, will become available for reservation from someone else', 'wdk-bookings'), 
                'field_type' => 'NUMBER', 
                'rules' => 'wdk_is_natural'
            ),
            array(
                'field' => 'wdk_bookings_max_guests', 
                'field_label' => __('Max guests for select list on booking', 'wdk-bookings'), 
                'hint' => __('Change default max guests (default is 10)', 'wdk-bookings'), 
                'field_type' => 'NUMBER', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_bookings_currency', 
                'field_label' => __('Enter default currency', 'wdk-bookings'), 
                'hint' => __('Enter default currency symbol like USD, this currency will be used only if WooComerce is not installed/enabled, otherwise we will use WooComerce configured currency', 'wdk-bookings'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_bookings_disable_bookings_by_default', 
                'field_label' => __('Disable booking by default', 'wdk-bookings'), 
                'hint' => __('If disabled will be only available if user have activated package with booking enabled', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_booking_disable_for_not_login', 
                'field_label' => __('Disable booking for not login users', 'wdk-bookings'), 
                'hint' => __('Disable booking for not logged users, If you plan to use automatic booking via woocommerce, then this must be checked', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_bookings_fee_percentage', 
                'field_label' => __('Enter percentage fee (%)', 'wdk-bookings'), 
                'hint' => __('Enter percentage fee, this is how much % from sales, website owner will receive', 'wdk-bookings'), 
                'field_type' => 'NUMBER', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_bookings_confirmation_email_note', 
                'field_label' => __('Confirmation email note', 'wdk-bookings'), 
                'hint' => __('Enter text for message when resevation is confirmed, put in message {address} {title} replaced with data from message', 'wdk-bookings'), 
                'field_type' => 'TEXTAREA', 
                'rules' => '', 
            ),
            
        );

	}

    /* [START] For dynamic data table */
    
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total_lang($where = array())
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        $query = $this->db->get();
        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination_lang($limit, $offset, $where = array())
    {
        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);
        $this->db->order_by($this->_order_by);
        $query = $this->db->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id)
    {
        return true;
    }
    
    /* [END] For dynamic data table */

    
    /* only admin can edit */
    public function is_related($item_id, $user_id, $method = 'edit')
    {
        return false;
    }
}
?>