<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Reservation_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_booking_reservation';
	public $_order_by = 'idreservation DESC';
    public $_primary_key = 'idreservation';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $fields_list_visitor = NULL;
    public $fields_list_calendar_woo_enabled = NULL;

	public function __construct(){
        parent::__construct();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        $this->fields_list = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'LISTING', 
                'rules' => 'required|numeric|post_exists|reservation_calendar_availability|reservation_check_availability'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATE_FROM', 
                'rules' => 'required|reservation_date_exists|reservation_date_range|reservation_date_availability'
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATE_TO', 
                'rules' => 'required'
            ),
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'is_approved',
                'field_label' => __('Is Approved', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_paid',
                'field_label' => __('Is Paid', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_booked',
                'field_label' => __('Is Booked', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'price',
                'field_label' => __('Price', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_paid',
                'field_label' => __('Price paid', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'notes',
                'field_label' => __('Notes', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'TEXTAREA_WYSIWYG', 
                'rules' => ''
            ),
        );

        $this->fields_list_calendar = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'LISTING', 
                'rules' => 'required|numeric|post_exists|reservation_calendar_availability|reservation_check_availability'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_FROM', 
                'rules' => 'required|reservation_date_exists|reservation_date_range|reservation_date_availability'
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_TO', 
                'rules' => 'required'
            ),
            array(
                'field' => 'calendar_dates',
                'field_label' => __('Calendar', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CALENDAR_DATES_VIEW', 
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'is_approved',
                'field_label' => __('Is Approved', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_paid',
                'field_label' => __('Is Paid', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_booked',
                'field_label' => __('Is Booked', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'price',
                'field_label' => __('Price', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_paid',
                'field_label' => __('Price paid', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'notes',
                'field_label' => __('Notes', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'TEXTAREA_WYSIWYG', 
                'rules' => ''
            ),
        );
        
        $this->fields_list_visitor = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'LISTING_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_approved',
                'field_label' => __('Is Approved', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_paid',
                'field_label' => __('Is Paid', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_booked',
                'field_label' => __('Is Booked', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'price',
                'field_label' => __('Price', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'price_paid',
                'field_label' => __('Price paid', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'NUMBER_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'notes',
                'field_label' => __('Notes', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'TEXTAREA_REPLY', 
                'rules' => ''
            )
        );

        $this->fields_list_calendar_woo_enabled = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing Related', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'LISTING', 
                'rules' => 'required|numeric|post_exists|reservation_calendar_availability|reservation_check_availability'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_FROM', 
                'rules' => 'required|reservation_date_exists|reservation_date_range|reservation_date_availability'
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'DATETIME_TO', 
                'rules' => 'required'
            ),
            array(
                'field' => 'calendar_dates',
                'field_label' => __('Calendar', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CALENDAR_DATES_VIEW', 
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'USERS', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'is_approved',
                'field_label' => __('Is Approved', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_paid',
                'field_label' => __('Is Paid', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_booked',
                'field_label' => __('Is Booked', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'price',
                'field_label' => __('Price', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX_READONLY', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'price_paid',
                'field_label' => __('Price paid', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX_READONLY', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'notes',
                'field_label' => __('Notes', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'TEXTAREA_WYSIWYG', 
                'rules' => ''
            ),
        );

        if(wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
            $this->fields_list[] = array(
                                                'field' => 'woocommerce_product_id',
                                                'field_label' => __('WooCommerce Product ID', 'wdk-bookings'),
                                                'hint' => __('Auto created when reservation approved', 'wdk-bookings'),
                                                'field_type' => 'INPUTBOX_WOO', 
                                                'rules' => 'numeric|unique_and_exists_woocommerce_product_id'
                                            );
        }

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

        foreach($this->fields_list_visitor as $key=>$field)
        {
            $this->fields_list_visitor[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function total_visitor($where = array())
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        $this->db->where('user_id', get_current_user_id());
        $this->db->where($where);
        
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }
        
        $this->db->where($where);

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function get_pagination_visitor($limit, $offset, $where = array(), $order_by = NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');

        $this->db->where('user_id', get_current_user_id());
        $this->db->where($where);
        
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }

    public function get_payouts($where = array())
    {
        global $wpdb;
        $this->_table_user_name = $wpdb->users;
        $this->_table_user_name_meta = $wpdb->usermeta;
        $post_table = $this->db->prefix.'posts';
        $postmeta_table = $this->db->prefix.'postmeta';
        $reservation_table = $this->db->prefix.'wdk_booking_reservation';
        $order_itemmeta_table = $this->db->prefix.'woocommerce_order_itemmeta';
        $order_items_table = $this->db->prefix.'woocommerce_order_items';
        
        $this->db->select('
        *, 
        '.$this->db->prefix.'wdk_listings.post_id as listing_id,
        idreservation as reservation_id,
        CAST(paid_date_table.meta_value AS DATETIME) as paid_date, 
        CAST(total_paid_table.meta_value AS UNSIGNED) as total_paid, 
        CAST(tax_paid_table.meta_value AS UNSIGNED) as tax_paid,
        owner_table.user_email as owner_email,
        guest_table.user_email as guest_email');
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        $this->db->join($this->db->prefix.'wdk_listings ON '.$reservation_table.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
        $this->db->join($this->_table_user_name.' owner_table ON '.$this->db->prefix.'wdk_listings.user_id_editor  = owner_table.ID', 'left');
        $this->db->join($this->_table_user_name.' guest_table ON guest_table.ID = '.$reservation_table.'.user_id ');
        $this->db->join($order_itemmeta_table.' ON '.$reservation_table.'.idreservation  = '.$order_itemmeta_table.'.meta_value AND '.$order_itemmeta_table.'.meta_key = \'reservation_id\'', 'left');
        $this->db->join($order_items_table.' ON '.$order_itemmeta_table.'.order_item_id  = '.$order_items_table.'.order_item_id', 'left');
        $this->db->join($postmeta_table.' paid_date_table  ON paid_date_table.post_id = '.$order_items_table.'.order_id AND paid_date_table.meta_key = \'_paid_date\' ');
        $this->db->join($postmeta_table.' total_paid_table ON total_paid_table.post_id = '.$order_items_table.'.order_id AND total_paid_table.meta_key = \'_order_total\' ');
        $this->db->join($postmeta_table.' tax_paid_table   ON tax_paid_table.post_id = '.$order_items_table.'.order_id AND tax_paid_table.meta_key = \'_order_tax\' ');

        //$this->db->group_by('user_email');

        $this->db->where($where);

        
        $query = $this->get();

        //echo $this->db->last_query();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }

    public function get_payouts_total($where = array())
    {
        global $wpdb;
        $this->_table_user_name = $wpdb->users;
        $this->_table_user_name_meta = $wpdb->usermeta;
        $post_table = $this->db->prefix.'posts';
        $postmeta_table = $this->db->prefix.'postmeta';
        $reservation_table = $this->db->prefix.'wdk_booking_reservation';
        $order_itemmeta_table = $this->db->prefix.'woocommerce_order_itemmeta';
        $order_items_table = $this->db->prefix.'woocommerce_order_items';

        $this->db->select('
        COUNT(DISTINCT(user_email)) as user_count, CAST(paid_date_table.meta_value AS DATETIME) as paid_date, 
        SUM(CAST(total_paid_table.meta_value AS UNSIGNED)) as total_paid, 
        SUM(CAST(tax_paid_table.meta_value AS UNSIGNED)) as tax_paid, currency_code');
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        $this->db->join($this->db->prefix.'wdk_listings ON '.$reservation_table.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
        $this->db->join($this->_table_user_name.' ON '.$this->db->prefix.'wdk_listings.user_id_editor  = '.$this->_table_user_name.'.ID', 'left');
        $this->db->join($order_itemmeta_table.' ON '.$reservation_table.'.idreservation  = '.$order_itemmeta_table.'.meta_value AND '.$order_itemmeta_table.'.meta_key = \'reservation_id\'', 'left');
        $this->db->join($order_items_table.' ON '.$order_itemmeta_table.'.order_item_id  = '.$order_items_table.'.order_item_id', 'left');
        $this->db->join($postmeta_table.' paid_date_table  ON paid_date_table.post_id = '.$order_items_table.'.order_id AND paid_date_table.meta_key = \'_paid_date\' ');
        $this->db->join($postmeta_table.' total_paid_table ON total_paid_table.post_id = '.$order_items_table.'.order_id AND total_paid_table.meta_key = \'_order_total\' ');
        $this->db->join($postmeta_table.' tax_paid_table   ON tax_paid_table.post_id = '.$order_items_table.'.order_id AND tax_paid_table.meta_key = \'_order_tax\' ');
        $this->db->where($where);
        
        $query = $this->get();

        //echo $this->db->last_query();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
            
        $row = $this->get($id, TRUE);
        if(!$row) return false;

        if(empty($user_id))
            $user_id = get_current_user_id();

        if(wdk_show_data('user_id', $row, '', TRUE, TRUE) == $user_id)
            return true;

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
        if(wmvc_show_data('user_id_editor', $listing) == $user_id)
            return true;
        
        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }
        
    public function calculate_price($post_id, $date_from, $date_to)
    {
        
  
        //$date_from='2024-08-28';
        //$date_to='2024-08-29';
        
        $hours = (strtotime($date_to)-strtotime($date_from)) / 3600;
        $price = 0;
        $currency_code = NULL;
        $this->load->model('price_m');
        $this->db->select('*');
        $this->db->from($this->price_m->_table_name);
        $this->db->where('post_id', $post_id);

        $this->db->where("(
                    (date_from < '$date_from' AND date_to > '$date_from') OR 
                    (date_from < '$date_to' AND date_to > '$date_to') OR
                    (date_from > '$date_from' AND date_to < '$date_to')
        )");

       // $this->db->where("date_from <='$date_from' OR date_to >= '$date_to'");
        $this->db->order_by("date_from ASC");
        $query = $this->db->get();
        
        $time_periods = array();
        
        $time_period_date_from = $date_from;
        $time_period_date_to = $date_to;

        
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();
            //dump($results);
            foreach($results as $row)
            {

                /* skip if not inlcude in price */
                if(
                    ($date_from >= $row->date_from && $date_from <= $row->date_to)
                    || ($post_id >= $row->date_from && $post_id <= $row->date_to) 
                    || ($date_from < $row->date_from && $post_id > $row->date_to)
                    ) 
                {
                } else {
   
                    continue;
                }
                
             

                $time_period_date_from = $row->date_from;
                $time_period_date_to = $row->date_to;
                
                if($date_from > $row->date_from) {
                    $time_period_date_from = $date_from;
                }
                
                if($date_to < $row->date_to) {
                    $time_period_date_to = $date_to;
                }
             
                $time_periods[] = array(
                    'hours' => ((strtotime($time_period_date_to)-strtotime($time_period_date_from)) / 3600),
                    'row' => $row,
                );
            }
        }
       
        if (count($time_periods) > 0)
        {
            foreach($time_periods as $time_period)
            {
                if($time_period['hours']<24) // By hour
                {
                    if(!empty($time_period['row']->price_hour))
                    {
                        $price+=$time_period['hours']*$time_period['row']->price_hour;
                    }
                    elseif(!empty($time_period['row']->price_day))
                    {
                        $price+=($time_period['hours']/24)*$time_period['row']->price_day;
                    }
                    elseif(!empty($time_period['row']->price_week))
                    {
                        $price+=($time_period['hours']/168)*$time_period['row']->price_week;
                    }
                    elseif(!empty($time_period['row']->price_month))
                    {
                        $price+=($time_period['hours']/720)*$time_period['row']->price_month;
                    }
                }
                elseif($time_period['hours']<24*7) // By day
                {

                    if(!empty($time_period['row']->price_day))
                    {
                        $price+=($time_period['hours']/24)*$time_period['row']->price_day;
                    }
                    elseif(!empty($time_period['row']->price_hour))
                    {
                        $price+=$time_period['hours']*$time_period['row']->price_hour;
                    }
                    elseif(!empty($time_period['row']->price_week))
                    {
                        $price+=($time_period['hours']/168)*$time_period['row']->price_week;
                    }
                    elseif(!empty($time_period['row']->price_month))
                    {
                        $price+=($time_period['hours']/720)*$time_period['row']->price_month;
                    }
                }
                elseif($time_period['hours']<24*7*30) // By week
                {
                    if(!empty($time_period['row']->price_week))
                    {
                        $price+=($time_period['hours']/168)*$time_period['row']->price_week;
                    }
                    elseif(!empty($time_period['row']->price_day))
                    {
                        $price+=($time_period['hours']/24)*$time_period['row']->price_day;
                    }
                    elseif(!empty($time_period['row']->price_hour))
                    {
                        $price+=$time_period['hours']*$time_period['row']->price_hour;
                    }
                    elseif(!empty($time_period['row']->price_month))
                    {
                        $price+=($time_period['hours']/720)*$time_period['row']->price_month;
                    }
                }
                else // By month
                {
                    if(!empty($time_period['row']->price_month))
                    {
                        $price+=($time_period['hours']/720)*$time_period['row']->price_month;
                    }
                    elseif(!empty($time_period['row']->price_week))
                    {
                        $price+=($time_period['hours']/168)*$time_period['row']->price_week;
                    }
                    elseif(!empty($time_period['row']->price_day))
                    {
                        $price+=($time_period['hours']/24)*$time_period['row']->price_day;
                    }
                    elseif(!empty($time_period['row']->price_hour))
                    {
                        $price+=$time_period['hours']*$time_period['row']->price_hour;
                    }
                }

                $currency_code = $row->currency_code;
            }
        } else {
            return NULL;
        }

        return array('price'=>round($price,2), 'currency_code'=>$currency_code);
    }

    public function get_reservation_dates($post_id, $current_reservation_id = NULL, $current_reservation_key = 'booked')
    {
        $dates_available = array();
        
        $this->load->model('price_m');
        $this->db->select('*');
        $this->db->from($this->price_m->_table_name);
        $this->db->where('post_id', $post_id);
        $this->db->where("date_to >'".date('Y-m-01 00:00:00')."'");
        $query = $this->db->get();
        
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();

            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));
                foreach ($period as $date) {
                    $dates_available[$date->format("Y-m-d")] = 'available';
                }
            }
        }
        

        $this->db->select('*');
        $this->db->from($this->_table_name);

        $this->db->where('post_id', $post_id);
        $this->db->where("date_from >'".date('Y-m-01 00:00:00', strtotime('-2 month'))."'");

        if(!empty($current_reservation_id)) {
            $this->db->where(array(
                '((is_approved = 1 AND idreservation != '.intval($current_reservation_id).') OR (idreservation = '.intval($current_reservation_id).'))'=>NULL,
            ));
        } else {
            $this->db->where('is_approved', 1);
        }


        $query = $this->db->get();
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();
            
            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));
                $period_end = $period->end->format("Y-m-d");
                $first_period = true;
                foreach ($period as $date) {
                    $current_date = $date->format("Y-m-d");
                    $class_start = 'reservation_start';
                    $class_end = 'reservation_end';
                    if(!isset($dates_available[$current_date])) {
                        $dates_available[$current_date] = '';
                    
                    }
                    
                    $dates_available[$current_date] = str_replace('available','', $dates_available[$current_date]);

                    if($first_period) {
                        if(strpos($dates_available[$current_date], $current_reservation_key) !== FALSE && strpos($dates_available[$current_date], 'reservation_end') !== FALSE) {
                            $dates_available[$current_date] .= ' book_book_current';
                        }elseif(strpos($dates_available[$current_date], 'booked') !== FALSE && strpos($dates_available[$current_date], 'reservation_end') !== FALSE) {
                            $dates_available[$current_date] .= ' book_current_bookd';
                        } else {
                            $dates_available[$current_date] .= ' '.$class_start;
                        }

                        $dates_available[$current_date] .= ' '.$class_start;
                        $first_period = false;
                    }

                    if(!empty($current_reservation_id) && $row->idreservation == $current_reservation_id) {
                        $dates_available[$current_date] .= ' '.$current_reservation_key;
                    } else {
                        $dates_available[$current_date] .= ' booked';
                    }
                }

                if($period_end) {
                    if(!isset($dates_available[$period_end])) {
                        $dates_available[$period_end] = '';
                    }
                    
                    if(strpos($dates_available[$period_end], $current_reservation_key) !== FALSE) {
                        $dates_available[$period_end] .= ' book_current_bookd';
                    } elseif(strpos($dates_available[$period_end], 'booked') !== FALSE && $row->idreservation == $current_reservation_id) {
                        $dates_available[$period_end] .= ' book_book_current';
                    } else {
                        if(!empty($current_reservation_id) && $row->idreservation == $current_reservation_id) {
                            $dates_available[$period_end] .= ' '.$current_reservation_key.' '.$class_end;
                        } else {
                            $dates_available[$period_end] .= ' booked '.$class_end;
                        }
                    }
                }
            }

        }
        return $dates_available;
    }

    public function get_reservationprices_dates($post_id, $current_reservation_id = NULL, $current_reservation_key = 'booked')
    {

        $reservations = array();
        $prices = array();

        $dates_available = array();
        
        $this->load->model('price_m');
        $this->db->select('*');
        $this->db->from($this->price_m->_table_name);
        $this->db->where('post_id', $post_id);
        $this->db->where("date_to >'".date('Y-m-01 00:00:00')."'");
        $query = $this->db->get();
        
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();

            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));
                foreach ($period as $date) {
                    $prices[$date->format("Y-m-d")] = true;
                }
            }
        }

        $this->db->select('*');
        $this->db->from($this->_table_name);

        $this->db->where('post_id', $post_id);
        $this->db->where("date_from >'".date('Y-m-01 00:00:00', strtotime('-2 month'))."'");

        if(!empty($current_reservation_id)) {
            $this->db->where(array(
                '((is_approved = 1 AND idreservation != '.intval($current_reservation_id).') OR (idreservation = '.intval($current_reservation_id).'))'=>NULL,
            ));
        } else {
            $this->db->where('is_approved', 1);
        }


        $query = $this->db->get();
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();

            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));
                $period_end = $period->end->format("Y-m-d");

                foreach ($period as $date) {
                    $current_date = $date->format("Y-m-d");
                    $reservations[$current_date] = true;
                }
                $reservations[$period_end] = true;

            }

        }

        return array(
            'prices'=> $prices,
            'reservations'=> $reservations,
        );
    }

    
    public function get_enabled_dates($post_id)
    {
        $dates_available = array();
        
        $this->load->model('price_m');
        $this->db->select('*');
        $this->db->from($this->price_m->_table_name);
        $this->db->where('post_id', $post_id);
        $this->db->where("date_to >'".date('Y-m-01 00:00:00')."'");
        $query = $this->db->get();
        
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();

            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));
                foreach ($period as $date) {
                    $dates_available[$date->format("Y-m-d")] = '\''.$date->format("Y-m-d").'\'';
                }
            }
        }

        $this->db->select('*');
        $this->db->from($this->_table_name);

        $this->db->where('post_id', $post_id);
        $this->db->where("date_from >'".date('Y-m-01 00:00:00')."'");
        //$this->db->where('is_approved', 1);
        $this->db->where('is_approved', 1);

        $query = $this->db->get();
        if ($this->db->num_rows() > 0)
        {
            $results = $this->db->results();
            
            foreach($results as $row)
            {
                $period = new DatePeriod(new DateTime($row->date_from), new DateInterval('P1D'), new DateTime($row->date_to));

                foreach ($period as $date) {
                    unset($dates_available[$date->format("Y-m-d")]);
                }
            }

        }

        return $dates_available;
    }

    public function is_booked($post_id, $date_from, $date_to, $except_id = NULL)
    {
        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->where('post_id', $post_id);
        //$this->db->where('is_approved', '1');
        $this->db->where('is_approved', '1');
        
        if(!empty($except_id))
        {
            $this->db->where('idreservation !=', $except_id);
        }
        
        // Check dates availability
        $this->db->where('date_from <', $date_to);
        $this->db->where('date_to >', $date_from);
        
        $query = $this->db->get();

        if ($this->db->num_rows() > 0)
        {
            return TRUE;
        }

        return FALSE;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $row = $this->get($item_id, TRUE);
        if($method == 'dash_edit_reservation') {
            global $Winter_MVC_WDK;
            $Winter_MVC_WDK->model('listing_m');
            $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
            if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
                return true;

        } else if($method =='dash_edit_myreservation') {
            if(wdk_show_data('user_id', $row, '', TRUE, TRUE) == get_current_user_id())
                return true;

        } else {
            if(wdk_show_data('user_id', $row, '', TRUE, TRUE) == get_current_user_id())
            return true;

            if($method == 'edit' && isset($_POST['post_id'])) {
                if(isset($_POST['post_id'])) {
                    $post_id = intval($_POST['post_id']);
                } else {
                    return false;
                }
            } else {
                $post_id = $row->post_id;
            }
        
            global $Winter_MVC_WDK;
            $Winter_MVC_WDK->model('listing_m');
            $listing = $Winter_MVC_WDK->listing_m->get($post_id, TRUE);
            if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
                return true;

        }

        return false;
    }

    public function is_owner($item_id, $user_id = NULL)
    {	 
        $row = $this->get($item_id, TRUE);
        
        if(empty($user_id))
            $user_id = get_current_user_id();

        if(wdk_show_data('user_id', $row, '', TRUE, TRUE) == $user_id)
            return true;
            
        return false;
    }

    public function delete_where($where)
    {
        $this->db->where($where);
        $this->db->delete($this->_table_name);
    }

}
?>