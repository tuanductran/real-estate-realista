<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Calendar_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_booking_calendar';
	public $_order_by = 'idcalendar DESC';
    public $_primary_key = 'idcalendar';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
    public $calculation_base = array();
    
	public function __construct(){
        parent::__construct();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        $this->calculation_base = array(
                    'per_stay' =>  esc_html__('Per Stay', 'wdk-bookings'),
                    'per_person' =>  esc_html__('Per Person', 'wdk-bookings'),
                    'per_night' =>  esc_html__('Per Night', 'wdk-bookings'),
        );

        $this->fields_list = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'LISTING', 
                'rules' => 'required|numeric|post_exists|unique_post_id_calendar'
            ),
            array(
                'field' => 'is_hour_enabled',
                'field_label' => __('Is Hour Enabled', 'wdk-bookings'),
                'hint' => __('Visitor will be able to reserve only few hours, and not just days', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_disable_for_not_login',
                'field_label' => __('Only For Login Users', 'wdk-bookings'),
                'hint' => __('Disable booking for not logged users', 'wdk-bookings'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_enable_public_url',
                'field_label' => __('Enable public export url', 'wdk-bookings'),
                'hint' => __('Please enable and save for generate public link', 'wdk-bookings'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_enable_noapprovements',
                'field_label' => __('No approvements needed', 'wdk-bookings'),
                'hint' => __('By checking, guest reservation will be auto approved, this feature is usualy used when owner renting listing only on our portal', 'wdk-bookings'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_guests_disabled',
                'field_label' => __('Disable guests number', 'wdk-bookings'),
                'hint' => __('Hide guests number in booking form and table', 'wdk-bookings'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            /*array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),*/
            array(
                'field' => 'guests',
                'field_label' => __('Max guests', 'wdk-bookings'),
                'hint' => __('How many guests listing can accept', 'wdk-bookings'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'is_children_acceptable',
                'field_label' => __('Is Children Acceptable', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_pets_acceptable',
                'field_label' => __('Is Pets Acceptable', 'wdk-bookings'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        
        if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
            $this->fields_list [] = array(
                'field' => 'payment_info',
                'field_label' => __('Wire Transfer Payment info', 'wdk-bookings'),
                'hint' => '',
                'field_type' => 'TEXTAREA', 
                'rules' => 'required'
            );
        }

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = FALSE, $user_id=NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*, '.$this->_table_name.'.is_activated AS calendar_is_activated');
        $this->db->from($this->_table_name);
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID');
        
        if( (!wmvc_user_in_role('administrator') && $user_check) || (!is_null($user_id) && !empty($user_id) ) )
        {
            $this->db->join($this->db->prefix.'wdk_listings ON '.$this->_table_name.'.post_id = '.$this->db->prefix.'wdk_listings.post_id', 'left');
            
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', $user_id);
            }
            else
            {
                $this->db->where($this->db->prefix.'wdk_listings`.`user_id_editor', get_current_user_id());
            }
        } else {
            $this->db->where($where);
        }

        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        
        if(wmvc_user_in_role('administrator')) return true;

        $row = $this->get($id, TRUE);
        if(!$row) return false;

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
        if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
            return true;

        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        
        $this->load->model('price_m');
        $this->load->model('reservation_m');

        /* remove listing */
        parent::delete($id);

        $this->price_m->delete_where(array('calendar_id'=>$id));
        $this->reservation_m->delete_where(array('calendar_id'=>$id));

        return true;
    }

    
    public function is_related($item_id, $user_id, $method = 'edit')
    {	 

        $row = $this->get($item_id, TRUE);
        if(!$row) return false;

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $listing = $Winter_MVC_WDK->listing_m->get($row->post_id, TRUE);
        if(wmvc_show_data('user_id_editor', $listing) == get_current_user_id())
            return true;

        return false;
    }
    
    public function is_hours_enable($post_id)
    {	 
        $this->db->select('idcalendar');
        $this->db->from($this->_table_name);
        $this->db->where('post_id', $post_id);
        $this->db->where('is_hour_enabled', 1);
     
        $query = $this->get();

        if ($this->db->num_rows() > 0)
           return true;

        return false;
    }

}
?>