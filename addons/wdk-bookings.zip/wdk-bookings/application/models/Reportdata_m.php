<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Reportdata_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_booking_reportdata';
	public $_order_by = 'idreportdata DESC';
    public $_primary_key = 'idreportdata';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $fields_list_visitor = NULL;
    
	public function __construct(){
        parent::__construct();
	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $group_by = NULL)
    {
        $post_table = $this->db->prefix.'posts';
        $report_table = $this->db->prefix.'wdk_booking_report';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->join($report_table.' ON '.$report_table.'.idreport = '.$this->_table_name.'.report_id');

        $this->db->where($where);
        if(!empty($group_by))
            $this->db->group_by($group_by);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $group_by = NULL)
    {
        $post_table = $this->db->prefix.'posts';
        $report_table = $this->db->prefix.'wdk_booking_report';

        $this->db->select($this->_table_name.'.*, '.$report_table.'.fee_percentage, '.$report_table.'.year, '.$report_table.'.month'.(empty($group_by)?'':', SUM('.$this->_table_name.'.total_price_net) as total_price_net_sum'));
        $this->db->from($this->_table_name);
        $this->db->join($report_table.' ON '.$report_table.'.idreport = '.$this->_table_name.'.report_id');
        
        $this->db->where($where);

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($group_by))
            $this->db->group_by($group_by);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();

        //echo ($this->db->last_query());
        
        return array();
    }

    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
        
        return false;
    }

    public function update($data = array(), $where = array())
    {
        $this->db->update($this->_table_name, $data, $where);
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function delete_by_report ($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        $this->db->where('report_id', $id);
        $this->db->delete($this->_table_name);

        return true;
    }

}
?>