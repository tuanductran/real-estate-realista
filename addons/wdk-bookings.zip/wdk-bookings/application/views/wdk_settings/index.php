<?php
/**
 * The template for Settings.
 *
 * This is the template that settings edit page
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('WDK Bookings Settings', 'wdk-bookings'); ?></h1>
    <br /><br />
    <div class="wdk-body">
    <div class="row fields_list">
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('General Settings', 'wdk-bookings'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-bookings'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>   

                    <div class="wdk-field-edit">
                        <a target="_blank" href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'wdk_bookings_disable_reservations_sync_cron=1')); ?>" class="button button-primary"><?php echo esc_html__('Run cronjob for disable reservation sync manually', 'wdk-bookings'); ?></a> 
                    </div>
                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', 'wdk-bookings'); ?>">
        </form>
    </div>
</div>

<?php //$this->view('general/footer', $data); ?>