<?php
/**
 * The template for Calendars Management.
 *
 * This is the template that form edit
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline">
      <?php echo esc_html__('Calendars Management', 'wdk-bookings'); ?>
      
      <a class="button " href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-calendar&function=import_icl_calendar&id=" . wmvc_show_data('idcalendar', $db_data, '-'); ?>">
        <?php echo esc_html__('iCal import calendar', 'wdk-bookings'); ?>
      </a>
      <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-calendar&function=export_icl_calendar&calendar_id=" . wmvc_show_data('idcalendar', $db_data, '-'); ?>"
        class="button">
        <?php echo esc_html__('iCal export calendar', 'wdk-bookings'); ?>
    </a>
    </h1>
    <br /><br />
    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Add/Edit Calendar', 'wdk-bookings'); ?></h3>
                <?php if(wmvc_show_data('post_id', $db_data, false)):?>
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk_listing&id=".esc_attr(wmvc_show_data('post_id', $db_data)); ?>" 
                            class="wdk-mr-5 button button-secondary alignright"
                    >
                        <span class="dashicons dashicons-edit" style="margin-top: 4px;"></span> <?php echo __('Edit Listing','wpdirectorykit')?>
                    </a>
                <?php endif;?>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php
                      $success_message = __('Successfully saved', 'wdk-bookings');

                      if(function_exists('run_wdk_bookings')) {
                        /* if booking addon exists, show custom message with link to edit calendar */
                        $success_message = esc_html__('Successfully saved','wdk-membership').'. <a target="_blank" href="'. wdk_dash_url("dash_page=booking-prices&function=edit&post_id=".wmvc_show_data('post_id', $db_data)).'">'.esc_html__('Set availability prices', 'wdk-membership').'</a>';
                    }
                    
                      
                      $form->messages('class="alert alert-danger"', $success_message);
                    ?>
                    

                    <?php echo wdk_generate_fields($fields, $db_data); ?>
                    <?php if(wmvc_show_data('is_enable_public_url',$db_data, false)):?>
                    <div class="wdk-field-edit CHECKBOX wdk-col- ">
                        <label for="is_disable_for_not_login"><?php echo esc_html__('Public Export Url', 'wdk-bookings'); ?></label>
                        <div class="wdk-field-container">
                            <?php
                                $public_link = wdk_url_suffix(home_url(),'wdk_booking_public_calendar='.md5(wmvc_show_data('idcalendar',$db_data).NONCE_KEY.'wdk-booking'));
                            ?>
                            <a href="<?php echo esc_url($public_link);?>" target="_blank">
                                <?php echo esc_url($public_link);?>
                            </a>
                           
                        </div>
                    </div>
                    <?php endif;?>
                    <?php if(true):?>
                        <div class="wdk-field-edit hidden">
                            <label for="star_icon_half_active"><?php echo esc_html__('json_data_fees','wdk-bookings'); ?></label>
                            <div class="wdk-field-container">
                                <textarea readonly="readonly" name="json_data_fees" type="text" id="json_data_fees" class="regular-text"><?php echo esc_textarea(wmvc_show_data('json_data_fees', $db_data, '')); ?></textarea>
                            </div>
                        </div>
                    <?php endif;?>
                    <input type="submit" name="submit" id="submit" class="button button-primary"
                        value="<?php echo esc_html__('Save Changes', 'wdk-bookings'); ?>">

                </form>
            </div>
        </div>
    </div>
    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Additional Fees','wdk-bookings'); ?></h3>
            </div>
            <div class="inside">
                <p class="alert alert-success"><?php echo esc_html__('This fees are used on booking form, like for end cleaning and similar scenarios','wdk-bookings'); ?></p>
                <table class="wp-list-table widefat fixed striped table-view-list pages wdk-table-options">
                    <thead>
                        <tr>
                            <th><?php echo esc_html__('Fee Title', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Price', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Hint', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Calculation base', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('is Required', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('is Activated', 'wdk-bookings'); ?></th>
                            <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="pattern hidden">
                            <td>
                                <input class="" name="title" type="text" value="" placeholder="<?php echo esc_html__('Fee Title', 'wdk-bookings'); ?>">
                            </td>
                            <td>
                                <input class="" name="value" type="number" value="" placeholder="<?php echo esc_html__('Price', 'wdk-bookings'); ?>">
                            </td>
                            <td>
                                <input class="" name="hint" type="text" value="" placeholder="<?php echo esc_html__('Hint', 'wdk-bookings'); ?>">
                            </td>
                            <td>
                                <select name="calculation_base" id="">
                                    <option value=""><?php echo esc_html__('Calculation base', 'wdk-bookings'); ?></option>
                                    <?php  foreach ($this->calendar_m->calculation_base as $key => $value) :?>
                                        <option value="<?php echo esc_attr($key);?>"><?php echo esc_attr($value);?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <label>
                                    <input name="is_required" type="checkbox" value="1">
                                    <?php echo esc_html__('is Required', 'wdk-bookings'); ?>
                                </label>
                            </td>
                            <td>
                                <label>
                                    <input name="is_activated" type="checkbox" value="1">
                                    <?php echo esc_html__('is activated', 'wdk-bookings'); ?>
                                </label>
                            </td>
                            <td class="actions_column">
                                <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                                <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                            </td>
                        </tr>
                        <tr class="skip">
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="actions_column">
                                <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                            </td>
                        </tr>
                        <?php foreach ($calendar_fees as $fee) :?>
                            <tr>
                                <td>
                                    <input class="" name="title" type="text" value="<?php echo wmvc_show_data('title', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Fee Title', 'wdk-bookings'); ?>">
                                </td>
                                <td>
                                    <input class="" name="value" type="number" value="<?php echo wmvc_show_data('value', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Price', 'wdk-bookings'); ?>">
                                </td>
                                <td>
                                    <input class="" name="hint" type="text" value="<?php echo wmvc_show_data('hint', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Hint', 'wdk-bookings'); ?>">
                                </td>
                                <td>
                                    <select name="calculation_base" id="">
                                        <option value=""><?php echo esc_html__('Calculation base', 'wdk-bookings'); ?></option>
                                        <?php  foreach ($this->calendar_m->calculation_base as $key => $value) :?>
                                            <option value="<?php echo esc_attr($key);?>" <?php if(wmvc_show_data('calculation_base', $fee, '-') == $key): ?> selected="selected" <?php endif;?>><?php echo esc_attr($value);?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <label>
                                        <input name="is_required" type="checkbox" value="1" <?php echo !empty(wdk_show_data('is_required', $fee, false, TRUE, TRUE))?'checked':''; ?>>
                                        <?php echo esc_html__('is required', 'wdk-bookings'); ?>
                                    </label>
                                </td>
                                <td>
                                    <label>
                                        <input name="is_activated" type="checkbox" value="1" <?php echo !empty(wdk_show_data('is_activated', $fee, false, TRUE, TRUE))?'checked':''; ?>>
                                        <?php echo esc_html__('is activated', 'wdk-bookings'); ?>
                                    </label>
                                </td>
                                <td class="actions_column">
                                    <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                                    <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>    
                </table>
            </div>
        </div>
    </div>
</div>

<?php
wp_enqueue_style('wdk-modal');
wp_enqueue_script('wdk-modal');
?>

<script>
var wdk_timerOut;
jQuery(document).ready(function($) {

    const wdk_bookings_calendar_add_option = (this_form) => {
        var json_gen = '';
        $('table.wdk-table-options tr:not(.pattern):not(.skip)').each(function(index, tr) { 
            if(index==0) {$
                ('#json_data_fees').val('');
                return;
            }
            json_gen += '{';
            $(this).find('input,select').each(function(){
                var el_name = $(this).attr('name');
                if(el_name)
                {
                    json_gen += '"'+el_name+'"';
                    if($(this).attr('type') == 'checkbox') {
                        if($(this).prop('checked')){
                            json_gen += ': "'+1+'" ';
                        } else {
                            json_gen += ': "'+0+'" ';
                        }
                    } else if($(this).is('select')) {
                        json_gen += ': "'+$(this).find( "option:selected" ).val()+'" ';
                    } 
                    else {
                        json_gen += ': "'+$(this).val()+'" ';
                    }
                    json_gen += ', ';
                }
            });
            json_gen = json_gen.substr(0, json_gen.length-2);
            json_gen += '}, ';
        });

        if(json_gen.length > 0)
            json_gen = json_gen.substr(0, json_gen.length-2);

        if(json_gen.length > 0)
                $('#json_data_fees').val('[ ' + json_gen + ' ]');
    };
    
    const wdk_bookings_calendar_remove_option = (row) => {
        row.remove();
        wdk_bookings_calendar_add_option();
    };

    const wdk_bookings_calendar_actions = () => {
        $('.wdk-table-options').find('input').off().on('input', function(){
            //clearTimeout(wdk_timerOut);
            var tr = $(this).closest('tr');
            wdk_timerOut = setTimeout(function () {
                wdk_bookings_calendar_add_option(tr);
            }, 1000);
        });

        $('button.add_btn').off().on('click', function()
        {
            var table = $(this).closest('table');
            var clone = table.find('.pattern').clone();
            clone.removeClass('hidden pattern');
            table.find('tbody').append(clone);

            wdk_bookings_calendar_add_option(clone);
            wdk_bookings_calendar_actions();
        });

        $('button.remove_btn').off().on('click', function()
        {
            wdk_bookings_calendar_remove_option($(this).closest('tr'));
            wdk_bookings_calendar_actions();
        });

    };

    wdk_bookings_calendar_actions();
});
</script>

<?php $this->view('general/footer', $data); ?>