<?php
/**
 * The template for Import icl.
 *
 * This is the template that form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Reservation Import Management', 'wdk-bookings'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Import Reservations', 'wdk-bookings'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-bookings'));
                    ?>

                    <?php echo wdk_generate_fields($fields, $db_data); ?>

                    <input type="submit" name="submit" id="submit" class="button button-primary"
                        value="<?php echo esc_html__('Import', 'wdk-bookings'); ?>">
                </form>
            </div>
        </div>
    </div>
</div>



<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>

<script>
	(function( $ ) {
		'use strict';
        $('[name="enable_auto_import"], [name="import_public_url"], [name="import_availability_to_date"], [name="is_import_remove_old_dates"]').on('input', function(e){
            let ajax_url = '<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>';

            var data = [];
            data.push({ name: 'action', value: "wdk_bookings_public_action" });
            data.push({ name: 'page', value: "wdk_bookings_frontendajax" });
            data.push({ name: 'function', value: "autoimportdatacalendar" });
            data.push({ name: 'idcalendar', value: "<?php echo esc_js(intval($_GET['id']));?>" });
            data.push({ name: 'import_public_url', value: $('[name="import_public_url"]').val() });
            data.push({ name: 'enable_auto_import', value: $('[name="enable_auto_import"]').prop('checked')});
            data.push({ name: 'import_availability_to_date', value: $('[name="import_availability_to_date"]').val()});
            data.push({ name: 'is_import_remove_old_dates', value: $('[name="is_import_remove_old_dates"]').prop('checked')});
            
            jQuery.post(ajax_url, data, 
                function(data){
                    
                    if(data.popup_text_success)
                        wdk_log_notify(data.popup_text_success);
                        
                    if(data.popup_text_error)
                        wdk_log_notify(data.popup_text_error, 'error');
                        
                    if(data.success == true)
                    {
                    } else {
                    }
            }).always(function(){
            });
            return false;
        })
	})( jQuery );
</script>

<?php $this->view('general/footer', $data); ?>