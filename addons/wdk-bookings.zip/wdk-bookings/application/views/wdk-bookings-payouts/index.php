<?php
/**
 * The template for Calendar Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Payout Reports Management', 'wdk-bookings'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=report"; ?>" class="button button-primary" id="add_report_button"><?php echo esc_html__('Generate report', 'wdk-bookings'); ?></a></h1>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-bookings-payouts" />

                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-bookings'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-bookings'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-bookings'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-bookings')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-bookings'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-bookings'); ?></label><input id="cb-select-all-1" type="checkbox"></td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total net income', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total payout', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Fee percentage', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Users', 'wdk-bookings'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($payouts) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="8"><?php echo esc_html__('No Payouts reports found.', 'wdk-bookings'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($payouts as $report) : ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input id="cb-select-<?php echo wmvc_show_data('idreport', $report, '-'); ?>" type="checkbox" name="post[]" value="<?php echo wmvc_show_data('idreport', $report, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-bookings'); ?></span>
                            </div>
                        </th>
                        <td>
                            <?php echo wmvc_show_data('idreport', $report, '-'); ?>
                        </td>
                        <td>
                        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=view_report&id=" . wmvc_show_data('idreport', $report, '-'); ?>"><?php echo wmvc_show_data('year', $report, '-'); ?>-<?php echo wmvc_show_data('month', $report, '-'); ?></a>
                        </td>
                        <td>
                            <span class="label label-success"> <?php echo wmvc_show_data('total_price_net', $report, '-'); ?> <?php echo wmvc_show_data('currency_code', $report, '-'); ?></span>
                        </td>
                        <td>
                            <span class="label label-success"> <?php echo esc_html((100-$report->fee_percentage)/100*$report->total_price_net); ?> <?php echo wmvc_show_data('currency_code', $report, '-'); ?></span>
                        </td>
                        <td>
                            <?php echo esc_html($report->fee_percentage); ?>%
                        </td>
                        <td>
                            <?php echo wmvc_show_data('users', $report, '-'); ?>
                        </td>
                        <td class="actions_column">
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=view_report&id=" . wmvc_show_data('idreport', $report, '-'); ?>"><span class="dashicons dashicons-search"></span></a>
                            <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-bookings');?>"  href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idreport', $report, '-'); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <td class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2"><?php echo esc_html__('Select All', 'wdk-bookings'); ?></label><input id="cb-select-all-2" type="checkbox"></td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total net income', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total payout', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Fee percentage', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Users', 'wdk-bookings'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <div class="alignleft actions bulkactions">
                <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-bookings'); ?></label>
                <select name="action" id="bulk-action-selector-bottom">
                    <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-bookings'); ?></option>
                    <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-bookings'); ?></option>
                </select>
                <input type="hidden" name="page" value="wdk-bookings-payouts" />
                <input type="submit" id="table_action" class="button action" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-bookings'); ?>">
            </div>

            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be deactivated!', 'wdk-bookings')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>