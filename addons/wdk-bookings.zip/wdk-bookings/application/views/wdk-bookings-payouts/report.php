<?php
/**
 * The template for Calendars Management.
 *
 * This is the template that form edit
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline">
      <?php echo esc_html__('Payout Reports Management', 'wdk-bookings'); ?>
    </h1>
    <br /><br />
    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Generate report', 'wdk-bookings'); ?></h3>
                <?php if(wmvc_show_data('post_id', $db_data, false)):?>
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk_listing&id=".esc_attr(wmvc_show_data('post_id', $db_data)); ?>" 
                            class="wdk-mr-5 button button-secondary alignright"
                    >
                        <span class="dashicons dashicons-edit" style="margin-top: 4px;"></span> <?php echo __('Edit Listing','wpdirectorykit')?>
                    </a>
                <?php endif;?>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php
                      $form->messages('class="alert alert-danger"',  __('Report generated, check on Payouts page', 'wdk-bookings'));
                    ?>

                    <?php echo wdk_generate_fields($fields, $db_data); ?>

                    <input type="submit" name="submit" id="submit" class="button button-primary"
                        value="<?php echo esc_html__('Generate report', 'wdk-bookings'); ?>">

                </form>
            </div>
        </div>
    </div>
</div>

<?php
wp_enqueue_style('wdk-modal');
wp_enqueue_script('wdk-modal');
?>

<script>
var wdk_timerOut;
jQuery(document).ready(function($) {

    const wdk_bookings_calendar_add_option = (this_form) => {
        var json_gen = '';
        $('table.wdk-table-options tr:not(.pattern):not(.skip)').each(function(index, tr) { 
            if(index==0) {$
                ('#json_data_fees').val('');
                return;
            }
            json_gen += '{';
            $(this).find('input,select').each(function(){
                var el_name = $(this).attr('name');
                if(el_name)
                {
                    json_gen += '"'+el_name+'"';
                    if($(this).attr('type') == 'checkbox') {
                        if($(this).prop('checked')){
                            json_gen += ': "'+1+'" ';
                        } else {
                            json_gen += ': "'+0+'" ';
                        }
                    } else if($(this).is('select')) {
                        json_gen += ': "'+$(this).find( "option:selected" ).val()+'" ';
                    } 
                    else {
                        json_gen += ': "'+$(this).val()+'" ';
                    }
                    json_gen += ', ';
                }
            });
            json_gen = json_gen.substr(0, json_gen.length-2);
            json_gen += '}, ';
        });

        if(json_gen.length > 0)
            json_gen = json_gen.substr(0, json_gen.length-2);

        if(json_gen.length > 0)
                $('#json_data_fees').val('[ ' + json_gen + ' ]');
    };
    
    const wdk_bookings_calendar_remove_option = (row) => {
        row.remove();
        wdk_bookings_calendar_add_option();
    };

    const wdk_bookings_calendar_actions = () => {
        $('.wdk-table-options').find('input').off().on('input', function(){
            //clearTimeout(wdk_timerOut);
            var tr = $(this).closest('tr');
            wdk_timerOut = setTimeout(function () {
                wdk_bookings_calendar_add_option(tr);
            }, 1000);
        });

        $('button.add_btn').off().on('click', function()
        {
            var table = $(this).closest('table');
            var clone = table.find('.pattern').clone();
            clone.removeClass('hidden pattern');
            table.find('tbody').append(clone);

            wdk_bookings_calendar_add_option(clone);
            wdk_bookings_calendar_actions();
        });

        $('button.remove_btn').off().on('click', function()
        {
            wdk_bookings_calendar_remove_option($(this).closest('tr'));
            wdk_bookings_calendar_actions();
        });

    };

    wdk_bookings_calendar_actions();
});
</script>

<?php $this->view('general/footer', $data); ?>