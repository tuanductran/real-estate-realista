<?php
/**
 * The template for Calendar Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Report payout info', 'wdk-bookings'); ?>
        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=view_report_export&id=" . $report_id; ?>" 
        class="button button-primary" id="export_report_button" title="<?php echo esc_attr__('Export in CSV', 'wdk-bookings');?>" ><?php echo esc_html__('Export in CSV', 'wdk-bookings'); ?></a>
    </h1>

        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('User', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total net income', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total payout', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Fee percentage', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('IBAN', 'wdk-bookings'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($payouts) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="8"><?php echo esc_html__('No report payouts found.', 'wdk-bookings'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($payouts as $report) : ?>
                    <tr>
                        <td>
                            <?php echo wmvc_show_data('idreportdata', $report, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('year', $report, '-'); ?>-<?php echo wmvc_show_data('month', $report, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('owner_email', $report, '-'); ?>
                        </td>
                        <td>
                            <span class="label label-success"> <?php echo wmvc_show_data('total_price_net_sum', $report, '-'); ?> <?php echo wmvc_show_data('currency_code', $report, '-'); ?></span>
                        </td>
                        <td>
                            <span class="label label-success"> <?php echo esc_html((100-$report->fee_percentage)/100*$report->total_price_net_sum); ?> <?php echo wmvc_show_data('currency_code', $report, '-'); ?></span>
                            <?php if($report->is_payout == 1): ?>
                                <span class="label label-info"><?php echo esc_html__('Paid', 'wdk-bookings'); ?></span>
                            <?php else: ?>
                                <span class="label label-danger"><?php echo esc_html__('Not paid', 'wdk-bookings'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo esc_html($report->fee_percentage); ?>%
                        </td>
                        <td>
                            <?php 
                            
                            $user = get_user_by( 'email', $report->owner_email );
                            
                            
                            echo wmvc_show_data('wdk_iban', $user , '-'); ?>
                        </td>
                        <td class="actions_column">
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=view_report_user&id=" . wmvc_show_data('report_id', $report, '-')."&owner_email=".wmvc_show_data('owner_email', $report, '-'); ?>"><span class="dashicons dashicons-search"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('User', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total net income', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Total payout', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Fee percentage', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('IBAN', 'wdk-bookings'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be deactivated!', 'wdk-bookings')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>