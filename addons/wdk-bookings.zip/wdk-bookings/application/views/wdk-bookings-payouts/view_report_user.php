<?php
/**
 * The template for Calendar Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<?php                      
    $user = get_user_by( 'email', $payouts[0]->owner_email );
    ?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Report payout info', 'wdk-bookings'); ?>
    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-bookings-payouts&function=view_report_user_export&id=" . $payouts[0]->report_id.'&owner_email='.$payouts[0]->owner_email; ?>" 
        class="button button-primary" id="export_report_button" title="<?php echo esc_attr__('Export in CSV', 'wdk-bookings');?>" ><?php echo esc_html__('Export in CSV', 'wdk-bookings'); ?></a>
    </h1>

    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <tr>
            <th><?php echo esc_html__('User email', 'wdk-bookings'); ?></th><td><a href="<?php echo admin_url('user-edit.php?user_id='.$user->ID); ?>"><?php echo $payouts[0]->owner_email; ?></a></td>
        </tr>
            <th><?php echo esc_html__('Name', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('display_name', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Address', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_address', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Country', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_country', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('City', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_city', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Company', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_company_name', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('IBAN', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_payment_instructions', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Payment Instructions', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_iban', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Payment instructions', 'wdk-bookings'); ?></th><td><?php echo wmvc_show_data('wdk_payment_instructions', $user , '-'); ?></td>
            </tr><tr>
            <th><?php echo esc_html__('Is payout', 'wdk-bookings'); ?></th><td>
                <?php if($payouts[0]->is_payout != 1): ?>
                    <a href="<?php echo admin_url('admin.php?page=wdk-bookings-payouts&function=view_report_user_paid&id='.$payouts[0]->report_id.'&owner_email='.$payouts[0]->owner_email); ?>" class="wdk-mr-5 button button-secondary">
                        <span class="dashicons dashicons-saved" style="margin-top: 4px;"></span> <?php echo __('Mark as paid','wpdirectorykit')?>
                    </a>
                <?php else: ?>
                    <span class="dashicons dashicons-saved" style="margin-top: 4px;"></span> <?php echo esc_html($payouts[0]->date_payout); ?>
                <?php endif; ?>
            </td>
            </tr><tr>
            <th><?php echo esc_html__('Total payout', 'wdk-bookings'); ?></th><td><span class="label label-success"><?php echo esc_html((100-$payouts[0]->fee_percentage)/100*$total_earnings); ?></span></td>
            </tr><tr>
            <th><?php echo esc_html__('Fee percentage', 'wdk-bookings'); ?></th><td><?php echo esc_html($payouts[0]->fee_percentage); ?>%</td>
            </tr><tr>
            <th><?php echo esc_html__('Total net income', 'wdk-bookings'); ?></th><td><?php echo esc_html($total_earnings); ?></td>
        </tr>
    </table>
    <p>

    </p>


        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('User', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Price net', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date From', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date To', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Listing', 'wdk-bookings'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($payouts) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No report payouts found.', 'wdk-bookings'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($payouts as $report) : ?>
                    <tr>
                        <td>
                            <?php echo wmvc_show_data('idreportdata', $report, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('year', $report, '-'); ?>-<?php echo wmvc_show_data('month', $report, '-'); ?>
                        </td>
                        <td>
                        <?php echo wmvc_show_data('owner_email', $report, '-'); ?>
                        </td>
                        <td>
                        <a href="<?php echo admin_url('post.php?action=edit&post='.$report->order_id); ?>"><span class="label label-success"> <?php echo wmvc_show_data('total_price_net', $report, '-'); ?> <?php echo wmvc_show_data('currency_code', $report, '-'); ?></span></a>
                        </td>
                        <td>
                            <a href="<?php echo admin_url('admin.php?page=wdk-bookings-add&id='.$report->reservation_id); ?>"><?php echo wmvc_show_data('date_from', $report, '-'); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo admin_url('admin.php?page=wdk-bookings-add&id='.$report->reservation_id); ?>"><?php echo wmvc_show_data('date_to', $report, '-'); ?></a>
                        </td>
                        <td>
                            <a href="<?php echo admin_url('admin.php?page=wdk_listing&id='.$report->listing_id); ?>"><?php echo wmvc_show_data('listing_title', $report, '-'); ?>, <?php echo wmvc_show_data('listing_address', $report, '-'); ?>, #<?php echo wmvc_show_data('listing_id', $report, '-'); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('User', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Price net', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date From', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date To', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Listing', 'wdk-bookings'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be deactivated!', 'wdk-bookings')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>