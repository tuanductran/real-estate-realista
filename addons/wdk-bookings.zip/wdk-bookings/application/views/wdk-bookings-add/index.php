<?php
/**
 * The template for Reservation Edit.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Reservations Management','wdk-bookings'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Add/Edit Reservation','wdk-bookings'); ?></h3>
            </div>
            <div class="inside">
                <div class="wdk-row">
                    <div class="wdk-col-6">
                    <?php if(wmvc_show_data('idreservation',$db_data, false)):?>
                        <input type="hidden" name="current_reservation_id" id="current_reservation_id" value="<?php echo esc_attr(wmvc_show_data('idreservation',$db_data, false)); ?>">
                    <?php endif;?>
                   
                    <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                            <?php 
                                $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-bookings'));
                            ?>

                            <?php echo wdk_generate_fields($fields, $db_data); ?> 

                            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-bookings'); ?>">
                            <?php
                                $data_user = get_userdata(wmvc_show_data('user_id', $db_data));
                            ?>
                            <a href="mailto:<?php echo esc_attr(wmvc_show_data('user_email', $data_user, false, TRUE, TRUE));?>?subject=<?php echo esc_attr__('Your Reservation','wdk-bookings');?>" class="button button-default"><?php echo esc_html__('Reply To Email','wdk-bookings'); ?></a>
                        
                        </form>
                    </div>
                    <div class="wdk-col-6">
                        <div class="wdk-booking-calendar">
                            <div class="hidden data-ajax" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>"></div>
                            <div class="hidden js_message"><?php echo esc_html__('For Booking please login', 'wdk-bookings');?></div>
                            <div class="hidden js_message_error_date"><?php echo esc_html__('Dates in not available, please set other dates', 'wdk-bookings');?></div>
                            <div class="wdk-row">
                                <?php
                                    $available_dates = [];
                                    $current_day = date("j");
                                    $current_month = date("m");
                                    $wdk_order = 0;
                                ?>
                                <?php for($month_i=0;$month_i < wmvc_show_data('month_count', $settings,6); $month_i++):?>
                                    <div class="wdk-col">
                                        <table>
                                        <?php
                                        $next_month_time = strtotime("+$month_i month", strtotime(date("F") . "1"));
                                        
                                        // Get the value of day, month, year
                                        $days = array(
                                                0 => esc_html__('Sun','wdk-bookings'),
                                                1 => esc_html__('Mon','wdk-bookings'), 
                                                2 => esc_html__('Tue','wdk-bookings'), 
                                                3 => esc_html__('Wed','wdk-bookings'), 
                                                4 => esc_html__('Thu','wdk-bookings'), 
                                                5 => esc_html__('Fri','wdk-bookings'), 
                                                6 => esc_html__('Sat','wdk-bookings'),
                                            );
                                        
                                        list($mon, $month_m, $month, $year, $num_days) = explode('-', date("n-m-F-Y-t", $next_month_time));

                                        $first_day_of_week = array_search(esc_html__(date('D', strtotime($year . '-' . $month . '-1')), 'wdk-bookings'), $days);
                                        if(!$first_day_of_week)
                                            $first_day_of_week = 1;

                                        $num_days_last_month = date('j', strtotime('last day of previous month', strtotime($current_day. '-' . $month . '-' . $year)));
                                        $startDay = $first_day_of_week;
                                        ?>
                                            <caption><?php echo esc_html__($month,'wdk-bookings');?> <?php echo esc_html($year);?></caption>
                                            <thead>
                                            <tr>
                                                <?php foreach ($days as $key => $day) :?>
                                                    <th><?php echo esc_html($day);?></th>
                                                <?php endforeach;?>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <?php for ($i = $first_day_of_week; $i > 0; $i--):?>
                                                        <?php
                                                            $d = $num_days_last_month-$i+1;
                                                            $date_day = '';
                                                            $class_td = '';

                                                            $hidden_m = intval($month_m) - 1;
                                                            if ($hidden_m<1) {
                                                                $hidden_m = "12";
                                                            }elseif($hidden_m<10) {
                                                                $hidden_m = "0{$hidden_m}";
                                                            } 

                                                            if($d<10) {
                                                                $date_day = "{$year}-{$hidden_m}-0{$d}";
                                                            } else {
                                                                $date_day = "{$year}-{$hidden_m}-{$d}";
                                                            }
                                                        ?>

                                                        <td class='ignore'><a title-hidden="<?php echo esc_html($date_day);?>"><?php echo esc_html(($num_days_last_month-$i+1));?></a></td>
                                                    <?php endfor;?>

                                                    <?php for ($d=1;$d<=$num_days;$d++):?>
                                                        <?php
                                                            $date_day = '';
                                                            $class_td = '';
                                                            if($d<10) {
                                                                $date_day = "{$year}-{$month_m}-0{$d}";
                                                            } else {
                                                                $date_day = "{$year}-{$month_m}-{$d}";
                                                            }

                                                            if ($d == $current_day && $month_m == $current_month) {
                                                                $class_td = "bg-today";
                                                            } elseif (isset($available_dates[$date_day])) {
                                                                if(strpos($available_dates[$date_day], 'book_book_current') !== FALSE ) {
                                                                    $class_td = "bg-booked";
                                                                } elseif(strpos($available_dates[$date_day], 'book_current_bookd') !== FALSE ) {
                                                                    $class_td = "bg-booked";
                                                                } elseif(strpos($available_dates[$date_day], 'reservation_start') !== FALSE && strpos($available_dates[$date_day], 'reservation_end') === FALSE) {
                                                                    $class_td = "bg-available bg-booked reservation-start";
                                                                } elseif(strpos($available_dates[$date_day], 'reservation_end') !== FALSE && strpos($available_dates[$date_day], 'reservation_start') === FALSE) {
                                                                    $class_td = "bg-available bg-booked reservation-end";
                                                                } elseif(strpos($available_dates[$date_day], 'booked') !== FALSE) {
                                                                    $class_td = "bg-booked";
                                                                } else {
                                                                    $class_td = "bg-available";
                                                                }
                                                            } else {
                                                                $class_td = "bg-not-selected";
                                                            }
                                                            $startDay++;
                                                        ?>
                                                        <td data-order="<?php echo esc_attr($wdk_order++);?>" class="<?php echo esc_html($class_td);?>"><a title="<?php echo esc_html($date_day);?>"><?php echo esc_html($d);?></a></td>

                                                        <?php if($startDay > 6 && $d < $num_days):?>
                                                            <?php $startDay = 0; ?>
                                                            </tr><tr>
                                                        <?php endif;?>
                                                    <?php endfor;?>

                                                    <?php for ($i = $startDay,$y=1; $i <= 6 ; $i++,$y++):?>
                                                        <?php
                                                            $d = $y;
                                                            $date_day = '';
                                                            $hidden_m = intval($month_m) + 1;
                                                            if ($hidden_m>12) {
                                                                $hidden_m = "01";
                                                            }elseif($hidden_m<10) {
                                                                $hidden_m = "0{$hidden_m}";
                                                            } 

                                                            if($d<10) {
                                                                $date_day = "{$year}-{$hidden_m}-0{$d}";
                                                            } else {
                                                                $date_day = "{$year}-{$hidden_m}-{$d}";
                                                            }
                                                        ?>
                                                        <td class='ignore'><a title-hidden="<?php echo esc_html($date_day);?>"><?php echo esc_html($y);?></a></td>
                                                    <?php endfor;?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div> 
                                <?php endfor;?>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>
<?php wp_enqueue_style('wdk-booking-calendar');?>
<?php wp_enqueue_script('wdk-booking-calendar');?>
<?php $this->view('general/footer', $data); ?>