<?php
/**
 * The template for Edit Price.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->


<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Availability/Prices Management','wdk-bookings'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Add/Edit Availability/Price','wdk-bookings'); ?></h3>
            </div>
            <div class="inside">
                <div class="wdk-row">
                    <div class="wdk-col-3">
                        <?php if(wmvc_show_data('idprice',$db_data, false)):?>
                            <input type="hidden" name="current_price_id" id="current_price_id" value="<?php echo esc_attr(wmvc_show_data('idprice',$db_data, false)); ?>">
                        <?php endif;?>
                        <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                            <?php 
                                $form->messages('class="alert alert-danger"', sprintf(__('Successfully saved %1$s Add new %2$s', 'wdk-bookings'), '<a href="'.admin_url('admin.php?page=wdk-bookings-prices&function=edit&post_id='.wmvc_show_data('post_id',$db_data, false)).'" target="_blank">', '</a>'));
                            ?>

                            <?php echo wdk_generate_fields($fields, $db_data); ?> 

                            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-bookings'); ?>">
                        </form>
                    </div>
                    <div class="wdk-col-9">
                        <div class="wdk-booking-calendar">
                            <div class="hidden data-ajax" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>"></div>
                            <div class="hidden js_message"><?php echo esc_html__('For Booking please login', 'wdk-bookings');?></div>
                            <div class="hidden js_message_error_date"><?php echo esc_html__('Dates in not available, please set other dates', 'wdk-bookings');?></div>
                            <div class="wdk-row">
                                <?php
                                    $available_dates = [];
                                    $current_day = date("j");
                                    $current_month = date("m");
                                    $wdk_order = 0;
                                ?>
                                <?php for($month_i=0;$month_i < wmvc_show_data('month_count', $settings,48); $month_i++):?>
                                    <?php if($month_i%12==0 && $month_i !=0):?>
                                        </div>
                                        <div class="wdk-row wdk-booking-calendar-addinition" style="display: none;">
                                    <?php endif;?>

                                    <div class="wdk-col wdk-column-3">
                                        <table>
                                        <?php
                                        $next_month_time = strtotime("+$month_i month", strtotime(date("F") . "1"));
                                        
                                        // Get the value of day, month, year
                                        $days = array(
                                                0 => esc_html__('Sun','wdk-bookings'),
                                                1 => esc_html__('Mon','wdk-bookings'), 
                                                2 => esc_html__('Tue','wdk-bookings'), 
                                                3 => esc_html__('Wed','wdk-bookings'), 
                                                4 => esc_html__('Thu','wdk-bookings'), 
                                                5 => esc_html__('Fri','wdk-bookings'), 
                                                6 => esc_html__('Sat','wdk-bookings'),
                                            );
                                        
                                        list($mon, $month_m, $month, $year, $num_days) = explode('-', date("n-m-F-Y-t", $next_month_time));

                                        $first_day_of_week = array_search(esc_html__(date('D', strtotime($year . '-' . $month . '-1')), 'wdk-bookings'), $days);
                                        if(!$first_day_of_week)
                                            $first_day_of_week = 1;

                                        $num_days_last_month = date('j', strtotime('last day of previous month', strtotime($current_day. '-' . $month . '-' . $year)));
                                        $startDay = $first_day_of_week;
                                        ?>
                                            <caption><?php echo esc_html__($month,'wdk-bookings');?><?php echo esc_html($year);?></caption>
                                            <thead>
                                            <tr>
                                                <?php foreach ($days as $key => $day) :?>
                                                    <th><?php echo esc_html(substr($day,0,3));?></th>
                                                <?php endforeach;?>
                                            </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <?php for ($i = $first_day_of_week; $i > 0; $i--):?>
                                                        <td class='ignore' data-order="<?php echo esc_attr($wdk_order++);?>"><a><?php echo esc_html(($num_days_last_month-$i+1));?></a></td>
                                                    <?php endfor;?>

                                                    <?php for ($d=1;$d<=$num_days;$d++):?>
                                                        <?php
                                                            $date_day = '';
                                                            $class_td = '';
                                                            if($d<10) {
                                                                $date_day = "{$year}-{$month_m}-0{$d}";
                                                            } else {
                                                                $date_day = "{$year}-{$month_m}-{$d}";
                                                            }

                                                            if ($d == $current_day && $month_m == $current_month) {
                                                                $class_td = "bg-today";
                                                            } elseif (isset($available_dates[$date_day])) {
                                                                if($available_dates[$date_day] == 'booked') {
                                                                    $class_td = "bg-booked";
                                                                } else {
                                                                    $class_td = "bg-available";
                                                                }
                                                            } else {
                                                                $class_td = "bg-not-selected";
                                                            }
                                                            $startDay++;
                                                        ?>
                                                        <td data-order="<?php echo esc_attr($wdk_order++);?>" class="<?php echo esc_html($class_td);?>"><a title="<?php echo esc_html($date_day);?>"><?php echo esc_html($d);?></a></td>

                                                        <?php if($startDay > 6 && $d < $num_days):?>
                                                            <?php $startDay = 0; ?>
                                                            </tr><tr>
                                                        <?php endif;?>
                                                    <?php endfor;?>

                                                    <?php for ($i = $startDay,$y=1; $i <= 6 ; $i++,$y++):?>
                                                        <td class='ignore'><a><?php echo esc_html($y);?></a></td>
                                                    <?php endfor;?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div> 
                                <?php endfor;?>
                            </div> 
                            <div class="wdk-row">
                                <div class="wdk-col wdk-col-full wdk-cal-pag">
                                    <a href="#" class="wdk-btn-pag next">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                    </a>
                                    <a href="#" class="wdk-btn-pag pre noactive">
                                        <span class="dashicons dashicons-minus"></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="postbox postbox-rates hidden">
            <div class="postbox-header">
                <h3><?php echo esc_html__('Listing prices','wdk-bookings'); ?></h3>
            </div>
            <div class="inside">
            <table class="wp-list-table widefat fixed striped table-view-list pages">
                    <thead>
                        <tr>
                            <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Date From', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Date To', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Guests', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Price Day', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Price Week', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Price Month', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Price Year', 'wdk-bookings'); ?></th>
                            <th><?php echo esc_html__('Activated', 'wdk-bookings'); ?></th>
                            <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-bookings'); ?></th>
                        </tr>
                    </thead>
                    <tbody class="prices-table">
                    </tbody>    
                </table>
            </div>
        </div>
    </div>
</div>

<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>
<?php wp_enqueue_style('wdk-booking-rates');?>
<?php wp_enqueue_script('wdk-booking-rates');?>

<?php $this->view('general/footer', $data); ?>