<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
function wdk_booking_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_bookings;
    $WMVC = &$Winter_MVC_wdk_bookings;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_booking_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_booking_listings.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

if ( ! function_exists('wdk_booking_is_date'))
{
	function wdk_booking_is_date($date, $format = 'Y-m-d H:i:s')
	{
        $d = DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) == $date;
	}
}

if ( ! function_exists('is_post_exists'))
{
    function is_post_exists($string)
    {
        return get_post(intval($string)) !== NULL;
    }
}

if ( ! function_exists('is_price_date_exists'))
{
    function is_price_date_exists($string)
    {
        if(!isset($_POST['date_to']))return FALSE;
        if(empty($string))return FALSE;

        $date_from = date('Y-m-d H:i:s', strtotime($string));
        $date_to = date('Y-m-d H:i:s', strtotime(sanitize_text_field($_POST['date_to'])));
        $post_id = intval($_POST['post_id']);

        $additional_sql = '';
        if(isset($_REQUEST['id']))
        {
            $current_id = intval($_REQUEST['id']);
            $additional_sql = " AND idprice != $current_id";
        }
            

        //if(strtotime($date_from) < time())return FALSE;
        if(strtotime($date_from) >= strtotime($date_to))return FALSE;

        // check dates in db table
        global $wpdb;
        $results = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."wdk_booking_price WHERE (
                                                                                        (date_from < '$date_from' AND date_to > '$date_from') OR 
                                                                                        (date_from < '$date_to' AND date_to > '$date_to') OR
                                                                                        (date_from > '$date_from' AND date_to < '$date_to')
                                                                                    ) 
                                                                                    AND post_id = $post_id $additional_sql;");

        return count($results) == 0;
    }
}

if ( ! function_exists('is_reservation_date_exists'))
{
    function is_reservation_date_exists($string)
    {
        if(!isset($_POST['date_to']))return FALSE;
        if(empty($string))return FALSE;
        return TRUE;
        $date_from = date('Y-m-d H:i:s', strtotime($string));
        $date_to = date('Y-m-d H:i:s', strtotime(sanitize_text_field($_POST['date_to'])));
        $post_id = intval($_POST['post_id']);
        $additional_sql = '';
        if(isset($_REQUEST['id']) && !empty($_REQUEST['id']))
        {
            $current_id = intval($_REQUEST['id']);
            $additional_sql = " AND idreservation != $current_id";
        }

        // check dates in db table
        global $wpdb;

        $results = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."wdk_booking_reservation WHERE date_from > '$date_to' AND date_to < '$date_from' AND post_id = $post_id $additional_sql;");

        return count($results) == 0;
    }
}

if ( ! function_exists('is_reservation_date_availability'))
{
    function is_reservation_date_availability($string)
    {
        if(!isset($_POST['date_to']))return FALSE;
        if(empty($string))return FALSE;

        $date_from = date('Y-m-d H:i:s', strtotime($string));
        $date_to = date('Y-m-d H:i:s', strtotime(sanitize_text_field($_POST['date_to'])));
        $post_id = intval($_POST['post_id']);

        
        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('price_m');

        $results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_bookings->price_m->_table_name." WHERE date_from <= '$date_from' AND date_to >= '$date_to' AND post_id = $post_id ;");

        return count($results) != 0;
    }
}

if ( ! function_exists('is_reservation_date_range'))
{
    function is_reservation_date_range($string)
    {
        if(!isset($_POST['date_to']))return FALSE;
        if(empty($string))return FALSE;

        $date_from = date('Y-m-d H:i:s', strtotime($string));
        $date_to = date('Y-m-d H:i:s', strtotime(sanitize_text_field($_POST['date_to'])));
        
        //if(strtotime($date_from) < time())return FALSE;
        if(strtotime($date_from) >= strtotime($date_to)) return FALSE;

        return TRUE;
    }
}

if ( ! function_exists('is_unique_post_id'))
{
    function is_unique_post_id_calendar($param)
    {
        if(!is_numeric($param))return FALSE;

        $additional_sql = '';
        if(isset($_REQUEST['id']))
        {
            $current_id = intval($_REQUEST['id']);
            $additional_sql = " AND idcalendar != $current_id";
        }

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');

        $results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_bookings->calendar_m->_table_name." WHERE post_id = $param $additional_sql;");

        return count($results) == 0;
    }
}

if ( ! function_exists('is_reservation_calendar_availability'))
{
    function is_reservation_calendar_availability($param)
    {
        if(!is_numeric($param))return FALSE;

        $additional_sql = '';

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');

        $results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_bookings->calendar_m->_table_name." WHERE post_id = $param AND is_activated = 1 $additional_sql;");

        return count($results) != 0;
    }
}

if ( ! function_exists('is_reservation_check_availability'))
{
    function is_reservation_check_availability($param)
    {
        if(!is_numeric($param))return FALSE;

        $except_id =NULL;
        if(isset($_REQUEST['id']))
        {
            $except_id = intval($_REQUEST['id']);
        }

        $date_to =NULL;
        if(isset($_POST['date_to']))
        {
            $date_to = ($_POST['date_to']);
        } else {
            return FALSE;
        }

        $date_from =NULL;
        if(isset($_POST['date_from']))
        {
            $date_from = ($_POST['date_from']);
        } else {
            return FALSE;
        }

        // check dates in db table
        global $wpdb,$Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $results = $Winter_MVC_wdk_bookings->reservation_m->is_booked($param, $date_from, $date_to, $except_id);
        //$results = $wpdb->get_results("SELECT * FROM ".$Winter_MVC_wdk_bookings->reservation_m->_table_name." WHERE post_id = $param AND is_approved = 1 $additional_sql;");
        
        return !$results;
    }
}

if ( ! function_exists('is_wdkbooking_file_exists'))
{
    function is_wdkbooking_file_exists($param)
    {   

        if((isset($_POST['import_public_url']) && !empty($_POST['import_public_url'])) || (isset($_POST['icl_file']) && !empty($_POST['icl_file'])))
        {
            return TRUE;
        }
        
        return FALSE;
    }
}

if ( ! function_exists('wdk_calendar_ical_export'))
{
    function wdk_calendar_ical_export($reservation_id = NULL)
    {
        global $Winter_MVC_wdk_bookings,$Winter_MVC_WDK;
        $Winter_MVC_wdk_bookings->model('reservation_m');

        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $reservations = $Winter_MVC_wdk_bookings->reservation_m->get($reservation_id);
        $listing = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $reservations[0], false, TRUE, TRUE), TRUE);
        $print_data = [];
        $print_data [] = 'BEGIN:VCALENDAR';
        $print_data [] = 'VERSION:2.0';
        $print_data [] = 'PRODID:-//'.get_bloginfo("name").'//EN';
        $print_data [] = 'X-WR-CALNAME:'.get_bloginfo("name").'';
        $print_data [] = 'X-WR-CALDESC:Public '.get_bloginfo("name").' Reservations Provided by '.site_url();
        $print_data [] = 'X-PUBLISHED-TTL:PT1H';
        $print_data [] = 'REFRESH-INTERVAL;VALUE=DURATION:P1H';
        $print_data [] = 'NAME:'.get_bloginfo("name").'';
        $print_data [] = 'CALSCALE:GREGORIAN';
        $print_data [] = 'METHOD:PUBLISH';
        
        foreach ($reservations as $key => $reservation) {
                $print_data [] = 'BEGIN:VEVENT';
                $print_data [] = 'DTEND;VALUE=DATE:'. date('YmdTHis', strtotime(wmvc_show_data('date_to', $reservation)));
                $print_data [] = 'DTSTART;VALUE=DATE:'.date('YmdTHis', strtotime(wmvc_show_data('date_from', $reservation)));
                $print_data [] = 'URL;VALUE=URI:' . admin_url('admin.php?page=wdk-bookings-add&id='.wmvc_show_data('idreservation', $reservation));
                $print_data [] = 'UID:reservation_' .wmvc_show_data('idreservation', $reservation);
                $print_data [] = 'SUMMARY:'.esc_html__('Reservation for', 'wdk-bookings').' '.wmvc_show_data('post_title', $listing, '', TRUE, TRUE); 
                $print_data [] = 'DESCRIPTION:<strong>Price</strong> '.wmvc_show_data('price', $reservation).wdk_booking_currency_symbol().'\n'.str_replace(array('#',':',';', PHP_EOL),array('',' ','','<br>'),wmvc_show_data('notes', $reservation)) ;
                $print_data [] = 'ORGANIZER;CN='.get_bloginfo('name').':MAILTO:'.get_bloginfo('admin_email');
                $print_data [] = 'STATUS:CONFIRMED';
                $print_data [] = 'LOCATION:'.esc_html(wmvc_show_data('address', $listing, '', TRUE, TRUE));
                $print_data [] = 'END:VEVENT';
            
        }
        
        $print_data [] = 'END:VCALENDAR';

        $print_data = preg_replace('/^[ \t]*[\r\n]+/m', '', implode(PHP_EOL, $print_data));

        return $print_data;
    }
}

if ( ! function_exists('wdk_convert_date_format_js'))
{
    /**
	 * Convert date format for support in js
	 * From: https://wordpress.org/support/article/formatting-date-and-time/
     * To: https://momentjscom.readthedocs.io/en/latest/moment/04-displaying/01-format/
     * 
	 * @param      string    php date format       Option key
	 * @return     string    js date format
	 */
	function wdk_convert_date_format_js($date_format)
	{
        $replaced = array(
            'D'=>'ddd',
            'j'=>'D',
            'd'=>'DD',
            'l'=>'dddd',
            'F'=>'MMMM',
            'Y'=>'YYYY',
            'j'=>'D',
            'S'=>'Do',
            'l'=>'dddd',
            'm'=>'MM',
            'n'=>'MM',
            'F'=>'MMMM',
            'M'=>'MMM',
            'Y'=>'YYYY',
            'y'=>'YY',
            'a'=>'a',
            'A'=>'A',
            'h'=>'hh',
            'G'=>'H',
            'H'=>'HH',
            'g'=>'h',
            'i'=>'mm',
            's'=>'ss',
            'T'=>'zz',
            'c'=>'',
            'r'=>'llll',
            'u'=>'x',
        );

        $replaced_from = array_keys($replaced);
        $date_format = str_replace($replaced_from, array_keys($replaced_from), $date_format);
		return str_replace(array_reverse(array_keys($replaced_from)), array_reverse($replaced), $date_format);
	}
}

if ( ! function_exists('wdk_booking_currency_symbol'))
{
    /**
	 * Return currency symbol
     * 
	 * @return     string    currency symbol
	 */
	function wdk_booking_currency_symbol()
	{

        if(function_exists('get_woocommerce_currency_symbol'))
            return get_woocommerce_currency_symbol();

        if(wdk_get_option('wdk_default_currency_symbol'))
            return wdk_get_option('wdk_default_currency_symbol');

        return '$';
	}
}

if ( ! function_exists('wdk_booking_reservation_price'))
{
    /**
	 * Return currency symbol
     * 
	 * @return     string    currency symbol
	 */
	function wdk_booking_reservation_price($post_id, $date_from, $date_to)
	{

        global $Winter_MVC_wdk_bookings;
		$Winter_MVC_wdk_bookings->model('reservation_m');
		$Winter_MVC_wdk_bookings->model('calendar_m');

        $output = array(
            'price' => '',
            'total' => '',
            'fees' => '',
            'success' => false,
            'error' => '',
            'symbol' => '',
        );
        
        $price = $Winter_MVC_wdk_bookings->reservation_m->calculate_price($post_id, $date_from, $date_to);

        $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>$post_id), TRUE); // date_package_expire package_id
        $calendar_fees = array();
        if($calendar && !empty($calendar->json_data_fees))
            $calendar_fees = json_decode($calendar->json_data_fees );
        
        if(function_exists('wdk_booking_currency_symbol'))
            $output['symbol'] = wdk_booking_currency_symbol();
        
        if($price) {
            $output['price'] = $price['price'];
            $output['total'] = $price['price'];
            $output['fees_data'] = $calendar_fees;
            $output['fees'] = array();
            foreach ($calendar_fees as $fee) {
                if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                if(is_intval(wmvc_show_data('value', $fee,'',TRUE,TRUE))) {
                    $field = wdk_generate_slug(strtolower(esc_html(wmvc_show_data('title', $fee,'-',TRUE,TRUE)))); 
                    if(!wmvc_show_data('is_required', $fee, false,TRUE,TRUE) && isset($parameters['fee_'.$field]) && $parameters['fee_'.$field] == 0) {
                        
                    } else {
                        $price = 0;
                        if(wmvc_show_data('calculation_base', $fee,'',TRUE,TRUE) == 'per_night') {
                            $nights = (int)abs(strtotime($date_from) - strtotime($date_to))/(60*60*24);
                            $price += intval(wmvc_show_data('value', $fee,'',TRUE,TRUE)) * $nights;
                        } else if(wmvc_show_data('calculation_base', $fee,'',TRUE,TRUE) == 'per_person') {
                            $price += intval(wmvc_show_data('value', $fee,'',TRUE,TRUE)) * intval(wmvc_show_data('guests', $_POST, 0,TRUE,TRUE));
                        } else {
                            $price += intval(wmvc_show_data('value', $fee,'',TRUE,TRUE));
                        }
                        $output['fees'][wmvc_show_data('title', $fee,'',TRUE,TRUE)] = $price;
                        $output['total'] += $price;
                    }
                }
            }
            $output['success'] = true;
        } else {
            $output['success'] = false;
            $output['error'] = __('Those dates are not available', 'wpdirectorykit');
        }

        return $output;
        
	}
}

/*
 validation function for gps, temporary, can be removed after few updates main plugins, added in main plugin version  1.2.3
*/
if ( ! function_exists('is_wdk_gps_single'))
{
    function is_wdk_gps_single($param)
    {

        if (is_numeric($param) && $param > -180 && $param < 180) {
            return true;
        }

        return false;
    }
}

/*
    Validation is natural integer, temp function added in main plugin version 1.3.1
*/

if ( ! function_exists('is_wdk_is_natural'))
{
    function is_wdk_is_natural($param)
    {

        if (is_intval($param) && stripos($param, '.') === FALSE && stripos($param, ',') === FALSE) {
            return true;
        }

        return false;
    }
}
?>