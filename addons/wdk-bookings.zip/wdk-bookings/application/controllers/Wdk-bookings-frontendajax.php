<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function availabledates($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');
		$this->load->model('reservation_m');
		$this->load->model('calendar_m');

        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;

		$post_id = false;

		if(isset($_POST['post_id']))
			$post_id = intval($_POST['post_id']);

        $user_id = get_current_user_id();

		if(empty($user_id))
        {
			$data['popup_text_error'] .= __('Please login to use feature', 'wdk-bookings');
        } 

		if(empty($post_id))
        {
            $data['popup_text_error'] .= __('Missing post id', 'wdk-bookings');
        } 

		if($post_id && empty($data['popup_text_error'])) {
			if(isset($_POST['current_reservation_id'])) {
				$data['output'] = $this->reservation_m->get_reservation_dates($post_id, sanitize_text_field($_POST['current_reservation_id']), 'booked_current');
			} else {
				$data['output'] = $this->reservation_m->get_reservation_dates($post_id);
			}
			
			$data['success'] = true;
			$data['is_hours_enable'] = $this->calendar_m->is_hours_enable($post_id);
		}

		$this->output($data);
    }

    public function availablerates($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');
		$this->load->model('price_m');
		$this->load->model('calendar_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;

		$post_id = false;

		if(isset($_POST['post_id']))
			$post_id = intval($_POST['post_id']);

        $user_id = get_current_user_id();

		if(empty($user_id))
        {
			$data['popup_text_error'] .= __('Please login to use feature', 'wdk-bookings');
        } 

		if(empty($post_id))
        {
            $data['popup_text_error'] .= __('Missing post id', 'wdk-bookings');
        } 

		if($post_id && empty($data['popup_text_error'])) {
			$prices = array();
			$db_prices = $this->price_m->get_pagination(10, NULL, array('post_id'=>$post_id));
			foreach($db_prices as $price) {
				$price->link_edit = get_admin_url() . "admin.php?page=wdk-bookings-prices&function=edit&id=". $price->idprice;
				$price->btn_edit = '<a target="_blank" href="'.$price->link_edit.'"><span class="dashicons dashicons-edit"></span></a>';
				
				if($price->is_activated == 1) {
					$price->activated ='<span class="dashicons dashicons-yes"></span>';
				} else {
					$price->activated ='<span class="dashiconsdashicons-no-alt"></span>';
				}
				$prices[] = $price;
			}

			$symbol = wdk_booking_currency_symbol();

			$data['output'] = array(
				'is_hours_enable' => $this->calendar_m->is_hours_enable($post_id),
				'prices_dates' => $this->price_m->get_prices_dates($post_id),
				'prices' => $prices,
				'currency' => $symbol,
			);
			$data['success'] = true;
		}

		$this->output($data);
    }

    public function autoimportdatacalendar($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');
		$this->load->model('calendar_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;

		$idcalendar = false;
		if(isset($_POST['idcalendar']))
			$idcalendar = intval($_POST['idcalendar']);

        $user_id = get_current_user_id();

		if(empty($user_id))
        {
			$data['popup_text_error'] .= __('Please login to use feature', 'wdk-bookings');
        } 

		if(empty($idcalendar))
        {
            $data['popup_text_error'] .= __('Missing post id', 'wdk-bookings');
        } 

		if($idcalendar && empty($data['popup_text_error'])) {
			$calendar = $this->calendar_m->get($idcalendar, TRUE);
			if($calendar) {
				$data_insert = array();
				$data_insert['import_public_url'] = sanitize_text_field($_POST['import_public_url']);
				$data_insert['import_availability_to_date'] = sanitize_text_field($_POST['import_availability_to_date']);
				$data_insert['is_enable_auto_import'] = 0;
				if($_POST['enable_auto_import'] == 1 || $_POST['enable_auto_import'] =='true') {
					$data_insert['is_enable_auto_import'] = 1;
				}

				$data_insert['is_import_remove_old_dates'] = 0;
				if($_POST['is_import_remove_old_dates'] == 1 || $_POST['is_import_remove_old_dates'] =='true') {
					$data_insert['is_import_remove_old_dates'] = 1;
				}

				$insert_id = $this->calendar_m->insert($data_insert, $idcalendar);
				$data['popup_text_success'] .= __('Calendar data updated', 'wdk-bookings');
			} else {
				$data['popup_text_error'] .= __('Calendar not found in db, id#', 'wdk-bookings').$idcalendar;
			}

			$data['success'] = true;
		}

		$this->output($data);
    }
	
    public function loading_listings($output="", $atts=array(), $instance=NULL)
    {
		
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('listing_m');
		$this->load->model('price_m');
		$this->load->model('calendar_m');
		
        $data = array();
        $data['message'] = '';
        $data['output_message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = array();
		$data['success'] = false;

		$post_table = $this->db->prefix.'posts';

		$parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[sanitize_text_field($key)] = sanitize_text_field($value);
		}

		if(empty(wmvc_show_data('date_from',$parameters,'')) || empty(wmvc_show_data('date_to',$parameters,''))) {
			$data['message'] = '<p class="alert alert-danger">'.esc_html__('Date from and to, should be populated','wdk-bookings').'</p>';
		}

		if(empty($data['message'])) {

			$columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by','is_featured', 'address');
			$external_columns = array('location_id', 'category_id', 'post_title');
			$controller = 'listing';
            $limit = 20;
            $offset = NULL;

			$custom_parameters = array();
			$custom_parameters['field_booking_date_from'] = wmvc_show_data('date_from',$parameters,'');
			$custom_parameters['field_booking_date_to'] = wmvc_show_data('date_to',$parameters,'');
		
			
			wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters);
			

			$this->db->select(' calendar_table.guests AS calendar_guests,
								calendar_table.is_children_acceptable AS calendar_is_children_acceptable,
								calendar_table.is_pets_acceptable AS calendar_is_pets_acceptable');
			$this->db->join($this->calendar_m->_table_name.' AS calendar_table ON (calendar_table.post_id = '.$post_table.'.ID) ', NULL, 'LEFT');

			$this->db->select(''.$this->price_m->_table_name.'.price_day AS price_price_day,
								'.$this->price_m->_table_name.'.is_children_acceptable AS price_is_children_acceptable,
								'.$this->price_m->_table_name.'.is_pets_acceptable AS price_is_pets_acceptable'
							);
            $results = $Winter_MVC_WDK->listing_m->get_pagination($limit, $offset, array('is_activated' => 1,'is_approved'=>1));
		
			foreach ($results as $key => $value) {
				$listing = array(
					'post_title' => wmvc_show_data('post_title',$value,''),
					'thumbnail' => esc_url(wdk_image_src($value, 'full')),
					'post_id' => wmvc_show_data('post_id',$value,''),
					'link' => esc_url(get_permalink($value)),
					'description' => '',
				);

				if(wmvc_show_data('calendar_guests', $value, '-') < 5) {
					for($i=0; $i<wmvc_show_data('calendar_guests', $value); $i++) {
						$listing['description'] .=  '<i class="fas fa-user"></i>';
					}
				} else {
					$listing['description'] .=  '<i class="fas fa-user"></i> x'. wmvc_show_data('calendar_guests', $value, '');
				}

				if(wmvc_show_data('calendar_is_children_acceptable', $value) == 1) {
					$listing['description'] .= '<span class="item">
						<i class="fas fa-child"></i> '.esc_html__('Childrens','wdk-bookings').'
					</span>';
				}
				if(wmvc_show_data('calendar_is_pets_acceptable', $value) == 1) {
					$listing['description'] .= '<span class="item">
						<i class="fas fa-paw"></i> '.esc_html__('Pets','wdk-bookings').'
					</span>';
				}

				$price = wdk_booking_reservation_price(wmvc_show_data('post_id',$value,''), wdk_normalize_date_db(wmvc_show_data('date_from',$parameters,''), 'Y-m-d H:i:s', 'Y-m-d'), wdk_normalize_date_db(wmvc_show_data('date_to',$parameters,''), 'Y-m-d H:i:s', 'Y-m-d'));
				$listing['price_total'] = $price['total'].$price['symbol'];
				if(empty($price['total'])) continue;
				$data['output'][] = $listing;
			}

			if(defined( 'WP_DEBUG' ) && WP_DEBUG)
				$data['listings_sql'] = $Winter_MVC_WDK->db->last_query();

			$data['success'] = true;
		}

		if(empty($data['output'])) {
			$data['output_message'] .= '<p class="alert alert-info">'.esc_html__('No Listings','wdk-bookings').'</p>';
		}

		$this->output($data);
    }
	
    public function send_reservation($output="", $atts=array(), $instance=NULL)
    {
		
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
        $Winter_MVC_WDK->model('listingusers_m');

		do_action('eli/ajax-handler/after', array());
		$ajax_output = array();
		if(has_filter('eli/ajax-handler/filter_output'))
			$ajax_output = apply_filters('eli/ajax-handler/filter_output', $ajax_output);
		
        $data = array();
        $data['message'] = '';
        $data['output_message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = array();
		$data['success'] = false;

		if(!isset($ajax_output['no_clear_from'])) {
			$data['success'] = true;
		}

		if(!empty($ajax_output['redirect'])) {
			$data['redirect'] = $ajax_output['redirect'];
		}

		if(isset($ajax_output['message']))
			$data['message'] = $ajax_output['message'];

		$this->output($data);
    }

     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
