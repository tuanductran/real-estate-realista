<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'reservation';
        $columns = array('idreservation', 'search', 'order_by', 'post_title', 'post_id');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idreservation DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreservation ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->reservation_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reservation_m->total();

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['reservations'] = $this->reservation_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-bookings/index', $this->data);
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('reservation_m');

        $this->reservation_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-bookings&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reservation_m');
    
            $this->reservation_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reservation_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reservation_m', $post_id);
            $this->reservation_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('reservation_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('reservation_m', $post_id);
            $this->reservation_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings"));
    }

}
