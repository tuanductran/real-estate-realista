<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_calendar extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'calendar';
        $columns = array('idcalendar', 'search', 'order_by', 'post_title');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idcalendar DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idcalendar ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->calendar_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->calendar_m->total();

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['calendars'] = $this->calendar_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-bookings-calendar/index', $this->data);
    }

    public function edit()
	{
        $this->load->model('calendar_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('calendar_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->calendar_m->fields_list;
        $this->data['calendar_fees'] = array();

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-bookings'));
        $this->form->add_error_message('unique_post_id_calendar', __('Calender already defined for this Listing/Post ID', 'wdk-bookings'));

        //exit($this->db->last_query());

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->calendar_m->prepare_data($this->input->post(), $this->data['fields']);
            $data['json_data_fees'] = $this->input->post('json_data_fees');

            $insert_id = $this->calendar_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->calendar_m->get($id, TRUE);
            if(!empty($this->data['db_data']->json_data_fees))
                $this->data['calendar_fees'] = json_decode($this->data['db_data']->json_data_fees );
        } else {
            $this->data['db_data'] = array();
            if(wmvc_show_data('post_id', $_GET, false)) {
                $this->data['db_data']['post_id'] = wmvc_show_data('post_id', $_GET, false);
            }
        }

        // Load view
        $this->load->view('wdk-bookings-calendar/edit', $this->data);
    }

    public function export_icl_calendar()
    {
        ob_clean();

        $calendar_id = sanitize_text_field($this->input->post_get('calendar_id'));
        $this->load->model('reservation_m');
        $this->load->model('calendar_m');

        if(!$this->calendar_m->check_deletable($calendar_id))   exit(__('Permission denied', 'wdk-bookings'));

        $this->data['reservations'] = $this->reservation_m->get_pagination(NULL, NULL, array('calendar_id'=>$calendar_id, 'is_approved' =>1));
 
		$print_data = [];
		$print_data [] = 'BEGIN:VCALENDAR';
		$print_data [] = 'VERSION:2.0';
		$print_data [] = 'PRODID:-//'.get_bloginfo("name").'//EN';
		$print_data [] = 'X-WR-CALNAME:'.get_bloginfo("name").'';
		$print_data [] = 'X-WR-CALDESC:Public '.get_bloginfo("name").' Reservations Provided by '.site_url();
		$print_data [] = 'X-PUBLISHED-TTL:PT1H';
		$print_data [] = 'REFRESH-INTERVAL;VALUE=DURATION:P1H';
		$print_data [] = 'NAME:'.get_bloginfo("name").'';
		$print_data [] = 'CALSCALE:GREGORIAN';
		$print_data [] = 'METHOD:PUBLISH';
		
		foreach ($this->data['reservations'] as $key => $reservation) {
				$print_data [] = 'BEGIN:VEVENT';
				$print_data [] = 'DTEND;VALUE=DATE:'. date('YmdTHis', strtotime(wmvc_show_data('date_to', $reservation)));
				$print_data [] = 'DTSTART;VALUE=DATE:'.date('YmdTHis', strtotime(wmvc_show_data('date_from', $reservation)));
				$print_data [] = 'URL;VALUE=URI:' . admin_url('admin.php?page=wdk-bookings-add&id='.wmvc_show_data('idreservation', $reservation));
				$print_data [] = 'UID:reservation_' .wmvc_show_data('idreservation', $reservation);
				$print_data [] = 'SUMMARY:'.get_bloginfo("name").' Reservation Id '.wmvc_show_data('idreservation', $reservation); 
				$print_data [] = 'DESCRIPTION:<strong>Price</strong> '.wmvc_show_data('price', $reservation).wdk_booking_currency_symbol().'\n'.wmvc_show_data('notes', $reservation) ;
				$print_data [] = 'END:VEVENT';
			
		}
        
		$print_data [] = 'END:VCALENDAR';

		$print_data = preg_replace('/^[ \t]*[\r\n]+/m', '', implode(PHP_EOL, $print_data));


        header('Content-type: text/calendar; charset=utf-8');
        header("Content-Length:".strlen($print_data));
        header("Content-Disposition: attachment; filename=export_icl_calendar".$calendar_id.".ics");
		
        echo $print_data;
        
        exit();
    }

    public function import_icl_calendar()
    {

        $this->load->model('calendar_m');
        $this->load->model('reservation_m');

        $id = $this->input->post_get('id');

        $this->data['calendar'] = $this->calendar_m->get($id, TRUE);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['fields'] = array( 
            array(
                'field' => 'hidden_valid', 
                'field_label' => __('Url', 'wdk-bookings'), 
                'label' => __('Url', 'wdk-bookings'), 
                'hint' => __('Import reservations to ics link', 'wdk-bookings'), 
                'field_type' => 'INPUTBOX', 
                'class' => 'hidden', 
                'rules' => 'required|wdkbooking_file_exists'
            ),
            array(
                'field' => 'import_public_url',
                'field_label' => __('Url', 'wdk-bookings'), 
                'label' => __('Url', 'wdk-bookings'), 
                'hint' => __('Import reservations to ics link', 'wdk-bookings'), 
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_import_remove_old_dates',
                'field_label' => __('Remove all availability dates before each import', 'wdk-bookings'), 
                'label' => __('Remove all availability dates before each import', 'wdk-bookings'), 
                'hint' => __('Remove all availability dates before each import', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'import_availability_to_date',
                'field_label' => __('Availability until this Date', 'wdk-bookings'), 
                'label' => __('Availability until this Date', 'wdk-bookings'), 
                'hint' => __('By default set to 1 year from now/sync time, to define availability on import', 'wdk-bookings'), 
                'field_type' => 'DATETIME', 
                'rules' => ''
            ),
            array(
                'field' => 'icl_file', 
                'field_label' => __('File', 'wdk-bookings'), 
                'label' => __('File', 'wdk-bookings'), 
                'hint' => __('Import reservations from ics file', 'wdk-bookings'), 
                'field_type' => 'UPLOAD_FILE', 
                'rules' => ''
            ),
            array(
                'field' => 'is_enable_auto_import', 
                'field_label' => __('Enable auto import', 'wdk-bookings'), 
                'label' => __('Enable auto import', 'wdk-bookings'), 
                'hint' => __('Please Follow Bookings -> Settings and set custom interval for cron', 'wdk-bookings'), 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );
        $this->data['db_data']['hidden_valid'] = 'valid';

        $this->form->add_error_message('wdkbooking_file_exists', __('Link/File doesn\'t exists', 'wdk-bookings'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->calendar_m->prepare_data($this->input->post(), $this->data['fields']);

            if(!empty($data['icl_file']))
                $file = get_attached_file(intval($data['icl_file']));

            if(!empty($data['import_public_url']))
                $file = sanitize_text_field($data['import_public_url']);

            $name_ics = null;
            if(!empty($data['import_public_url'])) {
                $name_ics = basename($data['import_public_url']);
                $name_ics = substr ($name_ics, 0, stripos($name_ics, '.ics')).'.ics';
            } elseif(!empty($data['icl_file'])) {
                $name_ics = substr ($data['icl_file'], 0, stripos($data['icl_file'], '.ics')).'.ics';
            }

            /* remove old */
            if($name_ics && wmvc_show_data('is_import_remove_old_dates', $data, false)) {
                global $wpdb;
                $query = "DELETE FROM `".$wpdb->prefix."wdk_booking_reservation` 
                WHERE `source` = '".$name_ics."'";
                $wpdb->query($query);	
            }

            global $wp_filesystem;
            // Initialize the WP filesystem, no more using 'file-put-contents' function
            if (empty($wp_filesystem)) {
                WP_Filesystem();
            }
            $string =  $wp_filesystem->get_contents($file);

            $reservations = $this->parse_icl($string);
            if($reservations && !empty($reservations['reservations'])) {
                $import_availability_to_date = '+1 year';

                if(wmvc_show_data('import_availability_to_date', $data, false))    
                    $import_availability_to_date = wmvc_show_data('import_availability_to_date', $data);
                
                $import_availability_to_date = date("Y-m-d H:i:s", strtotime($import_availability_to_date)) ;

                $date = date("Y-m-d H:i:s");
                
                foreach ($reservations['reservations'] as $reservation) {
                    if($import_availability_to_date < wmvc_show_data('dateEnd', $reservation)){
                        continue;
                    }

                    //if(stripos(wmvc_show_data('summary', $reservation), 'Not available') !== FALSE) continue;
                    
                    /* price */
                    $data_res = array();
                    $data_res['calendar_id'] = $id;
                    $data_res['post_id'] = wmvc_show_data('post_id', $this->data['calendar']);
                    $data_res['user_id'] = NULL;
                    $data_res['date'] = $date;
                    $data_res['date_from'] = wmvc_show_data('dateStart', $reservation);
                    $data_res['date_to'] =  wmvc_show_data('dateEnd', $reservation);
                    $data_res['is_approved'] = 1;
                    $data_res['is_paid'] = NULL;
                    $data_res['is_booked'] = 1;
                    $data_res['is_imported'] = 1;
                    $data_res['source'] = $name_ics;
                    $data_res['notes'] = 'UID:'.wmvc_show_data('uid', $reservation).' '. wmvc_show_data('description', $reservation);
                  
                    $results = $this->reservation_m->is_booked(wmvc_show_data('post_id', $this->data['calendar']), $data_res['date_from'], $data_res['date_to']);
                    if( $results ) {
                        continue;
                    }

                    if(!$this->data['calendar']->is_hour_enabled && !empty($data_res['date_from']) && !empty($data_res['date_to'])) {
                        $data_res['date_from'] = date('Y-m-d 00:00:00', strtotime($data_res['date_from']));
                        $data_res['date_to'] = date('Y-m-d 00:00:00', strtotime($data_res['date_to']));
                    }

                    $insert_id = $this->reservation_m->insert($data_res, NULL);
                }
            }
            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?wdk-bookings-calendar&function=import_icl_calendar&id={$id}&is_updated=true"));
                exit;
            }
                
        }
        
        if(!empty($id))
        {
            $this->data['db_data'] = $this->calendar_m->get($id, TRUE);
            $this->data['db_data']->hidden_valid = 'valid';
        }

        // Load view
        $this->load->view('wdk-bookings-calendar/import_icl', $this->data);

    }

    public function parse_icl ($content = '') {
        $this->icl_data = array(
            'title'=>'',
            'description'=>'',
            'reservations'=>array(),
        );
        try {
            //code...
            $content = str_replace("\r\n ", '', $content);

            // Title
            preg_match('`^X-WR-CALNAME:(.*)$`m', $content, $m);
            $this->icl_data['title'] = $m ? trim($m[1]) : null;

            // Description
            preg_match('`^X-WR-CALDESC:(.*)$`m', $content, $m);
            $this->icl_data['description'] = $m ? trim($m[1]) : null;

            // Events
            preg_match_all('`BEGIN:VEVENT(.+)END:VEVENT`Us', $content, $m);
            foreach ((array)$m[0] as $c) {
                $event = $this->_parse_icl_event($c);
                $this->icl_data['reservations'][] = $event;
            }
        } catch (\Throwable $th) {
            var_dump('error');
            return false;
        } 

        return $this->icl_data;
    }

    private function _parse_icl_event($content)
	{
		$content = str_replace("\r\n ", '', $content);
        $event = array();
		// UID
		if (preg_match('`^UID:(.*)$`m', $content, $m))
			$event['uid'] = trim($m[1]);

		// Summary
		if (preg_match('`^SUMMARY:(.*)$`m', $content, $m))
			$event['summary'] = trim($m[1]);

		// Description
		if (preg_match('`^DESCRIPTION:(.*)$`m', $content, $m))
			$event['description'] = trim($m[1]);

		// Date start
		if (preg_match('`^DTSTART(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_timeStart'] = strtotime($m[1]);
			$event['dateStart'] = date('Y-m-d H:i:s', $event['_timeStart']);
		}

		// Date end
		if (preg_match('`^DTEND(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_timeEnd'] = strtotime($m[1]);
			$event['dateEnd'] = date('Y-m-d H:i:s', $event['_timeEnd']);
		}

		// Recurrence-Id
		if (preg_match('`^RECURRENCE-ID(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_recurrenceId'] = strtotime($m[1]);
			$event['recurrenceId'] = date('Y-m-d H:i:s', $event['_recurrenceId']);
		}

		// Recurrence
		if (preg_match('`^RRULE:(.*)`m', $content, $m)) {
			$rules = (object) array();
			$rule = trim($m[1]);

			$rule = explode(';', $rule);
			foreach ($rule as $r) {
				list($key, $value) = explode('=', $r);
				$rules->{ strtolower($key) } = $value;
			}

			if (isset($rules->until)) {
				$rules->until = date('Y-m-d H:i:s', strtotime($rules->until));
			}
			if (isset($rules->count)) {
				$rules->count = intval($rules->count);
			}
			if (isset($rules->interval)) {
				$rules->interval = intval($rules->interval);
			}
			if (isset($rules->byday)) {
				$rules->byday = explode(',', $rules->byday);
			}

			// Avoid infinite recurrences
			if (! isset($rules->until) && ! isset($rules->count)) {
				$rules->count = 500;
			}

			$event['recurrence'] = $rules;
		}


		// Location
		if (preg_match('`^LOCATION:(.*)$`m', $content, $m))
			$event['location'] = trim($m[1]);

		// Status
		if (preg_match('`^STATUS:(.*)$`m', $content, $m))
			$event['status'] = trim($m[1]);


		// Created
		if (preg_match('`^CREATED:(.*)`m', $content, $m))
			$event['created'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

		// Updated
		if (preg_match('`^LAST-MODIFIED:(.*)`m', $content, $m))
			$event['updated'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

		return $event;
	}

    
    private function _filter_icl_data($data = '') {
        return str_replace('','',($data));
    }

    public function deactivate()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('calendar_m');

        $this->calendar_m->insert(array('is_activated'=>NULL), $post_id);

        wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar&paged=$paged"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('calendar_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('calendar_m', $post_id);
            $this->calendar_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('calendar_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('calendar_m', $post_id);
            $this->calendar_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar"));
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('calendar_m');

        $this->calendar_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar&paged=$paged"));
    }

    
    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('calendar_m');
    
            $this->calendar_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-calendar"));
    }

}