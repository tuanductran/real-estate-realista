<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_add extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('calendar_m');
        $this->load->model('reservation_m');
        $this->load->model('price_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('reservation_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->reservation_m->fields_list;

        //exit($this->db->last_query());
       

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-bookings'));
        $this->form->add_error_message('reservation_date_exists', __('Date already in use for this Listing/Post', 'wdk-bookings'));
        $this->form->add_error_message('reservation_date_range', __('\'Date to\' can\'t be after \'date from\'', 'wdk-bookings'));
        $this->form->add_error_message('reservation_date_availability', __('Date not available', 'wdk-bookings'));
        $this->form->add_error_message('reservation_calendar_availability', __('Calendar not available, for this listing', 'wdk-bookings'));
        $this->form->add_error_message('reservation_check_availability', __('Dates already booked', 'wdk-bookings'));
        
        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->reservation_m->prepare_data($this->input->post(), $this->data['fields']);

            // get calendar
            $calendar = $this->calendar_m->get_by(array('post_id' => $data['post_id']), TRUE);
            $data['calendar_id'] = $calendar->idcalendar;

            $calendar_fees = array();
            if($calendar && !empty($calendar->json_data_fees))
                $calendar_fees = json_decode($calendar->json_data_fees );

            /* message data */

            if ((empty( $data['price']) ||  $data['price'] == '0.00') && !empty($data['date_from']) && !empty($data['date_to'])) {
                if ((bool)strtotime($data['date_from'])) {
                    $data['date_from'] = date('Y-m-d H:i:s', strtotime($data['date_from']));
                }
            
                if ((bool)strtotime($data['date_to'])) {
                    $data['date_to'] = date('Y-m-d H:i:s', strtotime($data['date_to']));
                }

                $price = $this->reservation_m->calculate_price($data['post_id'], $data['date_from'], $data['date_to']);
                $_POST['price'] = $data['price'] = $price['price'];
                $_POST['currency_code'] = $data['currency_code'] = $price['currency_code'];
            }   

            /* if approved */
            if (!empty($id)) {
                $reservation = $this->reservation_m->get($id, true);
            }
            
            if(!$calendar->is_hour_enabled && !empty($data['date_from']) && !empty($data['date_to'])) {
                $data['date_from'] = date('Y-m-d 00:00:00', strtotime($data['date_from']));
                $data['date_to'] = date('Y-m-d 00:00:00', strtotime($data['date_to']));
            }
            $insert_id = $this->reservation_m->insert($data, $id);


            if (!empty($insert_id) && !empty($id) && wmvc_show_data('user_id', $data, false)) {
                /* if approved message */
                if($reservation->is_approved != 1 && wmvc_show_data('is_approved', $data) == 1) {
                    global $Winter_MVC_WDK;
                    $Winter_MVC_WDK->model('listing_m');
                    $Winter_MVC_WDK->model('listingusers_m');
                    $Winter_MVC_WDK->load_helper('listing');

                    $this->db->where("date_from <='".$data['date_from']."'");
                    $this->db->where("date_to >= '".$data['date_to']."'");
                    $price = $this->price_m->get_by(array('post_id'=>$data['post_id']), TRUE);

                    $user = get_userdata( wmvc_show_data('user_id', $data) );

                    $listing =  $Winter_MVC_WDK->listing_m->get($data['post_id'], TRUE);

                    $user_owner_id = NULL;
                    $user_data_owner = NULL;
                    if(wmvc_show_data('user_id_editor', $listing, '', TRUE, TRUE )) {
                        $user_owner_id = wmvc_show_data('user_id_editor', $listing, '', TRUE, TRUE );
                        if(wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE )) {
                            $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing, false, TRUE, TRUE ) );
                        }
                    }
                        
                    if(empty($user_data_owner)) {
                        $user_data_owner = array(
                            'display_name' => __('Administrator', 'wdk-bookings'),
                            'user_email' => get_bloginfo('admin_email'),
                        );
                    }

                    /* message */
                    $data_message = array();
                    $data_message['user'] = $user;
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['reservation'] = $data;
                    $data_message['listing'] =  $listing;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $data))
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();

                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments') && wmvc_show_data('payment_info', $calendar, false)) {
                        $data_message['data'][__('Payment info', 'wdk-bookings')] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('payment_info', $calendar, '-'));
                    }
                  
                    if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
                        $ret = wdk_mail(wdk_show_data('user_email', $user_data_owner, '' , TRUE, TRUE), __('New Reservation approved, please confirm as paid when you receive payment', 'wdk-bookings'), $data_message, 'reservation_approved_owner');
                        $ret = wdk_mail($user->user_email, __('Reservation approved, waiting for payment', 'wdk-bookings'), $data_message, 'reservation_approved_visitor');
                    } else {
                        /* auto create woo only if is_enable_noapprovements enabled */
                        global $Winter_MVC_WDK;
                        $user_owner_id = NULL;
                        $Winter_MVC_WDK->model('listingusers_m');
                        $Winter_MVC_WDK->model('listing_m');
                        $Winter_MVC_WDK->load_helper('listing');

                        $user_owner_id = wmvc_show_data('user_id_editor', $listing, '', TRUE, TRUE );
                        
                        /* auto create woo item and redirect to order */
                        if(class_exists( 'WooCommerce' )) {
                            $url_pay = '';
                            $title = __('Reservation for', 'wdk-bookings').' '.wdk_field_value ('post_title', wmvc_show_data('post_id', $data)).' #'.wmvc_show_data('post_id', $data);
                            if($user_owner_id) {
                                $title .= ' A'.$user_owner_id;
                            }
                            $title .= ' '.wmvc_show_data('date_from', $data).' - '.wmvc_show_data('date_to', $data); // The product's Title
                            
                            $post_args = array (
                                'post_author' => $user_owner_id, // The user's ID
                                'post_title' => $title, // The product's Title
                                'post_content' => str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-')), // The product's Title
                                'post_type' => 'product',
                                'post_status' => 'publish' // This could also be $data['status'];
                            );
                        
                            $_POST['woocommerce_product_id'] = $woo_id = wp_insert_post( $post_args );
                            // If the post was created okay, let's try update the WooCommerce values.
                            if ( ! empty( $woo_id ) && function_exists( 'wc_get_product' ) ) {
                                $product = wc_get_product( $woo_id );
                                $product->set_virtual(true);
                                $product->set_downloadable(true);
                                $product->set_sold_individually(true);
                                $product->set_sku( 'wdk-booking-' . $woo_id ); // Generate a SKU with a prefix. (i.e. 'pre-123') 
                                $product->set_regular_price(wmvc_show_data('price', $price)); // Be sure to use the correct decimal price.
                                $product->save(); // Save/update the WooCommerce order object.

                                $terms = array( 'exclude-from-catalog', 'exclude-from-search' );
                                wp_set_object_terms( $woo_id, $terms, 'product_visibility' );

                                update_post_meta($woo_id, '_manage_stock', 'yes');
                                update_post_meta($woo_id, '_stock', 1);

                                $wdk_attach_id = NULL;
                                $image_ids = explode(',', trim(wdk_show_data('listing_images' , $data_message['listing'], '', TRUE, TRUE), ','));

                                if(is_array($image_ids))
                                    $wdk_attach_id = $image_ids[0];
                        
                                set_post_thumbnail( $woo_id, $wdk_attach_id );
                                
                                /* set woo product id for reservation */
                                $update_data = array('woocommerce_product_id'=>$woo_id);
                                $this->reservation_m->insert($update_data, $insert_id);

                                if(function_exists('wc_get_cart_url')) {
                                    $url_pay = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($woo_id).'&reservation_id='.esc_attr($insert_id));
                                }
                            }
                            /* message */
                            $data_message['pay_link'] = $url_pay;
                            $ret = wdk_mail(wdk_show_data('user_email', $user, '' , TRUE, TRUE), __('Reservation approved, waiting for payment', 'wdk-bookings'), $data_message, 'reservation_user_payment_notify_not_expired');
                        }
                        
                    }
                
                }

                /* reservation completed when is_booked selected */
                if($reservation->is_booked != 1 && wmvc_show_data('is_booked', $data) == 1) {
                    global $Winter_MVC_WDK;
                    $Winter_MVC_WDK->model('listingusers_m');
                    $Winter_MVC_WDK->model('listing_m');
                    $Winter_MVC_WDK->load_helper('listing');

                    $listing_data =  $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $data), TRUE);

                    $user_client = get_userdata( wmvc_show_data('user_id', $data) );

                    /* send message to owner */
                    $owner_email = get_bloginfo('admin_email');
                    $user_data_owner = NULL;
                    if($listing_data) {
                        if(wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE )) {
                            $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE ) );
                            if($user_data_owner)
                                $owner_email = $user_data_owner->user_email;
                        }
                    }

                    if(empty($user_data_owner)) {
                        $user_data_owner = array(
                            'display_name' => __('Administrator', 'wdk-bookings'),
                            'user_email' => get_bloginfo('admin_email'),
                        );
                    }
                    
                    $data_message = array();
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['user_client'] = $user_client;
                    $data_message['reservation'] = $data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['listing'] =  $listing_data;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $data))
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();

                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    wdk_mail($owner_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_owner');
                    

                    /* send message to visitor */
                    $user = get_userdata( wmvc_show_data('user_id', $data) );
                    $data_message = array();
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['user_client'] = $user_client;
                    $data_message['reservation'] = $data;
                    $data_message['listing'] =  $listing_data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-bookings')=> wdk_get_date(wmvc_show_data('date_to', $data))
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-bookings').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-bookings')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();

                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    $ics_file = wp_upload_bits('reservation_'.$insert_id.'.ics', NULL, wdk_calendar_ical_export($insert_id));
                 
                    $attachments  = array();
                    if($ics_file)
                        $attachments[] = $ics_file['file'];

                    if( $user )
                        $ret = wdk_mail($user_client->user_email, __('Reservation Completed', 'wdk-bookings'), $data_message, 'reservation_completed_visitor', NULL, $attachments);


                }
            }

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-bookings-add&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->reservation_m->get($id, TRUE);
        }
        
        // Load view
        $this->load->view('wdk-bookings-add/index', $this->data);
    }

}
