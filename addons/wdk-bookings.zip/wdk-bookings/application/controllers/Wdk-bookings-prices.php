<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_prices extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
            } 
        }

        /* [Search Form] */

        $controller = 'price';
        $columns = array('idprice', 'search', 'order_by', 'post_title','post_id');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idprice DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idprice ASC' => __('ID', 'wdk-bookings').' ASC',  
                                          'date_from DESC' => __('Date From DESC', 'wdk-bookings'),  
                                          'date_from ASC' => __('Date From ASC', 'wdk-bookings'),  
                                          'date_to DESC' => __('Date To DESC', 'wdk-bookings'),  
                                          'date_to ASC' => __('Date To ASC', 'wdk-bookings'),  
                                        );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->price_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->price_m->total();

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['prices'] = $this->price_m->get_pagination($per_page, $offset, array(), wmvc_show_data('order_by', $db_data, 'date_from DESC'));

        // Load view
        $this->load->view('wdk-bookings-prices/index', $this->data);
    }

    public function edit()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('price_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->price_m->fields_list;

        //exit($this->db->last_query());

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-bookings'));
        $this->form->add_error_message('price_date_exists', __('Date already in use for this Listing/Post', 'wdk-bookings'));

        if(isset($_GET['post_id']))  {
            $this->data['db_data']['post_id'] = intval($_GET['post_id']);
        }
       
        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->price_m->prepare_data($this->input->post(), $this->data['fields']);

            // get calendar
            $calendar = $this->calendar_m->get_by(array('post_id' => $data['post_id']), TRUE);
            $data['calendar_id'] = $calendar->idcalendar;
            
            if(!$calendar->is_hour_enabled && !empty($data['date_from']) && !empty($data['date_to'])) {
                $data['date_from'] = date('Y-m-d 00:00:00', strtotime($data['date_from']));
                $data['date_to'] = date('Y-m-d 00:00:00', strtotime($data['date_to']));
            }
            $insert_id = $this->price_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-bookings-prices&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->price_m->get($id, TRUE);
        }

        // Load view
        $this->load->view('wdk-bookings-prices/edit', $this->data);
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('price_m');

        $this->price_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-bookings-prices&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('price_m');
    
            $this->price_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-prices"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('price_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('price_m', $post_id);
            $this->price_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-prices"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('price_m');
            if(function_exists('wdk_access_check'))
            wdk_access_check('price_m', $post_id);
            $this->price_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-prices"));
    }

}
