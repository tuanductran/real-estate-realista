<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_bookings_payouts extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'report';
        $columns = array('idreport', 'month', 'order_by', 'year', 'total_price_net');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idreport DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreport ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->report_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->report_m->total();

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['payouts'] = $this->report_m->get_pagination($per_page, $offset);

        //echo $this->db->last_query();

        // Load view
        $this->load->view('wdk-bookings-payouts/index', $this->data);
    }

    public function view_report_user_paid()
    {
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        $owner_email = sanitize_email($_GET['owner_email']);
        $report_id = intval($_GET['id']);

        $reports = $this->reportdata_m->get_pagination(NULL, NULL, array('report_id' => $report_id, 'owner_email' => $owner_email), NULL, NULL);

        if(!isset($reports[0]))exit('Report not found');

        $total_earnings = 0;
        foreach($reports as $payout)
        {
            $total_earnings += $payout->total_price_net;
        }

        $this->reportdata_m->update(array('is_payout' => '1', 'date_payout' => current_time( 'mysql' )), array('report_id' => $report_id, 'owner_email' => $owner_email));

        //send email
        $subject = __('Payout for month', 'wdk-bookings').' '.$reports[0]->year.'-'.$reports[0]->month;
          
        /* message data */
        $data_message = array();
        $data_message['Payout date'] = $reports[0]->date_payout;
        $data_message['Payout amount'] = esc_html((100-$reports[0]->fee_percentage)/100*$total_earnings);
        $data_message['Email'] = $owner_email;

        $ret =  wdk_mail( $owner_email, $subject, $data_message, 'default');

        //exit($this->db->last_query());

        wp_redirect(admin_url("admin.php?page=wdk-bookings-payouts&function=view_report_user&id=$report_id&owner_email=$owner_email"));
    }

    public function view_report_user_export()
	{
        ob_clean();

        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        /* [Search Form] */

        $owner_email = sanitize_email($_GET['owner_email']);

        $controller = 'reportdata';
        $columns = array('idreportdata', 'month','user_email','owner_email', 'order_by', 'year', 'total_price_net');
        $external_columns = array('report_id');

        $this->data['order_by']   = array('idreportdata DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreportdata ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->reportdata_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        $report_id = intval($_GET['id']);

        $per_page = NULL;
        $offset = NULL;

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['payouts'] = $this->reportdata_m->get_pagination($per_page, $offset, array('report_id' => $report_id, 'owner_email' => $owner_email), NULL, NULL);

        $skip_cols = array();

        $csv_list = $this->prepare_export($this->data['payouts'], $skip_cols);
        
        header('Content-Type: application/csv');
        header("Content-Length:".strlen($csv_list));
        header("Content-Disposition: attachment; filename=payout_report_user_".$report_id.'_'.date('Y-m-d-H-i-s', time()+get_option('gmt_offset')*60*60).".csv");

        echo $csv_list;
        exit();
    }

    public function view_report_user()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        /* [Search Form] */

        $owner_email = sanitize_email($_GET['owner_email']);

        $controller = 'reportdata';
        $columns = array('idreportdata', 'month','user_email','owner_email', 'order_by', 'year', 'total_price_net');
        $external_columns = array('report_id');

        $this->data['order_by']   = array('idreportdata DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreportdata ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->reportdata_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $report_id = intval($_GET['id']);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reportdata_m->total(array('report_id' => $report_id, 'owner_email' => $owner_email));

        //exit($this->db->last_query());

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['payouts'] = $this->reportdata_m->get_pagination($per_page, $offset, array('report_id' => $report_id, 'owner_email' => $owner_email), NULL, NULL);

        $this->data['payouts_total'] = $this->reportdata_m->get_pagination(NULL, NULL, array('report_id' => $report_id, 'owner_email' => $owner_email), NULL, NULL);

        $this->data['total_earnings'] = 0;
        foreach($this->data['payouts_total'] as $payout)
        {
            $this->data['total_earnings'] += $payout->total_price_net;
        }

        //echo wdk_db_table($this->data['payouts']);

        //echo $this->db->last_query();

        // Load view
        $this->load->view('wdk-bookings-payouts/view_report_user', $this->data);
    }

    public function view_report_export()
	{
        ob_clean();

        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        /* [Search Form] */

        $controller = 'reportdata';
        $columns = array('idreportdata', 'month','user_email','owner_email', 'order_by', 'year', 'total_price_net');
        $external_columns = array('report_id');

        $this->data['order_by']   = array('idreportdata DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreportdata ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->reportdata_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        $report_id = intval($_GET['id']);
        $this->data['report_id'] = $report_id;

        $per_page = NULL;
        $offset = NULL;

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['payouts'] = $this->reportdata_m->get_pagination($per_page, $offset, array('report_id' => $report_id), NULL, 'owner_email');

        $skip_cols = array();

        foreach($this->data['payouts'] as $key=>$report)
        {
            $user = get_user_by( 'email', $report->owner_email );
                            
            $this->data['payouts'][$key]->IBAN = wmvc_show_data('wdk_iban', $user , '-'); 
            $this->data['payouts'][$key]->Payout = esc_html((100-$report->fee_percentage)/100*$report->total_price_net_sum);
        }

        $csv_list = $this->prepare_export($this->data['payouts'], $skip_cols);
        
        header('Content-Type: application/csv');
        header("Content-Length:".strlen($csv_list));
        header("Content-Disposition: attachment; filename=payout_report_".$report_id.'_'.date('Y-m-d-H-i-s', time()+get_option('gmt_offset')*60*60).".csv");

        echo $csv_list;
        exit();
    }

    public function view_report()
	{
        $this->load->model('calendar_m');
        $this->load->model('price_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        /* [Search Form] */

        $controller = 'reportdata';
        $columns = array('idreportdata', 'month','user_email','owner_email', 'order_by', 'year', 'total_price_net');
        $external_columns = array('report_id');

        $this->data['order_by']   = array('idreportdata DESC' => __('ID', 'wdk-bookings').' DESC', 
                                          'idreportdata ASC' => __('ID', 'wdk-bookings').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-bookings'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-bookings'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->reportdata_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        $report_id = intval($_GET['id']);
        $this->data['report_id'] = $report_id;

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->reportdata_m->total(array('report_id' => $report_id), 'owner_email');

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['payouts'] = $this->reportdata_m->get_pagination($per_page, $offset, array('report_id' => $report_id), NULL, 'owner_email');

        //echo wdk_db_table($this->data['payouts']);

        //echo $this->db->last_query();

        // Load view
        $this->load->view('wdk-bookings-payouts/view_report', $this->data);
    }

    public function report()
	{
        $this->load->model('calendar_m');
        $this->load->model('report_m');
        $this->load->model('reportdata_m');
        $this->load->model('reservation_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('calendar_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->report_m->fields_list;
        $this->data['calendar_fees'] = array();


        //exit($this->db->last_query());

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->report_m->prepare_data($this->input->post(), $this->data['fields']);
            
            // generate report

            $payouts_total = $this->reservation_m->get_payouts_total(array('paid_date_table.meta_value LIKE \''.$data['year'].'-'.$data['month'].'%\'' => NULL));

            if(count($payouts_total) > 0)
            {
                $payout = $payouts_total[0];

                $data['users'] = $payout->user_count;
                $data['total_price_net'] = $payout->total_paid-$payout->tax_paid;
                $data['currency_code'] = $payout->currency_code;
                $data['fee_percentage'] = get_option('wdk_bookings_fee_percentage', 0);
    
                $report_id = $this->report_m->insert($data, NULL);
    
                //exit($this->db->last_error());
            }

            $payouts = $this->reservation_m->get_payouts(array('paid_date_table.meta_value LIKE \''.$data['year'].'-'.$data['month'].'%\'' => NULL));

            //echo $this->db->last_query();

            //echo wdk_db_table($payouts);

            foreach($payouts as $payout)
            {
                $data = array(
                    'report_id' => $report_id,
                    'owner_email' => $payout->owner_email,
                    'guest_email' => $payout->guest_email,
                    'listing_id' => $payout->listing_id,
                    'reservation_id' => $payout->reservation_id,
                    'order_id' => $payout->order_id,
                    'listing_title' => $payout->post_title,
                    'listing_address' => $payout->address,
                    'date_from' => $payout->date_from,
                    'date_to' => $payout->date_to,
                    'date_paid' => $payout->paid_date,
                    'is_payout' => FALSE,
                    'total_price_net' => $payout->total_paid - $payout->tax_paid,
                    'currency_code' => $payout->currency_code,
                    'notes' => $payout->notes,
                );

                $this->reportdata_m->insert($data, NULL);

                echo $this->db->last_error();
            }

            //echo '<pre>';
            //var_dump($payouts);
            //echo '</pre>';

            // redirect
            
            if(empty($this->db->last_error()))
            {
                wp_redirect(admin_url("admin.php?page=wdk-bookings-payouts"));
                exit;
            }
        }



        // Load view
        $this->load->view('wdk-bookings-payouts/report', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('report_m');
    
            $this->report_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-bookings-payouts"));
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('report_m');

        $this->report_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-bookings-payouts&paged=$paged"));
    }

    private function prepare_export($data, $skip_cols)
    {
        $counter=0;
        $print_data = '';
    
        foreach($data as $key_log=>$row_log)
        {
            // print only keys if first row
            if($counter==0)
            {
                //Define CSV format for Excel
                $print_data.="sep=;\r\n";
    
                foreach($row_log as $key=>$val)
                {
                    if(!is_string($key) || in_array($key, $skip_cols))continue;
    
                    $print_data.='"'.$key.'";';    
                }
                $print_data.="\r\n";
            }
    
            foreach($row_log as $key=>$val)
            {
                if(!is_string($key) || in_array($key, $skip_cols))continue;
    
                if(is_string($val))
                {
                    $val_prepared = strip_tags(htmlspecialchars($val));
                    $val_prepared = '"'.$val_prepared.'"';
    
                    $print_data.=$val_prepared.';';
                }
                else
                {
                    $print_data.=';';
                }
            }
            $print_data.="\r\n";
    
            $counter++;
        }
    
        $print_data.= "\r\n";
    
        return $print_data;
    }

}