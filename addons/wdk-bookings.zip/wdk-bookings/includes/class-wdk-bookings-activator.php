<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Bookings
 * @subpackage Wdk_Bookings/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Bookings_Activator {

    public static $db_version = 2.5;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

        $prefix = 'wdk_booking_';

	}

    public static function plugins_loaded()
    {
		if ( get_site_option( 'wdk_booking_db_version' ) === false ||
		     get_site_option( 'wdk_booking_db_version' ) < self::$db_version ) {
			self::install();
		}
    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0
        if(get_site_option( 'wdk_booking_db_version' ) === false)
        {
            // Main table for booking calendar

            $table_name = $wpdb->prefix . 'wdk_booking_calendar';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idcalendar` int(11) NOT NULL AUTO_INCREMENT,
                    `post_id` int(11) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `is_activated` tinyint(1) DEFAULT NULL,
                    `is_hour_enabled` tinyint(1) DEFAULT NULL,
                PRIMARY KEY  (idcalendar)
            ) $charset_collate COMMENT='Booking calendar';";
        
            dbDelta( $sql );

            // Main table for booking calendar

            $table_name = $wpdb->prefix . 'wdk_booking_price';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idprice` int(11) NOT NULL AUTO_INCREMENT,
                    `calendar_id` int(11) DEFAULT NULL,
                    `post_id` int(11) DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `date_from` datetime DEFAULT NULL,
                    `date_to` datetime DEFAULT NULL,
                    `is_activated` tinyint(1) DEFAULT NULL,
                    `price_hour` decimal(13,2) DEFAULT NULL,
                    `price_day` decimal(13,2) DEFAULT NULL,
                    `price_week` decimal(13,2) DEFAULT NULL,
                    `price_month` decimal(13,2) DEFAULT NULL,
                    `price_year` decimal(13,2) DEFAULT NULL,
                    `currency_code` varchar(20) DEFAULT NULL,
                    `min_hours` int(11) DEFAULT NULL,
                    `changeover_day` int(11) DEFAULT NULL,
                    `guests` int(11) DEFAULT NULL,
                    `is_children_acceptable` tinyint(1) DEFAULT NULL,
                    `is_pets_acceptable` tinyint(1) DEFAULT NULL,
                PRIMARY KEY  (idprice)
            ) $charset_collate COMMENT='Booking prices';";

            dbDelta( $sql );

            $table_name = $wpdb->prefix . 'wdk_booking_reservation';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreservation` int(11) NOT NULL AUTO_INCREMENT,
                    `calendar_id` int(11) DEFAULT NULL,
                    `post_id` int(11) DEFAULT NULL,
                    `user_id` int(11)  DEFAULT NULL,
                    `date` datetime DEFAULT NULL,
                    `date_from` datetime DEFAULT NULL,
                    `date_to` datetime DEFAULT NULL,
                    `is_approved` tinyint(1) DEFAULT NULL,
                    `is_paid` tinyint(1) DEFAULT NULL,
                    `is_booked` tinyint(1) DEFAULT NULL,
                    `price` decimal(13,2) DEFAULT NULL,
                    `price_paid` decimal(13,2) DEFAULT NULL,
                    `currency_code` varchar(20) DEFAULT NULL,
                    `notes` text DEFAULT '',
                PRIMARY KEY  (idreservation)
            ) $charset_collate COMMENT='Booking reservations';";
            
            dbDelta( $sql );

            update_option( 'wdk_booking_db_version', "1" );
            update_option( 'wdk_bookings_calendar_single', "1" );
            
            self::$db_version = 1;
        }
    
        
        /* version 1.1.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.1' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `is_disable_for_not_login` tinyint(1) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.1;
            /* udpate option with db version */
        }
       
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.2' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `is_enable_auto_import` tinyint(1) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `import_public_url` VARCHAR(256) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.2;
            /* udpate option with db version */
        }

        /* version 1.3.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.3' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `is_enable_public_url` tinyint(1) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.3;
            /* udpate option with db version */
        }

        /* version 1.3.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.4' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_reservation';
            $sql = "ALTER TABLE `$table_name` ADD `source` VARCHAR(100) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `external_uid` VARCHAR(256) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.4;
            /* udpate option with db version */
        }

        /* version 1.5.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.5' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_price';

            $sql = "ALTER TABLE `$table_name` ADD `payment_info` text DEFAULT '';";
            $wpdb->query($sql);

            self::$db_version = 1.5;
            /* udpate option with db version */
        }

        /* version 1.6.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.6' ) {
           
            $table_name = $wpdb->prefix . 'wdk_booking_calendar';

            $sql = "ALTER TABLE `$table_name` ADD `is_enable_noapprovements` tinyint(1) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            $table_name = $wpdb->prefix . 'wdk_booking_reservation';
            $sql = "ALTER TABLE `$table_name` ADD `woocommerce_product_id` int(11) NULL DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.6;
            /* udpate option with db version */
        }

        /* version 1.7.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.7' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_reservation';
            $sql = "ALTER TABLE `$table_name` ADD `date_expire` datetime DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.7;
            /* udpate option with db version */
        }

        /* version 1.8.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.8' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `json_data_fees` text DEFAULT NULL;";
            $wpdb->query($sql);
            self::$db_version = 1.8;
            /* udpate option with db version */
        }
        

        /* version 1.9.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '1.9' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `is_guests_disabled` text DEFAULT NULL;";
            $wpdb->query($sql);
            self::$db_version = 1.9;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.0' ) {


            $table_name = $wpdb->prefix . 'wdk_booking_calendar';
            $sql = "ALTER TABLE `$table_name` ADD `currency_code` varchar(20) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD  `min_hours` int(11) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `changeover_day` int(11) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `guests` int(11) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `is_children_acceptable` tinyint(1) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `is_pets_acceptable` tinyint(1) DEFAULT NULL";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `payment_info` text DEFAULT ''";
            $wpdb->query($sql);

            self::$db_version = 2.0;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.1' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_calendar';

            $sql = "ALTER TABLE `$table_name` ADD `is_import_remove_old_dates` tinyint(1) DEFAULT NULL";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `import_availability_to_date` datetime DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 2.1;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.2' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_price';

            $sql = "ALTER TABLE `$table_name` ADD `max_hours` INT(11) DEFAULT NULL";
            $wpdb->query($sql);

            self::$db_version = 2.2;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.3' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_report';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreport` int(11) NOT NULL AUTO_INCREMENT,
                    `month` text DEFAULT '',
                    `year` text DEFAULT '',
                    `date` datetime DEFAULT NULL,
                    `users` int(11)  DEFAULT NULL,
                    `total_price_net` decimal(13,2) DEFAULT NULL,
                    `currency_code` varchar(20) DEFAULT NULL,
                    `fee_percentage` int(11)  DEFAULT NULL,
                    `notes` text DEFAULT '',
                PRIMARY KEY  (idreport)
            ) $charset_collate COMMENT='Reports main data';";
            
            dbDelta( $sql );

            $table_name = $wpdb->prefix . 'wdk_booking_reportdata';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idreportdata` int(11) NOT NULL AUTO_INCREMENT,
                    `report_id` int(11)  DEFAULT NULL,
                    `owner_email` text DEFAULT '',
                    `guest_email` text DEFAULT '',
                    `order_id` text DEFAULT '',
                    `reservation_id` text DEFAULT '',
                    `listing_id` int(11)  DEFAULT NULL,
                    `listing_title` text DEFAULT '',
                    `listing_address` text DEFAULT '',
                    `date` datetime DEFAULT NULL,
                    `date_from` datetime DEFAULT NULL,
                    `date_to` datetime DEFAULT NULL,
                    `date_paid` datetime DEFAULT NULL,
                    `date_payout` datetime DEFAULT NULL,
                    `is_payout` tinyint(1) DEFAULT NULL,
                    `total_price_net` decimal(13,2) DEFAULT NULL,
                    `currency_code` varchar(20) DEFAULT NULL,
                    `notes` text DEFAULT '',
                PRIMARY KEY  (idreportdata)
            ) $charset_collate COMMENT='Reports archive data';";
            
            dbDelta( $sql );

            self::$db_version = 2.3;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.4' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_reservation';

            $sql = "ALTER TABLE `$table_name` ADD `is_payment_expired` tinyint(1) DEFAULT NULL";
            $wpdb->query($sql);

            self::$db_version = 2.4;
            /* udpate option with db version */
        }

        /* version 2.0.0 db install */
        if ( get_site_option( 'wdk_booking_db_version' ) < '2.5' ) {

            $table_name = $wpdb->prefix . 'wdk_booking_reservation';

            $sql = "ALTER TABLE `$table_name` ADD `is_imported` tinyint(1) DEFAULT NULL";
            $wpdb->query($sql);

            self::$db_version = 2.5;
            /* udpate option with db version */
        }

        
        
        update_option( 'wdk_booking_db_version', self::$db_version );
    }

}
