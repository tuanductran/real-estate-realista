(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	 
	 $( document ).on('ready', function() {
		$('.wdk-booking-listing-calendar .wdk-btn-pag').on('click', function (e) {
			e.preventDefault();
			var btn = $(this);
			var parent = btn.closest('.wdk-booking-listing-calendar');

			if (btn.hasClass('next')) {
				parent.find('.wdk-booking-listing-calendar-addinition[style*="none"]').first().slideDown('slow', function(){
					btn.parent().find('.pre').removeClass('noactive')
					if(!parent.find('.wdk-booking-listing-calendar-addinition[style*="none"]').length) {
						btn.parent().find('.next').addClass('noactive')
					} 
				});
			} else {
				parent.find('.wdk-booking-listing-calendar-addinition:not([style*="none"])').last().slideUp('slow', function(){
					btn.parent().find('.next').removeClass('noactive')
					if(!parent.find('.wdk-booking-listing-calendar-addinition:not([style*="none"])').length) {
						btn.parent().find('.pre').addClass('noactive')
					} 
				});
			}
		});

		//wdk_booking_quick_search();


		jQuery('.wdk-booking-quick-submission form').each(function(){
			wdk_booking_quick_reservation('.wdk-modal'+jQuery(this).attr('data-wdk-target'), jQuery(this));
		});

		jQuery('.wdk-booking-quick-submission .wdk-field-group .field-box .icon').on('click', function() {
			jQuery(this).parent().find('input,select').trigger('focus')
		});

	})

})(jQuery);

const wdk_booking_quick_reservation = ($modal_selector = '.wdk-booking-modal-search', $search_form_selector = '.wdk-booking-quick-submission form') => {
var $ = jQuery;
	var init,set_step,event_step_1,event_step_2,loading_listings,modal,search_form,step_1_container,step_2_container, event_navigations, reset, price_calculate;
	var $results_container = '.booking_quick_results', $alert_container = '.alert_box';

	init = () => {
		modal = jQuery($modal_selector);
		search_form = jQuery($search_form_selector);
		step_1_container = modal.find('.step[data-step="1"]');
		step_2_container = modal.find('.step[data-step="2"]');
		event_navigations();

		search_form.on('submit', function(e){
			e.preventDefault();
			let date_from = search_form.find('input[name="date_from"]').val();
			let date_to = search_form.find('input[name="date_to"]').val();
			let adult = search_form.find('select[name="adult"]').find(":selected").val() || '';

			if(search_form.find('input[name="post_id"]').length && search_form.find('input[name="post_id"]').val() != '') {
				/* step 2, quick reservation */
				step_2_container.find('.wdk-booking-modal-form input[name="date_from"]').val(date_from);
				step_2_container.find('.wdk-booking-modal-form input[name="date_to"]').val(date_to);
				step_2_container.find('.wdk-booking-modal-form input[name="listing_id"]').val(search_form.find('input[name="post_id"]').val());
				
				step_2_container.find('.wdk-booking-modal-form select[name="guests_number_adults"]').find("option[value='"+adult+"']").prop('selected', true);
				step_2_container.find('.block.top .value.date_from').html(date_from);
				step_2_container.find('.block.top .value.date_to').html(date_to);

				step_2_container.find('.block.listing .value.listing_title').html(search_form.find('input[name="post_id"]').attr('data-listing_title'));
				step_2_container.find('.block.listing .value.reservation_price').html('<i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking"></i>');
				var form = step_2_container.find('.wdk-booking-modal-form');
				price_calculate(form);
				set_step(2)

			} else {
				/* step 1 */
				step_1_container.find('.wdk-booking-modal-form input[name="date_from"]').val(date_from);
				step_1_container.find('.wdk-booking-modal-form input[name="date_to"]').val(date_to);
		
				loading_listings(date_from, date_to);
		
				set_step(1)
			}
			
			modal.show().toggleClass("active");
			jQuery("body").addClass("wdk-overlay-bgg");
		});


		jQuery("html").on("click", function (e) {
			if (jQuery(e.target).closest('.modal-content').length) return;
			reset();
		});
	
		jQuery('*[data-wdk-dismiss="modal"]').on('click', function(e){
			e.preventDefault();
			reset();
		});
	
	};

	set_step = ($step = 1) => {
		modal.find('.steps .step').addClass('wdk-hidden');
		modal.find('.steps .step[data-step="'+$step+'"]').removeClass('wdk-hidden');

		switch (+$step) {
			case 1:
					event_step_1();
					break;
			case 2:

					event_step_2();
					break;
		
			default:
					break;
		}
	};

	reset = () => {
		step_1_container.find('.booking_quick_results_alert_box').html('')
		step_1_container.find($alert_container).html('')


		modal.find('.reset_field').val('');
		modal.find('input[name="childrens_allowed"],input[name="pets_allowed"]').prop('checked', false);
	};

	event_navigations = () => {
		modal.find('.wdk-btn-change-step').on('click', function(e){
			e.preventDefault();
			/* validation */
			/* step 1 */
			if(!step_1_container.find("input[name='listing_id']:checked").length) {
				step_1_container.find('.booking_quick_results_alert_box').html('<p class="alert alert-info">'+wdk_bookings_script_parameters.text.select_listing+'</p>')
				wdk_log_notify(wdk_bookings_script_parameters.text.select_listing, 'error');
				return;
			}

			if(jQuery(this).attr('data-step') == 2) {
				let date_from = step_1_container.find('input[name="date_from"]').val();
				let date_to = step_1_container.find('input[name="date_to"]').val();
				let adult = search_form.find('select[name="adult"]').find(":selected").val() || '';

				step_2_container.find('.wdk-booking-modal-form').find('input[name="date_from"]').val(date_from);
				step_2_container.find('.wdk-booking-modal-form').find('input[name="date_to"]').val(date_to);
				step_2_container.find('.wdk-booking-modal-form').find('input[name="listing_id"]').val(step_1_container.find("input[name='listing_id']:checked").val());

				step_2_container.find('.block.top .value.date_from').html(date_from);
				step_2_container.find('.block.top .value.date_to').html(date_to);
				step_2_container.find('.wdk-booking-modal-form select[name="guests_number_adults"]').find("option[value='"+adult+"']").prop('selected', true);
				
				step_2_container.find('.block.listing .value.listing_title').html(step_1_container.find("input[name='listing_id']:checked").attr('data-listing_title'));
				step_2_container.find('.block.listing .value.reservation_price').html(step_1_container.find("input[name='listing_id']:checked").attr('data-price_total'));
			}

			set_step(jQuery(this).attr('data-step'));
		});
	};

	event_step_1 = () => {

		step_1_container.find($results_container).find('tbody tr').on('click', function(e){
			jQuery(this).find('input').prop('checked','checked');
			return;
		});

		step_1_container.find('.wdk-booking-modal-form').off().on('submit', function(e){
			e.preventDefault();
			let self = jQuery(this);

			let date_from = self.find('input[name="date_from"]').val();
			let date_to = self.find('input[name="date_to"]').val();
	
			loading_listings(date_from, date_to);
		});

		step_1_container.find('.wdk-booking-modal-form input').off().on('input', function(){
			step_1_container.find('.wdk-booking-modal-form').trigger('submit');
		});

		$('.wdk-fielddate_range').each(function(){
			var opens = 'left';
			if ($(this).hasClass('center'))
				opens = 'center';
			
			var date_format = wdk_bookings_script_parameters.format_date;
			if ($(this).attr('date-format'))
				date_format = $(this).attr('date-format');
			
			var singleDatePicker = false;
			if ($(this).attr('data-wdksingle')) {
				singleDatePicker = true;
			}

			$(this).daterangepicker({
				timePicker: false,
				opens: opens,
				autoApply: true,
				minDate: new Date(),
				"minSpan": {
					"hours": 25
				},
				isInvalidDate: function (date) {
					if (typeof isinvaliddates != 'undefined' && isinvaliddates != '') {
						if (isinvaliddates.indexOf(date.format('YYYY-MM-DD')) != -1)
							return true;
						
						return false;
					}
					
					if (typeof isallowdates != 'undefined' && isallowdates != '') {
						if (isallowdates.indexOf(date.format('YYYY-MM-DD')) != -1)
							return false;
						
						return true;
					}

					return false;
				},
				autoUpdateInput: false,
				"timePickerSeconds": false,
				timePicker24Hour: true,
				locale: {
					format: date_format
				}
			}).on('showCalendar.daterangepicker', function(ev, picker) {
				//do something, like clearing an input
				$('.calendar-table').each(function(){
					var el = $(this).find(".table-condensed .month").first().parent().children().last();
					if (!el.hasClass('next available')) {
						el.addClass('next available');
						el.append('<span></span>');
					}
				})

				var picker_el = $(picker.container);
				picker_el.find('.calendar-table').removeClass('from_picker to_picker');
				if(picker_el.find('.drp-calendar.left').length && picker_el.find('.drp-calendar.right').length && picker_el.find('.drp-calendar.right').css('display') != 'none') {
					picker_el.find('.drp-calendar.left .calendar-table').addClass('from_picker');
					picker_el.find('.drp-calendar.right .calendar-table').addClass('to_picker');
				} else {
					if (ev.currentTarget.classList.contains('date_from')) {
						picker_el.find('.calendar-table').addClass('from_picker');
					} else if (ev.currentTarget.classList.contains('date_to')) {
						picker_el.find('.calendar-table').addClass('to_picker');
					} 
				}
			});

			if (singleDatePicker && !$('body').hasClass('wdk-single-calendar')) {
				$('body').addClass('wdk-single-calendar');
			}
		});
		$('.wdk-fielddate_range').on('apply.daterangepicker', function (ev, picker) {
			let parent = $(ev.target).closest('form')
			parent.find('.wdk-fielddate_range.date_from').val(picker.startDate.format(wdk_bookings_script_parameters.format_date));
			parent.find('.wdk-fielddate_range.date_to').val(picker.endDate.format(wdk_bookings_script_parameters.format_date));

			parent.find('.wdk-fielddate_range.date_from').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_date));
			parent.find('.wdk-fielddate_range.date_from').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_date));

			parent.find('.wdk-fielddate_range.date_to').data('daterangepicker').setStartDate(picker.startDate.format(wdk_bookings_script_parameters.format_date));
			parent.find('.wdk-fielddate_range.date_to').data('daterangepicker').setEndDate(picker.endDate.format(wdk_bookings_script_parameters.format_date));

			parent.find('.wdk-fielddate_range.date_from').trigger('input');
		});
	
		$('.wdk-fielddate_range').on('cancel.daterangepicker', function (ev, picker) {
			let parent = $(ev.target).closest('form')
			parent.find('.wdk-fielddate_range[name="date_from]"').val('');
			parent.find('.wdk-fielddate_range.date_to').val('');
		});
	};

	event_step_2 = () => {

        var form = step_2_container.find('.wdk-booking-modal-form');
		step_2_container.find('.fees_box').html('');
		var box_alert = step_2_container.find($alert_container);
		box_alert.html('');
		
		price_calculate(form); 
        form.find('input[name="date_to"],.fees_checkbox,select[name="guests_number_adults"],select[name="guests_number_childs"]').off().on('change', function(){
            price_calculate(form); 
        });

		step_2_container.find('.wdk-booking-modal-form').off().on('submit', function(e){
			e.preventDefault();

			box_alert.html('');
			
			var data = jQuery(this).serializeArray();
			data.push({ name: 'action', value: "wdk_bookings_public_action" });
			data.push({ name: 'page', value: "wdk_bookings_frontendajax" });
			data.push({ name: 'function', value: "send_reservation" });

			// Loop through the array and edit values
			$.each(data, function(index, field) {
				if (field.name == "date_to" || field.name == "date_from") {
					field.value = wdk_booking_fix_date(field.value);
				}
				// You can add more conditions for other form fields if needed
			});

			jQuery.post(wdk_bookings_script_parameters.ajax_url, data, 
				function (data) {

				if(data.message)
					box_alert.html(data.message);

				if(data.popup_text_success)
					wdk_log_notify(data.popup_text_success);
					
				if(data.popup_text_error)
					wdk_log_notify(data.popup_text_error, 'error');
					
				if(data.success)
				{
					
                    if(typeof data.redirect !='undefined' && data.redirect !='') {
                        window.location = data.redirect;
                    }

					setTimeout(() => {
						jQuery('.wdk-modal').hide().removeClass("active");
						jQuery("body").removeClass("wdk-overlay-bgg");
						reset();
					}, 5000);
				} else {

				}
			}).always(function(data) {
				step_2_container.find('.fa-ajax-indicator').css('display', 'none');
			});
		});

	};

	loading_listings = ($date_from ='', $date_to ='') => {

			var container = step_1_container.find($results_container);
			var box_alert = step_1_container.find($alert_container);
			
			box_alert.html('');
			var data = new Array();
			data.push({ name: 'action', value: "wdk_bookings_public_action" });
            data.push({ name: 'page', value: "wdk_bookings_frontendajax" });
            data.push({ name: 'function', value: "loading_listings" });
            data.push({ name: 'date_from', value: $date_from });
            data.push({ name: 'date_to', value: $date_to });

			container.addClass('loading');
			
			jQuery.post(wdk_bookings_script_parameters.ajax_url, data, 
				function (data) {
				container.find('tbody').html();

				if(data.message)
					box_alert.html(data.message);
	
				if(data.popup_text_success)
					wdk_log_notify(data.popup_text_success);
					
				if(data.popup_text_error)
					wdk_log_notify(data.popup_text_error, 'error');


				if(data.success)
				{
					var html = '';
					for (var listing of data.output) {
						html += '<tr>\n\
									<td><input type="radio" name="listing_id" value = "'+listing.post_id+'" data-listing_title = "'+listing.post_title+'" data-price_total = "'+listing.price_total+'"></td>\n\
									<td><img src="'+listing.thumbnail+'" alt="'+listing.post_title+'" class="thumbnail"></img></td>\n\
									<td>'+listing.post_title+'<div class="sub-description">'+listing.description+'</div></td>\n\
									<td><a href="'+listing.link+'" title="'+listing.post_title+'" target="blank"><span class="dashicons dashicons-visibility"></span></a></td>\n\
									<td>'+listing.price_total+'</td>\n\
								</tr>';
					}

					container.find('tbody').html(html);
				} else {

				}
									
				if(data.output_message) {
					container.find('tbody').html('<tr class="clear_event"><td colspan="9" style="padding:15px 0">'+data.output_message+'</td></tr>');
				}
			}).always(function(data) {
				container.removeClass('loading');
				step_1_container.find('.fa-ajax-indicator').css('display', 'none');
				event_step_1();
			});
	};

	var price_calculate_jqxhr = null;
	price_calculate = (form) => {
		if(typeof form == 'undefined') {
			return false;
		}
		step_2_container.find('.block.listing .value.reservation_price').html('<i class="fa fa-spinner fa-spin fa-custom-ajax-indicator ajax-indicator-masking"></i>');
		var price_place = step_2_container.find('.price_list');
		var fees_box_place = step_2_container.find('.fees_box');
		
		price_place.html('');
		
		var data = {
			"action": 'wdk_public_action',
			"page": 'wdk_frontendajax',
			"function": 'booking_price_calculate',
		};
		data['post_id'] = form.find('[name="listing_id"]').val();
		data['date_from'] = form.find('[name="date_from"]').val();
		data['date_to'] = form.find('[name="date_to"]').val() ;
		data['guests'] = +(form.find('[name="guests_number_adults"] option:selected').val())+(+(form.find('[name="guests_number_childs"] option:selected').val()));

		data['date_from'] = wdk_booking_fix_date(data['date_from']);
		data['date_to'] = wdk_booking_fix_date(data['date_to']);
		

		form.find('.fees_checkbox:not([disabled])').each(function(){
			if(jQuery(this).prop('checked')) {
				data[jQuery(this).attr('name')] = 1 ;
			} else {
				data[jQuery(this).attr('name')] = 0 ;
			}
		});

		// Assign handlers immediately after making the request,
		// and remember the jqxhr object for this request
		if (price_calculate_jqxhr != null)
			price_calculate_jqxhr.abort();

		price_calculate_jqxhr = jQuery.post(wdk_bookings_script_parameters.ajax_url, data, function(data) {

			if(data.popup_text_success)
				wdk_log_notify(data.popup_text_success);
				
			if(data.popup_text_error)
				wdk_log_notify(data.popup_text_error, 'error');
				
			if(data.success)
			{

				step_2_container.find('.block.listing .value.reservation_price').html(data.results.total+' '+data.results.symbol);

				var html = '';
				html += "<ul class='list_booking_price'>"
				html += "<li class='price'><b class='fee-title'>"+wdk_bookings_script_parameters.text.price+"</b> <span class='fee-value'>"+data.results.price+' '+data.results.symbol+"</span></li>";
				jQuery.each(data.results.fees, function(k,v){
					html += "<li class='fee'><b class='fee-title'>"+k+"</b> <span class='fee-value'>"+v+' '+data.results.symbol+"</span></li>";
				});
				html += "</ul>"

				price_place.html(html);

				if(!fees_box_place.children().length) {
					var html = '';
					fees_box_place.html('');
					jQuery.each(data.results.fees_data, function(k,v){
						let readonly = '';
						if(v.is_required == 1) {
							readonly = 'readonly disabled';
						}

						html += " \n\
								<div class='wdk-col-6'>\n\
									<div class='wdk-form-group'>\n\
										<div class='input'>\n\
											<label for='fee_"+v.field_id+"' class='term'>\n\
												<input type='checkbox' value='1' name='fee_"+v.field_id+"' "+readonly+" checked='checked' id='fee_"+v.field_id+"' class='wdk-control fees_checkbox'> "+v.title+"</label>\n\
												<span class='fee_price'>("+v.value+" "+data.results.symbol+"/"+v.calculation_base_text+")</span>\n\
										</div>\n\
									</div>\n\
								</div>\n\
						";
					});
					fees_box_place.html(html);
					form.find('.fees_checkbox').off().on('change', function(){
						price_calculate(form); 
					});
				}
				step_2_container.find('.wdk-booking-modal-form .wdk-btn[type="submit"]').removeAttr('disabled');
			} else {
				step_2_container.find('.wdk-booking-modal-form .wdk-btn[type="submit"]').attr('disabled', 'disabled');
				
				if(data.popup_text_error)
					step_2_container.find('.block.listing .value.reservation_price').html(data.popup_text_error);
			}
		})
		.done(function () {
		})
		.fail(function() {

		});
	}


	init();
};


function wdk_booking_fix_date (string = '') {
	// Sample French date string
	var string = string.toLowerCase();
	// Map of French to English month names
	var monthNameMap = {
		'January': wdk_bookings_script_parameters.text.monthNames_January,
		'February': wdk_bookings_script_parameters.text.monthNames_February,
		'March': wdk_bookings_script_parameters.text.monthNames_March,
		'April': wdk_bookings_script_parameters.text.monthNames_April,
		'May': wdk_bookings_script_parameters.text.monthNames_May,
		'June': wdk_bookings_script_parameters.text.monthNames_June,
		'July': wdk_bookings_script_parameters.text.monthNames_July,
		'August': wdk_bookings_script_parameters.text.monthNames_August,
		'September': wdk_bookings_script_parameters.text.monthNames_September,
		'October': wdk_bookings_script_parameters.text.monthNames_October,
		'November': wdk_bookings_script_parameters.text.monthNames_November,
		'December': wdk_bookings_script_parameters.text.monthNames_December
	};

	// Replace French month names with English equivalents
	for (var key in monthNameMap) {
		if (monthNameMap.hasOwnProperty(key)) {
			var val = monthNameMap[key];
			string = string.replace(new RegExp(val.toLowerCase(), 'gi'), key.toLowerCase())
		}
	}

	return string;
}
