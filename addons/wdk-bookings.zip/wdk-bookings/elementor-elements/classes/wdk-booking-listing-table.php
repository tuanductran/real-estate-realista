<?php

namespace WdkBooking\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkBookingListingTable extends WdkBookingElementorBase
{

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null)
    {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-bookings')
        );

        if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }



        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'wdk-booking-listing-table';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Wdk Booking Listing Table', 'wdk-bookings');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-table';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render()
    {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['calendar_fees'] = NULL;

        $this->WMVC_Booking->model('price_m');
        $this->WMVC_Booking->model('calendar_m');

        
        $this->data['prices'] = $this->WMVC_Booking->price_m->get_pagination(NULL, NULL, array('is_activated'=>1, 'post_id' => $wdk_listing_id, 'date_to > \''.current_time('mysql').'\''=>NULL), 'date_from DESC');
        $this->data['calendar'] = $this->WMVC_Booking->calendar_m->get_by(array('post_id' => $wdk_listing_id, 'is_activated' =>1), TRUE);

        if($this->data['calendar'] && !empty($this->data['calendar']->json_data_fees))
            $this->data['calendar_fees'] = json_decode($this->data['calendar']->json_data_fees );

        $this->data['days'] = array(
                                    '1'=>__('Monday', 'wdk-bookings'),
                                    '2'=>__('Tuesday', 'wdk-bookings'),
                                    '3'=>__('Wednesday', 'wdk-bookings'),
                                    '4'=>__('Thursday', 'wdk-bookings'),
                                    '5'=>__('Friday', 'wdk-bookings'),
                                    '6'=>__('Saturday', 'wdk-bookings'),
                                    '7'=>__('Sunday', 'wdk-bookings'),
                                );

        $flex_columns = array('price_hour','price_day','price_week','price_month','price_year');

        foreach ($flex_columns as $value) {
            $this->data['prices_column_'.$value.'_empty'] = true;
        }

        foreach ($this->data['prices'] as $price) {
            foreach ($flex_columns as $value) {
                $this->data['prices_column_'.$value.'_empty'] = true;
                if(wmvc_show_data($value, $price, false) && wmvc_show_data($value, $price, false) !='0.00') {
                    $this->data['prices_column_'.$value.'_empty'] = false;
                }
            }
        }

        $this->data['is_edit_mode'] = false;
        if (Plugin::$instance->editor->is_edit_mode()) {
            $this->data['is_edit_mode'] = true;
        }

        if (Plugin::$instance->editor->is_edit_mode()) {
            echo $this->view('wdk-booking-listing-table-demo', $this->data);
        } else {
            if (!empty($this->data['prices']) && !empty($this->data['calendar']) ) {
                echo $this->view('wdk-booking-listing-table', $this->data);
            } else {
                return false;
            }
        }
    }

    private function generate_controls_conf()
    {


        $this->start_controls_section(
            'section_config',
            [
                'label' => esc_html__('Config', 'wdk-bookings'),
                'tab' => '1'
            ]
        );

        $this->add_control(
            'enable_columns_hour',
            [
                'label' => esc_html__('Show column Hours', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_columns_days',
            [
                'label' => esc_html__('Show column Days', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_columns_week',
            [
                'label' => esc_html__('Show column Week', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_columns_month',
            [
                'label' => esc_html__('Show column Month', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_columns_year',
            [
                'label' => esc_html__('Show column Year', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'enable_columns_changeover_day',
            [
                'label' => esc_html__('Show column Changeover day', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'enable_columns_auto_hide',
            [
                'label' => esc_html__('Auto hide column if on all rows empy', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );


        $this->end_controls_section();
    }

    private function generate_controls_layout()
    {
    }

    private function generate_controls_styles()
    {

        $this->start_controls_section(
            'colors_sections',
            [
                'label' => esc_html__('Styles', 'wdk-bookings'),
                'tab' => '1'
            ]
        );

        $this->add_control(
            'primary_color',
            [
                'label' => __('Color Primary', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wdk-booking-listing-table ' => '--color_primary:{{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label' => __('Border Color', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wdk-booking-listing-table ' => '--border_color:{{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'border_width',
            [
                'label' => __('Border Width', 'wdk-bookings'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-booking-listing-table ' => '--border_width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $items = [
            [
                'key' => 'header',
                'label' => esc_html__('Amenities', 'wdk-bookings'),
                'selector' => '.wdk-booking-listing-table table.wdk-table .amities .item',
                'selector_hover' => '.wdk-booking-listing-table table.wdk-table .amities .item%1$s',
                'options' => ['typo', 'color'],
            ],
            [
                'key' => 'text',
                'label' => esc_html__('Content', 'wdk-bookings'),
                'selector' => '.wdk-booking-listing-table table.wdk-table td',
                'options' => ['typo', 'color', 'align'],
            ],
            [
                'key' => 'action',
                'label' => esc_html__('Button', 'wdk-bookings'),
                'selector' => '.wdk-booking-listing-table table.wdk-table .wdk-btn',
                'selector_hover' => '.wdk-booking-listing-table table.wdk-table .wdk-btn .item%1$s',
                'options' => 'text-block',
            ],
        ];
        $this->add_control(
            'more_options',
            [
                'label' => __('Additional Options', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        foreach ($items as $item) {
            $this->add_control(
                $item['key'] . '_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} ' . $item['selector'],
            );

            if (isset($item['selector_hover']))
                $selectors['hover'] = '{{WRAPPER}} ' . $item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'] . '_dynamic', $item['options']);
        }


        $items = [
            [
                'key' => 'button_booking',
                'label' => esc_html__('Button Booking', 'wdk-bookings'),
                'selector' => '.wdk-booking-listing-table .wdk-booking',
                'options' => 'full',
            ],
        ];

        foreach ($items as $item) {
            $this->add_control(
                $item['key'] . '_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_responsive_control(
                $item['key'] . '_hide',
                [
                    'label' => esc_html__('Hide Element', 'wdk-bookings'),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__('Hide', 'wdk-bookings'),
                    'block' => esc_html__('Show', 'wdk-bookings'),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} ' . $item['selector'] => 'display: {{VALUE}};',
                    ],
                ]
            );
            $selectors = array(
                'normal' => '{{WRAPPER}} ' . $item['selector'],
                'hover' => '{{WRAPPER}} ' . $item['selector'] . '%1$s'
            );

            $this->generate_renders_tabs($selectors, $item['key'] . '_dynamic', $item['options']);

            /* END special for some elements */
        }
        $this->end_controls_section();

        /* Fees List */
        $this->start_controls_section(
            'fees_section',
            [
                'label' => esc_html__('Fees List', 'wdk-bookings'),
                'tab' => '1'
            ]
        );

        
        $this->add_control(
            'fees_list_ul',
            [
                'label' => __('Container', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-booking-listing-table .fees li',
        );

        $this->generate_renders_tabs($selectors, 'fees_list_ul_dynamic', ['background','border','border_radius','padding','margin','shadow','transition' ]);

          
        $this->add_control(
            'fees_list_li',
            [
                'label' => __('List Items', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'fees_list_li_hr',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $this->add_control(
            'fees_list_space',
            [
                'label' => __('Vertical Space', 'wdk-bookings'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 250,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-booking-listing-table .fees li:not(:last-child)' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-booking-listing-table .fees li',
        );

        $this->generate_renders_tabs($selectors, 'fees_list_item_dynamic', ['align','typo','color','background','border','border_radius','padding','shadow','transition' ]);

        $this->add_control(
            'fees_list_hr',
            [
                    'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        
        $this->add_control(
            'fees_list_items',
            [
                'label' => __('More Styles', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $items = [
            [
                'key' => 'fee_title',
                'label' => esc_html__('Title', 'wdk-bookings'),
                'selector' => '{{WRAPPER}} .wdk-booking-listing-table .fees li .fee-title',
                'options' => ['typo','color'],
            ],
            [
                'key' => 'fee_balue',
                'label' => esc_html__('Value', 'wdk-bookings'),
                'selector' => '{{WRAPPER}} .wdk-booking-listing-table .fees li .fee-value',
                'options' => ['typo', 'color'],
            ],
            [
                'key' => 'fee_hint',
                'label' => esc_html__('Hint', 'wdk-bookings'),
                'selector' => '{{WRAPPER}} .wdk-booking-listing-table .fees li .fee-hint',
                'options' => ['typo', 'color'],
            ],
          
        ];
    

        foreach ($items as $item) {
            $this->add_control(
                $item['key'] . '_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $selectors = array(
                'normal' => $item['selector'],
            );

            if (isset($item['selector_hover']))
                $selectors['hover'] = $item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'] . '_dynamic', $item['options']);
        }

        $this->end_controls_section();
    }

    private function generate_controls_content()
    {
    }

    public function enqueue_styles_scripts()
    {
        wp_enqueue_style('wdk-booking-listing-table');
    }
}
