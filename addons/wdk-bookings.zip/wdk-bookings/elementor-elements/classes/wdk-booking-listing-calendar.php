<?php

namespace WdkBooking\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkBookingListingCalendar extends WdkBookingElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-bookings')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-booking-listing-calendar';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Booking Listing Calendar', 'wdk-bookings');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-calendar';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->WMVC_Booking->model('price_m');
        $this->WMVC_Booking->model('reservation_m');
        $this->WMVC_Booking->model('calendar_m');
        $this->data['prices'] = $this->WMVC_Booking->price_m->get_pagination(NULL, NULL, array('post_id' => $wdk_listing_id));
        $this->data['property_rates'] = array();

        $this->data['calendar'] = $this->WMVC_Booking->calendar_m->get_by(array('post_id' => $wdk_listing_id, 'is_activated' => 1), TRUE);
        //$this->data['available_dates'] = $this->WMVC_Booking->reservation_m->get_reservation_dates($wdk_listing_id);
        $this->data['available_dates'] = $this->WMVC_Booking->reservation_m->get_reservationprices_dates($wdk_listing_id);
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        if (Plugin::$instance->editor->is_edit_mode()) {
            echo $this->view('wdk-booking-listing-calendar-demo', $this->data);
        } else {
            if (!empty($this->data['prices']) && !empty($this->data['calendar']) ) {
                echo $this->view('wdk-booking-listing-calendar', $this->data);
            } else {
		        wp_enqueue_style( 'wdk-booking-listing-no_booking');
                return false;
            }
        }
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-bookings'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'month_count',
            [
                'label' => __('Moths Nums', 'wdk-bookings'),
                'description' => __('Changes visible only on view mode, not edit mod', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 128,
                'step' => 1,
                'default' => 6,
            ]
        );

        
        $this->add_responsive_control(
            'row_gap_col',
            [
                    'label' => __( 'Columns', 'wdk-bookings' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'calc(100% / 3)' => esc_html__('Default', 'wdk-bookings'),
                        '100%' => '1',
                        '50%' => '2',
                        'calc(100% / 3)' => '3', 
                    ],
                    'selectors_dictionary' => [
                        '100%' =>  '-webkit-flex:1 2 100%;flex:1 2 100%',
                        '50%' =>  '-webkit-flex:1 2 50%;flex:1 2 50%',
                        'calc(100% / 3)' =>  '-webkit-flex:1 2 calc(100% / 3);flex:1 2 calc(100% / 3)',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => '{{UNIT}}',
                    ],
                    'default' => 'calc(100% / 3)',  
                    'separator' => 'before',
            ]
    );

    $this->add_responsive_control(
            'column_gap',
            [
                'label' => esc_html__('Columns Gap', 'wdk-bookings'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-row .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                    '{{WRAPPER}} .wdk-row' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                ],
            ]
    );

    $this->add_responsive_control(
            'row_gap',
            [
                'label' => esc_html__('Rows Gap', 'wdk-bookings'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-row  .wdk-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wdk-row' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wdk-row.wdk-booking-listing-calendar-addinition' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
    );
    
        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'colors_sections',
            [
                    'label' => esc_html__('Styles', 'wdk-bookings'),
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $items = [
            [
                'key'=>'wdk-btn-open',
                'label'=> esc_html__('Btns Open More / Less', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-cal-pag .wdk-btn-pag',
                'selector_hover'=>'{{WRAPPER}} .wdk-cal-pag .wdk-btn-pag%1$s',
                'options'=>['margin','color','background','border','border_radius','padding','shadow','transition','font-size'],
            ],
            [
                'key'=>'calendar-card',
                'label'=> esc_html__('Calendar Card', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .calendar-card',
                'selector_hover'=>'{{WRAPPER}} .calendar-card%1$s',
                'options'=>['background_group','border','border_radius','padding','shadow','transition'],
            ],
            [
                'key'=>'border',
                'label'=> esc_html__('Border', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td, {{WRAPPER}}  .wdk-booking-listing-calendar table th',
                'options'=>['border'],
            ],
            [
                'key'=>'caption',
                'label'=> esc_html__('Caption', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table caption',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table caption%1$s',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'header',
                'label'=> esc_html__('Cell Header', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table th',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table th%1$s',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'td_not_active',
                'label'=> esc_html__('Cell Not Active', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.bg-not-selected a',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.bg-not-selected a%1$s',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'td_available',
                'label'=> esc_html__('Cell Available', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.bg-available a',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'td_available_active',
                'label'=> esc_html__('Cell Hover/Active', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table tbody td.bg-available a.active',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table tbody td.bg-available a%1$s',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'td_booked',
                'label'=> esc_html__('Cell Booked', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.bg-booked a',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.bg-booked a%1$s',
                'options'=>['typo','color','align','background'],
            ],
            [
                'key'=>'td_ignored',
                'label'=> esc_html__('Cell Ignored', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.ignore a',
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-listing-calendar table td.ignore a%1$s',
                'options'=>['typo','color','align','background'],
            ],
         
        ];
        foreach ($items as $item) {
            $this->add_control(
                $item['key'].'_header',
                [
                    'label' => $item['label'],
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            if($item['key'] == 'border') {
                $selectors = array(
                    'normal' => $item['selector'],
                );
            } else {
                $selectors = array(
                    'normal' => ''.$item['selector'],
                );
            }

            if(isset($item['selector_hover']))
                $selectors['hover'] =''.$item['selector_hover'];

            if($item['key'] == 'wdk-btn-open') {
                $this->generate_renders_tabs(array(
                                                    'normal' => '.wdk-cal-pag',
                                                ), 'wdk-btn-open_parent_dynamic', ['align']);
            } 

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

        }

        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-booking-listing-calendar');
    }
}
