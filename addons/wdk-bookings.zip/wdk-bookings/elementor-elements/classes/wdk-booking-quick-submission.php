<?php

namespace WdkBooking\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkBookingQuickSubmission extends WdkBookingElementorBase
{

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null)
    {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_popup',
            esc_html__('Popup', 'wdk-bookings')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-bookings')
        );

        if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }



        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return 'wdk-booking-quick-submission';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return esc_html__('Wdk Booking Quick Submission', 'wdk-bookings');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return 'eicon-select';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render()
    {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['allowdates'] = '';
        $this->data['bookings_max_guests'] = 10;

        if(intval(wdk_get_option('wdk_bookings_max_guests'))) {
            $this->data['bookings_max_guests'] = intval(wdk_get_option('wdk_bookings_max_guests'));
        }

        if(empty($this->data['settings']['text_field_submit_button'])) {
            if(!empty($wdk_listing_id)) {
                $this->data['settings']['text_field_submit_button'] = __('Book Now', 'wdk-bookings');
            } else {
                $this->data['settings']['text_field_submit_button'] = __('Send inquiry', 'wdk-bookings');
            }
        }

        if(!empty($wdk_listing_id)) {
            $this->data['settings']['search_in_current_listing'] = 'yes';
            
            $this->WMVC_Booking->model('calendar_m');
            $this->WMVC_Booking->model('reservation_m');
            $dates = $this->WMVC_Booking->reservation_m->get_enabled_dates($wdk_listing_id);
            $this->data['allowdates'] = (str_replace("'",'',join(' ',$dates)));
            $calendar = $this->WMVC_Booking->calendar_m->get_by(array('post_id' => $wdk_listing_id, 'is_activated' => 1), TRUE);
            if($calendar && wmvc_show_data('guests',$calendar, false)) {
                $this->data['bookings_max_guests'] = intval(wmvc_show_data('guests',$calendar, false));
            }

        } else {
            $this->data['settings']['search_in_current_listing'] = '';
        }

        $this->data['post_id'] = NULL;
        
        if($this->data['settings']['search_in_current_listing'] == 'yes' && !empty($wdk_listing_id)) {
            $this->data['post_id'] = $wdk_listing_id;
        }

        $this->data['is_edit_mode'] = false;
        if (Plugin::$instance->editor->is_edit_mode()) {
            $this->data['is_edit_mode'] = true;
        }

        echo $this->view('wdk-booking-quick-submission', $this->data);
    }

    private function generate_controls_conf()
    {


        $this->start_controls_section(
            'section_config',
            [
                'label' => esc_html__('Config', 'wdk-bookings'),
                'tab' => '1'
            ]
        );

        $this->add_control(
            'text_field_label_date_from',
            [
                'label' => __('Label Field From Date', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('From Date', 'wdk-bookings'),
            ]
        );      

        $this->add_control(
            'text_field_label_date_to',
            [
                'label' => __('Label Field To Date', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('To Date', 'wdk-bookings'),
            ]
        );      

        $this->add_control(
            'text_field_label_persons',
            [
                'label' => __('Label Field Persons', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Persons', 'wdk-bookings'),
            ]
        );      

        $this->add_control(
            'text_field_label_persons_placeholder',
            [
                'label' => __('Placehoder Field Persons', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Total Persons', 'wdk-bookings'),
            ]
        );      

        $this->add_control(
            'text_field_submit_button',
            [
                'label' => __('Text Submit Button', 'wdk-bookings'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]
        );      

        $this->add_responsive_control(
            'form_style_fields_inline',
            [
                'label' => esc_html__('Form fields inline', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'form_style_label_inline',
            [
                'label' => esc_html__('Label and fields inline', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        
        $this->add_responsive_control(
            'field_phone_enable',
            [
                'label' => esc_html__('Show field phone on submit form', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        
        $this->add_responsive_control(
            'field_guests_number_childs_disable',
            [
                'label' => esc_html__('Hide booking field count childs', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        
        $this->add_responsive_control(
            'field_pets_disable',
            [
                'label' => esc_html__('Hide checkbox booking with pets', 'wdk-bookings'),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__('Hide', 'wdk-bookings'),
                'block' => esc_html__('Show', 'wdk-bookings'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-bookings'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .form .wdk-field-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .form' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'form_style_fields_inline',
                                'operator' => '==',
                                'value' => 'yes',
                            ]
                        ],
                    ],
                ]
        );

        $this->add_responsive_control(
            'row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-bookings'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .form .wdk-field-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .form' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->end_controls_section();
    }

    private function generate_controls_layout()
    {
    }

    private function generate_controls_styles()
    {

        $items = [
            [
                'key'=>'field_group',
                'label'=> esc_html__('Field Group', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group', 
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group%1$s', 
                'options'=> ['border','border_radius','padding','shadow','background_group'],
            ],
            [
                'key'=>'label',
                'label'=> esc_html__('Label', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .label', 
                'selector_hide'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .label',  
                'options'=> ['typo','align','margin','color','border','border_radius','padding','shadow','transition', 'background_group'],
            ],
            [
                'key'=>'field',
                'label'=> esc_html__('Field', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .field,{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .icon', 
                'selector_focus'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .field-box%1$s .field, {{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .field-box%1$s .icon',  
                'selector_placeholder'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .field:%1$s',  
                'options'=> ['typo','color','border','border_radius','padding','shadow','transition', 'height', 'background_group'],
            ],
            [
                'key'=>'submit',
                'label'=> esc_html__('Submit Button', 'wdk-bookings'),
                'selector'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .wdk-button', 
                'selector_hover'=>'{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group .wdk-button%1$s',  
                'options'=> ['typo','color','border','border_radius','padding','shadow','transition','height','background_group'],
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => '1',
                ]
            );

            if(!empty($item['selector_hide'])) {
                $this->add_responsive_control(
                    $item['key'].'_desktop_hide',
                    [
                        'label' => esc_html__( 'Hide Element On Dektop', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            "@media(min-width:992px){".$item['selector_hide']." " => 'display: {{VALUE}};}',
                        ],
                    ]
                );
                $this->add_responsive_control(
                    $item['key'].'_tablet_hide',
                    [
                        'label' => esc_html__( 'Hide Element On Tablet', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            "@media(min-width:768px) and (max-width: 991px){".$item['selector_hide']." " => 'display: {{VALUE}};}',
                        ],
                    ]
                );
                $this->add_responsive_control(
                    $item['key'].'_mobile_hide',
                    [
                        'label' => esc_html__( 'Hide Element On Mobile', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            "@media(max-width:767px)".$item['selector_hide']." " => 'display: {{VALUE}};}',
                        ],
                    ]
                );
            }
            $selectors = array();
            if(!empty($item['selector']))
                $selectors['normal'] = $item['selector'];

            if(!empty($item['selector_hover']))
                $selectors['hover'] = $item['selector_hover'];

            if(!empty($item['selector_focus']))
                $selectors['focus'] = $item['selector_focus'];
                
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            
            if(!empty($item['selector_placeholder'])) {
                $this->add_control(
                    $item['key'] . '_placeholder_header',
                    [
                        'label' => esc_html__( 'Placeholder', 'wdk-svg-map' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );
                $selectors = array();
                $selectors['placeholder'] = $item['selector_placeholder'];
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_placeholder',  ['typo','color']);
            }

            if($item['key'] == 'submit') { 
                $this->add_responsive_control(
                        'button_align',
                        [
                            'label' => esc_html__('Alignment', 'elementinvader-addons-for-elementor'),
                            'type' => Controls_Manager::CHOOSE,
                            'options' => [
                                'left' => [
                                    'title' => esc_html__('Left', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__('Right', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'stretch' => [
                                    'title' => esc_html__('Justified', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'default' => 'left',
                            'selectors_dictionary' => [
                                'left' => 'align-items: flex-start;',
                                'center' => 'align-items: center;',
                                'right' => 'align-items: flex-end;',
                                'stretch' => 'align-items: stretch;',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .wdk-booking-quick-submission .wdk-field-group.wdk-field-btn' => '{{VALUE}};',
                            ],
                            'conditions' => [
                                'terms' => [
                                    [
                                        'name' => 'form_style_fields_inline',
                                        'operator' => '!=',
                                        'value' => 'yes',
                                    ]
                                ],
                            ],
                        ]
                );
            }
            $this->end_controls_section();
        }

    }

    private function generate_controls_content()
    {
        $items = [
            [
                'key'=>'form_group',
                'label'=> esc_html__('Form group', 'wdk-report-abuse'),
                'selector'=>'#booking_quick_submission_modal_'.$this->get_id().' .wdk-form-group',
                'options'=>'block',
            ],
            [
                'key'=>'style_label',
                'label'=> esc_html__('Label', 'wdk-report-abuse'),
                'selector'=>'#booking_quick_submission_modal_'.$this->get_id().' .wdk-form-group label:not(.remember_btn)',
                'options'=>'full',
            ],
            [
                'key'=>'style_field',
                'label'=> esc_html__('Fields', 'wdk-report-abuse'),
                'selector'=>'#booking_quick_submission_modal_'.$this->get_id().' .wdk-form-group .wdk-control:not([type="checkbox"])',
                'options'=>'full',
            ],
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-report-abuse'),
                'selector'=>'#booking_quick_submission_modal_'.$this->get_id().' .wdk-btn',
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_popup'
                ]
            );

            if( $item ['key'] == 'style_label'){
                $selectors = array(
                    'normal' => $item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if ($item ['key'] == 'style_field' || $item ['key'] == 'style_button') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Height', 'wdk-report-abuse'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            $item['selector'] => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }
            $selectors = array(
                'normal' => $item['selector'],
                'hover'=>$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    public function enqueue_styles_scripts()
    {
        wp_enqueue_script('wdk-modal');
        wp_enqueue_style('wdk-modal');

        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
        
        wp_enqueue_style( 'dashicons' );
        wp_enqueue_style('wdk-booking-quick-submission');
    }
}
