<?php
/**
 * The template for Element Bookings Prices table.
 * This is the template that elementor element table, listings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-booking-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-booking-listing-table">
      
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <?php if(empty($calendar->is_guests_disabled)):?>
                    <th rowspan="6"><?php echo esc_html__('Guests','wdk-bookings'); ?></th>
                    <?php endif;?>
                    <th><?php echo esc_html__('Date From','wdk-bookings'); ?></th>

                    <th><?php echo esc_html__('Date To','wdk-bookings'); ?></th>

                    <?php if(wmvc_show_data('enable_columns_changeover_day', $settings) == 'yes'):?>
                        <th><?php echo esc_html__('Change Day','wdk-bookings'); ?></th>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_hour', $settings) == 'yes'
                                 && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_hour_empty)):?>
                        <th><?php echo esc_html__('Hour','wdk-bookings'); ?></th>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_days', $settings) == 'yes'
                                 && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_day_empty)):?>
                        <th><?php echo esc_html__('Day','wdk-bookings'); ?></th>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_week', $settings) == 'yes' 
                                && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_week_empty)):?>
                        <th><?php echo esc_html__('Week','wdk-bookings'); ?></th>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_month', $settings) == 'yes'
                                 && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_month_empty)):?>
                        <th><?php echo esc_html__('Month','wdk-bookings'); ?></th>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_year', $settings) == 'yes'
                             && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_year_empty)):?>
                        <th><?php echo esc_html__('Year','wdk-bookings'); ?></th>
                    <?php endif;?>
                </tr>
            </thead>
            <?php if(count($prices) == 0): ?>
                <tr class="no-items"><td class="colspanchange" colspan="7"><?php echo esc_html__('No Availability found.','wdk-bookings'); ?></td></tr>
            <?php endif; ?>
            <?php foreach ( $prices as $price ):?>
                <?php
                    $wdk_currency_symbol_prefix = '';
                    $wdk_currency_symbol_suffix = '';

                    $wdk_currency_symbol = apply_filters( 'wdk-currency-conversion/convert/symbol', wdk_booking_currency_symbol());
                    if($wdk_currency_symbol == '$' || $wdk_currency_symbol == '&#36;') {
                        $wdk_currency_symbol_prefix = $wdk_currency_symbol;
                    } else {
                        $wdk_currency_symbol_suffix = $wdk_currency_symbol; 
                    }
                ?>    
                <tr>
                    <?php if(empty($calendar->is_guests_disabled)):?>
                        <td data-label="<?php echo esc_html__('Guests', 'wdk-bookings'); ?>" class="text-center" >
                            <?php if(!wmvc_show_data('is_children_acceptable', $calendar, false) && !wmvc_show_data('is_pets_acceptable', $calendar, false) && !wmvc_show_data('guests', $calendar, false)):?>
                                - 
                            <?php endif;?>
                            <?php if(wmvc_show_data('guests', $calendar, '-') < 5):?>
                                <?php for($i=0; $i<wmvc_show_data('guests', $calendar); $i++):?>
                                    <i class="fas fa-user"></i>
                                <?php endfor;?>
                            <?php else :?>
                                <i class="fas fa-user"></i> x<?php echo wmvc_show_data('guests', $calendar, '');?>
                            <?php endif;?>

                            <div class="amities">
                                <?php if(wmvc_show_data('is_children_acceptable', $calendar) == 1):?>
                                    <span class="item">
                                        <i class="fas fa-child"></i> <?php echo esc_html__('Childrens','wdk-bookings');?>
                                    </span>
                                <?php endif;?>
                                <?php if(wmvc_show_data('is_pets_acceptable', $calendar) == 1):?>
                                    <span class="item">
                                        <i class="fas fa-paw"></i> <?php echo esc_html__('Pets','wdk-bookings');?>
                                    </span>
                                <?php endif;?>
                            </div>
                        </td>
                    <?php endif;?>
                    <td data-label="<?php echo esc_html__('Date from', 'wdk-bookings'); ?>" data-label="<?php echo esc_html__('Date from', 'wdk-bookings'); ?>"d class="v-vertical-m">
                        <?php echo wdk_get_date(wmvc_show_data('date_from', $price), (wmvc_show_data('price_hour', $price, false) !='0.00') ?: false); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Date To', 'wdk-bookings'); ?>" class="v-vertical-m">
                        <?php echo wdk_get_date(wmvc_show_data('date_to', $price), (wmvc_show_data('price_hour', $price, false) !='0.00') ?: false); ?>
                    </td>

                    <?php if(wmvc_show_data('enable_columns_changeover_day', $settings) == 'yes'):?>
                        <td data-label="<?php echo esc_html__('Change day', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('changeover_day', $price, false) &&  isset($days[wmvc_show_data('changeover_day', $price, false)])):?>
                                <?php echo esc_html($days[wmvc_show_data('changeover_day', $price, false)]); ?>
                            <?php else:?> 
                                <?php echo esc_html__('Every day', 'wdk-bookings'); ?>
                            <?php endif;?>
                        </td>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_hour', $settings) == 'yes' 
                             && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_hour_empty)):?>
                        <td data-label="<?php echo esc_html__('Hour', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('price_hour', $price, false) && wmvc_show_data('price_hour', $price, false) !='0.00'):?>
                                <?php echo esc_html($wdk_currency_symbol_prefix.' '.apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('price_hour', $price)).' '.$wdk_currency_symbol_suffix) ?>
                            <?php else:?> 
                                - 
                            <?php endif;?>
                        </td>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_days', $settings) == 'yes'
                                 && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_day_empty)):?>
                        <td data-label="<?php echo esc_html__('Day', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('price_day', $price, false) && wmvc_show_data('price_day', $price, false) !='0.00'):?>
                                <?php echo esc_html($wdk_currency_symbol_prefix.' '.apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('price_day', $price)).' '.$wdk_currency_symbol_suffix) ?>
                            <?php else:?> 
                                - 
                            <?php endif;?>
                        </td>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_week', $settings) == 'yes'
                             && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_week_empty)):?>
                        <td data-label="<?php echo esc_html__('Week', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('price_week', $price, false) && wmvc_show_data('price_week', $price, false) !='0.00'):?>
                                <?php echo esc_html($wdk_currency_symbol_prefix.' '.apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('price_week', $price)).' '.$wdk_currency_symbol_suffix) ?>
                            <?php else:?> 
                                - 
                            <?php endif;?>
                        </td>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_month', $settings) == 'yes'
                         && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_month_empty)):?>
                        <td data-label="<?php echo esc_html__('Month', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('price_month', $price, false) && wmvc_show_data('price_month', $price, false) !='0.00'):?>
                                <?php echo esc_html($wdk_currency_symbol_prefix.' '.apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('price_month', $price)).' '.$wdk_currency_symbol_suffix) ?>
                            <?php else:?> 
                                - 
                            <?php endif;?>
                        </td>
                    <?php endif;?>

                    <?php if(wmvc_show_data('enable_columns_year', $settings) == 'yes'
                         && (wmvc_show_data('enable_columns_auto_hide', $settings) != 'yes' || !$prices_column_price_year_empty)):?>
                        <td data-label="<?php echo esc_html__('Year', 'wdk-bookings'); ?>" class="v-vertical-m text-center">
                            <?php if(wmvc_show_data('price_year', $price, false) && wmvc_show_data('price_year', $price, false) !='0.00'):?>
                                <?php echo esc_html($wdk_currency_symbol_prefix.' '.apply_filters( 'wdk-currency-conversion/convert/price', wmvc_show_data('price_month', $price)).' '.$wdk_currency_symbol_suffix) ?>
                            <?php else:?> 
                                - 
                            <?php endif;?>
                        </td>
                    <?php endif;?>

            <?php endforeach; ?>
        </table>
        <?php if(!empty($calendar_fees)):?>
        <?php
            $wdk_currency_symbol_prefix = '';
            $wdk_currency_symbol_suffix = '';
            $wdk_currency_symbol = apply_filters( 'wdk-currency-conversion/convert/symbol', wdk_booking_currency_symbol());

            if($wdk_currency_symbol == '$' || $wdk_currency_symbol == '&#36;') {
                $wdk_currency_symbol_prefix = $wdk_currency_symbol;
            } else {
                $wdk_currency_symbol_suffix = $wdk_currency_symbol; 
            }
        ?>   
        <div class="fees">
            <ul class="fee-list">
                <?php foreach ($calendar_fees as $fee):?>
                    <?php if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;?>
                    <li class="item">
                        <span class="fee-title"><?php echo esc_html(wmvc_show_data('title', $fee,'-',TRUE,TRUE));?>:</span>
                        <span class="fee-value"><?php echo esc_html($wdk_currency_symbol_prefix);?><?php echo esc_html(wmvc_show_data('value', $fee,'-',TRUE,TRUE));?><?php echo esc_html($wdk_currency_symbol_suffix);?></span>
                        <?php if(wmvc_show_data('hint', $fee,'-',TRUE,TRUE)):?>
                            <span class="fee-hint">(<?php echo esc_html(wmvc_show_data('hint', $fee,'-',TRUE,TRUE));?>)</span>
                        <?php endif;?>
                    </li>
                <?php endforeach;?>
            </ul>
        </div>
        <?php endif;?>
        <a href="#" class="wdk-booking anchor_date_from"><?php echo esc_html__('Make Reservation', 'wdk-bookings'); ?></a>
        <?php if(!is_user_logged_in()):?>
            <a href="<?php echo esc_url(wdk_login_url(wdk_current_url()));?>" class="wdk-booking wdk-booking-login wdk-hidden"><?php echo esc_html__('For Booking please login', 'wdk-bookings'); ?></a>
        <?php endif;?>
    </div>
</div>

