<?php
/**
 * The template for Element Bookins Calendar Demo data For Edit Mode.
 * This is the template that elementor element calendar, listings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-booking-element" id="wdk_el_<?php echo esc_html($id_element); ?>">
   <div class="wdk-booking-listing-calendar">
      <div class="wdk-booking-listing-calendar">
         <div class="wdk-row">
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('December','wdk-bookings');?> 2021</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="ignore"><a href="#">28</a></td>
                        <td class="ignore"><a href="#">29</a></td>
                        <td class="ignore"><a href="#">30</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-01">1</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-02">2</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-03">3</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-04">4</a></td>
                     </tr>
                     <tr>
                        <td class="bg-available"><a href="#" title="2021-12-05">5</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-06">6</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-07">7</a></td>
                        <td class="bg-booked"><a href="#" title="2021-12-08">8</a></td>
                        <td class="bg-booked"><a href="#" title="2021-12-09">9</a></td>
                        <td class="bg-booked"><a href="#" title="2021-12-10">10</a></td>
                        <td class="bg-booked"><a href="#" title="2021-12-11">11</a></td>
                     </tr>
                     <tr>
                        <td class="bg-booked"><a href="#" title="2021-12-12">12</a></td>
                        <td class="bg-booked"><a href="#" title="2021-12-13">13</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-14">14</a></td>
                        <td class="bg-today"><a href="#" title="2021-12-15">15</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-16">16</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-17">17</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-18">18</a></td>
                     </tr>
                     <tr>
                        <td class="bg-available"><a href="#" title="2021-12-19">19</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-20">20</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-21">21</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-22">22</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-23">23</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-24">24</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-25">25</a></td>
                     </tr>
                     <tr>
                        <td class="bg-available"><a href="#" title="2021-12-26">26</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-27">27</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-28">28</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-29">29</a></td>
                        <td class="bg-available"><a href="#" title="2021-12-30">30</a></td>
                        <td class="bg-not-selected"><a href="#" title="2021-12-31">31</a></td>
                        <td class="ignore"><a href="#">1</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('January','wdk-bookings');?> 2022</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="ignore"><a href="#">26</a></td>
                        <td class="ignore"><a href="#">27</a></td>
                        <td class="ignore"><a href="#">28</a></td>
                        <td class="ignore"><a href="#">29</a></td>
                        <td class="ignore"><a href="#">30</a></td>
                        <td class="ignore"><a href="#">31</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-01">1</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-01-02">2</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-03">3</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-04">4</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-05">5</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-06">6</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-07">7</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-08">8</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-01-09">9</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-10">10</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-11">11</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-12">12</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-13">13</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-14">14</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-15">15</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-01-16">16</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-17">17</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-18">18</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-19">19</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-20">20</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-21">21</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-22">22</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-01-23">23</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-24">24</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-25">25</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-26">26</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-27">27</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-28">28</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-29">29</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-01-30">30</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-01-31">31</a></td>
                        <td class="ignore"><a href="#">1</a></td>
                        <td class="ignore"><a href="#">2</a></td>
                        <td class="ignore"><a href="#">3</a></td>
                        <td class="ignore"><a href="#">4</a></td>
                        <td class="ignore"><a href="#">5</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('February','wdk-bookings');?> 2022</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="ignore"><a href="#">30</a></td>
                        <td class="ignore"><a href="#">31</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-01">1</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-02">2</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-03">3</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-04">4</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-05">5</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-02-06">6</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-07">7</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-08">8</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-09">9</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-10">10</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-11">11</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-12">12</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-02-13">13</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-14">14</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-15">15</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-16">16</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-17">17</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-18">18</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-19">19</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-02-20">20</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-21">21</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-22">22</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-23">23</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-24">24</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-25">25</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-26">26</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-02-27">27</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-02-28">28</a></td>
                        <td class="ignore"><a href="#">1</a></td>
                        <td class="ignore"><a href="#">2</a></td>
                        <td class="ignore"><a href="#">3</a></td>
                        <td class="ignore"><a href="#">4</a></td>
                        <td class="ignore"><a href="#">5</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('March','wdk-bookings');?> 2022</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="ignore"><a href="#">27</a></td>
                        <td class="ignore"><a href="#">28</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-01">1</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-02">2</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-03">3</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-04">4</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-05">5</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-03-06">6</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-07">7</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-08">8</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-09">9</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-10">10</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-11">11</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-12">12</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-03-13">13</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-14">14</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-15">15</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-16">16</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-17">17</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-18">18</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-19">19</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-03-20">20</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-21">21</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-22">22</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-23">23</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-24">24</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-25">25</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-26">26</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-03-27">27</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-28">28</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-29">29</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-30">30</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-03-31">31</a></td>
                        <td class="ignore"><a href="#">1</a></td>
                        <td class="ignore"><a href="#">2</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('April','wdk-bookings');?> 2022</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="ignore"><a href="#">27</a></td>
                        <td class="ignore"><a href="#">28</a></td>
                        <td class="ignore"><a href="#">29</a></td>
                        <td class="ignore"><a href="#">30</a></td>
                        <td class="ignore"><a href="#">31</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-01">1</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-02">2</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-04-03">3</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-04">4</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-05">5</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-06">6</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-07">7</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-08">8</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-09">9</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-04-10">10</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-11">11</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-12">12</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-13">13</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-14">14</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-15">15</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-16">16</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-04-17">17</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-18">18</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-19">19</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-20">20</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-21">21</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-22">22</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-23">23</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-04-24">24</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-25">25</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-26">26</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-27">27</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-28">28</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-29">29</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-04-30">30</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
            <div class="wdk-col">
            <div class="calendar-card"> 
               <table border="0">
                  <caption><?php echo esc_html__('May','wdk-bookings');?> 2022</caption>
                  <thead>
                     <tr>
                        <th><?php echo esc_html__('Sun','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Mon','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Tue','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Wed','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Thu','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Fri','wdk-bookings');?></th>
                        <th><?php echo esc_html__('Sat','wdk-bookings');?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-05-01">1</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-02">2</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-03">3</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-04">4</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-05">5</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-06">6</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-07">7</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-05-08">8</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-09">9</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-10">10</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-11">11</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-12">12</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-13">13</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-14">14</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-05-15">15</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-16">16</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-17">17</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-18">18</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-19">19</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-20">20</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-21">21</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-05-22">22</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-23">23</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-24">24</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-25">25</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-26">26</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-27">27</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-28">28</a></td>
                     </tr>
                     <tr>
                        <td class="bg-not-selected"><a href="#" title="2022-05-29">29</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-30">30</a></td>
                        <td class="bg-not-selected"><a href="#" title="2022-05-31">31</a></td>
                        <td class="ignore"><a href="#">1</a></td>
                        <td class="ignore"><a href="#">2</a></td>
                        <td class="ignore"><a href="#">3</a></td>
                        <td class="ignore"><a href="#">4</a></td>
                     </tr>
                  </tbody>
               </table>
            </div>
            </div>
         </div>
         <div class="wdk-row">
            <div class="wdk-col wdk-col-full wdk-cal-pag">
                <a href="#" class="wdk-btn-pag next">
                    <span class="dashicons dashicons-plus-alt2"></span>
                </a>
                <a href="#" class="wdk-btn-pag pre">
                    <span class="dashicons dashicons-minus"></span>
                </a>
            </div>
        </div>
      </div>
   </div>
</div>

