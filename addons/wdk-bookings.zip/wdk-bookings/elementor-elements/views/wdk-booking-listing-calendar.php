<?php
/**
 * The template for Element Bookins Calendar.
 * This is the template that elementor element calendar, listings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$translate = array(
    0 => esc_html__('September','wdk-bookings'),
    1 => esc_html__('October','wdk-bookings'), 
    2 => esc_html__('November','wdk-bookings'), 
    3 => esc_html__('December','wdk-bookings'), 
    4 => esc_html__('January','wdk-bookings'), 
    5 => esc_html__('February','wdk-bookings'), 
    6 => esc_html__('March','wdk-bookings'),
    7 => esc_html__('April','wdk-bookings'),
    8 => esc_html__('May','wdk-bookings'),
    9 => esc_html__('June','wdk-bookings'),
    10 => esc_html__('July','wdk-bookings'),
    11 => esc_html__('August','wdk-bookings'),
);
$opened = false;
?>
<div class="wdk-booking-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-booking-listing-calendar <?php if(wmvc_show_data('is_hour_enabled', $calendar, false, TRUE, TRUE)):?> is_hour <?php endif;?>">
        <div class="wdk-hidden js_message"><?php echo esc_html__('For Booking please login', 'wdk-bookings');?></div>
        <div class="wdk-hidden js_message_error_date"><?php echo esc_html__('Dates in not available, please set other dates', 'wdk-bookings');?></div>
        <div class="wdk-row">
            <?php
                list($current_year, $current_month, $current_day) = explode('-', date("Y-m-j"));
                if($current_day<10) {
                    $current_date = "{$current_year}-{$current_month}-0{$current_day}";
                } else {
                    $current_date = "{$current_year}-{$current_month}-{$current_day}";
                }
                $wdk_order = 0;

             
            ?>
            <?php for($month_i=0;$month_i < wmvc_show_data('month_count', $settings,6); $month_i++):?>
                <?php if($month_i%6==0 && $month_i !=0):?>
                    </div>
                    <div class="wdk-row wdk-booking-listing-calendar-addinition" style="display: none;">
                <?php endif;?>
                <div class="wdk-col">

                    <div class="calendar-card"> 
                        <table> 
                        <?php
                        $next_month_time = strtotime("+$month_i month", strtotime(date("F") . "1"));
                        
                        // Get the value of day, month, year
                        $days = array(
                                0 => esc_html__('Sun','wdk-bookings'),
                                1 => esc_html__('Mon','wdk-bookings'), 
                                2 => esc_html__('Tue','wdk-bookings'), 
                                3 => esc_html__('Wed','wdk-bookings'), 
                                4 => esc_html__('Thu','wdk-bookings'), 
                                5 => esc_html__('Fri','wdk-bookings'), 
                                6 => esc_html__('Sat','wdk-bookings'),
                            );
                        
                        list($mon, $month_m, $month, $year, $num_days) = explode('-', date("n-m-F-Y-t", $next_month_time));

                        $first_day_of_week = array_search(esc_html__(date('D', strtotime($year . '-' . $month . '-1')), 'wdk-bookings'), $days);
                        if(!$first_day_of_week)
                            $first_day_of_week = 1;

                        $num_days_last_month = date('j', strtotime('last day of previous month', strtotime($current_day. '-' . $month . '-' . $year)));
                        $startDay = $first_day_of_week;
                        ?>
                            <caption><?php echo esc_html__($month,'wdk-bookings');?> <?php echo esc_html($year);?></caption>
                            <thead>
                            <tr>
                                <?php foreach ($days as $key => $day) :?>
                                    <th><?php echo esc_html(substr($day,0,3));?></th>
                                <?php endforeach;?>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php for ($i = $first_day_of_week; $i > 0; $i--):?>
                                        <td class='ignore' data-order="<?php echo esc_attr($wdk_order++);?>"><a><?php echo esc_html(($num_days_last_month-$i+1));?></a></td>
                                    <?php endfor;?>

                                    <?php for ($d=1;$d<=$num_days;$d++):?>
                                        <?php
                                            $date_day = '';
                                            $class_td = '';
                                            if($d<10) {
                                                $date_day = "{$year}-{$month_m}-0{$d}";
                                            } else {
                                                $date_day = "{$year}-{$month_m}-{$d}";
                                            }
                                            /*
                                            if ($date_day < $current_date) {
                                                $class_td = "ignore old-dates";
                                            }else if ($d == $current_day && $month_m == $current_month) {
                                                $class_td = "bg-today";
                                            } elseif (isset($available_dates[$date_day])) {
                                                if(strpos($available_dates[$date_day], 'book_book_current') !== FALSE ) {
                                                    $class_td = "bg-booked";
                                                } elseif(strpos($available_dates[$date_day], 'book_current_bookd') !== FALSE ) {
                                                    $class_td = "bg-booked";
                                                } elseif(strpos($available_dates[$date_day], 'reservation_start') !== FALSE && strpos($available_dates[$date_day], 'reservation_end') === FALSE) {
                                                    $class_td = "bg-available bg-booked reservation-start";
                                                } elseif(strpos($available_dates[$date_day], 'reservation_end') !== FALSE && strpos($available_dates[$date_day], 'reservation_start') === FALSE) {
                                                    $class_td = "bg-available bg-booked reservation-end";
                                                } elseif(strpos($available_dates[$date_day], 'booked') !== FALSE) {
                                                    $class_td = "bg-booked";
                                                } else {
                                                    $class_td = "bg-available";
                                                }
                                            } else {
                                                $class_td = "bg-not-selected";
                                            }*/

                                            if(isset($available_dates['prices'][$date_day])) {
                                                $class_td = "bg-available";
                                            }
                                            
                                            if ($date_day < $current_date) {
                                                $class_td = "ignore old-dates";
                                            } else {
                                                //$class_td = "bg-not-selected";
                                                if(isset($available_dates['reservations'][$date_day]) ) {
                                                    $class_td = "bg-booked";

                                                    $date_day_previous = date("Y-m-d", strtotime('-1 day',  strtotime($date_day)));
                                                    $date_day_next = date("Y-m-d", strtotime('+1 day',  strtotime($date_day)));

                                                    if(isset($available_dates['prices'][$date_day])) {
                                                        if(!isset($available_dates['reservations'][$date_day_next]) && isset($available_dates['prices'][$date_day_next])) {
                                                            $class_td = "bg-available bg-booked reservation-end";
                                                        }

                                                        if(!isset($available_dates['reservations'][$date_day_previous]) && isset($available_dates['prices'][$date_day_previous])) {
                                                            $class_td = "bg-available bg-booked reservation-start";
                                                        }
                                                    }

                                                }
                                            }

                                            if ($d == $current_day && $month_m == $current_month) {
                                                $class_td = "bg-today";
                                            }

                                            $startDay++;
                                        ?>
                                        <td data-order="<?php echo esc_attr($wdk_order++);?>" class="<?php echo esc_html($class_td);?>"><a title="<?php echo esc_html($date_day);?>"><?php echo esc_html($d);?></a></td>

                                        <?php if($startDay > 6 && $d < $num_days):?>
                                            <?php $startDay = 0; ?>
                                            </tr><tr>
                                        <?php endif;?>
                                    <?php endfor;?>

                                    <?php for ($i = $startDay,$y=1; $i <= 6 ; $i++,$y++):?>
                                        <td class='ignore'><a><?php echo esc_html($y);?></a></td>
                                    <?php endfor;?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div> 
            <?php endfor;?>
        </div> 
        <?php if(wmvc_show_data('month_count', $settings,6) > 6):?>
        <div class="wdk-row">
            <div class="wdk-col wdk-col-full wdk-cal-pag">
                <a href="#" class="wdk-btn-pag next">
                    <span class="dashicons dashicons-plus-alt2"></span>
                </a>
                <a href="#" class="wdk-btn-pag pre noactive">
                    <span class="dashicons dashicons-minus"></span>
                </a>
            </div>
        </div>
        <?php endif;?>
    </div>
    <script>

        jQuery( document ).on('ready', function() {
            /*
            jQuery.each(data.output, function (i, v) { 
                var cell = self_parent.find('[title="' + i + '"]');
                if (false && cell && cell.length) {
                    
                    if(v.indexOf ('booked_current') !== -1 ) {
                        cell.parent().addClass("bg-booked booked_current").removeClass('bg-not-selected');
                    } else if(v.indexOf ('booked') !== -1) {
                        cell.parent().addClass("bg-booked").removeClass('bg-not-selected');
                    } else {
                        cell.parent().addClass("bg-available").removeClass('bg-not-selected');
                    }

                    if(v.indexOf ('book_current_bookd') !== -1){
                        cell.parent().addClass("reservation-booked-booked_current")
                    }else if(v.indexOf ('book_book_current') !== -1){
                        cell.parent().addClass("reservation-booked_current-booked")
                    }else if(v.indexOf ('reservation_start') !== -1 && v.indexOf ('reservation_end') == -1){
                        cell.parent().addClass("bg-available reservation-start")
                    }else if(v.indexOf ('reservation_end') !== -1 && v.indexOf ('reservation_start') == -1){
                        cell.parent().addClass("bg-available reservation-end")
                    }
                }
            });
            */
        });
    </script>

</div>

