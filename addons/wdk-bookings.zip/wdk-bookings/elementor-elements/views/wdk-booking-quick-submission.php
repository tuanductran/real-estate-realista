<?php

/**
 * The template for Element Bookings Prices table Data for Edit Mode.
 * This is the template that elementor element table, listings
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
wp_enqueue_script( 'daterangepicker-moment' );
wp_enqueue_script( 'daterangepicker' );
wp_enqueue_style('daterangepicker');


?>
<div class="wdk-booking-element" id="wdk_el_<?php echo esc_html($id_element); ?>">
    <div class="wdk-booking-quick-submission">
        <form action="" data-wdk-target="#booking_quick_submission_modal_<?php echo esc_html($id_element); ?>" class="form  
            <?php if(wmvc_show_data('form_style_fields_inline', $settings) == 'yes'):?> wdk_form_inline <?php endif;?>
            <?php if(wmvc_show_data('form_style_fields_inline_tablet', $settings) == 'yes'):?> wdk_form_inline_tablet <?php endif;?>
            <?php if(wmvc_show_data('form_style_fields_inline_mobile', $settings) == 'yes'):?> wdk_form_inline_mobile <?php endif;?>
            <?php if(wmvc_show_data('form_style_label_inline', $settings) == 'yes'):?> wdk_field_group_inline <?php endif;?>
            <?php if(wmvc_show_data('form_style_label_inline_tablet', $settings) == 'yes'):?> wdk_field_group_inline_tablet <?php endif;?>
            <?php if(wmvc_show_data('form_style_label_inline_mobile', $settings) == 'yes'):?> wdk_field_group_inline_mobile <?php endif;?> 
             wdk_field_id_booking_dates
        ">
            <input name="post_id" type="hidden" value="<?php echo esc_html($post_id);?>" data-listing_title="<?php echo esc_html(wdk_field_value('post_title', $post_id));?>">
            <div class="wdk-field-col">
                <div class="wdk-field-group">
                    <label class="label"><?php echo esc_html__($settings['text_field_label_date_from']);?></label>
                    <div class="field-box field-icon">
                        <input type="text" data-wdksingle="true" name="date_from" data-allowdates="<?php echo esc_attr($allowdates);?>" class="field wdk-fielddate_range date_from" value="<?php echo wdk_get_date(time(), false); ?>">
                        <span class="icon"><i class="far fa-calendar-alt"></i></span>
                    </div>
                </div>
            </div>
            <div class="wdk-field-col">
                <div class="wdk-field-group">
                    <label class="label"><?php echo esc_html__($settings['text_field_label_date_to']);?></label>
                    <div class="field-box"><input type="text" data-wdksingle="true" name="date_to" data-allowdates="<?php echo esc_attr($allowdates);?>" class="field wdk-fielddate_range date_to" value="<?php echo wdk_get_date(strtotime('+7 days'), false); ?>"><span class="icon"><i class="far fa-calendar-alt"></i></span></div>
                </div>
            </div>
            <div class="wdk-field-col">
                <div class="wdk-field-group">
                    <label class="label"><?php echo esc_html__($settings['text_field_label_persons']);?></label>
                    <div class="field-box">
                        <select name="adult" class="field">
                            <option value=""><?php echo esc_html__($settings['text_field_label_persons_placeholder']);?></option>

                            <?php for ($i=1; $i <= $bookings_max_guests; $i++):?>
                                <option value="<?php echo esc_attr($i);?>"><?php echo esc_html($i);?></option>
                            <?php endfor;?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="wdk-field-col wdk-field-col-btn">
                <div class="wdk-field-group wdk-field-btn">
                    <button class="wdk-button" class="clear_event"><?php echo esc_html__($settings['text_field_submit_button']);?></button>
                </div>
            </div>
        </form>
    </div>
                
    <div class="wdk-modal wkd-fade wdk-booking-modal-search" id="booking_quick_submission_modal_<?php echo esc_html($id_element); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-notice">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo esc_html__('Book', 'wdk-bookings'); ?>
                    </h5>
                    <button type="button" class="close" data-wdk-dismiss="modal" aria-hidden="true">
                        <span class="dashicons dashicons-no-alt"></span>
                    </button>
                </div>
            <div class="modal-body">
                <div class="steps">
                    <?php if(true):?>
                    <div class="step" data-step="1">
                        <div class="modal-body">
                            <div class="wdk-booking-box">
                                <?php
                                    $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                                ?>
                                <form id="" action="<?php echo esc_url($current_url);?>" method="post" class="wdk-booking-modal-form">    
                                    <div class="alert_box">
                                    </div>
                                    <div class="wdk-row">
                                        <div class="wdk-col-6">
                                            <div class="wdk-form-group">
                                                <label for="<?php echo esc_html($id_element);?>_date_from"><?php echo esc_html__($settings['text_field_label_date_from']);?></label>
                                                <div class="input">
                                                    <input required="required" type="text" value="" name="date_from" id="<?php echo esc_html($id_element);?>_date_from" class="wdk-control reset_field wdk-fielddate_range date_from">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wdk-col-6">
                                            <div class="wdk-form-group">
                                                <label for="<?php echo esc_html($id_element);?>_date_to"><?php echo esc_html__($settings['text_field_label_date_to']);?></label>
                                                <div class="input">
                                                    <input required="required" type="text" name="date_to" id="<?php echo esc_html($id_element);?>_date_to" class="wdk-control reset_field wdk-fielddate_range date_to" value="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if(false):?>
                                    <div class="wdk-form-group">
                                        <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html__('Search', 'wdk-bookings');?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
                                    </div>
                                    <?php endif;?>
                                </form>

                                <div class="booking_quick_results">
                                    <div class="booking_quick_results_alert_box"></div>
                                    <table class="table-results">
                                        <thead>
                                            <th></th>
                                            <th></th>
                                            <th><?php echo esc_html__('Listing', 'wdk-bookings');?></th>
                                            <th></th>
                                            <th><?php echo esc_html__('Price', 'wdk-bookings');?></th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div> 
                        </div>
                        <div class="modal-footer justify-content-center">
                            <button type="button" class="button button-secondary wdk-btn"
                                data-wdk-dismiss="modal"><?php echo esc_html__('Cancel', 'wdk-bookings'); ?></button>
                            <button type="button" class="button button-secondary wdk-btn next wdk-btn-change-step" data-step="2"><?php echo esc_html__('Next', 'wdk-bookings'); ?></button>
                        </div>
                    </div>
                    <?php endif;?>

                    <div class="step wdk-hidden" data-step="2">
                        <div class="block top">
                            <div class="from">
                                <div class="title"><?php echo esc_html__('From Date','wdk-bookings');?></div>
                                <div class="value date_from"></div>
                            </div>
                            <div class="to">
                                <div class="title"><?php echo esc_html__('To Date','wdk-bookings');?></div>
                                <div class="value date_to"></div>
                            </div>
                        </div>
                        <div class="block listing">
                            <div class="listing">
                                <div class="title"><?php echo esc_html__('Choosen unit','wdk-bookings');?></div>
                                <div class="value listing_title"></div>
                            </div>
                            <div class="price">
                                <div class="title"><?php echo esc_html__('Price','wdk-bookings');?></div>
                                <div class="value reservation_price"></div>
                            </div>
                        </div>
                        <div class="block price_list">
                           
                        </div>
                        <form id="" action="" method="post" class="wdk-booking-modal-form">    
                            <div class="modal-body">
                               
                                <input name="wdk_widget" type="hidden" value="wdk-booking-quick-submission">
                                <input name="listing_id" type="hidden" value="#">
                                <input name="listing_link" type="hidden" value="">
                                <input name="date_from" id="date_from" type="hidden">
                                <input name="date_to" id="date_to" type="hidden">
                                <div class="wdk-row">
                                    <div class="<?php if(wmvc_show_data('field_guests_number_childs_disable', $settings) != 'yes'):?>wdk-col-6<?php else:?>wdk-col-12<?php endif;?>">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_guests_number_adults"><?php echo esc_html__('Adults','wdk-bookings');?></label>
                                            <div class="input">
                                                <select name="guests_number_adults" id="<?php echo esc_html($id_element);?>_guests_number_adults" class="wdk-control reset_field">
                                                    <option value=""><?php echo esc_html__('Not selected','wdk-bookings');?></option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10+">10+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if(wmvc_show_data('field_guests_number_childs_disable', $settings) != 'yes'):?>
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_guests_number_childs"><?php echo esc_html__('Childs','wdk-bookings');?></label>
                                            <div class="input">
                                                <select name="guests_number_childs" id="<?php echo esc_html($id_element);?>_guests_number_childs" class="wdk-control reset_field">
                                                <option value=""><?php echo esc_html__('Not selected','wdk-bookings');?></option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10+">10+</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif;?>
                                </div>
                                <?php if(wmvc_show_data('field_pets_disable', $settings) != 'yes'):?>
                                <div class="wdk-row">
                                    <div class="wdk-col-12">
                                        <div class="wdk-form-group">
                                            <div class="input">
                                                <label for="<?php echo esc_html($id_element);?>_pets_allowed" class='term'>
                                                    <input type="checkbox" value="1" name="pets_allowed" id="<?php echo esc_html($id_element);?>_pets_allowed" class="wdk-control">
                                                    <?php echo esc_html__('Pets','wdk-bookings');?>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif;?>

                                <div class="wdk-row fees_box">
                                
                                </div>
                                <div class="wdk-row">
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_name"><?php echo esc_html__('Name','wdk-bookings');?>*</label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="name" id="<?php echo esc_html($id_element);?>_name" placeholder="<?php echo esc_attr__('Name','wdk-bookings');?>" class="wdk-control reset_field">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wdk-col-6">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_email"><?php echo esc_html__('Email','wdk-bookings');?>*</label>
                                            <div class="input">
                                                <input required="required" type="email" value="" name="email" id="<?php echo esc_html($id_element);?>_email" placeholder="<?php echo esc_attr__('Email','wdk-bookings');?>" class="wdk-control reset_field">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if(wmvc_show_data('field_phone_enable', $settings) == 'yes'):?>
                                <div class="wdk-row">
                                    <div class="wdk-col-12">
                                        <div class="wdk-form-group">
                                            <label for="<?php echo esc_html($id_element);?>_phone"><?php echo esc_html__('Phone','wdk-bookings');?>*</label>
                                            <div class="input">
                                                <input required="required" type="text" value="" name="phone" id="<?php echo esc_html($id_element);?>_phone" placeholder="<?php echo esc_attr__('Phone','wdk-bookings');?>" class="wdk-control reset_field">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif;?>
                                <div class="wdk-form-group">
                                    <label for="<?php echo esc_html($id_element);?>_message"><?php echo esc_html__('Message','wdk-bookings');?>*</label>
                                    <div class="input">
                                        <textarea required="required" type="text" value="" row="3" name="message" id="<?php echo esc_html($id_element);?>_message" placeholder="<?php echo esc_attr__('Message','wdk-bookings');?>" class="wdk-control reset_field"></textarea>
                                    </div>
                                </div>
                                <?php
                                if(
                                    (get_option('wdk_report_abuse_recaptcha_site_key') && get_option('wdk_report_abuse_recaptcha_secret_key'))
                                    || (get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key'))
                                ):?>
                                    <div class="wdk-form-group">
                                        <?php wdk_report_abuse_recaptcha_field(); ?>
                                    </div>
                                <?php endif;?>
                            
                                <div class="alert_box"></div>
                            </div>
                            <div class="modal-footer justify-content-center">
                                <?php if(empty($post_id)):?>
                                    <button type="button" class="button button-secondary wdk-btn wdk-btn-change-step" data-step="1"><?php echo esc_html__('Back', 'wdk-bookings'); ?></button>
                                <?php else:?>
                                    <button type="button" class="button button-secondary wdk-btn"
                                        data-wdk-dismiss="modal"><?php echo esc_html__('Cancel', 'wdk-bookings'); ?></button>
                                <?php endif;?>

                                <button type="submit" class="button button-secondary wdk-btn wdk-click-load-animation "><?php echo esc_html__('Book Now','wdk-bookings');?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
          
        </div>
    </div>
</div>