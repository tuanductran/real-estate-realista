<?php

/**
 * The template for Element Bookings Prices table Data for Edit Mode.
 * This is the template that elementor element table, listings
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

?>
<div class="wdk-booking-element" id="wdk_el_<?php echo esc_html($id_element); ?>">
    <div class="wdk-booking-listing-table">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <th rowspan="6"><?php echo esc_html__('Guests', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date From', 'wdk-bookings'); ?></th>
                    <th><?php echo esc_html__('Date To', 'wdk-bookings'); ?></th>

                    <?php if (wmvc_show_data('enable_columns_changeover_day', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Change Day', 'wdk-bookings'); ?></th>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_hour', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Hour', 'wdk-bookings'); ?></th>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_days', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Day', 'wdk-bookings'); ?></th>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_week', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Week', 'wdk-bookings'); ?></th>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_month', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Month', 'wdk-bookings'); ?></th>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_year', $settings) == 'yes') : ?>
                        <th><?php echo esc_html__('Year', 'wdk-bookings'); ?></th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td data-label="<?php echo esc_html__('Guests', 'wdk-bookings'); ?>">
                        <i class="fas fa-user"></i> x5
                        <div class="amities">
                            <span class="item"><i class="fas fa-child"></i> <?php echo esc_html__('Childrens', 'wdk-bookings'); ?></span>
                        </div>
                    </td>
                    <td data-label="<?php echo esc_html__('Date from', 'wdk-bookings'); ?>" class="v-vertical-m"><?php echo esc_html__('December', 'wdk-bookings'); ?> 1, 2020 12:00 am</td>
                    <td data-label="<?php echo esc_html__('Date To', 'wdk-bookings'); ?>" class="v-vertical-m"><?php echo esc_html__('December', 'wdk-bookings'); ?> 30, 2025 12:00 am</td>


                    <?php if (wmvc_show_data('enable_columns_changeover_day', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Change Day', 'wdk-bookings'); ?>" class="v-vertical-m text-center"> <?php echo esc_html__('Monday', 'wdk-bookings'); ?></td>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_hour', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Hour', 'wdk-bookings'); ?>" class="v-vertical-m text-center"> 1.00$</td>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_days', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Day', 'wdk-bookings'); ?>" class="v-vertical-m text-center">10.00$</td>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_week', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Week', 'wdk-bookings'); ?>" class="v-vertical-m text-center">20.00$</td>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_month', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Month', 'wdk-bookings'); ?>" class="v-vertical-m text-center"> 30.00$</td>
                    <?php endif; ?>

                    <?php if (wmvc_show_data('enable_columns_year', $settings) == 'yes') : ?>
                        <td data-label="<?php echo esc_html__('Year', 'wdk-bookings'); ?>" class="v-vertical-m text-center"> 380.00$</td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
        <div class="fees">
            <ul class="fee-list">
                <li class="item">
                    <span class="fee-title">Cleaning:</span>
                    <span class="fee-value">150</span>
                    <span class="fee-hint">(Clean on first day)</span>
                </li>
                <li class="item">
                    <span class="fee-title">Fee:</span>
                    <span class="fee-value">10</span>
                </li>
                <li class="item">
                    <span class="fee-title">Heating:</span>
                    <span class="fee-value">100</span>
                    <span class="fee-hint">(service)</span>
                </li>
            </ul>
        </div>
        <?php if (is_user_logged_in()) : ?>
            <a href="#date_from" class="wdk-booking"><?php echo esc_html__('Make Reservation', 'wdk-bookings'); ?></a>
        <?php else : ?>
            <a href="<?php echo esc_url(wdk_login_url(wdk_current_url())); ?>" class="wdk-booking"><?php echo esc_html__('Login in', 'wdk-bookings'); ?></a>
        <?php endif; ?>
    </div>
</div>