<div class="widget-eli eli_blog_post_counter" id="eli_<?php echo esc_html($this->get_id_int());?>">
<?php echo esc_html($settings['prefix_counter']);?> <?php echo esc_html($count);?> <?php echo esc_html($settings['suffix_counter']);?>
</div>
