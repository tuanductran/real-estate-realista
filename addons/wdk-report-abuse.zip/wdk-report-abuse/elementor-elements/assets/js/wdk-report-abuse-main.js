(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

    /* mail send */
    $('.wdk-report-abuse-ajax').on('submit', function(e){
        e.preventDefault();
        var this_form = $(this);
        var $config = this_form.find('.config');
        var conf_link = $config.attr('data-url') || 0;
        var load_indicator = this_form.find('.fa-ajax-indicator');
		var box_alert = this_form.find('.alert_box');
		
        box_alert.html('');
        load_indicator.css('display', 'inline-block');
        
		var data = this_form.serializeArray();
		
		data.push({ name: 'action', value: "wdk_report_abuse_public_action" });
		data.push({ name: 'page', value: "wdk-report-abuse-frontendajax" });
		data.push({ name: 'function', value: "report_abuse_send" });
        
		$.post(conf_link, data, 
			function (data) {
				
			if(data.message)
				box_alert.html(data.message);

			if(data.popup_text_success)
				wdk_log_notify(data.popup_text_success);
				
			if(data.popup_text_error)
				wdk_log_notify(data.popup_text_error, 'error');
				
			if(data.success)
			{
				this_form.find('input:not([type="checkbox"]):not([name="element_id"]):not([name="post_id"]):not([type="radio"]):not([type="hidden"]),textarea').val('');
				jQuery('[data-wdk-dismiss="modal"]').trigger('click');

				let promise = new Promise((resolve, reject) => {
					setTimeout(() => {
						resolve(text_parameters.listing_reported);
					}, 1000);
				});

				promise.then((value) => {
					$('#wdk_report_abuse').html('<p class="wdk_alert wdk_alert-success">'+value+'</p>');
				});
			} else {
				
			}
		}).always(function(data) {
			load_indicator.css('display', 'none');
		});

        return false;
    });
	/* end mail send */
	
})(jQuery);