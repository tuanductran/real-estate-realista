<?php
/**
 * The template for Report Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Report Abuse','wdk-report-abuse'); ?></h1>
    <br />
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-report-abuse" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-report-abuse'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-report-abuse'); ?>" />
                
                <label class="screen-reader-text" for="category_id"><?php echo __('Filter by category', 'wdk-report-abuse'); ?></label>
                <?php echo wmvc_select_option('status',array( ''=>__('Select status', 'wdk-report-abuse')) + $this->report_abuse_m->statuses_list, wmvc_show_data('status', $db_data, ''), NULL, __('Status', 'wdk-report-abuse')); ?>

                <label class="screen-reader-text" for="post_id"><?php echo esc_html__('Post Id', 'wdk-report-abuse'); ?></label>
                <span class="wdk-unwrapp-field">
                    <?php echo wdk_treefield_option('post_id', 'listing_m', wmvc_show_data('post_id', $db_data, ''), 'post_title', '', __('Not Selected', 'wdk-report-abuse'));?>
                </span>

                <label class="screen-reader-text" for="user_id"><?php echo esc_html__('Filter by user name', 'wdk-report-abuse'); ?></label>
                <input type="text" name="name" id="name" class="postform left" value="<?php echo wmvc_show_data('name', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Name', 'wdk-report-abuse'); ?>" />

                <label class="screen-reader-text" for="address"><?php echo esc_html__('Filter by user address', 'wdk-report-abuse'); ?></label>
                <input type="text" name="address" id="address" class="postform left" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-report-abuse'); ?>" />

                <label class="screen-reader-text" for="email"><?php echo esc_html__('Filter by user email', 'wdk-report-abuse'); ?></label>
                <input type="text" name="email" id="email" class="postform left" value="<?php echo wmvc_show_data('email', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Email', 'wdk-report-abuse'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-report-abuse'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-report-abuse')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-report-abuse'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Title','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Full Name','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Email','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Date','wdk-report-abuse'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-report-abuse'); ?></th>
            </tr>
        </thead>
        <?php if(count($report_abuse) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="7"><?php echo esc_html__('No Report Abuse found.','wdk-report-abuse'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $report_abuse as $report_abuse ):?>
            <tr>
                <td>
                    <?php echo wmvc_show_data('idreportabuse', $report_abuse, '-'); ?>
                    <?php
                        $class="label-danger";
                        if(wmvc_show_data('status', $report_abuse) == 'NEW'){
                            $class="label-warning";
                        } else if(wmvc_show_data('status', $report_abuse) == 'IN PROGRESS') {
                            $class="label-info";
                        } else if(wmvc_show_data('status', $report_abuse) == 'DECLINED') {
                            $class="label-danger";
                        } else if(wmvc_show_data('status', $report_abuse) == 'APPROVED' || wmvc_show_data('status', $report_abuse) == 'COMPLETED') {
                            $class="label-success";
                        }
                    ?>

                    <?php if(wmvc_show_data('status', $report_abuse, false) && isset($this->report_abuse_m->statuses_list[wmvc_show_data('status', $report_abuse, '-')])):?>
                        <span class="label <?php echo esc_attr($class);?>"><?php echo esc_html($this->report_abuse_m->statuses_list[wmvc_show_data('status', $report_abuse, '-')]); ?></span>
                    <?php endif;?>

                </td>
                <td>
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $report_abuse, '-')); ?>" title="<?php echo esc_attr__('View', 'wdk-report-abuse');?>">
                        <?php echo wmvc_show_data('post_title', $report_abuse, '-'); ?>
                    </a>
                </td>
                <td>
                    <?php echo wmvc_show_data('name', $report_abuse, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('address', $report_abuse, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('email', $report_abuse, '-'); ?>
                </td>
                <td>
                    <?php echo wdk_get_date(wmvc_show_data('date', $report_abuse), false); ?>
                </td>
          
                <td class="actions_column">
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $report_abuse, '-')); ?>" target="_blank" title="<?php echo esc_attr__('View', 'wdk-report-abuse');?>"><span class="dashicons dashicons-visibility"></span></a>
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-report-abuse&function=edit&id=" . wmvc_show_data('idreportabuse', $report_abuse, '-'); ?>" title="<?php echo esc_attr__('Edit', 'wdk-report-abuse');?>"><span class="dashicons dashicons-edit"></span></a>
                    <a class="question_sure" href="<?php echo get_admin_url() . "admin.php?page=wdk-report-abuse&function=delete&id=".wmvc_show_data('idreportabuse', $report_abuse, '-'); ?>" title="<?php echo esc_attr__('Remove', 'wdk-report-abuse');?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Title','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Name', 'wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Address', 'wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Email','wdk-report-abuse'); ?></th>
                <th><?php echo esc_html__('Date','wdk-report-abuse'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-report-abuse'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-report-abuse')); ?>");
        });
    });
</script>

<?php $this->view('general/footer', $data); ?>
