<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_report_abuse_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('report_abuse_m');


        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->data['post_types'] = array();

        $this->data['order_by']   = array(  'idreportabuse DESC' => __('ID', 'wdk-report-abuse').' DESC', 
                                            'idreportabuse ASC' => __('ID', 'wdk-report-abuse').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-report-abuse').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-report-abuse').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'address',
                'label' => __('Address', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'name',
                'label' => __('Name', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'email',
                'label' => __('Email', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'post_id',
                'label' => __('Post Id', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-report-abuse'),
                'rules' => ''
            ),
            array(
                'field' => 'status',
                'label' => __('Status', 'wdk-report-abuse'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->report_abuse_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'report_abuse';
        $columns = array('idreportabuse', 'post_id','order_by', 'name', 'address', 'email','status');
        $external_columns = array('post_title', 'address');

        wdk_report_abuse_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->report_abuse_m->total( array(), FALSE);

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_report_abuse_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['report_abuse'] = $this->report_abuse_m->get_pagination($per_page, $offset, array(), NULL, FALSE);
       
        // Load view
        $this->load->view('wdk_report_abuse/index', $this->data);
    }

    public function edit()
	{
    
        $id = $this->input->post_get('id');
        $this->load->model('report_abuse_m');
        global $Winter_MVC_WDK;
		$Winter_MVC_WDK->load_helper('listing');

		$Winter_MVC_WDK->model('listing_m');
		$Winter_MVC_WDK->model('listingusers_m');
        $this->data['owner_user_id'] = NULL;

        if(function_exists('wdk_access_check'))
            wdk_access_check('report_abuse_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['fields'] = $this->report_abuse_m->fields_list;


        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->report_abuse_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post
            $insert_id = $this->report_abuse_m->insert($data, $id);

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-report-abuse-edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
           $this->data['db_data'] = $this->report_abuse_m->get($id, TRUE);
           $listing = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $this->data['db_data']), TRUE);
           if(wdk_show_data('user_id_editor', $listing, '',TRUE, TRUE))
            $this->data['owner_user_id'] = wdk_show_data('user_id_editor', $listing, '',TRUE, TRUE);
        }

        $this->load->view('wdk_report_abuse/edit', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('report_abuse_m');
        
        $this->report_abuse_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-report-abuse&paged=$paged"));
    }
    
}
