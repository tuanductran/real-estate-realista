<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Membership
 * @subpackage Wdk_Membership/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Membership
 * @subpackage Wdk_Membership/includes
 * @author     wpdirectorykit.com <info@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Membership_Activator {

	public static $db_version = 1.8;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_membership_';
	}

	public static function plugins_loaded(){
		if ( get_site_option( 'wdk_membership_db_version' ) === false ||
		     get_site_option( 'wdk_membership_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_membership_db_version' ) === false)
        {
			$role = get_role('wdk_visitor');
            if($role != NULL)
			    $role->remove_cap('edit_own_listings');

			update_option( 'wdk_membership_register_type', 'wdk_owner' );
			update_option( 'wdk_membership_register_show_user_select', '1' );
			
			self::$db_version = 1.0;
        }
        
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_membership_db_version' ) < '1.1' ) 
        {
            // Main table for subscriptions

            $table_name = $wpdb->prefix . 'wdk_membership_subscription';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idsubscription` int(11) NOT NULL AUTO_INCREMENT,
                    `date` datetime DEFAULT NULL,
                    `subscription_name` varchar(60) DEFAULT NULL,
                    `category_id` int(11) DEFAULT NULL,
                    `location_id` int(11) DEFAULT NULL,
                    `featured_rank` int(11) DEFAULT NULL,
                    `days_limit` int(11) DEFAULT NULL,
                    `listings_limit` int(11) DEFAULT NULL,
                    `images_limit` int(11) DEFAULT NULL,
                    `is_auto_featured` tinyint(1) DEFAULT NULL,
                    `is_auto_approved` tinyint(1) DEFAULT NULL,
                    `is_view_private_listings` tinyint(1) DEFAULT NULL,
                    `date_from` datetime DEFAULT NULL,
                    `date_to` datetime DEFAULT NULL,
                    `price` decimal(13,2) DEFAULT NULL,
                    `woocommerce_product_id` int(11) DEFAULT NULL,
                    `is_activated` tinyint(1) NOT NULL DEFAULT 1,
                PRIMARY KEY  (idsubscription)
            ) $charset_collate COMMENT='Membership Subscriptions';";
        
            dbDelta( $sql );

            $table_name = $wpdb->prefix . 'wdk_membership_subscription_user';
            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idsubscription_user` int(11) NOT NULL AUTO_INCREMENT,
                    `date` datetime DEFAULT NULL,
                    `user_id` int(11) DEFAULT NULL,
                    `subscription_id` int(11) DEFAULT NULL,
                    `date_last_paid` datetime DEFAULT NULL,
                    `date_expire` datetime DEFAULT NULL,
                    `date_notify` datetime DEFAULT NULL,
                    `status` varchar(45) DEFAULT NULL COMMENT '[ACTIVE|EXPIRED|PENDING]',
                PRIMARY KEY  (idsubscription_user)
            ) $charset_collate COMMENT='Membership Subscriptions';";
        
            dbDelta( $sql );

            self::$db_version = 1.1;
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.2' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_subscription_user';
            $sql = "ALTER TABLE `$table_name` ADD `price_paid` decimal(13,2) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.2;
            /* udpate option with db version */
        }
        
        if ( get_site_option( 'wdk_membership_db_version' ) < '1.3' ) {

            update_option( 'wdk_membership_is_enable_subscriptions', '1' );

            self::$db_version = 1.3;
            /* udpate option with db version */
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.4' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_subscription';
            $sql = "ALTER TABLE `$table_name` ADD `is_booked_enabled` tinyint(1) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.4;
            /* udpate option with db version */
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.5' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_subscription';
            $sql = "ALTER TABLE `$table_name` ADD `order_index` int(11) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.5;
            /* udpate option with db version */
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.6' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_subscription';
            $sql = "ALTER TABLE `$table_name` ADD `user_types` varchar(256) DEFAULT NULL;";
            $wpdb->query($sql);

            $sql = "ALTER TABLE `$table_name` ADD `is_only_login_user` varchar(256) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.6;
            /* udpate option with db version */
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.7' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_agency_agent';
            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idagency_agent` int(11) NOT NULL AUTO_INCREMENT,
                    `date` datetime DEFAULT NULL,
                    `agency_id` int(11) DEFAULT NULL,
                    `agent_id` int(11) DEFAULT NULL,
                    `date_send` datetime DEFAULT NULL,
                    `date_confirmed` datetime DEFAULT NULL,
                    `status` varchar(45) DEFAULT NULL COMMENT '[PENDING|CONFIRMED]',
                PRIMARY KEY  (idagency_agent)
            ) $charset_collate COMMENT='Agency related Agents';";
        
            dbDelta( $sql );

            self::$db_version = 1.7;
            /* udpate option with db version */
        }

        if ( get_site_option( 'wdk_membership_db_version' ) < '1.8' ) {

            $table_name = $wpdb->prefix . 'wdk_membership_agency_agent';
            
            $sql = "ALTER TABLE `$table_name` ADD `listings_count` int(11) DEFAULT NULL;";
            $wpdb->query($sql);

            self::$db_version = 1.8;
            /* udpate option with db version */
        }

        update_option( 'wdk_membership_db_version', self::$db_version );
    }

}
