<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Agency_agent_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_membership_agency_agent';
	public $_order_by = 'idagency_agent';
    public $_primary_key = 'idagency_agent';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();
	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE, $user_id = NULL)
    {
        $this->db->select('COUNT(*) as total_count');
        //$this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');
        $this->db->from($this->_table_name);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('agency_id', $user_id);
            }
            else 
            {
                $this->db->where('agency_id', get_current_user_id());
            }
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset=0, $where = array(), $order_by = NULL, $user_check = TRUE, $user_id = NULL)
    {
        $this->db->select('*');
        //$this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');

        $this->db->from($this->_table_name);
        $this->db->where($where);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('agency_id', $user_id);
            }
            else 
            {
                $this->db->where('agency_id', get_current_user_id());
            }
        }

        if(!empty($limit)) {
            $this->db->limit($limit);
            if(empty($offset)) $offset = 0;
            $this->db->offset($offset);
        }

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function get_pagination_agency($limit=NULL, $offset=0, $where = array(), $order_by = NULL)
    {
        $this->db->select('*');
        //$this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');

        $this->db->from($this->_table_name);
        $this->db->where($where);

        if(!empty($limit)) {
            $this->db->limit($limit);
            if(empty($offset)) $offset = 0;
            $this->db->offset($offset);
        }

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $this->db->group_by('agency_id');

        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    
    public function get_pagination_agents($agency_id, $limit = NULL, $offset = NULL, $where = array(), $order_by = NULL, $show_other_agents_litings = FALSE, $only_listings_assigned = FALSE)    
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('user_m');

        $this->db->join($this->_table_name.' ON ('.$Winter_MVC_WDK->user_m->_table_name.'.ID = '.$this->_table_name.'.agent_id  AND '.$this->_table_name.'.status = "CONFIRMED")', TRUE, 'LEFT');
        $this->db->where('agency_id', $agency_id);

        return $Winter_MVC_WDK->user_m->get_pagination($limit, $offset, $where, $order_by, "meta_value LIKE '%wdk_agent%'", $show_other_agents_litings, $only_listings_assigned, FALSE);

    }

        
    public function total_agents($agency_id, $where = array(), $only_listings_assigned = FALSE)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('user_m');
        $this->db->join($this->_table_name.' ON ('.$Winter_MVC_WDK->user_m->_table_name.'.ID = '.$this->_table_name.'.agent_id  AND '.$this->_table_name.'.status = "CONFIRMED")', TRUE, 'LEFT');
        $this->db->where('agency_id', $agency_id);

        return $Winter_MVC_WDK->user_m->total($where, "meta_value LIKE '%wdk_agent%'", $only_listings_assigned, FALSE);
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
                
        if(empty($user_id))
            $user_id = get_current_user_id();

        $item = $this->get($id, TRUE);
        if(isset($item->agency_id) && $item->agency_id == $user_id)
            return true;

        $item = $this->get($id, TRUE);
        if(isset($item->agent_id) && $item->agent_id == $user_id)
            return true;
            
        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        return false;
    }

}
?>