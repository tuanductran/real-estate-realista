<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;
    public $user_fields_list = array();
    public $user_types_list = array();
    public $user_fields_prefix = 'wdk_membership_custom_field_';
    public $user_types_prefix = 'wdk_membership_user_type_';

	public function __construct(){
        parent::__construct();

        global $wdk_membership_user_fields_list, $wdk_membership_user_types, $Winter_MVC_wdk_membership;
        
        foreach($wdk_membership_user_fields_list as $field_id => $field_name) {
            $this->user_fields_list[$this->user_fields_prefix.$field_id.'_enable'] = $field_name;
        }

        $roles = array('' => __('Not Selected', 'wdk-membership'));
        foreach($wdk_membership_user_types as $type_id => $type_name) {
            $this->user_types_list[$this->user_types_prefix.$type_id.'_enable'] =  __($type_name, 'wdk-membership');

            $roles [$type_id] = __($type_name, 'wdk-membership');
        }

        $pages = array('' => __('Not Selected', 'wdk-membership'));
        foreach(get_pages(array('sort_column' => 'post_title')) as $page)
        {
            $pages[$page->ID] = $page->post_title.' #'.$page->ID;
        }
        $Winter_MVC_wdk_membership->model('subscription_m');
        $subscriptions = $Winter_MVC_wdk_membership->subscription_m->get_pagination(NULL, FALSE, array('is_activated'=>1));
        $subscriptions_array = array('' => __('Not Selected', 'wdk-membership'));

        if (count($subscriptions) > 0) {
            foreach($subscriptions as $subscription) {
                $subscriptions_array[wdk_show_data('idsubscription',$subscription,'', TRUE, TRUE)] = wdk_show_data('idsubscription', $subscription,'', TRUE, TRUE)
                                                                                            .', '.wdk_show_data('subscription_name', $subscription,'', TRUE, TRUE);
            }
        }

        $this->fields_list = array( 

            array('field' => 'wdk_membership_register_page', 'field_label' => __('Register Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),
            
            array('field' => 'wdk_membership_login_page', 'field_label' => __('Login Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),
            
            array('field' => 'wdk_membership_profile_preview_page', 'field_label' => __('Profile Preview Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),
            
            array('field' => 'wdk_membership_profile_search_page', 'field_label' => __('Profile Search Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),
            
            array('field' => 'wdk_membership_dash_page', 'field_label' => __('Frontend Dashboard Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),
            
            array('field' => 'wdk_membership_quicksumbission_page', 'field_label' => __('Frontend Submission Listing Page', 'wdk-membership'), 'hint' => __('Select regular page which ill be used for listing preview page on frontend, you can create new one also for this purpose', 'wdk-membership'), 'field_type' => 'DROPDOWN_PAGE', 'rules' => '', 'values' => $pages),

            array('field' => 'wdk_membership_custom_fields_enabled', 'field_label' => __('Member custom fields', 'wdk-membership'), 'hint' => __('Select custom fields which you want to enable on frontend registration', 'wdk-membership'), 'field_type' => 'CHECKBOX_MULTIPLE', 'rules' => '', 'values' => $this->user_fields_list),
            
            array('field' => 'wdk_membership_types_enabled', 'field_label' => __('Member types', 'wdk-membership'), 'hint' => __('Select user types which you want to enable', 'wdk-membership'), 'field_type' => 'CHECKBOX_MULTIPLE', 'rules' => '', 'values' => $this->user_types_list),
           
            array('field' => 'wdk_membership_register_type', 'field_label' => __('New User default type', 'wdk-membership'), 'hint' => __('You can set default user types on frontend registration', 'wdk-membership'), 'field_type' => 'DROPDOWN', 'rules' => '', 'values'=>$roles),
            array('field' => 'wdk_membership_register_show_user_select', 'field_label' => __('Enable user types dropdown', 'wdk-membership'), 'hint' => __('You can enable dropdown with selection of currently enabled user types on registration form', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),

            array('field' => 'wdk_membership_adminbar_disabled', 'field_label' => __('Disable top admin bar', 'wdk-membership'), 'hint' => __('You can disable top admin bar for all except admin (only active if frontend dashboard page is selected/enabled)', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
        
            array(
                'field' => 'wdk_membership_disable_registration', 
                'field_label' => __('Disable new user registration', 'wdk-membership'), 
                'hint' => __('Select checkbox for disable registration', 'wdk-membership'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),

            array(
                'field' => 'wdk_membership_disable_registration_custom_message', 
                'field_label' => __('Disable new user registration custom message', 'wdk-membership'), 
                'hint' => __('Change default message of disable registration alert', 'wdk-membership'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),
            
            array(
                'field' => 'wdk_membership_login_required_listing_preview', 
                'field_label' => __('Login required for listing details', 'wdk-membership'), 
                'hint' => __('Select checkbox for show listings only for login users', 'wdk-membership'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_membership_login_required_listing_results', 
                'field_label' => __('Login required for results page', 'wdk-membership'), 
                'hint' => __('Select checkbox to show results page only for login users, otherwise redirect to login page when results and login pages are configured', 'wdk-membership'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_membership_is_always_dash_redirect', 
                'field_label' => __('Enable Always Redicted to Dash Account', 'wdk-membership'), 
                'hint' => __('Enable if you want after login by wp-admin redirect to Dash (Dash page should be defined in settings of Membership)', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_is_enable_subscriptions', 
                'field_label' => __('Enable Membership Subscriptions', 'wdk-membership'), 
                'hint' => '',
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_is_subscription_required', 
                'field_label' => __('Require active subscription to add listings', 'wdk-membership'), 
                'hint' => __('Enable if you want thats your users will be required to purchase some Membership Subscription before they can add listings', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_multiple_subscriptions_enabled', 
                'field_label' => __('Enable Multiple subscriptions', 'wdk-membership'), 
                'hint' => __('Enable one user can have few subscriptions', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_subscriptions_view_listing_enabled', 
                'field_label' => __('Membership required for listing details', 'wdk-membership'), 
                'hint' => __('Enable for show listings only if activated in subscription', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_subscriptions_default_on_registration', 
                'field_label' => __('Default subscription on registration', 'wdk-membership'), 
                'hint' => __('After success registration, set subscription', 'wdk-membership'),
                'field_type' => 'DROPDOWN', 'rules' => '',
                'values' => $subscriptions_array
            ),
            array(
                'field' => 'wdk_membership_enable_varification_mail', 
                'field_label' => __('Membership email varification', 'wdk-membership'), 
                'hint' => __('Enable verification email, when visitor create new account, need to click on link in email to verify ownership', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_enable_varification_mail_mobile_api', 
                'field_label' => __('Membership email varification For Mobile Api', 'wdk-membership'), 
                'hint' => __('Enable verification email, for mobile app, note required activate "Membership email varification"', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_enable_unique_phone_number', 
                'field_label' => __('Require unique phone number', 'wdk-membership'), 
                'hint' => __('If phone field is on wdk registration form, system will not allow to register with existing phone number in system', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array(
                'field' => 'wdk_membership_none_user_editable_hide', 
                'field_label' => __('Hide Membership', 'wdk-membership'), 
                'hint' => __('Enable hide Membership on Frontend dashboard for users which can\'t add own listings', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 'rules' => ''
            ),
            array('field' => 'wdk_auto_approved', 'field_label' => __('Auto Approve Listings', 'wdk-membership'), 'hint' => __('Always auto activate approved listings (all agents listings will be auto activated if agent approved)', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
        );

	}

}
?>