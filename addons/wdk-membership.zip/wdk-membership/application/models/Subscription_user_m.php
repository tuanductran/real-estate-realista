<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Subscription_user_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_membership_subscription_user';
	public $_order_by = 'idsubscription_user';
    public $_primary_key = 'idsubscription_user';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        $this->fields_list = array(
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-membership'),
                'hint' => '', 
                'field_type' => 'USERS', 
                'rules' => 'required'
            ),
            array(
                'field' => 'subscription_id',
                'field_label' => __('Subscription id', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => 'required|wdk_membership_unique_user_subscription|wdk_membership_user_subs_exists',
                'class' => 'hidden idsubscription-field'
            ),
            array(
                'field' => 'price_paid',
                'field_label' => __('Price paid', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'date_last_paid',
                'field_label' => __('Date last paid', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'DATE', 
                'rules' => ''
            ),
            array(
                'field' => 'date_expire',
                'field_label' => __('Date expire', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'DATE', 
                'rules' => 'required'
            ),
            array(
                'field' => 'date_notify',
                'field_label' => __('Date last Notify', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'DATE', 
                'rules' => ''
            ),
            array(
                'field' => 'status',
                'field_label' => __('Status', 'wdk-membership'),
                'hint' => '',
                'field_type' => 'DROPDOWN', 
                'rules' => '', 
                'values' => array('' => __('Not Selected', 'wdk-membership'), 'ACTIVE'=>__('ACTIVE', 'wdk-membership'),'EXPIRED'=>__('EXPIRED', 'wdk-membership'),'PENDING'=>__('PENDING', 'wdk-membership')),
            ),

        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE, $user_id = NULL)
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');
        $this->db->from($this->_table_name);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('user_id', $user_id);
            }
            else 
            {
                $this->db->where('user_id', get_current_user_id());
            }
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset=0, $where = array(), $order_by = NULL, $user_check = TRUE, $user_id = NULL)
    {


        $this->db->select('*');
        $this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');

        $this->db->from($this->_table_name);
        $this->db->where($where);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('user_id', $user_id);
            }
            else 
            {
                $this->db->where('user_id', get_current_user_id());
            }
        }

        if(!empty($limit)) {
            $this->db->limit($limit);
            if(empty($offset)) $offset = 0;
            $this->db->offset($offset);
        }

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
   
    public function total_belongs_listings($where = array(), $user_check = TRUE, $user_id = NULL)
    {

        $this->db->select('COUNT(*) as total_count');
        $this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');
        $this->db->from($this->_table_name);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('user_id', $user_id);
            }
            else 
            {
                $this->db->where('user_id', get_current_user_id());
            }
        }

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination_belongs_listings($limit, $offset=0, $where = array(), $order_by = NULL, $user_check = TRUE, $user_id = NULL)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        
        global $wpdb;
        $wp_usermeta_table = $wpdb->users;

        $this->db->select($wp_usermeta_table.'.*,'.$this->db->prefix.'wdk_membership_subscription.*,'.$this->_table_name.'.*, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS listings_counter');
        $this->db->join($this->db->prefix.'wdk_membership_subscription ON '.$this->db->prefix.'wdk_membership_subscription.idsubscription = '.$this->_table_name.'.subscription_id', TRUE, 'LEFT');
        
        $this->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON ('.$Winter_MVC_WDK->listing_m->_table_name.'.subscription_id = '.$this->_table_name.'.subscription_id
                        AND '.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor = '.$this->_table_name.'.user_id)', TRUE, 'LEFT');

        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.user_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');

        $this->db->group_by('idsubscription_user');

        $this->db->from($this->_table_name);
        $this->db->where($where);

        if($user_check) {
            if(!is_null($user_id) && !empty($user_id))
            {
                $this->db->where('user_id', $user_id);
            }
            else 
            {
                $this->db->where('user_id', get_current_user_id());
            }
        }

        if(!empty($limit)) {
            $this->db->limit($limit);
            if(empty($offset)) $offset = 0;
            $this->db->offset($offset);
        }

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
                
        if(empty($user_id))
            $user_id = get_current_user_id();

        $item = $this->get($id, TRUE);
        if(isset($item->user_id) && $item->user_id == $user_id)
            return true;
            
        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        return false;
    }

    public function check_have_active($user_id = NULL) {
        if(empty($user_id ))
            $user_id = get_current_user_id();

        $have_active = false;
        if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
            $user_subscriptions = $this->get_pagination(1, FALSE, array('is_activated'=>1),'subscription_id DESC');
            if(!empty($user_subscriptions) && strtotime($user_subscriptions[0]->date_expire) > time()) {
                $have_active = true;
            }
        } else {
            if($this->total(array('is_activated'=>1,'date_expire >' => date('Y-m-d H:i:s')), TRUE, $user_id)) {
                $have_active = true;
            }
        }

        return $have_active;
    }

}
?>