<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Subscription_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_membership_subscription';
	public $_order_by = 'idsubscription';
    public $_primary_key = 'idsubscription';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $user_types_list = array();

	public function __construct(){
        parent::__construct();

        $this->_order_by = $this->db->prefix.'wdk_membership_subscription.order_index';

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $categories = $Winter_MVC_WDK->category_m->get_parents();
        $locations  = $Winter_MVC_WDK->location_m->get_parents();

        global $wdk_membership_user_fields_list, $wdk_membership_user_types, $Winter_MVC_wdk_membership;
        foreach($wdk_membership_user_types as $type_id => $type_name) {
            $this->user_types_list[$type_id] = __($type_name, 'wdk-membership');
        }
        $this->user_types_list['administrator'] = __('Administrator', 'wdk-membership');

        $this->fields_list = array(
            array(
                'field' => 'subscription_name',
                'field_label' => __('Subscription Name', 'wdk-membership'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),

            array(
                'field' => 'user_types',
                'field_label' => __('User types', 'wdk-membership'),
                'hint' => __('Check to list this membership package to this defined account types, if nothing selected then will be available for all', 'wdk-membership'),
                'field_type' => 'CHECKBOX_MULTIPLE_SINGLE_FIELD', 
                'values' => $this->user_types_list,
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'field_label' => __('Category', 'wdk-membership'),
                'hint' => __('Leave empty if not related to specific category', 'wdk-membership'),
                'field_type' => 'DROPDOWN', 
                'values' => array('' => '') + $categories,
                'rules' => ''
            ),
            array(
                'field' => 'location_id',
                'field_label' => __('Location', 'wdk-membership'),
                'hint' => __('Leave empty if not related to specific location', 'wdk-membership'),
                'field_type' => 'DROPDOWN', 
                'values' => array('' => '') + $locations,
                'rules' => ''
            ),
            array(
                'field' => 'order_index',
                'field_label' => __('Order Index', 'wdk-membership'),
                'hint' => __('Index for sorting/ordering, used if you need specific order', 'wdk-membership'),
                'field_type' => 'NUMBER', 
                'rules' => ''
            ),
            array(
                'field' => 'featured_rank',
                'field_label' => __('Featured rank level', 'wdk-membership'),
                'hint' => __('Higher Rank means better position in search results', 'wdk-membership'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'days_limit',
                'field_label' => __('Days Limit', 'wdk-membership'),
                'hint' => __('When Days Limit expire, user will need to purchase again', 'wdk-membership'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'listings_limit',
                'field_label' => __('Listings Limit', 'wdk-membership'),
                'hint' => __('When Listings Limit, user can\'t add more listings, set -1 for unlimited', 'wdk-membership'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'images_limit',
                'field_label' => __('images Limit', 'wdk-membership'),
                'hint' => __('Limit images per one listing, set -1 for unlimited', 'wdk-membership'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'is_auto_featured',
                'field_label' => __('Make Listing Featured', 'wdk-membership'),
                'hint' => __('Enable marked as featured', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_auto_approved',
                'field_label' => __('Auto Approve Listing', 'wdk-membership'),
                'hint' => __('Listing will be automatically marked as approved', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_view_private_listings',
                'field_label' => __('Allow View Listing Details', 'wdk-membership'),
                'hint' => __('Enable visible listings, only if option in settings activated "Membership required for listing details"', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_booked_enabled',
                'field_label' => __('Allow Booking', 'wdk-membership'),
                'hint' => __('Enable visible bookings feature', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'price',
                'field_label' => __('Price', 'wdk-membership'),
                'hint' => __('If price is free, then subscription can be activated only once. Currency is based on WooCommerce configuration.', 'wdk-membership'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'woocommerce_product_id',
                'field_label' => __('WooCommerce Product ID', 'wdk-membership'),
                'hint' => __('In WooCommerce create product and based on #ID link it to this subscription, must be hidden virtual product. Otherwise purchase will not be possible. 
                              if no woocommerce product id entered, then create one automatically and assign', 'wdk-membership'),
                'field_type' => 'INPUTBOX_WOO', 
                'rules' => 'numeric|wdk_membership_unique_and_exists_woocommerce_product_id'
            ),
            array(
                'field' => 'date_from',
                'field_label' => __('Date From', 'wdk-membership'),
                'hint' => __('User will be able to use subscription from this date', 'wdk-membership'),
                'field_type' => 'DATE', 
                'rules' => ''
            ),
            array(
                'field' => 'date_to',
                'field_label' => __('Date To', 'wdk-membership'),
                'hint' => __('User will be able to use subscription until this date', 'wdk-membership'),
                'field_type' => 'DATE', 
                'rules' => ''
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-membership'),
                'hint' => __('Subscription is available for purchase, if days above allowe this also', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'default' => '1',
                'rules' => ''
            ),
            array(
                'field' => 'is_only_login_user',
                'field_label' => __('Is Only For login User', 'wdk-membership'),
                'hint' => __('Hide for non logged users', 'wdk-membership'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),

        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array())
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        
        $this->db->join($this->db->prefix.'wdk_categories ON '.$this->db->prefix.'wdk_categories.idcategory = '.$this->_table_name.'.category_id', TRUE, 'LEFT');
        $this->db->join($this->db->prefix.'wdk_locations ON '.$this->db->prefix.'wdk_locations.idlocation = '.$this->_table_name.'.location_id', TRUE, 'LEFT');

        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset = 0, $where = array(), $order_by = NULL, $custom_select = NULL)
    {
        if(!empty($custom_select)) {
            $this->db->select($custom_select);
        } else {
            $this->db->select('*');
        }

        $this->db->from($this->_table_name);

        $this->db->join($this->db->prefix.'wdk_categories ON '.$this->db->prefix.'wdk_categories.idcategory = '.$this->_table_name.'.category_id', TRUE, 'LEFT');
        $this->db->join($this->db->prefix.'wdk_locations ON '.$this->db->prefix.'wdk_locations.idlocation = '.$this->_table_name.'.location_id', TRUE, 'LEFT');

        $this->db->where($where);

        if(!empty($limit)) {
            $this->db->limit($limit);
            if(empty($offset)) $offset = 0;
            $this->db->offset($offset);
        }

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
                        
        if(empty($user_id))
            $user_id = get_current_user_id();

        $subscription = $this->get($id, TRUE);
        if(isset($subscription->user_id) && $subscription->user_id == $user_id)
            return true;
            
        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        parent::delete($id);

        return true;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        return false;
    }

}
?>