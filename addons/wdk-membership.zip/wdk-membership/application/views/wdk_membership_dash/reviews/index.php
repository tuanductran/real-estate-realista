<?php
/**
 * The template for Review Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_reviews_index">
    <h1 class="wdk-h"><?php echo esc_html__('My Reviews', 'wdk-membership'); ?></h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=reviews')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="reviews" />
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <?php if(false):?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="category_id"><?php echo esc_html__('Filter by category', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('category_id', $review_categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Category', 'wdk-membership')); ?>
                    </div>
                    <?php endif;?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="post_type"><?php echo esc_html__('Filter by post type', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('review_post_type', $post_types, wmvc_show_data('review_post_type', $db_data, ''), NULL, __('Post Type', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=reviews')); ?>">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-membership'); ?></label>
                        <input id="cb-select-all-1" type="checkbox" value="1">
                    </td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Listing/Profile', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Reviews Type', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('User', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Stars', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <?php if(count($reviews) == 0): ?>
                <tr class="no-items"><td class="colspanchange" colspan="5"><?php echo esc_html__('No reviews found.','wdk-membership'); ?></td></tr>
            <?php endif; ?>
            <?php foreach ( $reviews as $review ):?>
                <?php
                    $view_link = '#';
                    if(wmvc_show_data('review_post_type', $review) == 'profile') {
                        $view_link = wdk_generate_profile_permalink(wmvc_show_data('post_id', $review));
                    } else {
                        $view_link = get_permalink(wmvc_show_data('post_id', $review));
                    }
                ?>
                <tr>
                    <th data-label="<?php echo esc_html__('Checkbox', 'wdk-membership'); ?>" scope="row" class="check-column">
                        <input id="cb-select-<?php echo wmvc_show_data('s', $review, '-'); ?>" type="checkbox" name="ids[]" value="<?php echo wmvc_show_data('idreviews', $review, '-'); ?>">
                        <div class="locked-indicator">
                            <span class="locked-indicator-icon" aria-hidden="true"></span>
                            <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-membership'); ?></span>
                        </div>
                    </th>
                    <td data-label="<?php echo esc_html__('id', 'wdk-membership'); ?>">
                        <?php echo wmvc_show_data('idreviews', $review, '-'); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Post', 'wdk-membership'); ?>" class="title column-title column-primary page-title">
                        <strong>
                            <a class="row-title" target="blank" href="<?php echo esc_url($view_link.'#wdk_review_'.wmvc_show_data('idreviews', $review));?>">
                                <?php if(wmvc_show_data('review_post_type', $review) == 'profile'):?>
                                    <?php if(wmvc_show_data(wmvc_show_data('post_id', $review), $users, false)):?>
                                       <?php echo esc_html(wmvc_show_data(wmvc_show_data('post_id', $review), $users, false)); ?>
                                    <?php else:?>
                                        #<?php echo esc_html(wmvc_show_data('post_id', $review)); ?>, <?php echo esc_html__('User not found', 'wdk-membership');?>
                                    <?php endif;?>
                                <?php else:?>
                                    #<?php echo esc_html(wmvc_show_data('post_id', $review)); ?>, <?php echo wmvc_show_data('post_title', $review, '-'); ?>
                                <?php endif;?>
                            </a>
                            <?php if(!wmvc_show_data('is_confirmed', $review, 0)): ?>
                            <span class="label label-danger"><?php echo esc_html__('Not confirmed', 'wdk-membership'); ?></span>
                            <?php endif; ?>
                        </strong>
                    </td>
                    <td data-label="<?php echo esc_html__('Reviews Type', 'wdk-membership'); ?>">
                        <?php if(isset($post_types[wmvc_show_data('review_post_type', $review)])):?>
                            <?php echo esc_html($post_types[wmvc_show_data('review_post_type', $review)]); ?>
                        <?php else:?>
                            <?php echo esc_html(wmvc_show_data('review_post_type', $review, '-')); ?>
                        <?php endif;?>
                    </td>
                    <td data-label="<?php echo esc_html__('user', 'wdk-membership'); ?>" >
                        <?php if(wmvc_show_data(wmvc_show_data('user_id', $review), $users, false)):?>
                            <?php echo esc_html(wmvc_show_data(wmvc_show_data('user_id', $review), $users, false)); ?>
                        <?php else:?>
                            <?php echo esc_html__('User not found', 'wdk-membership');?>
                        <?php endif;?>
                    </td>
                    <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>" >
                        <?php echo wdk_get_date(wmvc_show_data('date', $review), false); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Stars', 'wdk-membership'); ?>" >
                        <?php echo wmvc_show_data('stars', $review, '-'); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>"  class="actions_column">
                        <a href="<?php echo esc_url($view_link.'#wdk_review_'.wmvc_show_data('idreviews', $review));?>" target="blank" title="<?php echo esc_attr__('View', 'wdk-membership');?>"><span class="dashicons dashicons-visibility"></span></a>
                        <a href="<?php echo wdk_dash_url("dash_page=reviews&function=edit&id=" . wmvc_show_data('idreviews', $review, '-')); ?>" title="<?php echo esc_attr__('Edit', 'wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                        <a class="question_sure" href="<?php echo wdk_dash_url("dash_page=reviews&table_action=table&action=delete&ids=" . wmvc_show_data('idreviews', $review, '-')); ?>"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"><span class="dashicons dashicons-no"></span></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <div class="tablenav bottom">
            <div class="tablenav-main">
                <div class="actions bulkactions">
                    <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-membership'); ?></label>
                    <select name="action" id="bulk-action-selector-bottom" class="wdk-controll-xs">
                        <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-membership'); ?></option>
                        <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-membership'); ?></option>
                    </select>
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="reviews" />
                    <input type="submit" id="table_action" class="wdk-btn wdk-btn-primary wdk-btn-xs" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-membership'); ?>">
                </div>
            </div>
            <div class="tablenav-sidebar">
                <?php echo wmvc_xss_clean($pagination_output); ?>
            </div>
        </div>
    </form>
</div>
<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>
<?php $this->view('general/footer', $data); ?>