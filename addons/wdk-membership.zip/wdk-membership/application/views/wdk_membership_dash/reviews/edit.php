<?php
/**
 * The template for Edit Review.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_reviews_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Edit Review', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=reviews&function=edit&id='.wmvc_show_data('idreviews', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
            </div>
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Options', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside">
                    <?php if(empty($options)) :?>
                        <p class="alert alert-info"><?php echo esc_html__('Any options missing for current review type', 'wdk-membership');?>, <a href="<?php get_admin_url();?>admin.php?page=wdk-reviews-type"><?php echo esc_html__('Add Options per type', 'wdk-membership');?></a></p>
                    <?php else :?>
                        <?php echo wdk_generate_fields($options, $db_data_options); ?> 
                    <?php endif;?>            
                </div>
            </div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>
</div>

<script>

jQuery(document).ready(function($) {

    $('.wdk-field-edit.USERS [name="post_id"], .reviews_type_id_empty').attr('name','post_id_profile');

    const option_depends = (review_type_id) => {
        $('.wdk-field-edit[class*="reviews_type_id"]').hide();
        if(typeof review_type_id != 'undefined' && review_type_id != '')
            $('.wdk-field-edit[class*="reviews_type_id_'+review_type_id+'"]').show();
    };

    option_depends("<?php echo wmvc_show_data('reviews_type_id', $db_data);?>");
    $('select[name="reviews_type_id"]').on('change', function(){
        option_depends($(this).val());
    });
})

</script>

<?php $this->view('general/footer', $data); ?>

