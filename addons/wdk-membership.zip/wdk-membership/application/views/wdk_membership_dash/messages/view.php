<?php
/**
 * The template for Edit Search.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="wdk-front-wrap wdk_membership_dash_messages_edit">
    <h1 class="wdk-h"><?php echo esc_html__('View Message', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=edit&id='.wmvc_show_data('idmessage', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Main Data', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
            </div>
                   
            <?php if(!empty(wmvc_show_data('email_sender', $db_data))):?>
                <a href="mailto:<?php echo esc_attr(wmvc_show_data('email_sender', $db_data));?>" class="wdk-btn wdk-btn-primary"><?php echo esc_html__('Reply to email','wdk-membership'); ?></a>
            <?php endif;?>
            
            <?php if(function_exists('run_wdk_messages_chat') && !empty(wmvc_show_data('post_id', $db_data)) && !empty(wmvc_show_data('user_id_sender', $listing, ''))):?>
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=chat&id='.wmvc_show_data('idmessage', $db_data)));?>" class="wdk-btn wdk-btn-primary"><?php echo esc_html__('Reply to chat','wdk-membership'); ?></a>
            <?php endif;?>
        </form>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

