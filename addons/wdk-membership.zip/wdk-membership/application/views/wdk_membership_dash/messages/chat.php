<?php

/**
 * The template for Edit Search.
 *
 * This is the template that edit form
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<div class="wdk-front-wrap wdk_membership_dash_messages_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Live Chat', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <?php if (!function_exists('run_wdk_messages_chat') || empty($user_sender)) : ?>
                    <h3><?php echo esc_html__('Main Data', 'wdk-membership'); ?></h3>
                <?php else : ?>
                    <div class="wdk-tabs_link">
                        <h3><a class="" href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=edit&id=' . wmvc_show_data('idmessage', $db_data))); ?>"><?php echo esc_html__('Main Data', 'wdk-membership'); ?></a></h3>
                        <h3><a class="active" href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=chat&id=' . wmvc_show_data('idmessage', $db_data))); ?>"><?php echo esc_html__('Chat', 'wdk-membership'); ?></a></h3>
                    </div>
                <?php endif; ?>
            </div>
            <div class="inside full-width">
                <section class="wdk-form-chat">
                    
                    <div class="header-chat">
                        <?php if (!empty($chats)):?>
                            <?php if(!empty($header_icon_src)):?>
                                <a href="<?php echo esc_url($header_icon_src); ?>" class="thumbnail">
                                    <img src="<?php echo esc_url($header_icon_src); ?>" alt="<?php echo esc_attr($header_title); ?>">
                                </a>
                            <?php else:?>
                                <i class="icon fas fa-user" aria-hidden="true"></i>
                            <?php endif;?>

                            <p class="name">
                                <?php echo esc_html($header_title); ?>
                            </p>

                            <?php if (wmvc_show_data('post_id', $db_data)) : ?>
                                <p class="sub">
                                    <?php echo esc_html__('related listing', 'wdk-membership'); ?>: <a class="listing_link" target="_blank" href="<?php echo esc_url(get_permalink(wdk_field_value('ID', wmvc_show_data('post_id', $db_data)))); ?>"><?php echo esc_html(wdk_field_value('post_title', wmvc_show_data('post_id', $db_data))); ?></a>
                                </p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="body-chat">
                        <section class="sidebar sidebar-chats">
                            <div class="chats-list">
                                <?php if (!empty($chats)): foreach ($chats as $chat) : ?>
                                    <?php
                                        if($current_user_id != $chat->user_id_editor && $chat->user_id_editor) {
                                            $userdata = wdk_get_user_data($chat->user_id_editor);
                                        } elseif($current_user_id != $chat->user_id_sender && $chat->user_id_sender) {
                                            $userdata = wdk_get_user_data($chat->user_id_sender);
                                        } else {
                                            continue;
                                        }

                                        $chat->profile_image = (!empty($userdata)) ? $userdata['avatar'] : '#';
                                        $chat->profile_url = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
                                        $chat->display_name = wdk_get_user_field($userdata['user_id'], 'display_name');
                                    ?>
                                    <div class="chat <?php if(wmvc_show_data('idmessage', $db_data) == wmvc_show_data('idmessage', $chat)):?> active <?php elseif(wmvc_show_data('chat_unread_counter', $chat, false)):?> unreaded <?php endif;?>"
                                            data-chat_id ="<?php echo esc_attr(wmvc_show_data('idmessage', $chat)); ?>" 
                                            data-chat_url ="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=chat&id=' . wmvc_show_data('idmessage', $chat))); ?>"
                                            data-listing_url ="<?php echo esc_url(get_permalink(wdk_field_value('ID', wmvc_show_data('post_id', $chat)))); ?>"
                                            data-listing_name ="<?php echo esc_html(wmvc_show_data('post_title', $chat)); ?>"
                                            data-user_src ="<?php echo esc_url(wmvc_show_data('profile_image', $chat)); ?>"
                                            data-user_name ="<?php echo esc_attr(wmvc_show_data('display_name', $chat)); ?>"
                                            data-user_url ="<?php echo (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';?>"
                                            >
                                        <div class="wdk-chatlst-thumbnail">
                                            <img src="<?php echo esc_url(wmvc_show_data('profile_image', $chat)); ?>" alt="<?php echo esc_attr(wmvc_show_data('display_name', $message)); ?>">
                                        </div>
                                        <div class="wdk-chatlst-body">
                                            <div class="listing"><?php echo esc_html(wmvc_character_hard_limiter(wmvc_show_data('post_title', $chat), 15)); ?> 
                                            <?php if(wmvc_show_data('chat_unread_counter', $chat, false)):?>
                                                <span class="count_unread">(<?php echo esc_html(wmvc_show_data('chat_unread_counter', $chat, false));?>)</span>
                                            <?php endif;?>
                                        </div>
                                        <div class="name"><?php echo esc_html__('from','wdk-membership'); ?> <?php echo esc_attr(wmvc_show_data('display_name', $chat)); ?></div>
                                        <div class="text"><?php echo esc_html(wmvc_character_hard_limiter(wmvc_show_data('message', $chat), 25)); ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                                <?php else:?>
                                    <div class="wdk_alert wdk_alert-info" role="alert" style="margin: 10px;width: calc(100% - 20px);"><?php echo esc_html__('You not have any contacts','wdk-membership'); ?></div>
                                <?php endif;?>
                            </div>
                        </section>

                        <section class="chat-content">
                            <div class="messages-chat">
                                <?php if (false) : ?>
                                    <div class="message incoming_msg placeholder">
                                        <div class="wdkchat-thumbnail-user">
                                            <a href="#">
                                                <span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span>
                                            </a>
                                        </div>
                                        <div class="wdkchat-message-body">
                                            <div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>
                                            <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div>
                                        </div>
                                    </div>
                                    <div class="message outcoming_msg placeholder">
                                        <div class="wdkchat-thumbnail-user">
                                            <a href="#">
                                                <span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span>
                                            </a>
                                        </div>
                                        <div class="wdkchat-message-body">
                                            <div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>
                                            <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div>
                                        </div>
                                    </div>
                                    <div class="message incoming_msg placeholder">
                                        <div class="wdkchat-thumbnail-user">
                                            <a href="#">
                                                <span class="wdk_loading_animation" style="height: 45px; width: 45px;border-radius: 50%;"></span>
                                            </a>
                                        </div>
                                        <div class="wdkchat-message-body">
                                            <div class="text" style="background: transparent;padding: 9px 5px;padding-bottom: 0;"><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></br><span class="wdk_loading_animation" style="height: 18px; width: 150px;"></span></div>
                                            <div class="footer" style="padding-right: 5px;padding-left: 5px;"><span class="wdk_loading_animation" style="height: 16px; width: 40px;"></span></div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if (!empty($chats)):?>

                                    <div class="message" data-message_id="inbox_message">
                                        <div class="wdkchat-message-body">
                                            <div class="text"><?php echo esc_html(wmvc_show_data('message', $db_data)); ?></div>
                                            <div class="footer"><?php echo esc_html(wdk_get_date(wmvc_show_data('date', $db_data))); ?></div>
                                        </div>
                                    </div>

                                    <div class="separed-chat"><?php echo esc_attr__('Start Chat', 'wdk-membership'); ?></div>

                                    <?php if (!empty($messages)) foreach ($messages as $message) : ?>
                                        <?php
                                            $userdata = wdk_get_user_data($message->outgoing_msg_user_id);
                                            $message->profile_image = (!empty($userdata)) ? $userdata['avatar'] : '#';
                                            $message->profile_url = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
                                            $message->display_name = wdk_get_user_field($message->outgoing_msg_user_id, 'display_name');
                                        ?>
                                        <div class="message <?php echo esc_attr((($current_user_id == wmvc_show_data('outgoing_msg_user_id', $message) ? 'outcoming_msg' : ''))); ?>" data-message_id="<?php echo esc_attr(wmvc_show_data('idmessageschat', $message)); ?>">
                                            <div class="wdkchat-thumbnail-user">
                                                <a href="<?php echo esc_url(wmvc_show_data('profile_url', $message)); ?>">
                                                    <img src="<?php echo esc_url(wmvc_show_data('profile_image', $message)); ?>" alt="<?php echo esc_attr(wmvc_show_data('display_name', $message)); ?>">
                                                </a>
                                            </div>
                                            <div class="wdkchat-message-body">
                                                <div class="text"><?php echo esc_html(wmvc_show_data('message', $message)); ?></div>
                                                <div class="footer"><?php echo esc_html(wdk_get_date(wmvc_show_data('date', $message))); ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>

                                <?php else:?>
                                    <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__(' Live chat option between users will simplify and provide faster communication','wdk-membership'); ?></div>
                                <?php endif;?>

                            </div>
                            <form action="" class="wdkchat-form">
                                <input type="hidden" name="related_key" value="<?php echo esc_attr(wmvc_show_data('idmessage', $db_data)); ?>">
                                <input type="hidden" name="outgoing_msg_user_id" value="<?php echo esc_attr(get_current_user_id()); ?>">
                                <input type="hidden" name="outgoing_msg_user_email" value="<?php echo esc_attr(wdk_get_user_field(get_current_user_id(), 'user_email')); ?>">
                                <div class="footer-chat">
                                    <textarea name="message" class="write-message" placeholder="<?php echo esc_attr__('Type your message here', 'wdk-membership'); ?>" rows="1"></textarea>
                                    <button type="submit" class="wdkchat-submit"><span class="dashicons dashicons-editor-break"></span></button>
                                </div>
                            </form>
                        </section>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

<?php
wp_enqueue_style('wdk-messages-chat-lib');
wp_enqueue_script('wdk-messages-chat-lib');
?>
<?php if (!empty($chats)):?>
<script>
    var wdk_messages_disable = true;
    jQuery(document).ready(function() {
        let el = document.querySelector('.messages-chat .message:last-child');
        if (el) {
            el.scrollIntoView({
                block: "center",
                behavior: "smooth"
            });
        }

        jQuery('.wdkchat-form').WdkMessagesChat_form();
    });
</script>
<?php endif;?>