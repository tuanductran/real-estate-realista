<?php
/**
 * The template for Management Messages.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wdk-front-wrap wdk_membership_dash_messages_index">
    <h1 class="wdk-h"><?php echo esc_html__('Sent Messages', 'wdk-membership'); ?> 
        <div class="wdk-float-right-md">
            <a href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=inbox'));?>" class="button button-primary" id="btn_messages_inbox"><?php echo esc_html__('Inbox', 'wdk-membership'); ?></a>
            <a href="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=outbox'));?>" class="button button-primary active" id="btn_messages_sent"><?php echo esc_html__('Sent', 'wdk-membership'); ?></a>
        </div>
    </h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=outbox')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="messages" />
                    <input type="hidden" name="function" value="outbox" />

                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=messages&function=outbox')); ?>">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-membership'); ?></label>
                        <input id="cb-select-all-1" type="checkbox" value="1">
                    </td>
                    <th style="width:65px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Email', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Listing Name', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($results) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No Messages found.', 'wdk-membership'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($results as $listing) : ?>
                    <tr>
                        <th data-label="<?php echo esc_html__('Checkbox', 'wdk-membership'); ?>" scope="row" class="check-column hide-resonsive">
                            <input id="cb-select-<?php echo wmvc_show_data('idmessage', $listing, '-'); ?>" type="checkbox" name="ids[]" value="<?php echo wmvc_show_data('idmessage', $listing, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-membership'); ?></span>
                            </div>
                        </th>
                        <td data-label="<?php echo esc_html__('id', 'wdk-membership'); ?>">
                            <?php if($current_user_id == wmvc_show_data('user_id_editor', $listing, '-')):?>
                                <span class="wdk_message_in dashicons dashicons-editor-outdent" title="<?php echo esc_html__('Inbox', 'wdk-membership'); ?>"></span>
                            <?php else:?>
                                <span class="wdk_message_out dashicons dashicons-editor-indent" title="<?php echo esc_html__('Sent', 'wdk-membership'); ?>"></span>
                            <?php endif;?>
                            <?php echo wmvc_show_data('idmessage', $listing, '-'); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Email', 'wdk-membership'); ?>" class="title column-title has-row-actions column-primary">
                            <strong>
                                <a class="row-title" href="<?php echo wdk_dash_url("dash_page=messages&function=edit&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><?php echo wmvc_show_data('email_sender', $listing, '-'); ?></a>
                                
                                <?php if(function_exists('run_wdk_messages_chat') && wmvc_show_data('chat_unread_counter', $listing, false)):?>
                                    (<?php echo esc_html(wmvc_show_data('chat_unread_counter', $listing, false));?>)
                                <?php endif;?>
                                
                                <?php if($current_user_id == wmvc_show_data('user_id_editor', $listing, '-')):?>
                                    <?php if(!wmvc_show_data('is_readed', $listing, 0)): ?>
                                        <span class="label label-success"><?php echo esc_html__('Unread', 'wdk-membership'); ?></span>
                                    <?php else: ?>
                                        <span class="label label-info"><?php echo esc_html__('I read it', 'wdk-membership'); ?></span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </strong>
                            <div class="row-actions">
                            <?php if($current_user_id == wmvc_show_data('user_id_editor', $listing, '-')):?>
                                    <span class="edit"><a href="<?php echo wdk_dash_url("dash_page=messages&function=edit&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><?php echo __('View', 'wdk-membership'); ?></a> | </span>
                                    <span class="trash "><a href="<?php echo wdk_dash_url("dash_page=messages&table_action=table&action=delete&ids=" . wmvc_show_data('idmessage', $listing, '-')); ?>" class="submitdelete question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>" ><?php echo __('Delete', 'wdk-membership'); ?></a></span>
                                <?php else:?>
                                    <span class="edit"><a href="<?php echo wdk_dash_url("dash_page=messages&function=view&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><?php echo __('View', 'wdk-membership'); ?></a></span>
                                <?php endif;?>
                                <?php if(function_exists('run_wdk_messages_chat') && !empty(wmvc_show_data('user_id_sender', $listing, ''))):?>
                                    <span class="edit"> | <a href="<?php echo wdk_dash_url("dash_page=messages&function=chat&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><?php echo __('Chat', 'wdk-membership'); ?></a></span>
                                <?php endif;?>
                            </div>
                        </td>
                        <td data-label="<?php echo esc_html__('Listing Name', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('post_title', $listing, '-'); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>">
                            <?php echo wdk_get_date($listing->message_date, false); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                            <?php if(function_exists('run_wdk_messages_chat') && !empty(wmvc_show_data('user_id_sender', $listing, ''))):?>
                               <a href="<?php echo wdk_dash_url("dash_page=messages&function=chat&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>" title="<?php echo esc_attr__('Chat','wdk-membership');?>"><span class="dashicons dashicons-format-chat"></span></a>
                               <?php if($current_user_id == wmvc_show_data('user_id_editor', $listing, '-')):?>
                                   <a href="<?php echo wdk_dash_url("dash_page=messages&function=edit&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                                   <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo wdk_dash_url("dash_page=messages&table_action=table&action=delete&ids=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><span class="dashicons dashicons-no"></span></a>
                               <?php else:?>
                                   <a href="<?php echo wdk_dash_url("dash_page=messages&function=view&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>"><span class="dashicons dashicons-search"></span></a>
                               <?php endif;?>
                            <?php else:?>
                                <?php if($current_user_id == wmvc_show_data('user_id_editor', $listing, '-')):?>
                                    <a href="<?php echo wdk_dash_url("dash_page=messages&function=view&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>"><span class="dashicons dashicons-search"></span></a>
                                    <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo wdk_dash_url("dash_page=messages&table_action=table&action=delete&ids=" . wmvc_show_data('idmessage', $listing, '-')); ?>"><span class="dashicons dashicons-no"></span></a>
                                <?php else:?>
                                    <a href="<?php echo wdk_dash_url("dash_page=messages&function=view&id=" . wmvc_show_data('idmessage', $listing, '-')); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>"><span class="dashicons dashicons-search"></span></a>
                                <?php endif;?>
                            <?php endif;?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
        </table>
        <div class="tablenav bottom">
            <div class="tablenav-main">
                <div class="actions bulkactions">
                    <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-membership'); ?></label>
                    <select name="action" id="bulk-action-selector-bottom" class="wdk-controll-xs">
                        <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-membership'); ?></option>
                        <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-membership'); ?></option>
                        <option value="activate" class="hide-if-no-js"><?php echo esc_html__('Mark as read', 'wdk-membership'); ?></option>
                    </select>
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="messages" />
                    <input type="hidden" name="function" value="outbox" />
                    <input type="submit" id="table_action" class="wdk-btn wdk-btn-primary wdk-btn-xs" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-membership'); ?>">
                </div>
            </div>
            <div class="tablenav-sidebar">
                <?php echo wmvc_xss_clean($pagination_output); ?>
            </div>
        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>

<?php $this->view('general/footer', $data); ?>

