<?php
/**
 * The template for Edit Calendar.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
global $Winter_MVC_wdk_bookings;
$Winter_MVC_wdk_bookings->model('calendar_m');
?>
<div class="wdk-front-wrap wdk_membership_dash_booking_calendar_edit">
    <h1 class="wdk-h">
        <?php echo esc_html__('Edit Calendar', 'wdk-membership'); ?>
        <a href="<?php echo esc_url(wdk_dash_url('dash_page=booking-calendars&function=ical_import&id='.wmvc_show_data('idcalendar', $db_data))); ?>" class="button button-primary" id="btn_import_ical"><?php echo esc_html__('iCal import calendar', 'wdk-membership'); ?></a>
        <a href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'function=wdk_export_icl_calendar&calendar_id='.wmvc_show_data('idcalendar', $db_data))); ?>" target="_blank" class="button button-primary" id="btn_export_ical"><?php echo esc_html__('iCal export calendar', 'wdk-membership'); ?></a>
        <div class="wdk-float-right-md">
        <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
            <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="add_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
            <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="add_listing_calendar"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
        <?php endif;?>
        </div>
    </h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=booking-calendars&function=edit&id='.wmvc_show_data('idcalendar', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $success_message = __('Successfully saved', 'wdk-membership');
  
                        if(function_exists('run_wdk_bookings')) {
                            /* if booking addon exists, show custom message with link to edit calendar */
                            $success_message = esc_html__('Successfully saved','wdk-membership').'. <a target="_blank" href="'. wdk_dash_url("dash_page=booking-prices&function=edit&post_id=".wmvc_show_data('post_id', $db_data)).'">'.esc_html__('Set availability prices', 'wdk-membership').'</a>';
                        }
                        
                        $form->messages('class="alert alert-danger"', $success_message);
                      
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
                <?php if(true):?>
                    <div class="wdk-field-edit wdk-hidden">
                        <label for="star_icon_half_active"><?php echo esc_html__('json_data_fees','wdk-membership'); ?></label>
                        <div class="wdk-field-container">
                            <textarea readonly="readonly" name="json_data_fees" type="text" id="json_data_fees" class="regular-text"><?php echo esc_textarea(wmvc_show_data('json_data_fees', $db_data, '')); ?></textarea>
                        </div>
                    </div>
                <?php endif;?>
            </div>
            <div class="wdk_alert wdk_alert-info mb-20" role="alert"><?php echo esc_html__('Reservation on frontend will be visible only if prices/availability dates are defined','wdk-membership'); ?></div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>
    <br />
    <div class="wdk_postbox_open" style="display: block;">
        <div class="wdk_postbox-header">
            <h3><?php echo esc_html__('Additional Fees','wdk-membership'); ?></h3>
        </div>
        <div class="wdk_inside"> 
            <div class="wdk_alert wdk_alert-info mb-20" role="alert"><?php echo esc_html__('This fees are used on booking form, like for end cleaning and similar scenarios','wdk-membership'); ?></div>
            <table class="wdk-table table-view-list wdk-table-options">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Fee Title', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Price', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Hint', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Calculation base', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('is Required', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('is Activated', 'wdk-membership'); ?></th>
                        <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="pattern wdk-hidden">
                        <td>
                            <input class="" name="title" type="text" value="" placeholder="<?php echo esc_html__('Fee Title', 'wdk-membership'); ?>">
                        </td>
                        <td>
                            <input class="" name="value" type="number" value="" placeholder="<?php echo esc_html__('Price', 'wdk-membership'); ?>">
                        </td>
                        <td>
                            <input class="" name="hint" type="text" value="" placeholder="<?php echo esc_html__('Hint', 'wdk-membership'); ?>">
                        </td>
                        <td>
                            <select name="calculation_base" id="">
                                <option value=""><?php echo esc_html__('Calculation base', 'wdk-membership'); ?></option>
                                <?php  foreach ($Winter_MVC_wdk_bookings->calendar_m->calculation_base as $key => $value) :?>
                                    <option value="<?php echo esc_attr($key);?>"><?php echo esc_attr($value);?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td>
                            <label>
                                <input name="is_required" type="checkbox" value="1">
                                <?php echo esc_html__('is required', 'wdk-membership'); ?>
                            </label>
                        </td>
                        <td>
                            <label>
                                <input name="is_activated" type="checkbox" value="1">
                                <?php echo esc_html__('is activated', 'wdk-membership'); ?>
                            </label>
                        </td>
                        <td class="actions_column">
                            <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                            <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                        </td>
                    </tr>
                    <tr class="skip">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td class="actions_column">
                            <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                        </td>
                    </tr>
                    <?php foreach ($calendar_fees as $fee) :?>
                        <tr>
                            <td>
                                <input class="" name="title" type="text" value="<?php echo wmvc_show_data('title', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Title', 'wdk-membership'); ?>">
                            </td>
                            <td>
                                <input class="" name="value" type="number" value="<?php echo wmvc_show_data('value', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Value', 'wdk-membership'); ?>">
                            </td>
                            <td>
                                <input class="" name="hint" type="text" value="<?php echo wmvc_show_data('hint', $fee, '-'); ?>" placeholder="<?php echo esc_html__('Hint', 'wdk-membership'); ?>">
                            </td>
                            <td>
                                <select name="calculation_base" id="">
                                    <option value=""><?php echo esc_html__('Calculation base', 'wdk-membership'); ?></option>
                                    <?php  foreach ($Winter_MVC_wdk_bookings->calendar_m->calculation_base as $key => $value) :?>
                                        <option value="<?php echo esc_attr($key);?>" <?php if(wmvc_show_data('calculation_base', $fee, '-') == $key): ?> selected="selected" <?php endif;?>><?php echo esc_attr($value);?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <label>
                                    <input name="is_required" type="checkbox" value="1" <?php echo !empty(wdk_show_data('is_required', $fee, false, TRUE, TRUE))?'checked':''; ?>>
                                    <?php echo esc_html__('is required', 'wdk-membership'); ?>
                                </label>
                            </td>
                            <td>
                                <label>
                                    <input name="is_activated" type="checkbox" value="1" <?php echo !empty(wdk_show_data('is_activated', $fee, false, TRUE, TRUE))?'checked':''; ?>>
                                    <?php echo esc_html__('is activated', 'wdk-membership'); ?>
                                </label>
                            </td>
                            <td class="actions_column">
                                <button class="button button-primary add_btn" style="line-height: 1;"><span class="dashicons dashicons-plus-alt2"></span></button>
                                <button class="button button-primary remove_btn" style="line-height: 1;"><span class="dashicons dashicons-minus"></span></button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>    
            </table>
        </div>
    </div>
</div>

<script>
var wdk_timerOut;
jQuery(document).ready(function($) {

    const wdk_bookings_calendar_add_option = (this_form) => {
        var json_gen = '';
        $('table.wdk-table-options tr:not(.pattern):not(.skip)').each(function(index, tr) { 
            if(index==0) {$
                ('#json_data_fees').val('');
                return;
            }
            json_gen += '{';
            $(this).find('input,select').each(function(){
                var el_name = $(this).attr('name');
                if(el_name)
                {
                    json_gen += '"'+el_name+'"';
                    if($(this).attr('type') == 'checkbox') {
                        if($(this).prop('checked')){
                            json_gen += ': "'+1+'" ';
                        } else {
                            json_gen += ': "'+0+'" ';
                        }
                    } else if($(this).is('select')) {
                        json_gen += ': "'+$(this).find( "option:selected" ).val()+'" ';
                    } 
                    else {
                        json_gen += ': "'+$(this).val()+'" ';
                    }
                    json_gen += ', ';
                }
            });
            json_gen = json_gen.substr(0, json_gen.length-2);
            json_gen += '}, ';
        });

        if(json_gen.length > 0)
            json_gen = json_gen.substr(0, json_gen.length-2);

        if(json_gen.length > 0)
                $('#json_data_fees').val('[ ' + json_gen + ' ]');
    };
    
    const wdk_bookings_calendar_remove_option = (row) => {
        row.remove();
        wdk_bookings_calendar_add_option();
    };

    const wdk_bookings_calendar_actions = () => {
        $('.wdk-table-options').find('input').off().on('input', function(){
            //clearTimeout(wdk_timerOut);
            var tr = $(this).closest('tr');
            wdk_timerOut = setTimeout(function () {
                wdk_bookings_calendar_add_option(tr);
            }, 1000);
        });

        $('button.add_btn').off().on('click', function()
        {
            var table = $(this).closest('table');
            var clone = table.find('.pattern').clone();
            clone.removeClass('wdk-hidden pattern');
            table.find('tbody').append(clone);

            wdk_bookings_calendar_add_option(clone);
            wdk_bookings_calendar_actions();
        });

        $('button.remove_btn').off().on('click', function()
        {
            wdk_bookings_calendar_remove_option($(this).closest('tr'));
            wdk_bookings_calendar_actions();
        });

    };

    wdk_bookings_calendar_actions();
});
</script>

<?php $this->view('general/footer', $data); ?>

