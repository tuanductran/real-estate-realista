<?php
/**
 * The template for Edit Reservation.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_booking_myreservations_view">
    <h1 class="wdk-h"><?php echo esc_html__('View Reservation', 'wdk-membership'); ?> 
        <div class="wdk-float-right-md">
            <a href="<?php echo wdk_dash_url("dash_page=booking-myreservations"); ?>" class="button button-primary" id="btn_my_reservation"><?php echo esc_html__('My Reservations', 'wdk-membership'); ?></a>
        </div>
    </h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=booking-myreservations&function=edit&id='.wmvc_show_data('idreservation', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    
                    <?php if(wmvc_show_data('post_id', $db_data, false)):?>
                        <a href="<?php echo esc_url(get_permalink(wmvc_show_data('post_id', $db_data)));?>" class="wdk-thumb-right">
                            <img src="<?php echo esc_url(wdk_image_src(array('listing_images'=>wdk_field_value('listing_images', wmvc_show_data('post_id', $db_data))), 'thumb'));?>" alt="<?php echo esc_attr(wdk_field_value('post_title', wmvc_show_data('post_id', $db_data))) ;?>" class="wdk-image">
                        </a>
                    <?php endif;?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Reservation ID', 'wdk-membership'); ?></label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                    <?php echo esc_html(wmvc_show_data('idreservation', $db_data, ' - '));?>  
                            </span>
                        </div>
                    </div> 
                    
                    <?php echo wdk_generate_fields($fields, $db_data); ?> 

                    <?php if(!wmvc_show_data('is_paid', $db_data, false)):?>
                        <?php if(wdk_get_option('wdk_bookings_enable_woocommerce_payments')):?>
                            <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                                <label for="currency_code"><?php echo esc_html__('Payment Link', 'wdk-membership'); ?></label>
                                <div class="wdk-field-container">
                                    <span class="regular-span">
                                        <?php
                                            $product = false;
                                            $stock = false;
                                            $status = false;
                                            if(wmvc_show_data('woocommerce_product_id',$db_data, false)) {
                                                $product = wc_get_product(wmvc_show_data('woocommerce_product_id',$db_data, false));
                                                $stock = $product->get_stock_quantity();

                                                /* get order */
                                                $orders_ids = wdk_get_orders_ids_by_product_id(wmvc_show_data('woocommerce_product_id',$db_data, false));
                                                if(!empty($orders_ids)) {
                                                    
                                                    $order = wc_get_order( current($orders_ids) );
                                                    $status = $order->get_status();
                                                }

                                            }
                                        ?>
                                        <?php if(wmvc_show_data('woocommerce_product_id',$db_data, false) && (!empty($status) && $status != 'failed')): ?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Order Processing','wdk-membership'); ?></div>
                                        <?php elseif(!wmvc_show_data('is_approved', $db_data, false)):?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Waiting approvement','wdk-membership'); ?></div>
                                        <?php elseif(wmvc_show_data('woocommerce_product_id',$db_data, false) && empty($stock) && (empty($status) || $status == 'failed')): ?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Purchase time expired, please make new reservation','wdk-membership'); ?></div>
                                        <?php elseif(!empty($url_pay)):?>
                                            <a href="<?php echo esc_url($url_pay);?>" class="wdk-btn wdk-btn-primary"><?php echo esc_html__('Pay for reservation', 'wdk-membership'); ?></a>
                                        <?php else:?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Payment Link Not Generated','wdk-membership'); ?></div>
                                        <?php endif;?>
                                    </span>
                                </div>
                            </div> 
                        <?php else:?>
                            <?php if(wmvc_show_data('payment_info', $calendar, false)):?>
                                <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                                    <label for="currency_code"><?php echo esc_html__('Wire Transfer Payment info', 'wdk-membership'); ?></label>
                                    <div class="wdk-field-container">
                                        <span class="regular-span">
                                            <?php if(!wmvc_show_data('is_approved', $db_data, false)):?>
                                                <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Please wait owner to approve reservation','wdk-membership'); ?></div>
                                            <?php else:?>
                                                <div class="wdk_alert wdk_alert-info" role="alert">
                                                    <?php echo esc_html(wmvc_show_data('payment_info', $calendar));?>  
                                                </div> 
                                            <?php endif;?>
                                        </span>
                                    </div>
                                </div> 
                            <?php endif;?>
                        <?php endif;?>
                    <?php else:?>
                        <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                            <label for="currency_code"><?php echo esc_html__('Wire Transfer Payment info', 'wdk-membership'); ?></label>
                            <div class="wdk-field-container">
                                <span class="regular-span">
                                <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Thanks on payment','wdk-membership'); ?></div>
                                </span>
                            </div>
                        </div> 
                    <?php endif;?>

                    <?php if(!empty($user_data_owner)):?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Owner Details', 'wdk-membership'); ?>:</label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                <ul class="wdk-list">
                                    <?php if(wmvc_show_data('display_name', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Name', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('display_name', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Phone', 'wdk-membership'); ?>:</strong> <a href="tel:<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE)));?>"><?php echo esc_html(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Email', 'wdk-membership'); ?>:</strong> <a href="mailto:<?php echo esc_attr(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE));?>"><?php echo esc_html(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_address', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_address', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_city', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('City', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_city', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                </ul>
                            </span>
                        </div>
                    </div> 
                    <?php endif;?>
                    <?php if(!empty($user_data_client)):?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Client Details', 'wdk-membership'); ?>:</label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                <ul class="wdk-list">
                                    <?php if(wmvc_show_data('display_name', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Name', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('display_name', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Phone', 'wdk-membership'); ?>:</strong> <a href="tel:<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE)));?>"><?php echo esc_html(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Email', 'wdk-membership'); ?>:</strong> <a href="mailto:<?php echo esc_attr(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE));?>"><?php echo esc_html(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_address', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_address', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_city', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('City', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_city', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                </ul>
                            </span>
                        </div>
                    </div> 
                    <?php endif;?>
                    <?php if(!empty($listing)):?>
                        <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                            <label for="currency_code"><?php echo esc_html__('Listing Details', 'wdk-membership'); ?>:</label>
                            <div class="wdk-field-container">
                                <span class="regular-span">
                                    <a href="<?php echo esc_url(get_permalink($listing)); ?>"><?php echo esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)); ?></a>
                                    <?php if(wmvc_show_data('address', $listing, false, TRUE, TRUE)):?>
                                    <p>
                                        <strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <a href="<?php echo esc_url(get_permalink($listing)); ?>"><?php echo esc_html(wmvc_show_data('address', $listing, '', TRUE, TRUE)); ?></a><br />
                                    </p>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('lng', $listing, false, TRUE, TRUE) && wmvc_show_data('lat', $listing, false, TRUE, TRUE)):?>
                                    <p>
                                        <a target="_blank" href="<?php echo esc_url('https://maps.google.com/maps?daddr='.wmvc_show_data('address', $listing, '', TRUE, TRUE).'@'.wmvc_show_data('lat', $listing, '', TRUE, TRUE).','.wmvc_show_data('lng', $listing, '', TRUE, TRUE)); ?>">
                                            <strong><?php echo esc_html__('Route to destination', 'wdk-membership'); ?></strong> 
                                        </a>
                                    </p>
                                    <?php endif;?>
                                </span>
                            </div>
                        </div> 
                        <?php if(wmvc_show_data('lng', $listing, false, TRUE, TRUE) && wmvc_show_data('lat', $listing, false, TRUE, TRUE)):?>
                        <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                            <label for="currency_code"><?php echo esc_html__('GPS', 'wdk-membership'); ?>:</label>
                            <div class="wdk-field-container">
                                <span class="regular-span">
                                    <?php echo esc_html(wmvc_show_data('lat', $listing, '', TRUE, TRUE)); ?>,<?php echo esc_html(wmvc_show_data('lng', $listing, '', TRUE, TRUE)); ?>
                                </span>
                            </div>
                        </div> 
                        <?php endif;?>
                    <?php endif;?>
                </div>
            </div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>
</div>
<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>
<?php wp_enqueue_style('wdk-booking-field-calendar');?>
<?php wp_enqueue_script('wdk-booking-field-calendar');?>

<?php $this->view('general/footer', $data); ?>

