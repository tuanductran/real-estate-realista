<?php
/**
 * The template for Import Ecal.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_booking_calendar_ical_import">
    <h1 class="wdk-h">
        <?php echo esc_html__('Reservation Import Management', 'wdk-membership'); ?>
        <div class="wdk-float-right-md">
            <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
                <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="btn_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="btn_calendars"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
            <?php endif;?>
        </div>
    </h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=booking-calendars&function=ical_import&id='.intval(wmvc_show_data('id', $_GET)))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Import Reservations', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="wdk-btn wdk-btn-primary" value="<?php echo esc_html__('Save Changes','wdk-membership'); ?>"> 
        </form>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

