<?php
/**
 * The template for Price Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wdk-front-wrap wdk_membership_dash_booking_prices">
    <h1 class="wdk-h"><?php echo esc_html__('Booking Prices', 'wdk-membership'); ?>
        <a href="<?php echo wdk_dash_url("dash_page=booking-prices&function=edit"); ?>" class="button button-primary" id="btn_add_price"><?php echo esc_html__('Add Price / Rate', 'wdk-membership'); ?></a>
        <div class="wdk-float-right-md">
            <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
                <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="btn_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="btn_calendars"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-myreservations"); ?>" class="button button-primary" id="btn_my_reservation"><?php echo esc_html__('My Reservations', 'wdk-membership'); ?></a>
            <?php endif;?>
        </div>
    </h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="booking-prices" />

                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, 'date_from DESC'), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-membership'); ?></label>
                        <input id="cb-select-all-1" type="checkbox" value="1">
                    </td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Listing', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date From', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date To', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Price Day', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($prices) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No Availability/Prices found.', 'wdk-membership'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($prices as $price) : ?>
                    <tr>
                        <th data-label="<?php echo esc_html__('Checkbox', 'wdk-membership'); ?>" scope="row" class="check-column">
                            <input id="cb-select-<?php echo wmvc_show_data('idprice', $price, '-'); ?>" type="checkbox" name="ids[]" value="<?php echo wmvc_show_data('idprice', $price, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-membership'); ?></span>
                            </div>
                        </th>
                        <td  data-label="<?php echo esc_html__('ID', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('idprice', $price, '-'); ?>
                        </td>
                        <td  data-label="<?php echo esc_html__('Listing', 'wdk-membership'); ?>" class="title column-title has-row-actions column-primary page-title" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo wdk_dash_url("dash_page=booking-prices&function=edit&id=" . wmvc_show_data('idprice', $price, '-')); ?>"><?php echo wmvc_show_data('post_title', $price, '-'); ?></a>
                                <?php if(!wmvc_show_data('price_is_activated', $price, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Not activated', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                            </strong>
                        </td>
                        <td  data-label="<?php echo esc_html__('Date From', 'wdk-membership'); ?>">
                            <?php echo wdk_get_date(wmvc_show_data('date_from', $price), false); ?>
                        </td>
                        <td  data-label="<?php echo esc_html__('Date To', 'wdk-membership'); ?>">
                            <?php echo wdk_get_date(wmvc_show_data('date_to', $price), false); ?>
                        </td>
                        <td  data-label="<?php echo esc_html__('Price Day', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('price_day', $price, '-'); ?>
                        </td>
                        <td  data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                            <a href="<?php echo wdk_dash_url("dash_page=booking-prices&function=edit&id=" . wmvc_show_data('idprice', $price, '-')); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                            <a class="question_sure" title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo wdk_dash_url("dash_page=booking-prices&table_action=table&action=delete&ids=" . wmvc_show_data('idprice', $price, '-')); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
        </table>
        <div class="tablenav bottom">
            <div class="tablenav-main">
                <div class="actions bulkactions">
                    <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-membership'); ?></label>
                    <select name="action" id="bulk-action-selector-bottom" class="wdk-controll-xs">
                        <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-membership'); ?></option>
                        <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-membership'); ?></option>
                        <option value="deactivate" class="hide-if-no-js"><?php echo esc_html__('Deactivate', 'wdk-membership'); ?></option>
                        <option value="activate" class="hide-if-no-js"><?php echo esc_html__('Activate', 'wdk-membership'); ?></option>
                    </select>
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="booking-prices" />
                    <input type="submit" id="table_action" class="wdk-btn wdk-btn-primary wdk-btn-xs" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-membership'); ?>">
                </div>
            </div>
            <div class="tablenav-sidebar">
                <?php echo wmvc_xss_clean($pagination_output); ?>
            </div>
        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>

<?php $this->view('general/footer', $data); ?>

