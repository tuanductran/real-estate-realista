<?php
/**
 * The template for Edit Reservation.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_booking_reservation_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Edit Reservation', 'wdk-membership'); ?>
        <div class="wdk-float-right-md">
            <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
                <a href="<?php echo wdk_dash_url("dash_page=booking-myreservations"); ?>" class="button button-primary" id="btn_my_reservation"><?php echo esc_html__('My Reservations', 'wdk-membership'); ?></a>
                <?php  if(!wdk_get_option('wdk_bookings_disable_bookings_by_default') || (wdk_get_option('wdk_bookings_disable_bookings_by_default') && wdk_membership_subscription_booking_enabled())):?>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="btn_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-prices"); ?>" class="button button-primary" id="btn_prices"><?php echo esc_html__('Availability/Prices', 'wdk-membership'); ?></a>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="btn_calendars"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
                <?php endif;?>
            <?php endif;?>
        </div>
    </h1>
    <div class="wdkmembership-content">
        <?php if(wmvc_show_data('idreservation',$db_data, false)):?>
            <input type="hidden" name="current_reservation_id" id="current_reservation_id" value="<?php echo esc_attr(wmvc_show_data('idreservation',$db_data, false)); ?>">
        <?php endif;?>
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=booking-reservations&function=edit&id='.wmvc_show_data('idreservation', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Reservation ID', 'wdk-membership'); ?></label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                    <?php echo esc_html(wmvc_show_data('idreservation', $db_data, ' - '));?>  
                            </span>
                        </div>
                    </div> 
                  
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  

                    <?php if(!wmvc_show_data('is_paid', $db_data, false)):?>
                        <?php if(wdk_get_option('wdk_bookings_enable_woocommerce_payments')):?>
                            <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                                <label for="currency_code"><?php echo esc_html__('Payment Link', 'wdk-membership'); ?></label>
                                <div class="wdk-field-container">
                                    <span class="regular-span">
                                        <?php if(!wmvc_show_data('is_approved', $db_data, false)):?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Pay for reservation','wdk-membership'); ?></div>
                                        <?php elseif(!empty($url_pay)):?>
                                            <a href="<?php echo esc_url($url_pay);?>" class="wdk-btn wdk-btn-primary"><?php echo esc_html__('Pay for reservation', 'wdk-membership'); ?></a>
                                        <?php else:?>
                                            <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Payment Link Not Generated','wdk-membership'); ?></div>
                                        <?php endif;?>
                                    </span>
                                </div>
                            </div> 
                        <?php else:?>
                            <?php if(wmvc_show_data('payment_info', $calendar, false)):?>
                                <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                                    <label for="currency_code"><?php echo esc_html__('Wire Transfer Payment info', 'wdk-membership'); ?></label>
                                    <div class="wdk-field-container">
                                        <span class="regular-span">
                                            <?php if(!wmvc_show_data('is_approved', $db_data, false)):?>
                                                <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Please wait owner to approve reservation','wdk-membership'); ?></div>
                                            <?php else:?>
                                                <div class="wdk_alert wdk_alert-info" role="alert">
                                                    <?php echo esc_html(wmvc_show_data('payment_info', $calendar));?>  
                                                </div> 
                                            <?php endif;?>
                                        </span>
                                    </div>
                                </div> 
                            <?php endif;?>
                        <?php endif;?>
                    <?php endif;?>

                    <?php if(!empty($user_data_owner)):?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Owner Details', 'wdk-membership'); ?>:</label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                <ul class="wdk-list">
                                    <?php if(wmvc_show_data('display_name', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Name', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('display_name', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Phone', 'wdk-membership'); ?>:</strong> <a href="tel:<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE)));?>"><?php echo esc_html(wmvc_show_data('wdk_phone', $user_data_owner, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Email', 'wdk-membership'); ?>:</strong> <a href="mailto:<?php echo esc_attr(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE));?>"><?php echo esc_html(wmvc_show_data('user_email', $user_data_owner, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_address', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_address', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_city', $user_data_owner, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('City', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_city', $user_data_owner, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                </ul>
                            </span>
                        </div>
                    </div> 
                    <?php endif;?>
                    <?php if(!empty($user_data_client)):?>
                    <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                        <label for="currency_code"><?php echo esc_html__('Client Details', 'wdk-membership'); ?>:</label>
                        <div class="wdk-field-container">
                            <span class="regular-span">
                                <ul class="wdk-list">
                                    <?php if(wmvc_show_data('display_name', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Name', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('display_name', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Phone', 'wdk-membership'); ?>:</strong> <a href="tel:<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE)));?>"><?php echo esc_html(wmvc_show_data('wdk_phone', $user_data_client, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Email', 'wdk-membership'); ?>:</strong> <a href="mailto:<?php echo esc_attr(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE));?>"><?php echo esc_html(wmvc_show_data('user_email', $user_data_client, false, TRUE, TRUE));?></a></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_address', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_address', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('wdk_city', $user_data_client, false, TRUE, TRUE)):?>
                                        <li class="meta-item"><strong><?php echo esc_html__('City', 'wdk-membership'); ?>:</strong> <?php echo esc_html(wmvc_show_data('wdk_city', $user_data_client, false, TRUE, TRUE));?></li>
                                    <?php endif;?>
                                </ul>
                            </span>
                        </div>
                    </div> 
                    <?php endif;?>

                    <?php if(!empty($listing)):?>
                        <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                            <label for="currency_code"><?php echo esc_html__('Listing Details', 'wdk-membership'); ?>:</label>
                            <div class="wdk-field-container">
                                <span class="regular-span">
                                    <a href="<?php echo esc_url(get_permalink($listing)); ?>"><?php echo esc_html(wmvc_show_data('post_title', $listing, '', TRUE, TRUE)); ?></a>
                                    <?php if(wmvc_show_data('address', $listing, false, TRUE, TRUE)):?>
                                    <p>
                                        <strong><?php echo esc_html__('Address', 'wdk-membership'); ?>:</strong> <a href="<?php echo esc_url(get_permalink($listing)); ?>"><?php echo esc_html(wmvc_show_data('address', $listing, '', TRUE, TRUE)); ?></a><br />
                                    </p>
                                    <?php endif;?>
                                    <?php if(wmvc_show_data('lng', $listing, false, TRUE, TRUE) && wmvc_show_data('lat', $listing, false, TRUE, TRUE)):?>
                                    <p>
                                        <a target="_blank" href="<?php echo esc_url('https://maps.google.com/maps?daddr='.wmvc_show_data('address', $listing, '', TRUE, TRUE).'@'.wmvc_show_data('lat', $listing, '', TRUE, TRUE).','.wmvc_show_data('lng', $listing, '', TRUE, TRUE)); ?>">
                                            <strong><?php echo esc_html__('Route to destination', 'wdk-membership'); ?></strong> 
                                        </a>
                                    </p>
                                    <?php endif;?>
                                </span>
                            </div>
                        </div> 
                        <?php if(wmvc_show_data('lng', $listing, false, TRUE, TRUE) && wmvc_show_data('lat', $listing, false, TRUE, TRUE)):?>
                        <div class="wdk-field-edit INPUTBOX_READONLY wdk-col- ">
                            <label for="currency_code"><?php echo esc_html__('GPS', 'wdk-membership'); ?>:</label>
                            <div class="wdk-field-container">
                                <span class="regular-span">
                                    <?php echo esc_html(wmvc_show_data('lat', $listing, '', TRUE, TRUE)); ?>,<?php echo esc_html(wmvc_show_data('lng', $listing, '', TRUE, TRUE)); ?>
                                </span>
                            </div>
                        </div> 
                        <?php endif;?>
                    <?php endif;?>
                </div>
            </div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>
</div>
<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>
<?php wp_enqueue_style('wdk-booking-field-calendar');?>
<?php wp_enqueue_script('wdk-booking-field-calendar');?>

<?php $this->view('general/footer', $data); ?>

