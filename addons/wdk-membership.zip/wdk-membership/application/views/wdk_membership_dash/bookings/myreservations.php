<?php
/**
 * The template for Management My Reservations.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wdk-front-wrap wdk_membership_dash_booking_myreservations">
    <h1 class="wdk-h"><?php echo esc_html__('My Reservations', 'wdk-membership'); ?> 
        <div class="wdk-float-right-md">
            <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
                <?php if(!wdk_get_option('wdk_bookings_disable_bookings_by_default') || (wdk_get_option('wdk_bookings_disable_bookings_by_default') && wdk_membership_subscription_booking_enabled())):?>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="btn_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-prices"); ?>" class="button button-primary" id="btn_prices"><?php echo esc_html__('Availability/Prices', 'wdk-membership'); ?></a>
                    <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="btn_calendars"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
                <?php endif;?>
            <?php endif;?>
        </div>
    </h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="booking-myreservations" />

                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php
    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->load_helper('listing');
    ?>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Listing', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date From', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date To', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Price Total', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Price Paid', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($reservations) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No Reservations found.', 'wdk-membership'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($reservations as $reservation) : ?>
                    <tr>
                        <td data-label="<?php echo esc_html__('id', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('idreservation', $reservation, '-'); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Listing', 'wdk-membership'); ?>" class="title column-title has-row-actions column-primary page-title" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo wdk_dash_url("dash_page=booking-myreservations&function=edit&id=" . wmvc_show_data('idreservation', $reservation, '-')); ?>"><?php echo wmvc_show_data('post_title', $reservation, '-'); ?></a>
                                <?php if(wmvc_show_data('is_payment_expired', $reservation, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Payment time expired', 'wdk-membership'); ?></span>
                                <?php elseif(!wmvc_show_data('is_approved', $reservation, 0)): ?>
                                <span class="label label-info"><?php echo esc_html__('Waiting approvement', 'wdk-membership'); ?></span>
                                <?php elseif(!wmvc_show_data('is_paid', $reservation, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Waiting payment', 'wdk-membership'); ?></span>
                                <?php elseif(!wmvc_show_data('is_booked', $reservation, 0)): ?>
                                <span class="label label-info"><?php echo esc_html__('Waiting confirmation', 'wdk-membership'); ?></span>
                                <?php elseif(wmvc_show_data('is_booked', $reservation, 0)): ?>
                                <span class="label label-success"><?php echo esc_html__('Confirmed', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                            </strong>
                        </td>
                        <td data-label="<?php echo esc_html__('Date From', 'wdk-membership'); ?>">
                            <?php echo wdk_get_date(wmvc_show_data('date_from', $reservation), false); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Date To', 'wdk-membership'); ?>">  
                            <?php echo wdk_get_date(wmvc_show_data('date_to', $reservation), false); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Price Total', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('price', $reservation, '-'); ?><?php echo wdk_booking_currency_symbol(); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Price Paid', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('price_paid', $reservation, '-'); ?>
                            <?php if(wmvc_show_data('price_paid', $reservation, false)) echo wdk_booking_currency_symbol(); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                            <a href="<?php echo wdk_dash_url("dash_page=booking-myreservations&function=edit&id=" . wmvc_show_data('idreservation', $reservation, '-')); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
        </table>
        <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
        <div class="tablenav bottom">
            <div class="tablenav-main">
            </div>
            <div class="tablenav-sidebar">
                <?php echo wmvc_xss_clean($pagination_output); ?>
            </div>
        </div>
        <?php endif;?>
    </form>

    <?php if(true || !empty($total_listings)):?>
        <div style="margin-bottom: 20px;<?php if(!current_user_can('edit_own_listings') && !wmvc_user_in_role('administrator')): ?> margin-top: 20px; <?php endif?>" class="wdk_alert wdk_alert-info" role="alert">
            <?php echo esc_html__('If you have listings for reservation, please add','wdk-membership'); ?> 
            <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>"> <?php echo esc_html__('Calendars','wdk-membership'); ?></a>
            <?php echo esc_html__('and','wdk-membership'); ?>
            <a href="<?php echo wdk_dash_url("dash_page=booking-prices"); ?>"><?php echo esc_html__('Availability prices','wdk-membership'); ?></a>
            <?php echo esc_html__('for related listing','wdk-membership'); ?>
        </div>
    <?php endif;?>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>

<?php $this->view('general/footer', $data); ?>

