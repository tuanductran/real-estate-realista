<?php
/**
 * The template for Edit Price.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_booking_price_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Edit Price', 'wdk-membership'); ?>
        <div class="wdk-float-right-md">
            <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
                <a href="<?php echo wdk_dash_url("dash_page=booking-reservations"); ?>" class="button button-primary" id="btn_listing_reservation"><?php echo esc_html__('Listings Reservations', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-prices"); ?>" class="button button-primary" id="btn_prices"><?php echo esc_html__('Availability/Prices', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-calendars"); ?>" class="button button-primary" id="btn_calendars"><?php echo esc_html__('Calendars', 'wdk-membership'); ?></a>
                <a href="<?php echo wdk_dash_url("dash_page=booking-myreservations"); ?>" class="button button-primary" id="btn_my_reservation"><?php echo esc_html__('My Reservations', 'wdk-membership'); ?></a>
            <?php endif;?>
        </div>
    </h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=booking-prices&function=edit&id='.wmvc_show_data('idprice', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <?php if(wmvc_show_data('idprice',$db_data, false)):?>
                <input type="hidden" name="current_price_id" id="current_price_id" value="<?php echo esc_attr(wmvc_show_data('idprice',$db_data, false)); ?>">
            <?php endif;?>
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
            </div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>
</div>
<?php
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>
<?php wp_enqueue_style('wdk-booking-field-calendar');?>
<?php wp_enqueue_script('wdk-booking-field-calendar-price');?>
<?php $this->view('general/footer', $data); ?>

