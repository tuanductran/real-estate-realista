<?php
/**
 * The template for Edit Listings.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_listings_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Add/Edit Listing', 'wdk-membership'); ?></h1>

    <?php do_action('wdk-membership/view/listing_edit/above_form', wmvc_show_data('ID', $db_data, ''));?>

    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=listings&function=edit&id='.wmvc_show_data('ID', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="form_listing wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3>
                            <?php echo esc_html__('Main Data ', 'wdk-membership'); ?>
                            <?php if(get_option('wdk_sub_listings_enable')): ?>
                                <?php if(!empty(wmvc_show_data('listing_parent_post_id', $db_data))):?>
                                    <?php echo __('Child Listing of', 'wdk-membership'); ?>  <a target="_blank" style="text-decoration: underline !important;" href="<?php echo esc_url(wdk_dash_url("dash_page=listings&function=edit&id=" .wmvc_show_data('listing_parent_post_id', $db_data)));?>"><?php echo esc_html(wdk_field_value('post_title', wmvc_show_data('listing_parent_post_id', $db_data)));?></a>
                                <?php elseif(isset($_GET['parent_post_id']) && !empty($_GET['parent_post_id'])):?>
                                    <?php echo __('Child Listing of', 'wdk-membership'); ?>  <a target="_blank" style="text-decoration: underline !important;" href="<?php echo esc_url(wdk_dash_url("dash_page=listings&function=edit&id=" .intval($_GET['parent_post_id'])));?>"><?php echo esc_html(wdk_field_value('post_title', intval($_GET['parent_post_id'])));?></a>
                                <?php endif;?>
                            <?php endif;?>
                        </h3>
                        <?php if(!empty(wmvc_show_data('ID', $db_data))):?>
                            <a href="<?php echo esc_url(get_permalink(wmvc_show_data('ID', $db_data))); ?>" class="button button-secondary alignright" target="_blank"  title="<?php echo esc_attr__('View Listing', 'wdk-membership');?>" style="margin-right:15px;"><span class="dashicons dashicons-visibility" style="margin-top: 4px;"></span> <?php echo esc_html__('View listing', 'wdk-membership'); ?></a>
                        <?php endif;?>
                    </div>
                <div class="inside full-width">
                                        
                    <?php if(wdk_get_option('wdk_membership_is_enable_subscriptions')):?>
                        <?php if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && !wmvc_show_data('subscription_id', $db_data, false) && $subscriptions && count($subscriptions)>1):?>
                            <?php if(isset($_POST['post_title']) && !wmvc_show_data('subscription_id', $db_data, false)):?>
                                <div class="wdk-col-12">
                                    <div class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Please select subscription above for this listing','wdk-membership'); ?></div>
                                </div>
                            <?php else:?>
                                <div class="wdk-col-12">
                                    <div class="wdk_alert wdk_alert-info"><?php echo esc_html__('Please select subscription above for this listing','wdk-membership'); ?></div>
                                </div>
                            <?php endif;?>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php
                        $success_message = __('Successfully saved', 'wdk-membership');
                        if(isset($_GET['custom_message']))
                            $success_message = esc_html(urldecode($_GET['custom_message']));

                        if(function_exists('run_wdk_bookings')) {
                            /* if booking addon exists, show custom message with link to edit calendar */
                            $success_message = esc_html__('Successfully saved','wdk-membership').'. <a target="_blank" href="'. wdk_dash_url("dash_page=booking-calendars&function=edit&id=" .$calendar_id.'&post_id='.wmvc_show_data('ID', $db_data)).'">'.esc_html__('To define calendar availability dates please click here', 'wdk-membership').'</a>';
                        }
                        
                        $form->messages('class="alert alert-danger"', $success_message);
                    ?>

                    <?php if(wdk_get_option('wdk_membership_is_enable_subscriptions')):?>
                        <?php if(empty($subscriptions) && wdk_get_option('wdk_membership_is_subscription_required')):?>
                            <div class="wdk-col-12">
                                <div class="wdk_alert wdk_alert-danger"><p><?php echo esc_html__('Membership subscription required, please check options here','wdk-membership'); ?>  <a href="<?php echo esc_url(wdk_dash_url('dash_page=membership'));?>" style="margin-left:5px;" class="button button-primary"><?php echo esc_html__('Subscriptions options','wdk-membership'); ?></a></p></div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="wdk-row">
                        <div class="wdk-col-8 wdk-col-xs-12 order-xs-2">
                            <div class="wdk-from-group">
                                <label class="" for="post_title"><?php echo esc_html__('Title', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                    <input name="post_title" type="text" id="post_title" value="<?php echo wmvc_show_data('post_title', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Title', 'wdk-membership');?>" class="regular-text">
                                </div>
                            </div>
                            <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
                            <div class="wdk-from-group">
                                <label class="" for="input_address"><?php echo esc_html__('Address', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input name="address" type="text" id="input_address" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-membership');?>" class="regular-text">
                                    <p class="description" id="input_address-description"><?php echo esc_html__('After you enter address system will try to autodetect and pin location on map, then you can drag and drop pin on map to fine tune location','wdk-membership'); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(get_option('wdk_sub_listings_enable')): ?>

                                <?php if(!empty(wmvc_show_data('listing_parent_post_id', $db_data)) || (isset($_GET['parent_post_id']) && !empty($_GET['parent_post_id']))):?>
                                    <div class="<?php echo (defined( 'WP_DEBUG' ) && WP_DEBUG) ? '': 'wdk-hidden';?> wdk-from-group">
                                        <label class="" for="category_id"><?php echo __('Parent ID', 'wdk-membership'); ?>*</label>
                                        <div class="wdk-from-group-control">
                                            <?php if(!empty(wmvc_show_data('listing_parent_post_id', $db_data))):?>
                                                <input readonly name="listing_parent_post_id" type="text" id="listing_parent_post_id" value="<?php echo wmvc_show_data('listing_parent_post_id', $db_data, ''); ?>" placeholder="<?php echo esc_html__('listing_parent_post_id', 'wdk-membership');?>" class="regular-text">
                                            <?php elseif(isset($_GET['parent_post_id']) && !empty($_GET['parent_post_id'])):?>
                                                <input readonly name="listing_parent_post_id" type="text" id="listing_parent_post_id" value="<?php echo esc_attr(intval($_GET['parent_post_id'])); ?>" placeholder="<?php echo esc_html__('listing_parent_post_id', 'wdk-membership');?>" class="regular-text">
                                            <?php endif;?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if(!empty(wmvc_show_data('ID', $db_data)) && empty(wmvc_show_data('listing_parent_post_id', $db_data,''))):?>
                                    <div class="wdk-from-group">
                                        <label class="" for="category_id"><?php echo __('Childs', 'wdk-membership'); ?>*</label>
                                        <div class="wdk-from-group-control">
                                        <div class="wdk-listing-childs-wrap">
                                            <input readonly name="listing_childs_id" type="hidden" id="listing_childs_id" value="<?php echo wmvc_show_data('listing_childs_id', $db_data, ''); ?>" class="regular-text">
                                                <div class="wdk-listing-childs-drop">
                                                    <?php if(!empty(wmvc_show_data('listing_childs_id', $db_data, ''))):?>
                                                        <?php foreach (explode(',',wmvc_show_data('listing_childs_id', $db_data, '')) as $key => $child_idlisting):?>
                                                            <div class="drop-listing-item" data-idlisting="<?php echo esc_attr($child_idlisting);?>">
                                                                <h3 class="handle"> 
                                                                    <a target="_blank" href="<?php echo esc_url(wdk_dash_url("dash_page=listings&function=edit&id=" .$child_idlisting));?>" class="title"><?php echo esc_html('#'.$child_idlisting.', '.wdk_field_value('post_title', $child_idlisting));?></a> 
                                                                    <a target="_blank" class="btn" href="<?php echo esc_url(wdk_dash_url("dash_page=listings&function=edit&id=" .$child_idlisting));?>" target="_blank" title="Edit"><span class="dashicons dashicons-edit"></span></a>
                                                                    <a class="question_sure btn remove" href="#" title="Remove"><span class="dashicons dashicons-no"></span></a>
                                                                </h3>
                                                            </div>
                                                        <?php endforeach;?>
                                                    <?php endif;?>
                                                </div>
                                                                                                    
                                                <div class="wdk-field-edit">
                                                    <div class="wdk-field-container" style="padding: 0;">
                                                        <?php echo wdk_treefield_option('new_listing_id', 'listing_m', NULL, 'post_title', '', __('Not Selected', 'wdk-membership'),'',TRUE,'listing_parent_post_id IS NOT NULL');?>
                                                        <a class="wdk-btn wdk-btn-primary add_new_listing" style="margin-left: 5px" href="#"><?php echo __('Add', 'wdk-membership'); ?></a>
                                                    </div>
                                                </div>
                                                <a target="_blank" class="wdk-btn wdk-btn-secondary" href="<?php echo esc_url(wdk_dash_url("dash_page=listings&function=edit&id=&parent_post_id=".wmvc_show_data('ID', $db_data)));?>"><?php echo __('Add New Child Listing', 'wdk-membership'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif;?>
                            <?php endif;?>


                            <?php if(get_option('wdk_is_category_enabled', FALSE)): ?>
                                <?php if(wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown'):?>
                                    <div class="wdk-from-group">
                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_category_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                            <?php
                                            global $Winter_MVC_WDK;
                                            $Winter_MVC_WDK->load_helper('listing');
                                            $Winter_MVC_WDK->model('category_m');
                                            $field_value =  wmvc_show_data('category_id', $db_data, '');
                                            $field_key = 'category_id';
                                            
                                            $categories = array();
                                            if(!empty($field_value)) {
                                                $categories[] = $field_value;
                                                $category = $Winter_MVC_WDK->category_m->get($field_value, TRUE); 

                                                while(!empty($category->parent_id)) {
                                                    $category = $Winter_MVC_WDK->category_m->get($category->parent_id, TRUE); 
                                                    $categories[] = $category->idcategory;
                                                }
                                                krsort($categories);
                                            } else {
                                                $categories[] = 0;
                                            }

                                            wp_enqueue_style('wdk-treefield-dropdown');
                                            wp_enqueue_script('wdk-treefield-dropdown');
                                            wp_enqueue_style( 'dashicons' );


                                            $level_max = $Winter_MVC_WDK->category_m->get_max_level();

                                            $placeholder = [
                                                0 => esc_html__('Select Categories','wpdirectorykit'),
                                                1 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                2 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                3 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                4 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                5 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                            ];
                                            ?>

                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                            <?php
                                            $level = 0;
                                            $current = NULL;
                                            foreach ($categories as $category) {
                                                $current = $Winter_MVC_WDK->category_m->get($category, TRUE); 

                                                $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = '.$current->parent_id => NULL)); 

                                                if(isset($placeholder[$level])) {
                                                    $values_list = array(''=> $placeholder[$level]);

                                                    } else {
                                                    $values_list = array(''=> esc_html__('Select Sub Categories','wpdirectorykit'));
                                                }

                                                foreach ($list as $list_value) {
                                                    $values_list[$list_value->idcategory] = $list_value->category_title; 
                                                }
                                                ?>

                                                <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                    <div class="wdk-field-group">
                                                        <?php echo wmvc_select_option('category_'.$level, $values_list, $category, 'class="wdk-control"');?>
                                                    </div>
                                                </div>

                                                <?php
                                                $level++;
                                            }
                                                    
                                            if($level<$level_max ) {
                                                for (; $level<$level_max;) {
                                                
                                                    if(isset($placeholder[$level])) {
                                                        $values_list = array(''=> $placeholder[$level]);
                                                    } else {
                                                        $values_list = array(''=> esc_html__('Select Sub Categories','wpdirectorykit'));
                                                    }
                                                    if($category) {
                                                        $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = '.$category => NULL)); 
                                                        foreach ($list as $list_value) {
                                                            $values_list[$list_value->idcategory] = $list_value->category_title; 
                                                        }
                                                        $category = NULL;
                                                    }

                                                    ?>
                                                    <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                        <div class="wdk-field-group">
                                                            <?php echo wmvc_select_option('category_'.$level, $values_list, NULL, 'class="wdk-control"');?>
                                                        </div>
                                                    </div>

                                                    <?php
                                                    $level++;
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="wdk-from-group">
                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_category_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control">
                                            <?php echo wdk_treefield_option ('category_id', 'category_m',  wmvc_show_data('category_id', $db_data, ''), 'category_title', '', __('Not Selected', 'wdk-membership'));?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                           
                            <?php if(get_option('wdk_is_category_enabled', FALSE) && get_option('wdk_multi_categories_other_enable', FALSE)): ?>
                            <div class="wdk-from-group">
                                <label class="" for="listing_categories"><?php echo esc_html__('More Categories', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                <?php echo wdk_treefield_select_ajax ('listing_sub_categories[]', 'category_m', wmvc_show_data('listing_sub_categories', $db_data, '', FALSE, TRUE), 'category_title', 'idcategory', '', __('All Categories', 'wdk-membership'), '', 'data-limit="10"');?>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(get_option('wdk_is_location_enabled', FALSE)): ?>
                                <?php if(wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown'):?>
                                    <div class="wdk-from-group">
                                        <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_location_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                            <?php
                                            global $Winter_MVC_WDK;
                                            $Winter_MVC_WDK->load_helper('listing');
                                            $Winter_MVC_WDK->model('location_m');
                                            $field_value =  wmvc_show_data('location_id', $db_data, '');
                                            $field_key = 'location_id';

                                            $locations = array();
                                            if(!empty($field_value)) {
                                                $locations[] = $field_value;
                                                $location = $Winter_MVC_WDK->location_m->get($field_value, TRUE); 
                                                
                                                while(!empty($location->parent_id)) {
                                                    $location = $Winter_MVC_WDK->location_m->get($location->parent_id, TRUE); 
                                                    $locations[] = $location->idlocation;
                                                }
                                                krsort($locations);
                                            } else {
                                                $locations[] = 0;
                                            }
                                    
                                            wp_enqueue_style('wdk-treefield-dropdown');
                                            wp_enqueue_script('wdk-treefield-dropdown');
                                            wp_enqueue_style( 'dashicons' );
                                    
                                            $level_max = $Winter_MVC_WDK->location_m->get_max_level();
                                            
                                            $placeholder = [
                                                0 => esc_html__('Select Country','wpdirectorykit'),
                                                1 => esc_html__('Select City','wpdirectorykit'),
                                                2 => esc_html__('Select Neighborhood','wpdirectorykit'),
                                                3 => esc_html__('Select Sub Area','wpdirectorykit'),
                                                4 => esc_html__('Select Sub Area','wpdirectorykit'),
                                                5 => esc_html__('Select Sub Area','wpdirectorykit'),
                                            ];
                                            ?>

                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                            <?php
                                                $level = 0;
                                                $current = NULL;
                                                foreach ($locations as $location) {
                                                    $current = $Winter_MVC_WDK->location_m->get($location, TRUE); 

                                                    $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = '.$current->parent_id => NULL)); 

                                                
                                                    if(isset($placeholder[$level])) {
                                                        $values_list = array(''=> $placeholder[$level]);
                                                    } else {
                                                        $values_list = array(''=> esc_html__('Select Sub Area','wpdirectorykit'));
                                                    }

                                                    foreach ($list as $list_value) {
                                                        $values_list[$list_value->idlocation] = $list_value->location_title; 
                                                    }


                                                    ?>

                                                    <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                        <div class="wdk-field-group">
                                                            <?php echo wmvc_select_option('location_'.$level, $values_list, $location, 'class="wdk-control"');?>
                                                        </div>
                                                    </div>

                                                    <?php
                                                    $level++;
                                                }
                                                
                                                if($level<$level_max ) {
                                                    for (; $level<$level_max;) {

                                                        if(isset($placeholder[$level])) {
                                                            $values_list = array(''=> $placeholder[$level]);
                                                        } else {
                                                            $values_list = array(''=> esc_html__('Select Sub Area','wpdirectorykit'));
                                                        }
                                                            
                                                        if($location) {
                                                            $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = '.$location => NULL)); 
                                                            foreach ($list as $list_value) {
                                                                $values_list[$list_value->idlocation] = $list_value->location_title; 
                                                            }
                                                            $location = NULL;
                                                        }

                                                        ?>
                                                        <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                            <div class="wdk-field-group">
                                                                <?php echo wmvc_select_option('location_'.$level, $values_list, NULL, 'class="wdk-control"');?>
                                                            </div>
                                                        </div>
                                            
                                                        <?php
                                                        $level++;
                                                    }
                                                }
                                            ?>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="wdk-from-group">
                                            <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_location_required')):?>*<?php endif;?></label>
                                            <div class="wdk-from-group-control">
                                                <?php echo wdk_treefield_option ('location_id', 'location_m',  wmvc_show_data('location_id', $db_data, ''), 'location_title', '', __('Not Selected', 'wdk-membership'));?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                            <?php endif; ?>

                            <?php if(get_option('wdk_is_location_enabled', FALSE) && get_option('wdk_multi_locations_other_enable', FALSE)): ?>
                                <div class="wdk-from-group">
                                    <label class="" for="location_id"><?php echo esc_html__('More Locations', 'wdk-membership'); ?></label>
                                    <div class="wdk-from-group-control">
                                    <?php echo wdk_treefield_select_ajax ('listing_sub_locations[]', 'location_m', wmvc_show_data('listing_sub_locations', $db_data, '', TRUE, TRUE), 'location_title', 'idlocation', '', __('All Locations', 'wdk-membership'), '', 'data-limit="10"');?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(wdk_get_option('wdk_membership_is_enable_subscriptions')):?>
                                <?php if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && count($subscriptions) > 1):?>
                                    <div class="wdk-from-group wdk-hidden">
                                        <label class="" for="user_id"><?php echo esc_html__('Subscription', 'wdk-membership'); ?>*</label>
                                        <div class="wdk-from-group-control">
                                            <?php
                                                echo wmvc_select_option('subscription_id', $subscriptions, wmvc_show_data('subscription_id', $db_data, ''), "id='subscriptions'", __('Not Selected', 'wdk-membership'));
                                            ?>
                                        </div>
                                    </div>
                                <?php else:?>
                                    <div class="wdk-from-group wdk-hidden">
                                        <label class="" for="subscription_id"><?php echo esc_html__('Subscription id', 'wdk-membership'); ?></label>
                                        <div class="wdk-from-group-control">
                                            <?php if(!empty($subscriptions)):?>
                                                <input readonly="readonly" name="subscription_id" type="number" id="subscription_id" value="<?php echo array_key_last($subscriptions); ?>" class="regular-text">
                                            <?php else:?>
                                                <input readonly="readonly" name="subscription_id" type="number" id="subscription_id" value="" class="regular-text">
                                            <?php endif;?>
                                        </div>
                                    </div>
                                <?php endif;?>
                            <?php endif;?>
                                    
                            <?php if(function_exists('run_wdk_payments')):?>
                            <div class="wdk-from-group">
                                <label class="" for="user_id"><?php echo esc_html__('Rank', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input readonly="readonly" name="rank" type="number" id="rank" value="<?php echo wmvc_show_data('rank', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Rank', 'wdk-membership');?>" class="regular-text">
                                </div>
                            </div>
                            <?php endif;?>
                            <div class="wdk-from-group CHECKBOX">
                                <label class="is_activated" for="is_activated"><?php echo esc_html__('Is Activated', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input name="is_activated" type="checkbox" id="is_activated" value="1" <?php echo !empty(wmvc_show_data('is_activated', $db_data, ''))?'checked':''; ?>> <label class="is_activated" for="is_activated"> <?php echo esc_html__('Make it available for public','wdk-membership'); ?></label>
                                    <p class="description" id="is_activated-description"><?php echo esc_html__('When listing is activated and approved will be visible on frontend','wdk-membership'); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="wdk-col-4 wdk-col-xs-12 order-xs-1">
                            <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
                                <div id="map" class="listing_edit_map"></div>
                                <br/>
                                <p class="alert alert-info"><?php echo esc_html__('Drag and drop pin to desired location','wdk-membership');?></p>
                                <div class="wdk-field-edit inline">
                                    <label for="listing_gps"><?php echo esc_html__('GPS','wdk-membership');?>:</label>
                                    <div class="wdk-field-container">
                                        <input name="lat" readonly="readonly" type="text" id="input_lat" value="<?php echo wmvc_show_data('lat', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lat', 'wdk-membership');?>">
                                        <input name="lng" readonly="readonly" type="text" id="input_lng" value="<?php echo wmvc_show_data('lng', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lng', 'wdk-membership');?>">
                                    </div>
                                </div>
                            <?php endif;?>
                        </div>
                    </div>
                    <?php if(wdk_get_option('wdk_is_post_content_enable', FALSE)): ?>
                    <div class="wdk-row">
                        <div class="wdk-col-12">
                            <div class="wdk-from-group">
                                <label class="" for="post_content"><?php echo esc_html__('Content', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                <?php wp_editor(wmvc_show_data('post_content', $db_data, ''), 'post_content', array('media_buttons' => FALSE)); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="wdk-row full-width wdk_generate_fields">
                        <?php if(count($fields) == 0): ?>
                            <div class="wdk-col-12">
                                <div class="alert alert-success mb0"><p><?php echo esc_html__('Fields doesn\'t exists','wdk-membership'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk_fields"; ?>" class="button button-primary" id="add_field_button"><?php echo esc_html__('Manage Fields','wdk-membership'); ?></a></p></div>
                            </div>
                        <?php endif; ?>
                        <?php echo wdk_generate_fields($fields, $db_data); ?>  
                    </div>
                </div>
            </div>

            <?php if(!wdk_get_option('wdk_listing_plangs_documents_disable')):?>
                <div class="postbox" style="display: block;">
                    <div class="postbox-header">
                        <h3><?php echo __('Listing plans and documents', 'wdk-membership'); ?></h3>
                    </div>
                    <div class="inside">
                        <p class="alert alert-info"><?php echo __('Drag and drop image to change order', 'wdk-membership'); ?></p>
                        <?php  
                            echo wdk_upload_multi_files('listing_plans_documents', wmvc_show_data('listing_plans_documents', $db_data, '')); 
                        ?>               
                    </div>
                </div>
            <?php endif;?>
            <?php if(!wdk_get_option('wdk_listing_images_disable')):?>
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Listing Images', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside">
                    <p class="alert alert-info"><?php echo esc_html__('Drag and drop image to change order', 'wdk-membership'); ?></p>
                    <?php  
                        echo wmvc_upload_multiple('listing_images', wmvc_show_data('listing_images', $db_data, '')); 
                    ?>               
                </div>
            </div>
            <?php endif;?>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>

    <?php do_action('wdk-membership/view/listing_edit/after_form', wmvc_show_data('ID', $db_data, ''));?>
</div>


<?php
    wp_enqueue_style('winter_mvc', plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/css/winter_mvc.css'));
    wp_enqueue_script( 'wpmediaelement',  plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/js/jquery.wpmediaelement.js'), false, false, false );
    wp_enqueue_script( 'wpmediamultiple',  plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/js/jquery.wpmediamultiple.js'), false, false, false );
    $params = array(
        'text' =>array(
            'frame_title' => esc_html__('Select or Upload Media Of Your Chosen Persuasion', 'wdk-membership'),
            'frame_button' => esc_html__('Use this media', 'wdk-membership'),
        ),
    );
    wp_localize_script('wpmediamultiple', 'wpmediamultiple_parameters', $params);
    wp_localize_script('wpmediaelement', 'wpmediaelement_parameters', $params);
    
    wp_enqueue_style('leaflet');
    wp_enqueue_script('leaflet');
            
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
            var wdk_edit_map_marker,wdk_timerMap,wdk_edit_map;
            wdk_edit_map = L.map('map', {
                center: [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>],
                zoom: 4,
            });   

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(wdk_edit_map);

            wdk_edit_map_marker = L.marker(
                [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>],
                {draggable: true}
            ).addTo(wdk_edit_map);

            wdk_edit_map_marker.on('dragend', function(event){
                clearTimeout(wdk_timerMap);
                var marker = event.target;
                var {lat,lng} = marker.getLatLng();
                $('#input_lat').val(lat);
                $('#input_lng').val(lng);
                //retrieved the position
            });

            wdk_edit_map.on('click', function(e){
                let lat = e.latlng.lat;
                let lng = e.latlng.lng;

                wdk_edit_map_marker.setLatLng([lat, lng]).update();
                $('#input_lat').val(lat);
                $('#input_lng').val(lng);
            })
            
            $('#input_address').on('change keyup', function (e) {
                clearTimeout(wdk_timerMap);
                wdk_timerMap = setTimeout(function () {
                    $.get('https://nominatim.openstreetmap.org/search?format=json&q='+$('#input_address').val(), function(data){
                        if(data.length && typeof data[0]) {
                            var {lat,lon} =data[0];
                            wdk_edit_map_marker.setLatLng([lat, lon]).update(); 
                            wdk_edit_map.panTo(new L.LatLng(lat, lon));
                            $('#input_lat').val(lat);
                            $('#input_lng').val(lon);
                        } else {
                            wdk_log_notify('<?php echo esc_js(__('Address not found', 'wdk-membership')); ?>', 'error');
                            return;
                        }
                    });
                }, 1000);
            });

            $('#input_gps').on('change keyup', function (e) {
                wdk_edit_map.panTo(new L.LatLng($('#input_lat').val(), $('#input_lng').val()));
                wdk_edit_map_marker.setLatLng([parseFloat($('#input_lat').val()), parseFloat($('#input_lng').val())]).update(); 
            })
        <?php endif;?>

        <?php if(wdk_get_option('wdk_membership_is_enable_subscriptions')):?>
        if($('.wdk-table-subs').length) {
            var subs_list = $('.wdk-table-subs');

            subs_list.find('input').on('input', function(e){
                $('[name="subscription_id"]').val($(this).val());
            });
        }
        <?php endif;?>

        wdk_childs_listings_list();
    });

    
const wdk_childs_listings_list = ($selector= '.wdk-listing-childs-wrap', $field_name = 'listing_childs_id') => {
    var el_wrapper = jQuery($selector);
    var remove_child_listing,save_data;
     
    remove_child_listing = () => {
        el_wrapper.find( ".wdk-listing-childs-drop .drop-listing-item .remove" ).off().on('click', function(e){
            e.preventDefault();

            if(confirm("<?php echo esc_js(__('Are you sure?','wdk-membership')); ?>")) {
                jQuery(this).closest('.drop-listing-item').remove();
                save_data();
            }
        });
    };

    save_data = () => {
        var data_fields_sublist = '';
        el_wrapper.find('.wdk-listing-childs-drop .drop-listing-item').each(function( index ) {
            if(data_fields_sublist !='')
                data_fields_sublist +=',';

            data_fields_sublist += jQuery(this).attr('data-idlisting');
        });
        console.log(el_wrapper.find('input[name="'+$field_name+'"]'));
        el_wrapper.find('input[name="'+$field_name+'"]').val(data_fields_sublist);
    }

    remove_child_listing(); 

    el_wrapper.find( ".wdk-listing-childs-drop" ).sortable({
            connectWith: ".wdk-listing-childs-drop",
            placeholder: "ui-sortable-placeholder widget-placeholder",
            update: function(event, ui) {
                save_data();
            }
    }).disableSelection();

    el_wrapper.find('.add_new_listing').on('click', function(e){
        e.preventDefault();

        var listing_id = el_wrapper.find('input[name="new_listing_id"]').val();
        var listing_title = el_wrapper.find('.wdk_dropdown_tree button:first-child').text();

        if(listing_id == '') {
            wdk_log_notify('<?php echo esc_js(esc_attr__('Listing Not Defined','wdk-membership'));?>', 'error');
            return;
        }

        if(listing_id == '<?php echo esc_js(wmvc_show_data('ID', $db_data));?>') {
            wdk_log_notify('<?php echo esc_js(esc_attr__('Impossible add current listing','wdk-membership'));?>', 'error');
            return;
        }

        if( el_wrapper.find( ".wdk-listing-childs-drop .drop-listing-item[data-idlisting='"+listing_id+"']" ).length) {
            wdk_log_notify('<?php echo esc_js(esc_attr__('Listing already added','wdk-membership'));?>', 'error');
            return;
        }

        var item_html = '<div class="drop-listing-item" data-idlisting="'+listing_id+'">\n\
                            <h3 class="handle"> \n\
                                <a target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=wdk_listing&id='));?>'+listing_id+'" class="title">'+listing_title+'</a>\n\
                                <a target="_blank" class="btn" href="<?php echo esc_url(admin_url('admin.php?page=wdk_listing&id='));?>'+listing_id+'" target="_blank" title="Edit"><span class="dashicons dashicons-edit"></span></a>\n\
                                <a class="question_sure btn remove" href="#" title="<?php echo esc_js(__('Remove','wdk-membership'));?>"><span class="dashicons dashicons-no"></span></a>\n\
                            </h3> \n\
                        </div>';

        el_wrapper.find( ".wdk-listing-childs-drop" ).append(item_html);
        remove_child_listing();
        save_data();
    });
};
</script>

<?php $this->view('general/footer', $data); ?>

