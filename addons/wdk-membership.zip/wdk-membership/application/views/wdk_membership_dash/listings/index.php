<?php
/**
 * The template for Management Listings.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wdk-front-wrap wdk_membership_dash__index">
    <h1 class="wdk-h"><?php echo esc_html__('My Listings', 'wdk-membership'); ?> <a href="<?php echo wdk_dash_url("dash_page=listings&function=edit&"); ?>" class="button button-primary" title="<?php echo esc_attr__('Add Listing','wdk-membership');?>" id="add_listing_button"><?php echo esc_html__('Add Listing', 'wdk-membership'); ?></a></h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="listings" />
                    <?php if(get_option('wdk_is_location_enabled', FALSE)): ?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="location_id"><?php echo esc_html__('Filter by location', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('location_id', $locations, wmvc_show_data('location_id', $db_data, ''), NULL, __('Location', 'wdk-membership')); ?>
                    </div>
                    <?php endif; ?>

                    <?php if(get_option('wdk_is_category_enabled', FALSE)): ?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="category_id"><?php echo esc_html__('Filter by category', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('category_id', $categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Category', 'wdk-membership')); ?>
                    </div>
                    <?php endif; ?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=listings')); ?>">
        <table class="wdk-table responsive">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column">
                        <label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All', 'wdk-membership'); ?></label>
                        <input id="cb-select-all-1" type="checkbox" value="1">
                    </td>
                    <th style="width:50px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Title', 'wdk-membership'); ?></th>
                    <?php if(get_option('wdk_is_category_enabled', FALSE)): ?>
                    <th><?php echo esc_html__('Category', 'wdk-membership'); ?></th>
                    <?php endif; ?>
                    <th><?php echo esc_html__('Image', 'wdk-membership'); ?></th>
                    <th><?php echo esc_html__('Date', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo esc_html__('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($listings) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="7"><?php echo esc_html__('No Listings found.', 'wdk-membership'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($listings as $listing) : ?>
                    <tr>
                        <th data-label="<?php echo esc_html__('Checkbox', 'wdk-membership'); ?>" scope="row" class="check-column hide-resonsive">
                            <input id="cb-select-<?php echo wmvc_show_data('ID', $listing, '-'); ?>" type="checkbox" name="ids[]" value="<?php echo wmvc_show_data('ID', $listing, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo esc_html__('Is Locked', 'wdk-membership'); ?></span>
                            </div>
                        </th>
                        <td data-label="<?php echo esc_html__('id', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('ID', $listing, '-'); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Title', 'wdk-membership'); ?>" class="title column-title has-row-actions column-primary" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo wdk_dash_url("dash_page=listings&function=edit&id=" . wmvc_show_data('ID', $listing, '-')); ?>"><?php echo wmvc_show_data('post_title', $listing, '-'); ?></a>
                                <?php if(!wmvc_show_data('is_activated', $listing, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Not activated', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                                <?php if(!wmvc_show_data('is_approved', $listing, 0)): ?>
                                <span class="label label-danger"><?php echo esc_html__('Not approved', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                                <?php if(wmvc_show_data('is_featured', $listing, 0)): ?>
                                <span class="label label-info"><?php echo esc_html__('featured', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                            </strong>
                            <div class="row-actions">
                                <span class="edit"><a href="<?php echo wdk_dash_url("dash_page=listings&function=edit&id=" . wmvc_show_data('ID', $listing, '-')); ?>"><?php echo __('Edit', 'wdk-membership'); ?></a> | </span>
                                <span class="trash "><a href="<?php echo wdk_dash_url("dash_page=listings&table_action=table&action=delete&ids=" . wmvc_show_data('ID', $listing, '-')); ?>" class="submitdelete question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>" ><?php echo __('Delete', 'wdk-membership'); ?></a> | </span>
                                <span class="view"><a href="<?php echo get_permalink($listing); ?>" target="blank"><?php echo __('View', 'wdk-membership'); ?></a></span>
                            </div>
                            
                            <?php if(get_option('wdk_sub_listings_enable')): ?>
                                <?php if(!empty(wmvc_show_data('listing_related_ids', $listing))):?>
                                <div class="">
                                    <strong>
                                        <a href="#" class="laoding_sublistings" data-listing_id = '<?php echo esc_attr(wmvc_show_data('ID', $listing, '-'));?>'><?php echo esc_html__('Show Related','wdk-membership');?></a>
                                    </strong>
                                </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>

                        <?php if(get_option('wdk_is_category_enabled', FALSE)): ?>
                        <td data-label="<?php echo esc_html__('Categery', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data($listing->category_id, $categories, '-'); ?>
                        </td>
                        <?php endif; ?>
                        <td data-label="<?php echo esc_html__('Images', 'wdk-membership'); ?>">
                            <a class="img-link" href="<?php echo get_permalink($listing); ?>"  target="blank">
                                <img src="<?php echo esc_url(wdk_image_src($listing));?>" alt="thumb" style="height:70px;width:110px;object-fit:cover;text-align: center;"/>
                            </a>
                        </td>
                        <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>">
                            <?php echo wdk_get_date($listing->post_date, false); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                            <a href="<?php echo get_permalink($listing); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>" target="blank"><span class="dashicons dashicons-visibility"></span></a>
                            <a href="<?php echo wdk_dash_url("dash_page=listings&function=edit&id=" . wmvc_show_data('ID', $listing, '-')); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                            <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo wdk_dash_url("dash_page=listings&table_action=table&action=delete&ids=" . wmvc_show_data('ID', $listing, '-')); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>

                    <?php if(false && get_option('wdk_sub_listings_enable')): ?>
                        <?php if(!empty(wmvc_show_data('listing_childs_id', $listing))):?>
                            <?php foreach (explode(',',wmvc_show_data('listing_childs_id', $listing, '')) as $key => $child_idlisting):?>
                            <tr class="child">
                                <th scope="row"></th>
                                <td scope="row"></td>
                                <td data-label="<?php echo esc_html__('Title', 'wdk-membership'); ?>" colspan="1">
                                    <a target="_blank" href="<?php echo esc_url(admin_url('admin.php?page=wdk_listing&id='.$child_idlisting));?>"><?php echo esc_html('#'.$child_idlisting.', '.wdk_field_value('post_title', $child_idlisting));?></a> 
                                </td>
                                <td data-label="<?php echo esc_html__('Categery', 'wdk-membership'); ?>">
                                    <?php echo wdk_field_value('category_id', $categories); ?>
                                </td>
                                <td data-label="<?php echo esc_html__('Images', 'wdk-membership'); ?>" style="text-align: center;">
                                    <a class="img-link" href="<?php echo get_admin_url() . "admin.php?page=wdk_listing&id=" . $child_idlisting; ?>">
                                        <img src="<?php echo esc_url(wdk_image_src(array('listing_images'=>wdk_field_value('listing_images', $child_idlisting))));?>" alt="thumb" style="height:50px;width:65px;object-fit:cover;text-align: center;"/>
                                    </a>
                                </td>
                                <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>">
                                    <?php echo wdk_get_date(wdk_field_value('post_title', $child_idlisting), false); ?>
                                </td>
                                <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                                    <a href="<?php echo get_permalink($child_idlisting); ?>" title="<?php echo esc_attr__('View','wdk-membership');?>" target="blank"><span class="dashicons dashicons-visibility"></span></a>
                                    <a href="<?php echo wdk_dash_url("dash_page=listings&function=edit&id=" . $child_idlisting); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                                    <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo wdk_dash_url("dash_page=listings&table_action=table&action=delete&ids=" . $child_idlisting); ?>"><span class="dashicons dashicons-no"></span></a>
                                </td>
                            </tr>
                            <?php endforeach;?>
                        <?php endif;?>
                    <?php endif;?>
                <?php endforeach; ?>
            </tbody>    
        </table>
        <div class="tablenav bottom">
            <div class="tablenav-main">
                <div class="actions bulkactions">
                    <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action', 'wdk-membership'); ?></label>
                    <select name="action" id="bulk-action-selector-bottom" class="wdk-controll-xs">
                        <option value="-1"><?php echo esc_html__('Bulk actions', 'wdk-membership'); ?></option>
                        <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete', 'wdk-membership'); ?></option>
                        <option value="deactivate" class="hide-if-no-js"><?php echo esc_html__('Deactivate', 'wdk-membership'); ?></option>
                        <option value="activate" class="hide-if-no-js"><?php echo esc_html__('Activate', 'wdk-membership'); ?></option>
                    </select>
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="listings" />
                    <input type="submit" id="table_action" class="wdk-btn wdk-btn-primary wdk-btn-xs" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-membership'); ?>">
                </div>
            </div>
            <div class="tablenav-sidebar">
                <?php echo wmvc_xss_clean($pagination_output); ?>
            </div>
        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })

        wdk_loading_sublistings();
    });
    
    const wdk_loading_sublistings = ($selector_btn = '.laoding_sublistings') => {
        var init,action,event,eventRemove;

        event = (elem) => {
            var listing_id = jQuery(elem).attr('data-listing_id');
            var self = jQuery(elem);

            if(self.attr('disabled')) {
                return false;
            }

            self.addClass('wdk_btn_load_indicator out');
            self.attr('disabled','disabled');

            var ajax_param = {
                "page": 'wdk_backendajax',
                "function": 'loading_sublistings',
                "action": 'wdk_public_action',
                "listing_id": listing_id,
                "_wpnonce": '<?php echo esc_js(wp_create_nonce( 'wdk-backendajax'));?>',
            };
            
            jQuery.post("<?php echo admin_url( 'admin-ajax.php' );?>", ajax_param, 
                function(data){
                    
                if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                    
                self.removeClass('wdk_btn_load_indicator out');

                var html = '';
                jQuery.each(data.results, function(index, value){
                    html += '<tr class="child" data-loading-removing="<?php echo esc_js(__('Removing', 'wdk-membership')); ?>" data-loading-removed="<?php echo esc_js(__('Removed success', 'wdk-membership')); ?>" data-loading-removed_error="<?php echo esc_js(__('Remove error', 'wdk-membership')); ?>">\n\
                        <th scope="row"></th>\n\
                        <td scope="row">'+value.post_id+'</td>\n\
                        <td colspan="1">\n\
                            <a target="_blank" href="'+value.listing_dash_edit_url+'">'+value.post_title+'</a>\n\
                        </td>\n\
                        <td>\n\
                            '+value.category+'\n\
                        </td>\n\
                        <td style="text-align: center;">\n\
                            <a class="img-link" href="'+value.listing_dash_edit_url+'">\n\
                                <img src="'+value.image_src+'" alt="thumb" style="height:50px;width:65px;object-fit:cover;text-align: center;"/>\n\
                            </a>\n\
                        </td>\n\
                        <td>\n\
                            '+value.date+'\n\
                        </td>\n\
                        <td class="actions_column">\n\
                            <a href="'+value.listing_view_url+'" title="<?php echo esc_attr__('View','wdk-membership');?>" target="blank"><span class="dashicons dashicons-visibility"></span></a>\n\
                            <a href="'+value.listing_dash_edit_url+'" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>\n\
                            <a class="question_sure remove_event" href="'+value.listing_dash_remove_url+'" data-listing_id ="'+value.post_id+'" title="<?php echo esc_attr__('Remove','wdk-membership');?>"><span class="dashicons dashicons-no"></span></a>\n\
                        </td>\n\
                    </tr>'
                });

                jQuery( html ).insertAfter( self.closest('tr') );
                jQuery(self).remove();

               
            }).always(function(data) {
                if(true) {
                    eventRemove();
                } else {
                    jQuery('.child .question_sure').off().on('click', function() {
                        return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
                    });
                }
            });

            return false;
        };

        eventRemove = () => {

            jQuery('.child .remove_event').off().on('click', function(e) {
                e.preventDefault();
                if(!confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>")) {
                    return false;
                }

                var self = jQuery(this);
                var listing_id = self.attr('data-listing_id');

                var ajax_param = {
                    "page": 'wdk_backendajax',
                    "function": 'remove_listing',
                    "action": 'wdk_public_action',
                    "listing_id": listing_id,
                    "_wpnonce": '<?php echo esc_js(wp_create_nonce( 'wdk-backendajax'));?>',
                };

                var tr = self.closest('tr');

                self.addClass('wdk_btn_load_indicator out');
                
                jQuery.post("<?php echo admin_url( 'admin-ajax.php' );?>", ajax_param, 
                function(data){
                    
                    if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                    if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                    
                    if(data.success) {
                        
                        setTimeout(function() {
                            tr.animate({ opacity: 1/2 }, 500, function(){tr.remove();});
                        }, 200);
                        
                    } else {
                        self.removeClass('loading_removing').addClass('loading_removed_error');
                    }
                    
                }).always(function(data) {
                    self.removeClass('wdk_btn_load_indicator out').addClass('wdk_btn_load_success out');
                });
            })
        };
        
       
        action = () => {
            /*
            jQuery($selector_btn).on('click', function(e){
                e.preventDefault();
                event(jQuery(this));
            }); 
            */

            document.querySelectorAll($selector_btn).forEach(elem => elem.addEventListener('click', (e)=>{
                e.preventDefault();
                event(e.target);
            }, false));

        };

        init = () => {
            action();
        };

        init();
    };
</script>

<?php $this->view('general/footer', $data); ?>

