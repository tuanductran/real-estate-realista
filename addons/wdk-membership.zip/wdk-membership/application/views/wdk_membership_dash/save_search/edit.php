<?php
/**
 * The template for Edit Search.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="wdk-front-wrap wdk_membership_dash_save_search_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Edit Saved Search', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(wdk_dash_url('dash_page=save-search&function=edit&id='.wmvc_show_data('idsave_search', $db_data))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3><?php echo esc_html__('Main Data ', 'wdk-membership'); ?></h3>
                    </div>
                <div class="inside full-width">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>  
                </div>
            </div>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading in"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
            <?php if(get_option('wdk_results_page')):?>
                <a href="<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')), wmvc_show_data('parameters', $db_data, '-')); ?>" target="_blank" class="wdk-btn wdk-btn-default"><?php echo esc_html__('Show search','wdk-membership'); ?></a>
            <?php endif;?>
        </form>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

