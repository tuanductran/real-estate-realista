<?php
/**
 * The template for Management Searchs.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<?php
$translate = esc_html__('wdk-listing', 'wdk-membership');
$translate = esc_html__('page', 'wdk-membership');
?>

<div class="wdk-front-wrap wdk_membership_dash_save_search_index">
    <h1 class="wdk-h"><?php echo esc_html__('My Saved Searches', 'wdk-membership'); ?></h1>
    
    <?php if(!get_option('wdk_results_page')):?>
        <div class="wdk_alert wdk_alert-info" role="alert"><?php echo esc_html__('Not defined results page, please follow Directory kit -> Settings and set results page','wdk-membership'); ?></div>
    <?php endif;?>

    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=save-search')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="save-search" />
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <?php
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');
    ?>
    <table class="wdk-table responsive">
        <thead>
            <tr>
                <th><?php echo esc_html__('Parameters','wdk-membership'); ?></th>
                <th><?php echo esc_html__('Date Last Notify','wdk-membership'); ?></th>
                <th><?php echo esc_html__('Email Alert Enabled', 'wdk-membership'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-membership'); ?></th>
            </tr>
        </thead>
        <?php if(count($results) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="5"><?php echo esc_html__('No Save Search found.','wdk-membership'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $results as $item ):?>
            <tr>
                <td data-label="<?php echo esc_html__('Parameters', 'wdk-membership'); ?>">
                    <?php 
                        $custom_parameters = array();
                        $qr_string = trim(wmvc_show_data('parameters', $item, ''));
                        $string_par = array();
                        parse_str($qr_string, $string_par);
                        $custom_parameters = $string_par;

                    ?>
                        <?php 
                            $parsed_parameters = array();

                            $function_parse_values = function($field_key, $field_value) {
                                $value = '';
                                $parse = function($field_key, $field_value) {
                                    global $Winter_MVC_WDK;
                                    $Winter_MVC_WDK->load_helper('listing');
                                    $value = '';
                                    if( $field_key == 'category') {
                                        $Winter_MVC_WDK->model('category_m');
                                        $tree_data = $Winter_MVC_WDK->category_m->get($field_value, TRUE);
                                        $value = wmvc_show_data('category_title', $tree_data);
                                    }
                                    elseif( $field_key == 'location') {
                                        $Winter_MVC_WDK->model('location_m');
                                        $tree_data = $Winter_MVC_WDK->location_m->get($field_value, TRUE);
                                        $value = wmvc_show_data('location_title', $tree_data);
                                    }
                                    else {
                                        $value = $field_value;
                                    }
                                    return $value;
                                };

                                if(is_array($field_value)) {
                                    foreach ($field_value as $v) {
                                        if(!empty($value))
                                            $value .= ', ';
                                    
                                        $value .= $parse($field_key, $v);
                                    } 
                                }  else {
                                    $value = $parse($field_key, $field_value);
                                }
                                return $value;
                            };

                            foreach ($custom_parameters as $field_search_key => $field_value) {
                                $field_search_key_parsed = explode('_', $field_search_key);
                                if(!isset($field_search_key_parsed[1])) continue;

                                $parameter_key = $field_search_key_parsed[1];
                                $parameter_value = $function_parse_values($parameter_key, $field_value);

                                
                                if(!empty($parameter_value)) {

                                    if(substr($field_search_key, -4) == '_min') {
                                        $parameter_value = esc_html__('from','wdk-membership').' '.$parameter_value;
                                    }

                                    if(substr($field_search_key, -4) == '_max') {
                                        $parameter_value = esc_html__('to','wdk-membership').' '.$parameter_value;
                                    }

                                    if(!empty($parsed_parameters[$parameter_key])) {
                                        $parsed_parameters[$parameter_key] .= ', ';
                                    } else {
                                        $parsed_parameters[$parameter_key] = '';
                                    }
                                    $parsed_parameters[$parameter_key] .= $parameter_value;
                                }
                            }

                            foreach ($parsed_parameters as $field_key => $field_value) {
                                if(is_numeric($field_key)) {
                                    echo '<b style="font-weight: 600;">'.esc_html(trim(wdk_field_label($field_key))).':</b> '.esc_html($field_value).'; ';
                                } 
                                elseif($field_key == 'category') {
                                    echo '<b style="font-weight: 600;">'.esc_html__('Category','wdk-membership').':</b> '.esc_html($field_value).'; ';
                                }
                                elseif($field_key == 'location') {
                                    echo '<b style="font-weight: 600;">'.esc_html__('Location','wdk-membership').':</b> '.esc_html($field_value).'; ';
                                }
                                elseif($field_key == 'search') {
                                    echo '<b style="font-weight: 600;">'.esc_html__('Search Smart','wdk-membership').':</b> '.esc_html($field_value).'; ';
                                }
                                else {
                                    echo '<b style="font-weight: 600;">'.esc_html($field_key).':</b> '.esc_html($field_value).' ';
                                }
                            }
                        ?>
                </td>
                <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>">
                    <?php if(!wmvc_show_data('date_notify', $item, 0) || wmvc_show_data('date_notify', $item, 0) == wmvc_show_data('date', $item, 0)): ?>-<?php else: ?>
                        <?php echo wdk_get_date(wmvc_show_data('date_notify', $item), false); ?>
                    <?php endif; ?>
                </td>
                <td data-label="<?php echo esc_html__('Email Alert Enabled', 'wdk-membership'); ?>">
                    <?php if(!wmvc_show_data('is_enable_email_notify', $item, 0)): ?>-<?php else: ?>
                        <span class="label label-success"><span class="dashicons dashicons-saved"></span></span>
                    <?php endif; ?>
                </td>
                <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                    <a href="<?php echo wdk_dash_url("dash_page=save-search&function=edit&id=" . wmvc_show_data('idsave_search', $item, '-')); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                    <?php if(get_option('wdk_results_page')):?>
                        <a target="_blank" href="<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')), wmvc_show_data('parameters', $item, '-')); ?>" target="_blank" title="<?php echo esc_attr__('View', 'wdk-membership');?>"><span class="dashicons dashicons-visibility"></span></a>
                    <?php endif;?>
                    <a class="question_sure" href="<?php echo wdk_dash_url("dash_page=save-search&table_action=apply&action=delete&ids=" . wmvc_show_data('idsave_search', $item, '-')); ?>" title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <div class="tablenav bottom">
        <div class="tablenav-sidebar">
            <?php echo wmvc_xss_clean($pagination_output); ?>
        </div>
    </div>
</div>

