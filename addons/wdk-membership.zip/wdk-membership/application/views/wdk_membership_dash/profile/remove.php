<?php
/**
 * The template for Profile.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_profile_index">
<h1 class="wdk-h"><?php echo esc_html__('My Profile', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <form method="post" id="adduser" action="<?php echo esc_url(wdk_dash_url('dash_page=profile&function=remove')); ?>" enctype="multipart/form-data" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Remove Account', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                    <div class="wdk-row">
                        <div class="wdk-col-12">
                            <p><?php echo esc_html__('NOTE: Account will be full removed, without support recover', 'wdk-membership'); ?></p>

                            <div class="wdk-from-group">
                                <label class="" for="username"><?php echo esc_html__('Type your username', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" name="username"  autocomplete="new-password" type="text" id="username" value="" />
                                    <p class="description" id="input_address-description"><?php echo  wdk_sprintf(__( 'Type your username "%1$s"', 'wdk-membership' ),  get_the_author_meta( 'user_login', $current_user->ID )); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <input type="hidden" name="_wpnonce" id="submit"value="<?php echo wp_create_nonce('remove-user_'.esc_attr($current_user->ID));?>"> 
            <input type="submit" name="submit" id="submit" class="wdk-btn wdk-btn-primary" value="<?php echo esc_html__('Remove profile', 'wdk-membership'); ?>"> 
        </form><!-- #adduser -->
    </div>
</div>

