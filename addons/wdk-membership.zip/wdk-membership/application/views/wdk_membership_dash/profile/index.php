<?php
/**
 * The template for Profile.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_profile_index">
<h1 class="wdk-h"><?php echo esc_html__('My Profile', 'wdk-membership'); ?></h1>
    <div class="wdkmembership-content">
        <form method="post" id="adduser" action="<?php echo esc_url(wdk_dash_url('dash_page=profile')); ?>" enctype="multipart/form-data" class="wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Personal info', 'wdk-membership'); ?></h3>
                    <a href="<?php echo wdk_dash_url("dash_page=profile&function=remove"); ?>" class="button button-secondary alignright" title="<?php echo esc_attr__('Remove account', 'wdk-membership'); ?>" style="margin-right:15px;"><?php echo esc_html__('Remove account', 'wdk-membership'); ?></a>
                </div>
                <div class="inside">
                    <?php
                        if($credentials_updated) {
                            $form->messages('class="alert alert-danger"',  __('Successfully saved, after 5s. auto redirect to login form', 'wdk-membership'));
                        } else {
                            $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                        }
                        ?>
                    <div class="wdk-row">
                        <div class="wdk-col-12">
                            <div class="wdk-from-group">
                                <label class="" for="user_login"><?php echo esc_html__('Username', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" name="user_login"type="text" id="user_login" value="<?php the_author_meta( 'user_login', $current_user->ID ); ?>"  placeholder="<?php echo esc_html__('Username', 'wdk-membership');?>" disabled/>
                                    <p class="description" id="input_address-description"><?php echo esc_html__('It is not possible to change your username.', 'wdk-membership'); ?></p>
                                </div>
                            </div>

                            <div class="wdk-from-group">
                                <label class="" for="first-name"><?php echo esc_html__('First name', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" name="first-name" type="text" id="first-name" value="<?php echo wmvc_show_data('first-name', $db_data, get_the_author_meta( 'first_name', $current_user->ID )); ?>" />
                                </div>
                            </div>

                            <div class="wdk-from-group">
                                <label class="" for="last-name"><?php echo esc_html__('Last name', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" name="last-name" type="text" id="last-name" value="<?php echo wmvc_show_data('last-name', $db_data, get_the_author_meta( 'last', $current_user->ID )); ?>" />
                                </div>
                            </div>

                            <div class="wdk-from-group">
                                <label class="" for="input_address-description"><?php echo esc_html__('Public name', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <p class="description" id="input_address-description"><?php echo $current_user->display_name; ?></p>
                                </div>
                            </div>

                            <div class="wdk-from-group">
                                <label class="" for="email"><?php echo esc_html__('E-mail', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" name="email" type="text" readonly="readonly" id="email" value="<?php echo wmvc_show_data('email', $db_data, get_the_author_meta( 'user_email', $current_user->ID )); ?>" />
                                    <p class="description" id="input_address-description"><?php echo esc_html__('It is not possible to change your email.', 'wdk-membership'); ?></p>
                                </div>
                            </div>

                            <div class="wdk-from-group">
                                <label class="" for="pass1"><?php echo esc_html__('Password', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                <input class="text-input" autocomplete="new-password"  name="pass1" type="password" id="pass1" />
                                    <p class="description" id="input_address-description"><?php echo esc_html__('When both password fields are left empty, your password will not change. After changed password required re login', 'wdk-membership'); ?></p>
                                </div>
                            </div>
                            <div class="wdk-from-group">
                                <label class="" for="pass2"><?php echo esc_html__('Repeat password', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input class="text-input" autocomplete="off" name="pass2" type="password" id="pass2" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('About Yourself', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside">
                    <div class="wdk-row">
                        <div class="wdk-col-12">
                            <div class="wdk-from-group">
                                <label class="" for="description"><?php echo esc_html__('Biographical Info', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <textarea class="text-input" style="width: 100%;" name="description" id="description" rows="5" cols="30"><?php echo wmvc_show_data('description', $db_data, get_the_author_meta( 'description', $current_user->ID )); ?></textarea>
                                </div>
                            </div>
                            <?php if(!function_exists('ppu_custom_user_profile_fields')):?>
                            <div class="wdk-from-group">
                                <label class=""><?php echo esc_html__('Profile Picture', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <img src="<?php echo esc_url(get_avatar_url( $current_user->ID, array("size"=>180)));?>" class='wdk-image'>
                                    <p class="description"></p> <a href="https://en.gravatar.com/" target="_blank"><?php echo esc_html__('You can change your profile picture on Gravatar', 'wdk-membership'); ?></a></p>
                                </div>
                            </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>

            <?php 
                // action hook for plugin and extra fields
                do_action('edit_user_profile', $current_user); 
            ?>
            <br>
            <input type="hidden" name="_wpnonce" id="submit"value="<?php echo wp_create_nonce('update-user_'.esc_attr($current_user->ID));?>"> 
            <input type="submit" name="submit" id="submit" class="wdk-btn wdk-btn-primary" value="<?php echo esc_html__('Update profile', 'wdk-membership'); ?>"> 
        </form><!-- #adduser -->
    </div>
</div>

