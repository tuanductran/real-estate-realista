<?php
/**
 * The template for Notice Page.
 *
 * This is the template that title, alert, infor notice, message
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="wdk-front-wrap wdk_membership_dash_notice_page">
    <h2 class="wdk-h"><?php echo esc_html($title);?></h2>
    <p class="wdk-h"><?php echo wp_kses_post($message);?></p>
</div>

