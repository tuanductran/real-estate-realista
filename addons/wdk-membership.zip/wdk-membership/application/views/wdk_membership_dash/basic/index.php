<?php
/**
 * The template for Dash Layout.
 *
 * This is the template that widths, dash home page
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="wdk-front-wrap wdk_membership_dash_index">

    <?php if(wmvc_show_data('custom_message',$_GET, false)):?>
        <p class="<?php echo (wmvc_show_data('custom_message_class', $_GET, false)) ? esc_attr(wmvc_show_data('custom_message_class', $_GET)) : 'wdk_alert wdk_alert-info';?>">
            <?php echo wp_kses_post(str_replace(__('contact us', 'wdk-membership'),'<a href="mailto:@'.wdk_get_option('admin_email').'">'.__('contact us', 'wdk-membership').'</a>', urldecode(wmvc_show_data('custom_message',$_GET))));?>
        </p>
    <?php endif;?>

    <h2 class="wdk-h"><?php echo esc_html__('Hi','wdk-membership');?> <?php echo esc_html(wp_get_current_user()->display_name);?>,</h2>
    <h3 class="wdk-h"><?php echo esc_html__('Welcome in dashboard!','wdk-membership');?></h3>

    <div class="wdk-row wdk_dash_widgets">
        <?php do_action('wdk-membership/dash/homepage/widgets');?>
    </div>
</div>

