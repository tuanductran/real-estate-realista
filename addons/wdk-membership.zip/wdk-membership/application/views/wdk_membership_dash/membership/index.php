<?php
/**
 * The template for Review Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_membership_index">
    <h1 class="wdk-h"><?php echo esc_html__('Subscription', 'wdk-membership'); ?></h1>

    <br>
    
    <?php if(wmvc_show_data('custom_message',$_GET, false)):?>
        <p class="<?php echo esc_attr(wmvc_show_data('custom_message_class',$_GET, 'wdk_alert wdk_alert-info'));?>"><?php echo esc_html(urldecode(wmvc_show_data('custom_message',$_GET)));?></p>
    <?php endif;?>

    <?php if(wdk_get_option('wdk_membership_is_subscription_required') && empty($user_subscriptions)):?>
    <div class="wdk_alert wdk_alert-info  mb-20" role="alert">
        <?php echo esc_html__('Membership subscription required to add/edit listing, please select one below','wdk-membership'); ?>
    </div>
    <?php endif;?>

    <?php if(!empty($user_have_active) && $listings_limit):?>
        <div class="wdk_alert wdk_alert-danger mb-20" role="alert">
            <?php if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled')):?>
                <?php echo esc_html__('Your membership(s) subscription reaches max listings number limitation, please', 'wdk-membership'); ?> 
                <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                    <?php echo esc_html__('purchase one more or contact us','wdk-membership'); ?>
                </a>
            <?php else: ?>
                    <?php echo esc_html__('You reached subscription limit listings','wdk-membership'); ?> 

                    <?php echo esc_html($listings_count);?> / <?php echo esc_html(current($user_subscriptions)->listings_limit);?>

                    <?php echo esc_html__('listing exists','wdk-membership'); ?> 
                    
            <?php endif;?>  
        </div>

        <?php if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled')):?>
        <div class="wdk_alert wdk_alert-danger mb-20" role="alert">
            <?php echo esc_html__('If you want to change your membership subscription, please', 'wdk-membership'); ?> 
            <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                <?php echo esc_html__('contact us','wdk-membership'); ?>
            </a>
        </div>
        <?php endif;?>

    <?php endif;?>

    <?php if(!empty($user_subscriptions)):?>
        <?php foreach($user_subscriptions as $user_subscription): ?>
            <?php if($user_subscription->date_expire < date('Y-m-d H:i:s')):?>
                    <div class="wdk_alert wdk_alert-danger  mb-20" role="alert">
                        <?php echo  sprintf(esc_html__('You active subscription %1$s expired on %2$s', 'wdk-membership'), 
                                                        wdk_show_data('subscription_name',$user_subscription, false, TRUE, TRUE),
                                                        wdk_get_date( wdk_show_data('date_expire',$user_subscription, false, TRUE, TRUE), false)
                                                        ); ?>
                    </div>
                <?php else:?>
                    <div class="wdk_alert wdk_alert-info  mb-20" role="alert">
                        <?php echo  sprintf(esc_html__('You active subscription %1$s, will expire on %2$s', 'wdk-membership'), 
                                                        wdk_show_data('subscription_name',$user_subscription, false, TRUE, TRUE),
                                                        wdk_get_date( wdk_show_data('date_expire',$user_subscription, false, TRUE, TRUE), false)
                                                        ); ?>
                    </div>
                <?php endif;?>
        <?php endforeach;?>
    <?php endif;?>
    <br>
    <?php if(!empty($subscriptions)):?>
        <div class="wdk-row">
        <?php foreach($subscriptions as $subscription): ?>
            <?php
                $currency = '';
                $price = wdk_show_data('price',$subscription, '', TRUE, TRUE);

                if ( wdk_show_data('woocommerce_product_id',$subscription, false, TRUE, TRUE) && function_exists( 'wc_get_product' ) ) {
                    $product = wc_get_product(wdk_show_data('woocommerce_product_id',$subscription, false, TRUE, TRUE));
                    $currency = get_woocommerce_currency_symbol();
                    $price = $product->get_price();
                }
            ?>
            <div class="wdk-col-4 wdk-col-xs-12">
                <div class="wdk-pac <?php if(isset($listings_custom[wdk_show_data('idsubscription', $subscription, '-', TRUE, TRUE)]) && wdk_show_data('is_auto_featured',$listings_custom[wdk_show_data('idsubscription',$subscription, '-', TRUE, TRUE)], false, TRUE, TRUE)):?> featured <?php endif;?>">
                    <div class="top">
                        <h2 class="title">
                            <?php echo esc_html(wdk_show_data('subscription_name',$subscription, '', TRUE, TRUE));?>

                            <?php if(isset($user_subscriptions[$subscription->idsubscription])):?>
                                <?php if(!empty($user_subscriptions[$subscription->idsubscription]->date_expire) && $user_subscriptions[$subscription->idsubscription]->date_expire < date('Y-m-d H:i:s')):?>
                                    <span class="label label-danger"><?php echo esc_html__('expired', 'wdk-membership'); ?></span>
                                <?php elseif(!empty($user_subscriptions[$subscription->idsubscription]->date_expire)):?>
                                    <span class="label label-success"><?php echo esc_html__('active', 'wdk-membership'); ?></span>
                                <?php endif;?>
                            <?php endif;?>
                    </h4>
                    </div>
                    <div class="header">
                        <div class="pricing-value">
                            <span class="price"><span class="before"><?php echo esc_html($currency);?></span><?php echo (!empty($price)) ? esc_html(wdk_filter_decimal($price)) : '0';?><span class="after"></span></span>

                            <?php if(!empty($item->days_limit)):?>
                            <span class="expired">/
                                <?php
                                    echo esc_html(sprintf(_nx(
                                            '%1$s Day',
                                            '%1$s Days',
                                            intval($subscription->days_limit),
                                            'days count',
                                            'wdk-membership'
                                    ), intval($subscription->days_limit)));
                                ?>
                            </span>
                            <?php endif;?>
                        </div>
                    </div>
                    <ul class="list-items">
                        <li class="item item-days_limit days_limit_value_<?php echo esc_attr(wdk_show_data('days_limit',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('days_limit',$subscription, '', TRUE, TRUE)): ?>
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>
                            <?php echo esc_html(wdk_show_data('days_limit', $subscription, '', TRUE, TRUE));?>
                            <?php echo esc_html__('Days', 'wdk-membership'); ?>
                        </li>
                        <li class="item item-listings_limit listings_limit_value_<?php echo esc_attr(wdk_show_data('listings_limit',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('listings_limit',$subscription, '', TRUE, TRUE)): ?>
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>

                            <?php echo wmvc_show_data('listings_counter', $subscription, 0); ?> / 
                            <?php if(wdk_show_data('listings_limit',$subscription, '', TRUE, TRUE) == '-1'): ?>
                                <?php echo esc_html__('Unlimited Listings', 'wdk-membership'); ?>
                            <?php else: ?>
                                <?php echo esc_html(wdk_show_data('listings_limit', $subscription, esc_html__('No', 'wdk-membership'), TRUE, TRUE));?> 
                                <?php echo esc_html__('Listings Allowed', 'wdk-membership'); ?>
                            <?php endif; ?>
                        </li>
                        <li class="item item-images_limit images_limit_value_<?php echo esc_attr(wdk_show_data('images_limit',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('images_limit',$subscription, '', TRUE, TRUE)): ?>
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>

                            <?php if(wdk_show_data('images_limit',$subscription, '', TRUE, TRUE) == '-1'): ?>
                                <?php echo esc_html__('Unlimited Images', 'wdk-membership'); ?>
                            <?php else: ?>
                                <?php echo esc_html(wdk_show_data('images_limit', $subscription, esc_html__('No', 'wdk-membership'), TRUE, TRUE));?> 
                                <?php echo esc_html__('Images Allowed', 'wdk-membership'); ?>
                            <?php endif; ?>
                        </li>
                        <li class="item item-featured_rank featured_rank_value_<?php echo esc_attr(wdk_show_data('featured_rank',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('featured_rank',$subscription, '', TRUE, TRUE)): ?> 
                                <span class="dashicons dashicons-yes enable"></span>
                                <?php echo esc_html__('Featured rank level', 'wdk-membership'); ?>: 
                                <?php echo esc_html(wdk_show_data('featured_rank', $subscription, '', TRUE, TRUE));?>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                                <?php echo esc_html__('Featured rank level', 'wdk-membership'); ?>
                            <?php endif; ?>
                        </li>
                        <li class="item item-location_title images_limit_value_<?php echo esc_attr(wdk_show_data('location_id',$item, '0', TRUE, TRUE));?>">
                            <span class="dashicons dashicons-yes enable"></span>
                            <?php if(wdk_show_data('location_title',$subscription, '', TRUE, TRUE)): ?> 
                                <?php echo esc_html__('Locations', 'wdk-membership'); ?>: 
                                <?php echo esc_html((wdk_show_data('location_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                            <?php else: ?>
                                <?php echo esc_html((wdk_show_data('location_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                <?php echo esc_html__('Location', 'wdk-membership'); ?>
                            <?php endif; ?>
                        </li>
                        <li class="item item-category_title category_title_value_<?php echo esc_attr(wdk_show_data('category_id',$item, '0', TRUE, TRUE));?>">
                            <span class="dashicons dashicons-yes enable"></span>
                            <?php if(wdk_show_data('category_title',$subscription, '', TRUE, TRUE)): ?> 
                                <?php echo esc_html__('Categories', 'wdk-membership'); ?>: 
                                <?php echo esc_html((wdk_show_data('category_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                            <?php else: ?>
                                <?php echo esc_html((wdk_show_data('category_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                <?php echo esc_html__('Category', 'wdk-membership'); ?>
                            <?php endif; ?>
                        </li>
                        <li class="item item-is_auto_featured is_auto_featured_value_<?php echo esc_attr(wdk_show_data('is_auto_featured',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('is_auto_featured',$subscription, '', TRUE, TRUE)): ?>
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>
                            <?php echo esc_html__('Auto Featured', 'wdk-membership'); ?>
                        </li>
                        <li class="item item-is_auto_approved is_auto_approved_value_<?php echo esc_attr(wdk_show_data('is_auto_approved',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('is_auto_approved',$subscription, '', TRUE, TRUE)): ?> 
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>
                            <?php echo esc_html__('Auto Approved', 'wdk-membership'); ?>
                        </li>
                        <?php if(wdk_get_option('wdk_membership_subscriptions_view_listing_enabled')):?>
                        <li class="item item-is_view_private_listings is_view_private_listings_value_<?php echo esc_attr(wdk_show_data('is_view_private_listings',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('is_view_private_listings',$subscription, '', TRUE, TRUE)): ?> 
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>
                            <?php echo esc_html__('View Listing Details', 'wdk-membership'); ?>
                        </li>
                        <?php endif;?>
                        <?php if(wdk_get_option('wdk_bookings_disable_bookings_by_default')):?>
                        <li class="item item-is_booked_enabled is_booked_enabled_value_<?php echo esc_attr(wdk_show_data('is_booked_enabled',$item, '0', TRUE, TRUE));?>">
                            <?php if(wdk_show_data('is_booked_enabled',$subscription, '', TRUE, TRUE)): ?> 
                                <span class="dashicons dashicons-yes enable"></span>
                            <?php else: ?>
                                <span class="dashicons dashicons-no-alt disable"></span>
                            <?php endif; ?>
                            <?php echo esc_html__('Allow Booking', 'wdk-membership'); ?>
                        </li>
                        <?php endif;?>
                    </ul>
                    <div class="wdk-pac-footer">
                        <?php if(function_exists('wc_get_cart_url') && !empty($subscription->woocommerce_product_id)): ?>
                            <?php if(isset($user_subscriptions[$subscription->idsubscription])):?>
                                <?php if(!empty($subscription->date_expire) && (empty($price) || $price == '0.00')):?>
                                    <a target="_blank" href="#" class="btn btn-outline-secondary disabled"><?php echo esc_html__('Free possible activate only once', 'wdk-membership'); ?></a>
                                <?php else:?>
                                    <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($subscription->woocommerce_product_id)); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Extend', 'wdk-membership'); ?></a>
                                <?php endif;?>
                            <?php elseif(!empty($user_have_active) && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled') 
                                        && current($user_subscriptions)->price != '0.00' && !empty(current($user_subscriptions)->price)
                                        ):?>
                                <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($subscription->woocommerce_product_id)); ?>" class="btn btn-outline-secondary disabled"><?php echo esc_html__('Other subscription currently active', 'wdk-membership'); ?></a>
                            <?php elseif(empty($price) || $price == '0.00'):?>
                                <a href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'wdk_membership_activate_subscription=1&id='.wdk_show_data('idsubscription', $subscription, '-', TRUE, TRUE).'&redirect_to='.urlencode(wdk_server_current_url()))); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Select Subscription', 'wdk-membership'); ?></a>
                            <?php else:?>
                                <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($subscription->woocommerce_product_id)); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Buy', 'wdk-membership'); ?></a>
                            <?php endif;?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach;?>
        </div>
        <?php if(wdk_get_option('wdk_membership_is_subscription_required') && !empty($user_have_active) && $listings_limit):?>
        <?php else:?>
            <?php if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && !empty($user_have_active) 
                                                                            && (!empty($user_subscriptions) && (!wmvc_show_data('price', $user_subscriptions[key($user_subscriptions)], false, TRUE, TRUE)
                                                                                                                || wmvc_show_data('price', $user_subscriptions[key($user_subscriptions)], false, TRUE, TRUE) != '0.00'
                                                                                                                )
                                                                                                                )):?>
                <div class="wdk_alert wdk_alert-info mb-20" role="alert">
                    <?php echo esc_html__('If you want to change your membership subscription, please', 'wdk-membership'); ?> 
                    <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                        <?php echo esc_html__('contact us','wdk-membership'); ?>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    <?php else:?>
        <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Results not found', 'wdk-membership');?></p>
    <?php endif;?>

</div>
<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected subscription will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>
<?php $this->view('general/footer', $data); ?>