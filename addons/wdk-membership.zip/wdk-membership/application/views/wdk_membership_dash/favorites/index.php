<?php
/**
 * The template for Favorites Management.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<?php
$translate = esc_html__('profile', 'wdk-membership');
$translate = esc_html__('listing', 'wdk-membership');
$translate = esc_html__('wdk-listing', 'wdk-membership');
$translate = esc_html__('page', 'wdk-membership');
?>

<div class="wdk-front-wrap wdk_membership_dash_favorites_index">
    <h1 class="wdk-h"><?php echo esc_html__('My Favorites', 'wdk-membership'); ?></h1>
    <form method="GET" action="<?php echo esc_url(wdk_dash_url('dash_page=favorites')); ?>" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
        <div class="tablenav top">
            <div class="tablenav-main">
                <div class="actions">
                    <input type="hidden" name="page_id" value="<?php echo esc_attr(get_option('wdk_membership_dash_page'));?>" />
                    <input type="hidden" name="dash_page" value="favorites" />
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?></label>
                        <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-membership'); ?>" />
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="listing_location_id"><?php echo esc_html__('Filter by location', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('listing_location_id', $locations, wmvc_show_data('listing_location_id', $db_data, ''), NULL, __('Location', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="listing_category_id"><?php echo esc_html__('Filter by category', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('listing_category_id', $categories, wmvc_show_data('listing_category_id', $db_data, ''), NULL, __('Category', 'wdk-membership')); ?>
                    </div>
                    <?php if(false):?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="category_id"><?php echo esc_html__('Filter by category', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('category_id', $favorite_categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Category', 'wdk-membership')); ?>
                    </div>
                    <?php endif;?>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="f_post_type"><?php echo esc_html__('Filter by post type', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('f_post_type', $post_types, wmvc_show_data('f_post_type', $db_data, ''), NULL, __('Post Type', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-membership'); ?></label>
                        <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>
                    </div>
                    <div class="wdk-from-group">
                        <button type="submit" name="filter_action" id="post-query-submit" class="wdk-click-load-animatio wdk-btn wdk-btn-primary wdk-btn-slim event-ajax-indicator">
                            <span class="dashicons dashicons-search hidden-onloading"></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <table class="wdk-table responsive">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-membership'); ?></th>
                <th><?php echo esc_html__('Title','wdk-membership'); ?></th>
                <th><?php echo esc_html__('Post type','wdk-membership'); ?></th>
                <?php if(false):?>
                <th><?php echo esc_html__('Category','wdk-membership'); ?></th>
                <?php endif;?>
                <th><?php echo esc_html__('Date','wdk-membership'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-membership'); ?></th>
            </tr>
        </thead>
        <?php if(count($favorites) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="5"><?php echo esc_html__('No Favorites found.','wdk-membership'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $favorites as $favorite ):?>
            <tr>
                <td class="hide-resonsive">
                   <?php echo wmvc_show_data('post_id', $favorite, '-'); ?>
                </td>
                <td data-label="<?php echo esc_html__('Title', 'wdk-membership'); ?>">
                    <a href="<?php echo esc_url(wdk_favorite_item_link($favorite)); ?>"  title="<?php echo esc_attr__('View Listing', 'wdk-membership');?> <?php echo esc_attr(wmvc_show_data('post_title', $favorite, '-')); ?>">
                        <?php echo wdk_favorite_item_name($favorite); ?>
                    </a>
                </td>
                <td data-label="<?php echo esc_html__('Post type', 'wdk-membership'); ?>">
                    <?php echo esc_html__(wmvc_show_data('post_type', $favorite, '-'), 'wdk-membership'); ?>
                </td>
                <?php if(false):?>
                <td data-label="<?php echo esc_html__('Category', 'wdk-membership'); ?>">
                    <?php echo wmvc_show_data('category_title', $favorite, __('Uncategory','wdk-membership')); ?>
                </td>
                <?php endif;?>
                <td data-label="<?php echo esc_html__('Date', 'wdk-membership'); ?>">
                    <?php echo wdk_get_date(wmvc_show_data('date', $favorite, ''), false); ?>
                </td>
                <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                    <?php if(false):?>
                        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites-edit&id=".wmvc_show_data('idfavorite', $favorite, ''); ?>" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                    <?php endif;?>
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $favorite, '-')); ?>" title="<?php echo esc_attr__('View Listing', 'wdk-membership');?> <?php echo esc_attr(wmvc_show_data('post_title', $favorite, '-')); ?>" target="_blank"><span class="dashicons dashicons-visibility"></span></a>
                    <a class="question_sure" href="<?php echo wdk_dash_url("dash_page=favorites&table_action=apply&action=delete&ids=" . wmvc_show_data('idfavorite', $favorite, '-')); ?>"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
    <div class="tablenav bottom">
        <div class="tablenav-sidebar">
            <?php echo wmvc_xss_clean($pagination_output); ?>
        </div>
    </div>
</div>

