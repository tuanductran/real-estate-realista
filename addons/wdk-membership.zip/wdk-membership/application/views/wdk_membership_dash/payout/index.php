<?php
/**
 * The template for Management payout.
 *
 * This is the template that table, search layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wdk-front-wrap wdk_membership_dash_payout_index">
    <h1 class="wdk-h"><?php echo esc_html__('Payouts', 'wdk-membership'); ?> <a href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'function=wdk_export_payout')); ?>" class="button button-primary" id="export_button"><?php echo esc_html__('Export in CSV', 'wdk-membership'); ?></a></h1>

    <?php if(empty($owner->wdk_iban)): ?>
        <div class="wdk_alert wdk_alert-danger mb-20" role="alert">
            <?php echo esc_html__('To receive payouts please populate IBAN and payment instructions in your','wdk-membership');?> <a href="<?php echo esc_url(wdk_dash_url('dash_page=profile'));?>"><?php echo esc_html__('Profile','wdk-membership');?></a>
        </div>
    <?php endif; ?>

    <div class="wdk-row wdk_dash_widgets">
        <div class="wdk-col-12 wdk-col-md-4  wdk-membership-dash-widget_reviews"> 
            <a href="#" class="wdk-membership-dash-widget">
                <span class="wdk-content">
                    <span class="icon"><span class="dashicons dashicons-saved"></span></span>
                </span>
                <span class="wdk-side">
                    <span class="title"><?php echo esc_html__('Total Paid','wdk-membership');?></span>
                    <span class="wdk-count"><?php echo esc_html($total_paid.$currency_code); ?></span>
                </span>
            </a>
        </div>

        <div class="wdk-col-12 wdk-col-md-4  wdk-membership-dash-widget_reviews"> 
            <a href="#" class="wdk-membership-dash-widget">
                <span class="wdk-content">
                    <span class="icon"><span class="dashicons dashicons-money-alt"></span></span>
                </span>
                <span class="wdk-side">
                    <span class="title"><?php echo esc_html__('Ramaining payment','wdk-membership');?></span>
                    <span class="wdk-count"><?php echo esc_html($total_remaining.$currency_code); ?></span>
                </span>
            </a>
        </div>
    </div>

    <table class="wdk-table responsive">
        <thead>
            <tr>
                <th style="width:65px;"><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                <th><?php echo esc_html__('Month', 'wdk-membership'); ?></th>
                <th><?php echo esc_html__('Total net income', 'wdk-membership'); ?></th>
                <th><?php echo esc_html__('Total payout', 'wdk-membership'); ?></th>
                <th><?php echo esc_html__('Fee percentage', 'wdk-membership'); ?></th>
                <th><?php echo esc_html__('Payout date', 'wdk-membership'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($results) == 0) : ?>
                <tr class="no-items">
                    <td class="colspanchange" colspan="7"><?php echo esc_html__('No payout found.', 'wdk-membership'); ?></td>
                </tr>
            <?php endif; ?>
            <?php foreach ($results as $listing) :  ?>
                <tr>
                    <td data-label="<?php echo esc_html__('id', 'wdk-membership'); ?>">
                        <?php echo wmvc_show_data('report_id', $listing, '-'); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Month', 'wdk-membership'); ?>" class="title column-title has-row-actions column-primary">
                        <strong>
                            <?php echo wmvc_show_data('month', $listing, '-'); ?>-<?php echo wmvc_show_data('year', $listing, '-'); ?>
                        </strong>
                    </td>
                    <td data-label="<?php echo esc_html__('Total net income', 'wdk-membership'); ?>">
                        <?php echo wmvc_show_data('total_price_net_sum', $listing, '-'); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Total payout', 'wdk-membership'); ?>">
                    <span class="label label-success"> <?php echo esc_html((100-$listing->fee_percentage)/100*$listing->total_price_net_sum); ?> <?php echo wmvc_show_data('currency_code', $listing, '-'); ?></span>
                    <?php if($listing->is_payout == 1): ?>
                            <span class="label label-info"><?php echo esc_html__('Paid', 'wdk-membership'); ?></span>
                        <?php else: ?>
                            <span class="label label-danger"><?php echo esc_html__('Not paid', 'wdk-membership'); ?></span>
                        <?php endif; ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Fee percentage', 'wdk-membership'); ?>" class="actions_column">
                        <?php echo wmvc_show_data('fee_percentage', $listing, '-'); ?>
                    </td>
                    <td data-label="<?php echo esc_html__('Payout date', 'wdk-membership'); ?>" class="actions_column">
                        <?php echo wmvc_show_data('date_payout', $listing, '-'); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>    
    </table>
    <div class="tablenav bottom">
        <div class="tablenav-sidebar">
            <?php echo wmvc_xss_clean($pagination_output); ?>
        </div>
    </div>

</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

        $('.wdk-table thead .check-column input[type="checkbox"]').on('click', function(e){
            if($(this).prop('checked')){
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', 'checked');
            } else {
                $(".wdk-table tbody .check-column input[type='checkbox']").prop('checked', false);
            }
        })

        $('.wdk-table tbody .check-column input[type="checkbox"]').on('change', function(e){
            if(!$(this).prop('checked')){
                $(this).closest('.wdk-table').find("thead .check-column input[type='checkbox']").prop('checked', false);
            } 
        })
    });
</script>

<?php $this->view('general/footer', $data); ?>

