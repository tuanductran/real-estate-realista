<?php
/**
 * The template for Edit Subscription.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo __('Users Subscriptions','wdk-membership'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo __('Add/Edit User Subscription','wdk-membership'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-membership'));
                    ?>
                <?php if(!empty($listings)):?>
                <table class="wp-list-table widefat fixed striped table-view-list pages wdk-table wdk-table-listings">
                    <thead>
                        <tr>
                            <th style="width:50px;"><?php echo __('#ID', 'wdk-membership'); ?></th>
                            <th><?php echo __('Image', 'wdk-membership'); ?></th>
                            <th><?php echo __('Title', 'wdk-membership'); ?></th>
                            <th class="actions_col"><?php echo __('Actions', 'wdk-membership'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($listings as $key=>$listing): ?>
                        <?php
                            $url = get_permalink($listing);
                        ?>
                        <tr>
                            <td data-label="<?php echo __('#ID', 'wdk-membership'); ?>"><?php echo wdk_field_value('post_id', $listing); ?></td>
                            <td>
                                <a href="<?php echo esc_url($url);?>" target="_blank" title="<?php echo esc_attr(wdk_field_value('post_title', $listing));?>" class="d-block">
                                    <img src="<?php echo esc_url(wdk_image_src($listing, 'full'));?>" alt="<?php echo esc_attr(wdk_show_data('post_title', $listing, '', TRUE, TRUE));?>">
                                </a>
                            </td>
                            <td class="title column-title page-title"  data-label="<?php echo esc_html__('Title','wdk-membership');?>" class="max-width">
                                <strong>
                                    <a class="row-title" href="<?php echo get_admin_url() . "admin.php?page=wdk_listing&id=" . wmvc_show_data('ID', $listing, '-'); ?>"><?php echo wmvc_show_data('post_title', $listing, '-'); ?></a>
                                    <?php if(!wmvc_show_data('is_activated', $listing, 0)): ?>
                                    <span class="label label-danger"><?php echo __('Not activated', 'wdk-membership'); ?></span>
                                    <?php endif; ?>
                                    <?php if(!wmvc_show_data('is_approved', $listing, 0) && function_exists('run_wdk_membership')): ?>
                                    <span class="label label-danger"><?php echo esc_html__('Not approved', 'wdk-membership'); ?></span>
                                    <?php endif; ?>
                                    <?php if(wmvc_show_data('is_featured', $listing, 0)): ?>
                                    <span class="label label-info"><?php echo esc_html__('featured', 'wdk-membership'); ?></span>
                                    <?php endif; ?>
                                </strong>
                            </td>
                            <td data-label="<?php echo esc_html__('Actions','wdk-membership');?>" class="actions_col check-column">
                                <div class="nav">
                                    <a href="<?php echo esc_url($url); ?>" class="" target="_blank"><span class="dashicons dashicons-search"></span></a>

                                    <?php if(!wmvc_user_in_role('administrator')):?>
                                        <?php if(function_exists('wdk_dash_url') && wdk_dash_url('dash_page=listings&function=edit') && current_user_can('edit_own_listings')):?>
                                            <a href="<?php echo esc_url(wdk_dash_url('dash_page=listings&function=edit&id=' . wmvc_show_data('post_id', $listing, '-'))); ?>" class="" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                                        <?php endif;?>
                                    <?php else:?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=wdk_listing&id='.wdk_field_value('post_id', $listing))); ?>" class="" title="<?php echo esc_attr__('Edit','wdk-membership');?>"><span class="dashicons dashicons-edit"></span></a>
                                    <?php endif;?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif;?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?> 

                    <div class="wdk-field-edit TABLE wdk-col- ">
                        <label for="status"><?php echo esc_html__('Subscription', 'wdk-membership'); ?></label>
                        <div class="wdk-field-container">
                        <table class="wp-list-table widefat striped table-view-list pages" style="width: auto;white-space: normal;word-break: normal;">
                            <thead>
                                <tr>
                                    <th><?php echo esc_html__('#ID', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Subscription Name', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Days', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Featured Positions', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Listings', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Auto Approved', 'wdk-membership'); ?></th>
                                    <th><?php echo esc_html__('Price', 'wdk-membership'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($subscriptions as $subscription): ?>
                                <tr>
                                    <td data-label="<?php echo esc_html__('Select', 'wdk-membership'); ?>" class="title column-title column-primary">

                                    <input type="radio" id="subscription_id_<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>" name="subscription_id" 
                                            value="<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>"
                                            <?php if(wmvc_show_data('subscription_id', $db_data, '') == wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)):?>checked="checked" <?php endif;?>
                                        />
                                    </td>
                                    <td data-label="<?php echo esc_html__('Membership Subscription', 'wdk-membership'); ?>" class="title column-title column-primary">
                                        <strong>
                                            <label style="display: inline-block; width: 100%;max-width: 100%;" for="subscription_id_<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>">
                                                <?php echo esc_html(wmvc_show_data('subscription_name', $subscription, '-')); ?>
                                            </label>
                                        </strong>
                                        <?php if(!empty($subscription->date_expire) && $subscription->date_expire < date('Y-m-d H:i:s')):?>
                                            <span class="label label-danger"><?php echo esc_html__('expired', 'wdk-membership'); ?></span>
                                        <?php elseif(!empty($subscription->date_expire)):?>
                                            <span class="label label-success"><?php echo esc_html__('active', 'wdk-membership'); ?></span>
                                        <?php endif;?>
                                    </td>
                                    <td data-label="<?php echo esc_html__('Days', 'wdk-membership'); ?>">
                                        <?php echo esc_html(wmvc_show_data('days_limit', $subscription, '-')); ?>
                                    </td>
                                    <td data-label="<?php echo esc_html__('Featured Positions', 'wdk-membership'); ?>">
                                        <?php if(wmvc_show_data('is_auto_featured', $subscription, 0)): ?>
                                        <span class="label label-info"><span class="dashicons dashicons-saved"></span></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo esc_html__('Listings', 'wdk-membership'); ?>">
                                        <?php echo wmvc_show_data('listings_counter', $subscription, 0); ?> / 

                                        <?php if(wdk_show_data('listings_limit',$subscription, '', TRUE, TRUE) == '-1'): ?>
                                            <?php echo esc_html__('Unlimited', 'wdk-membership'); ?>
                                        <?php else: ?>
                                            <?php echo wmvc_show_data('listings_limit', $subscription, '-'); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo esc_html__('Auto Approved', 'wdk-membership'); ?>">
                                        <?php if(wmvc_show_data('is_auto_approved', $subscription, 0)): ?>
                                        <span class="label label-info"><span class="dashicons dashicons-saved"></span></span>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo esc_html__('Price', 'wdk-membership'); ?>">
                                        <?php echo esc_html(wmvc_show_data('price', $subscription, '-')); ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-membership'); ?>">
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>

<script>
    jQuery(document).on('ready', function() {
        jQuery('.wdk-field-edit.idsubscription-field').remove();
    })
</script>