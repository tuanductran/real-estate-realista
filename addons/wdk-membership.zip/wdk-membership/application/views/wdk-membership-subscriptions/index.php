<?php
/**
 * The template for Membership Subscriptions.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo __('Membership Subscriptions', 'wdk-membership'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscription-add"; ?>" class="button button-primary" id="add_subscription_button"><?php echo __('Add Subscription', 'wdk-membership'); ?></a></h1>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-membership-subscriptions" />

                <label class="screen-reader-text" for="location_id"><?php echo __('Filter by location', 'wdk-membership'); ?></label>
                <?php echo wmvc_select_option('location_id', $locations, wmvc_show_data('location_id', $db_data, ''), NULL, __('Location', 'wdk-membership')); ?>

                <label class="screen-reader-text" for="category_id"><?php echo __('Filter by category', 'wdk-membership'); ?></label>
                <?php echo wmvc_select_option('category_id', $categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Category', 'wdk-membership')); ?>

                <label class="screen-reader-text" for="search"><?php echo __('Filter by keyword', 'wdk-membership'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo __('Filter by keyword', 'wdk-membership'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo __('Order By', 'wdk-membership'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-membership')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo __('Filter', 'wdk-membership'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo __('Select All', 'wdk-membership'); ?></label><input id="cb-select-all-1" type="checkbox"></td>
                    <th style="width:50px;"><?php echo __('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo __('Subscription Name', 'wdk-membership'); ?></th>
                    <th><?php echo __('Category', 'wdk-membership'); ?></th>
                    <th><?php echo __('Location', 'wdk-membership'); ?></th>
                    <th><?php echo __('Listings Limit', 'wdk-membership'); ?></th>
                    <th><?php echo __('Days Limit', 'wdk-membership'); ?></th>
                    <th><?php echo __('Price', 'wdk-membership'); ?></th>
                    <th><?php echo __('Product', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo __('Actions', 'wdk-membership'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($subscriptions) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="10"><?php echo __('No Subscriptions found.', 'wdk-membership'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($subscriptions as $subscription) : ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input id="cb-select-<?php echo wmvc_show_data('idsubscription', $subscription, '-'); ?>" type="checkbox" name="post[]" value="<?php echo wmvc_show_data('idsubscription', $subscription, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo __('Is Locked', 'wdk-membership'); ?></span>
                            </div>
                        </th>
                        <td>
                            <?php echo wmvc_show_data('idsubscription', $subscription, '-'); ?>
                        </td>
                            <td class="title column-title has-row-actions column-primary page-title" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscription-add&id=" . wmvc_show_data('idsubscription', $subscription, '-'); ?>"><?php echo wmvc_show_data('subscription_name', $subscription, '-'); ?></a>
                                <?php if(wmvc_show_data('is_auto_approved', $subscription, 0)): ?>
                                <span class="label label-info"><?php echo __('Activate', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                                <?php if(wmvc_show_data('is_auto_featured', $subscription, 0)): ?>
                                <span class="label label-danger"><?php echo __('Featured', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                                <?php if(!empty($subscription->date_to) && strtotime($subscription->date_to) < time()): ?>
                                <span class="label label-danger"><?php echo __('date to expired', 'wdk-membership'); ?></span>
                                <?php endif; ?>
                            </strong>
                            <div class="row-actions">
                                <span class="edit"><a href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscription-add&id=" . wmvc_show_data('idsubscription', $subscription, '-'); ?>"><?php echo __('Edit', 'wdk-membership'); ?></a> | </span>
                                <span class="trash "><a href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscriptions&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idsubscription', $subscription, '-'); ?>" class="submitdelete question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>" ><?php echo __('Delete', 'wdk-membership'); ?></a></span>
                            </div>
                        </td>

                        <td>
                            <?php echo wmvc_show_data($subscription->category_id, $categories, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data($subscription->location_id, $locations, '-'); ?>
                        </td>
                        <td>
                            <?php if(wdk_show_data('listings_limit',$subscription, '', TRUE, TRUE) == '-1'): ?>
                                <?php echo esc_html__('Unlimited', 'wdk-membership'); ?>
                            <?php else: ?>
                                <?php echo wmvc_show_data('listings_limit', $subscription, '-'); ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('days_limit', $subscription, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('price', $subscription, '-'); ?>
                        </td>
                        <td>
                            <?php if(wmvc_show_data('woocommerce_product_id', $subscription, false)):?>
                                <a target="_blank" href="<?php echo admin_url('post.php?post='.wmvc_show_data('woocommerce_product_id', $subscription, '-').'&action=edit');?>">
                                    #<?php echo wmvc_show_data('woocommerce_product_id', $subscription, '-'); ?>.
                                    <?php echo esc_html(get_the_title(wmvc_show_data('woocommerce_product_id', $subscription, '-')));?>
                                </a>
                            <?php else:?>
                                <span class="label label-danger"><?php echo __('not defined', 'wdk-membership'); ?></span>
                            <?php endif;?>
                        </td>
                        <td class="actions_column">
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscription-add&id=" . wmvc_show_data('idsubscription', $subscription, '-'); ?>"><span class="dashicons dashicons-edit"></span></a>
                            <a class="question_sure" title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscriptions&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idsubscription', $subscription, '-'); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <td class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2"><?php echo __('Select All', 'wdk-membership'); ?></label><input id="cb-select-all-2" type="checkbox"></td>
                    <th style="width:50px;"><?php echo __('#ID', 'wdk-membership'); ?></th>
                    <th><?php echo __('Subscription Name', 'wdk-membership'); ?></th>
                    <th><?php echo __('Category', 'wdk-membership'); ?></th>
                    <th><?php echo __('Location', 'wdk-membership'); ?></th>
                    <th><?php echo __('Listings Limit', 'wdk-membership'); ?></th>
                    <th><?php echo __('Days Limit', 'wdk-membership'); ?></th>
                    <th><?php echo __('Price', 'wdk-membership'); ?></th>
                    <th><?php echo __('Product', 'wdk-membership'); ?></th>
                    <th class="actions_column"><?php echo __('Actions', 'wdk-membership'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <div class="alignleft actions bulkactions">
                <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo __('Select bulk action', 'wdk-membership'); ?></label>
                <select name="action" id="bulk-action-selector-bottom">
                    <option value="-1"><?php echo __('Bulk actions', 'wdk-membership'); ?></option>
                    <option value="delete" class="hide-if-no-js"><?php echo __('Delete', 'wdk-membership'); ?></option>
                    <option value="deactivate" class="hide-if-no-js"><?php echo __('Deactivate', 'wdk-membership'); ?></option>
                    <option value="activate" class="hide-if-no-js"><?php echo __('Activate', 'wdk-membership'); ?></option>
                </select>
                <input type="hidden" name="page" value="wdk-membership-subscriptions" />
                <input type="submit" id="table_action" class="button action" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-membership'); ?>">
            </div>

            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-membership')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>