<?php
/**
 * The template for Edit Listings.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_listings_edit">
    <h1 class="wdk-h"><?php echo esc_html__('Submit Listing', 'wdk-membership'); ?></h1>

    <?php do_action('wdk-membership/view/quicksubmission_listing/above_form', wmvc_show_data('ID', $db_data, ''));?>

    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(get_permalink(wdk_get_option('wdk_membership_quicksumbission_page'))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="form_listing wdk-from-table">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                        <h3>
                            <?php echo esc_html__('Main Data ', 'wdk-membership'); ?>
                        </h3>
                        <?php if(!empty(wmvc_show_data('ID', $db_data))):?>
                            <a href="<?php echo esc_url(get_permalink(wmvc_show_data('ID', $db_data))); ?>" class="button button-secondary alignright" target="_blank"  title="<?php echo esc_attr__('View Listing', 'wdk-membership');?>" style="margin-right:15px;"><span class="dashicons dashicons-visibility" style="margin-top: 4px;"></span> <?php echo esc_html__('View listing', 'wdk-membership'); ?></a>
                        <?php endif;?>
                    </div>
                <div class="inside full-width">
                    <?php
                        $success_message = __('Listing Submitted', 'wdk-membership');
                        if(isset($_GET['custom_message']))
                            $success_message = esc_html(urldecode($_GET['custom_message']));

                        $form->messages('class="alert alert-danger"', $success_message);
                    ?>

                    <div class="wdk-row">
                        <div class="wdk-col-8 wdk-col-xs-12 order-xs-2">
                            <?php if(!is_user_logged_in()):?>
                            <div class="wdk-from-group">
                                <label class="" for="user_name"><?php echo esc_html__('Your Name', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                    <input name="user_name" type="text" id="user_name" value="<?php echo wmvc_show_data('user_name', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Your Name', 'wdk-membership');?>" class="regular-text">
                                </div>
                            </div>
                            <div class="wdk-from-group">
                                <label class="" for="user_email"><?php echo esc_html__('You Email', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                    <input name="user_email" type="text" id="user_email" value="<?php echo wmvc_show_data('user_email', $db_data, ''); ?>" placeholder="<?php echo esc_html__('You email', 'wdk-membership');?>" class="regular-text">
                                </div>
                            </div>
                            <?php endif;?>
                            <div class="wdk-from-group">
                                <label class="" for="post_title"><?php echo esc_html__('Title', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                    <input name="post_title" type="text" id="post_title" value="<?php echo wmvc_show_data('post_title', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Title', 'wdk-membership');?>" class="regular-text">
                                </div>
                            </div>

                            <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
                            <div class="wdk-from-group">
                                <label class="" for="input_address"><?php echo esc_html__('Address', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                    <input name="address" type="text" id="input_address" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-membership');?>" class="regular-text">
                                    <p class="description" id="input_address-description"><?php echo esc_html__('After you enter address system will try to autodetect and pin location on map, then you can drag and drop pin on map to fine tune location','wdk-membership'); ?></p>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(get_option('wdk_is_category_enabled', FALSE)): ?>
                                <?php if(wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown'):?>
                                    <div class="wdk-from-group">
                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_category_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                            <?php
                                            global $Winter_MVC_WDK;
                                            $Winter_MVC_WDK->load_helper('listing');
                                            $Winter_MVC_WDK->model('category_m');
                                            $field_value =  wmvc_show_data('category_id', $db_data, '');
                                            $field_key = 'category_id';
                                            
                                            $categories = array();
                                            if(!empty($field_value)) {
                                                $categories[] = $field_value;
                                                $category = $Winter_MVC_WDK->category_m->get($field_value, TRUE); 

                                                while(!empty($category->parent_id)) {
                                                    $category = $Winter_MVC_WDK->category_m->get($category->parent_id, TRUE); 
                                                    $categories[] = $category->idcategory;
                                                }
                                                krsort($categories);
                                            } else {
                                                $categories[] = 0;
                                            }

                                            wp_enqueue_style('wdk-treefield-dropdown');
                                            wp_enqueue_script('wdk-treefield-dropdown');
                                            wp_enqueue_style( 'dashicons' );


                                            $level_max = $Winter_MVC_WDK->category_m->get_max_level();

                                            $placeholder = [
                                                0 => esc_html__('Select Categories','wpdirectorykit'),
                                                1 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                2 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                3 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                4 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                                5 => esc_html__('Select Sub Categories','wpdirectorykit'),
                                            ];
                                            ?>

                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                            <?php
                                            $level = 0;
                                            $current = NULL;
                                            foreach ($categories as $category) {
                                                $current = $Winter_MVC_WDK->category_m->get($category, TRUE); 

                                                $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = '.$current->parent_id => NULL)); 

                                                if(isset($placeholder[$level])) {
                                                    $values_list = array(''=> $placeholder[$level]);

                                                    } else {
                                                    $values_list = array(''=> esc_html__('Select Sub Categories','wpdirectorykit'));
                                                }

                                                foreach ($list as $list_value) {
                                                    $values_list[$list_value->idcategory] = $list_value->category_title; 
                                                }
                                                ?>

                                                <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                    <div class="wdk-field-group">
                                                        <?php echo wmvc_select_option('category_'.$level, $values_list, $category, 'class="wdk-control"');?>
                                                    </div>
                                                </div>

                                                <?php
                                                $level++;
                                            }
                                                    
                                            if($level<$level_max ) {
                                                for (; $level<$level_max;) {
                                                
                                                    if(isset($placeholder[$level])) {
                                                        $values_list = array(''=> $placeholder[$level]);
                                                    } else {
                                                        $values_list = array(''=> esc_html__('Select Sub Categories','wpdirectorykit'));
                                                    }
                                                    if($category) {
                                                        $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = '.$category => NULL)); 
                                                        foreach ($list as $list_value) {
                                                            $values_list[$list_value->idcategory] = $list_value->category_title; 
                                                        }
                                                        $category = NULL;
                                                    }

                                                    ?>
                                                    <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                        <div class="wdk-field-group">
                                                            <?php echo wmvc_select_option('category_'.$level, $values_list, NULL, 'class="wdk-control"');?>
                                                        </div>
                                                    </div>

                                                    <?php
                                                    $level++;
                                                }
                                            }
                                            ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="wdk-from-group">
                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_category_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control">
                                            <?php
                                                echo wmvc_select_option('category_id', $categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Not Selected', 'wdk-membership'));
                                            ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                           
                            <?php if(get_option('wdk_is_category_enabled', FALSE) && get_option('wdk_multi_categories_other_enable', FALSE)): ?>
                            <div class="wdk-from-group">
                                <label class="" for="listing_categories"><?php echo esc_html__('More Categories', 'wdk-membership'); ?></label>
                                <div class="wdk-from-group-control">
                                <?php echo wdk_treefield_select_ajax ('listing_sub_categories[]', 'category_m', wmvc_show_data('listing_sub_categories', $db_data, '', FALSE, TRUE), 'category_title', 'idcategory', '', __('All Categories', 'wdk-membership'), '', 'data-limit="10"');?>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php if(get_option('wdk_is_location_enabled', FALSE)): ?>
                                <?php if(wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown'):?>
                                    <div class="wdk-from-group">
                                        <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_location_required')):?>*<?php endif;?></label>
                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                            <?php
                                            global $Winter_MVC_WDK;
                                            $Winter_MVC_WDK->load_helper('listing');
                                            $Winter_MVC_WDK->model('location_m');
                                            $field_value =  wmvc_show_data('location_id', $db_data, '');
                                            $field_key = 'location_id';

                                            $locations = array();
                                            if(!empty($field_value)) {
                                                $locations[] = $field_value;
                                                $location = $Winter_MVC_WDK->location_m->get($field_value, TRUE); 
                                                
                                                while(!empty($location->parent_id)) {
                                                    $location = $Winter_MVC_WDK->location_m->get($location->parent_id, TRUE); 
                                                    $locations[] = $location->idlocation;
                                                }
                                                krsort($locations);
                                            } else {
                                                $locations[] = 0;
                                            }
                                    
                                            wp_enqueue_style('wdk-treefield-dropdown');
                                            wp_enqueue_script('wdk-treefield-dropdown');
                                            wp_enqueue_style( 'dashicons' );
                                    
                                            $level_max = $Winter_MVC_WDK->location_m->get_max_level();
                                            
                                            $placeholder = [
                                                0 => esc_html__('Select Country','wpdirectorykit'),
                                                1 => esc_html__('Select City','wpdirectorykit'),
                                                2 => esc_html__('Select Neighborhood','wpdirectorykit'),
                                                3 => esc_html__('Select Sub Area','wpdirectorykit'),
                                                4 => esc_html__('Select Sub Area','wpdirectorykit'),
                                                5 => esc_html__('Select Sub Area','wpdirectorykit'),
                                            ];
                                            ?>

                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                            <?php
                                                $level = 0;
                                                $current = NULL;
                                                foreach ($locations as $location) {
                                                    $current = $Winter_MVC_WDK->location_m->get($location, TRUE); 

                                                    $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = '.$current->parent_id => NULL)); 

                                                
                                                    if(isset($placeholder[$level])) {
                                                        $values_list = array(''=> $placeholder[$level]);
                                                    } else {
                                                        $values_list = array(''=> esc_html__('Select Sub Area','wpdirectorykit'));
                                                    }

                                                    foreach ($list as $list_value) {
                                                        $values_list[$list_value->idlocation] = $list_value->location_title; 
                                                    }


                                                    ?>

                                                    <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                        <div class="wdk-field-group">
                                                            <?php echo wmvc_select_option('location_'.$level, $values_list, $location, 'class="wdk-control"');?>
                                                        </div>
                                                    </div>

                                                    <?php
                                                    $level++;
                                                }
                                                
                                                if($level<$level_max ) {
                                                    for (; $level<$level_max;) {

                                                        if(isset($placeholder[$level])) {
                                                            $values_list = array(''=> $placeholder[$level]);
                                                        } else {
                                                            $values_list = array(''=> esc_html__('Select Sub Area','wpdirectorykit'));
                                                        }
                                                            
                                                        if($location) {
                                                            $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = '.$location => NULL)); 
                                                            foreach ($list as $list_value) {
                                                                $values_list[$list_value->idlocation] = $list_value->location_title; 
                                                            }
                                                            $location = NULL;
                                                        }

                                                        ?>
                                                        <div data-level="<?php echo esc_attr($level);?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                            <div class="wdk-field-group">
                                                                <?php echo wmvc_select_option('location_'.$level, $values_list, NULL, 'class="wdk-control"');?>
                                                            </div>
                                                        </div>
                                            
                                                        <?php
                                                        $level++;
                                                    }
                                                }
                                            ?>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                        <div class="wdk-from-group">
                                            <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if(wdk_get_option('wdk_listing_location_required')):?>*<?php endif;?></label>
                                            <div class="wdk-from-group-control">
                                                <?php
                                                    echo wmvc_select_option('location_id', $locations, wmvc_show_data('location_id', $db_data, ''), NULL, __('Not Selected', 'wdk-membership'));
                                                ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                            <?php endif; ?>

                            <?php if(get_option('wdk_is_location_enabled', FALSE) && get_option('wdk_multi_locations_other_enable', FALSE)): ?>
                                <div class="wdk-from-group">
                                    <label class="" for="location_id"><?php echo esc_html__('More Locations', 'wdk-membership'); ?></label>
                                    <div class="wdk-from-group-control">
                                    <?php echo wdk_treefield_select_ajax ('listing_sub_locations[]', 'location_m', wmvc_show_data('listing_sub_locations', $db_data, '', TRUE, TRUE), 'location_title', 'idlocation', '', __('All Locations', 'wdk-membership'), '', 'data-limit="10"');?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="wdk-col-4 wdk-col-xs-12 order-xs-1">
                            <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
                                <div id="map" class="listing_edit_map"></div>
                                <br/>
                                <p class="alert alert-info"><?php echo esc_html__('Drag and drop pin to desired location','wdk-membership');?></p>
                                <div class="wdk-field-edit inline">
                                    <label for="listing_gps"><?php echo esc_html__('GPS','wdk-membership');?>:</label>
                                    <div class="wdk-field-container">
                                        <input name="lat" readonly="readonly" type="text" id="input_lat" value="<?php echo wmvc_show_data('lat', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lat', 'wdk-membership');?>">
                                        <input name="lng" readonly="readonly" type="text" id="input_lng" value="<?php echo wmvc_show_data('lng', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lng', 'wdk-membership');?>">
                                    </div>
                                </div>
                            <?php endif;?>
                        </div>
                    </div>
                    <?php if(wdk_get_option('wdk_is_post_content_enable', FALSE)): ?>
                    <div class="wdk-row">
                        <div class="wdk-col-12">
                            <div class="wdk-from-group">
                                <label class="" for="post_content"><?php echo esc_html__('Content', 'wdk-membership'); ?>*</label>
                                <div class="wdk-from-group-control">
                                <?php wp_editor(wmvc_show_data('post_content', $db_data, ''), 'post_content', array('media_buttons' => FALSE)); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="wdk-row full-width wdk_generate_fields">
                        <?php if(count($fields) == 0): ?>
                            <div class="wdk-col-12">
                                <div class="alert alert-success mb0"><p><?php echo esc_html__('Fields doesn\'t exists','wdk-membership'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk_fields"; ?>" class="button button-primary" id="add_field_button"><?php echo esc_html__('Manage Fields','wdk-membership'); ?></a></p></div>
                            </div>
                        <?php endif; ?>
                        <?php echo wdk_generate_fields($fields, $db_data); ?>  
                    </div>
                </div>
            </div>

            <?php if(!wdk_get_option('wdk_listing_plangs_documents_disable')):?>
                <div class="postbox" style="display: block;">
                    <div class="postbox-header">
                        <h3><?php echo __('Listing plans and documents', 'wdk-membership'); ?></h3>
                    </div>
                    <div class="inside">
                        <p class="alert alert-info"><?php echo __('Drag and drop image to change order', 'wdk-membership'); ?></p>
                        <?php  
                            echo wdk_upload_multi_files('listing_plans_documents', wmvc_show_data('listing_plans_documents', $db_data, '')); 
                        ?>               
                    </div>
                </div>
            <?php endif;?>
            <?php if(!wdk_get_option('wdk_listing_images_disable')):?>
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('Listing Images', 'wdk-membership'); ?></h3>
                </div>
                <div class="inside">
                    <p class="alert alert-info"><?php echo esc_html__('Drag and drop image to change order', 'wdk-membership'); ?></p>
                    <?php  
                        echo wmvc_upload_multiple('listing_images', wmvc_show_data('listing_images', $db_data, '')); 
                    ?>               
                </div>
            </div>
            <?php endif;?>
            <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes','wdk-membership'); ?></button>
        </form>
    </div>

    <?php do_action('wdk-membership/view/quicksubmission_listing/after_form', wmvc_show_data('ID', $db_data, ''));?>
</div>


<?php
    wp_enqueue_style('winter_mvc', plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/css/winter_mvc.css'));
    wp_enqueue_script( 'wpmediaelement',  plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/js/jquery.wpmediaelement.js'), false, false, false );
    wp_enqueue_script( 'wpmediamultiple',  plugins_url(plugin_basename(WINTER_MVC_PATH).'/assets/js/jquery.wpmediamultiple.js'), false, false, false );
    $params = array(
        'text' =>array(
            'frame_title' => esc_html__('Select or Upload Media Of Your Chosen Persuasion', 'wdk-membership'),
            'frame_button' => esc_html__('Use this media', 'wdk-membership'),
        ),
    );
    wp_localize_script('wpmediamultiple', 'wpmediamultiple_parameters', $params);
    wp_localize_script('wpmediaelement', 'wpmediaelement_parameters', $params);
    
    wp_enqueue_style('leaflet');
    wp_enqueue_script('leaflet');
            
    wp_enqueue_style('wdk-notify');
    wp_enqueue_script('wdk-notify');
?>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        <?php if(get_option('wdk_is_address_enabled', FALSE)): ?>
            var wdk_edit_map_marker,wdk_timerMap,wdk_edit_map;
            wdk_edit_map = L.map('map', {
                center: [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>],
                zoom: 4,
            });   

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(wdk_edit_map);

            wdk_edit_map_marker = L.marker(
                [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>],
                {draggable: true}
            ).addTo(wdk_edit_map);

            wdk_edit_map_marker.on('dragend', function(event){
                clearTimeout(wdk_timerMap);
                var marker = event.target;
                var {lat,lng} = marker.getLatLng();
                $('#input_lat').val(lat);
                $('#input_lng').val(lng);
                //retrieved the position
            });

            $('#input_address').on('change keyup', function (e) {
                clearTimeout(wdk_timerMap);
                wdk_timerMap = setTimeout(function () {
                    $.get('https://nominatim.openstreetmap.org/search?format=json&q='+$('#input_address').val(), function(data){
                        if(data.length && typeof data[0]) {
                            var {lat,lon} =data[0];
                            wdk_edit_map_marker.setLatLng([lat, lon]).update(); 
                            wdk_edit_map.panTo(new L.LatLng(lat, lon));
                            $('#input_lat').val(lat);
                            $('#input_lng').val(lon);
                        } else {
                            wdk_log_notify('<?php echo esc_js(__('Address not found', 'wdk-membership')); ?>', 'error');
                            return;
                        }
                    });
                }, 1000);
            });

            $('#input_gps').on('change keyup', function (e) {
                wdk_edit_map.panTo(new L.LatLng($('#input_lat').val(), $('#input_lng').val()));
                wdk_edit_map_marker.setLatLng([parseFloat($('#input_lat').val()), parseFloat($('#input_lng').val())]).update(); 
            })
        <?php endif;?>

    });
</script>

<?php $this->view('general/footer', $data); ?>

