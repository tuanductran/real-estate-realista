<?php

/**
 * The template for Edit Listings.
 *
 * This is the template that edit form
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_listings_edit">
    <div class="wdkmembership-content">
        <div class="alert alert-success">
            <?php if (!is_user_logged_in()) : ?>
                <?php echo esc_html__('Thank you very much on submission, we will create account for you, and send instructions to your email.', 'wdk-membership');?>
            <?php else: ?>
                <?php echo esc_html__('Thank you very much on submission', 'wdk-membership');?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
wp_enqueue_style('wdk-notify');
wp_enqueue_script('wdk-notify');
?>



<?php $this->view('general/footer', $data); ?>