<?php

/**
 * The template for Edit Listings.
 *
 * This is the template that edit form
 *
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>
<div class="wdk-front-wrap wdk_membership_dash_listings_edit">

    <?php do_action('wdk-membership/view/quicksubmission_listing/above_form', wmvc_show_data('ID', $db_data, '')); ?>

    <div class="wdkmembership-content">
        <form method="post" action="<?php echo esc_url(get_permalink(wdk_get_option('wdk_membership_quicksumbission_page'))); ?>" enctype="multipart/form-data" novalidate="novalidate" class="form_listing wdk-from-table">
            <?php
            $success_message = __('Listing Submitted', 'wdk-membership');
            if (isset($_GET['custom_message']))
                $success_message = esc_html(urldecode($_GET['custom_message']));

            $form->messages('class="alert alert-danger"', $success_message);
            ?>

            <div class="wdk-tabs-wrapper wdk-tabs-wrapper-submit-listing">
                <div class="wdk-tabs-navs">
                    <label for="wdk_tab_basicinfo" class="active <?php if (!is_user_logged_in()) : ?>validation_tab<?php endif; ?>">1. <?php echo esc_html__('Main data', 'wpdirectorykit'); ?></label>
                    <label for="wdk_tab_fields" class="">2. <?php echo esc_html__('Details', 'wpdirectorykit'); ?></label>
                    <label for="wdk_tab_images" class="<?php if (!is_user_logged_in()) : ?>disable_active<?php endif; ?>">3. <?php echo esc_html__('Images', 'wpdirectorykit'); ?></label>
                </div>
                <div class="wdk-tabs-panel">
                    <input type="radio" class="wdk-tab-input" name="wdk_tabs" id="wdk_tab_basicinfo" checked value="1">
                    <div class="wdk-tab">
                        <div class="postbox" style="display: block;">
                            <div class="inside full-width">
                                <div class="alert_box"></div>
                                <div class="wdk-row">
                                    <?php if (wmvc_show_data('step_1', $settings, false)) : ?>
                                        <div class="wdk-col-md-7">
                                        <?php endif; ?>

                                        <div class="<?php if (!wmvc_show_data('step_1', $settings, false)) : ?>wdk-col-8 wdk-col-xs-12 order-xs-2<?php endif; ?>">
                                            <?php if (!is_user_logged_in()) : ?>
                                                <div class="wdk-from-group">
                                                    <label class="" for="user_name"><?php echo esc_html__('Your Name', 'wdk-membership'); ?>*</label>
                                                    <div class="wdk-from-group-control">
                                                        <input name="user_name" type="text" id="user_name" value="<?php echo wmvc_show_data('user_name', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Your Name', 'wdk-membership'); ?>" class="regular-text">
                                                    </div>
                                                </div>
                                                <div class="wdk-from-group">
                                                    <label class="" for="user_email"><?php echo esc_html__('You Email', 'wdk-membership'); ?>*</label>
                                                    <div class="wdk-from-group-control">
                                                        <input name="user_email" type="email" id="user_email" value="<?php echo wmvc_show_data('user_email', $db_data, ''); ?>" placeholder="<?php echo esc_html__('You email', 'wdk-membership'); ?>" class="regular-text">
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <div class="wdk-from-group">
                                                <label class="" for="post_title"><?php echo esc_html__('Title', 'wdk-membership'); ?>*</label>
                                                <div class="wdk-from-group-control">
                                                    <input name="post_title" type="text" id="post_title" value="<?php echo wmvc_show_data('post_title', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Title', 'wdk-membership'); ?>" class="regular-text">
                                                </div>
                                            </div>

                                            <?php if (get_option('wdk_is_address_enabled', FALSE)) : ?>
                                                <div class="wdk-from-group">
                                                    <label class="" for="input_address"><?php echo esc_html__('Address', 'wdk-membership'); ?></label>
                                                    <div class="wdk-from-group-control">
                                                        <input name="address" type="text" id="input_address" value="<?php echo wmvc_show_data('address', $db_data, ''); ?>" placeholder="<?php echo esc_html__('Address', 'wdk-membership'); ?>" class="regular-text">
                                                        <p class="description" id="input_address-description"><?php echo esc_html__('After you enter address system will try to autodetect and pin location on map, then you can drag and drop pin on map to fine tune location', 'wdk-membership'); ?></p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_option('wdk_is_category_enabled', FALSE)) : ?>
                                                <?php if (wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown') : ?>
                                                    <div class="wdk-from-group">
                                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if (wdk_get_option('wdk_listing_category_required')) : ?>*<?php endif; ?></label>
                                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                                            <?php
                                                            global $Winter_MVC_WDK;
                                                            $Winter_MVC_WDK->load_helper('listing');
                                                            $Winter_MVC_WDK->model('category_m');
                                                            $field_value =  wmvc_show_data('category_id', $db_data, '');
                                                            $field_key = 'category_id';

                                                            $categories = array();
                                                            if (!empty($field_value)) {
                                                                $categories[] = $field_value;
                                                                $category = $Winter_MVC_WDK->category_m->get($field_value, TRUE);

                                                                while (!empty($category->parent_id)) {
                                                                    $category = $Winter_MVC_WDK->category_m->get($category->parent_id, TRUE);
                                                                    $categories[] = $category->idcategory;
                                                                }
                                                                krsort($categories);
                                                            } else {
                                                                $categories[] = 0;
                                                            }

                                                            wp_enqueue_style('wdk-treefield-dropdown');
                                                            wp_enqueue_script('wdk-treefield-dropdown');
                                                            wp_enqueue_style('dashicons');


                                                            $level_max = $Winter_MVC_WDK->category_m->get_max_level();

                                                            $placeholder = [
                                                                0 => esc_html__('Select Categories', 'wpdirectorykit'),
                                                                1 => esc_html__('Select Sub Categories', 'wpdirectorykit'),
                                                                2 => esc_html__('Select Sub Categories', 'wpdirectorykit'),
                                                                3 => esc_html__('Select Sub Categories', 'wpdirectorykit'),
                                                                4 => esc_html__('Select Sub Categories', 'wpdirectorykit'),
                                                                5 => esc_html__('Select Sub Categories', 'wpdirectorykit'),
                                                            ];
                                                            ?>

                                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                                            <?php
                                                            $level = 0;
                                                            $current = NULL;
                                                            foreach ($categories as $category) {
                                                                $current = $Winter_MVC_WDK->category_m->get($category, TRUE);

                                                                $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = ' . $current->parent_id => NULL));

                                                                if (isset($placeholder[$level])) {
                                                                    $values_list = array('' => $placeholder[$level]);
                                                                } else {
                                                                    $values_list = array('' => esc_html__('Select Sub Categories', 'wpdirectorykit'));
                                                                }

                                                                foreach ($list as $list_value) {
                                                                    $values_list[$list_value->idcategory] = $list_value->category_title;
                                                                }
                                                            ?>

                                                                <div data-level="<?php echo esc_attr($level); ?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                                    <div class="wdk-field-group">
                                                                        <?php echo wmvc_select_option('category_' . $level, $values_list, $category, 'class="wdk-control"'); ?>
                                                                    </div>
                                                                </div>

                                                                <?php
                                                                $level++;
                                                            }

                                                            if ($level < $level_max) {
                                                                for (; $level < $level_max;) {

                                                                    if (isset($placeholder[$level])) {
                                                                        $values_list = array('' => $placeholder[$level]);
                                                                    } else {
                                                                        $values_list = array('' => esc_html__('Select Sub Categories', 'wpdirectorykit'));
                                                                    }
                                                                    if ($category) {
                                                                        $list = $Winter_MVC_WDK->category_m->get_by(array('parent_id = ' . $category => NULL));
                                                                        foreach ($list as $list_value) {
                                                                            $values_list[$list_value->idcategory] = $list_value->category_title;
                                                                        }
                                                                        $category = NULL;
                                                                    }

                                                                ?>
                                                                    <div data-level="<?php echo esc_attr($level); ?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                                        <div class="wdk-field-group">
                                                                            <?php echo wmvc_select_option('category_' . $level, $values_list, NULL, 'class="wdk-control"'); ?>
                                                                        </div>
                                                                    </div>

                                                            <?php
                                                                    $level++;
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                <?php else : ?>
                                                    <div class="wdk-from-group">
                                                        <label class="" for="category_id"><?php echo esc_html__('Category', 'wdk-membership'); ?><?php if (wdk_get_option('wdk_listing_category_required')) : ?>*<?php endif; ?></label>
                                                        <div class="wdk-from-group-control">
                                                            <?php
                                                                if(!empty($settings['custom_category_root'])) {
                                                                    $custom_field_value = substr($settings['custom_category_root'], strpos($settings['custom_category_root'],'__')+2);
                                                                    $custom_field_value = intval($custom_field_value);
                                                                    global $Winter_MVC_WDK;
                                                                    $Winter_MVC_WDK->load_helper('listing');
                                                                    $Winter_MVC_WDK->model('category_m');
                                                                    $category = $Winter_MVC_WDK->category_m->get($custom_field_value, TRUE); 

                                                                    /* if root search childs */
                                                                    if(empty(wmvc_show_data('parent_id', $category, false, TRUE, TRUE))) {
                                                                        $filter_ids = wdk_category_get_all_childs($custom_field_value); 

                                                                       // $filter_ids[] = $custom_field_value;
                                                                    }
                                                                }    
                                                            ?>
                                                            <?php echo wdk_treefield_option ('category_id', 'category_m',  wmvc_show_data('category_id', $db_data, ''), 'category_title', '', __('Not Selected', 'wdk-membership'), $filter_ids);?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if (get_option('wdk_is_category_enabled', FALSE) && get_option('wdk_multi_categories_other_enable', FALSE)) : ?>
                                                <div class="wdk-from-group">
                                                    <label class="" for="listing_categories"><?php echo esc_html__('More Categories', 'wdk-membership'); ?></label>
                                                    <div class="wdk-from-group-control">
                                                        <?php echo wdk_treefield_select_ajax('listing_sub_categories[]', 'category_m', wmvc_show_data('listing_sub_categories', $db_data, '', FALSE, TRUE), 'category_title', 'idcategory', '', __('All Categories', 'wdk-membership'), '', 'data-limit="10"'); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (get_option('wdk_is_location_enabled', FALSE)) : ?>
                                                <?php if (wdk_get_option('wdk_multi_categories_edit_field_type') == 'wdk_treefield_dropdown') : ?>
                                                    <div class="wdk-from-group">
                                                        <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if (wdk_get_option('wdk_listing_location_required')) : ?>*<?php endif; ?></label>
                                                        <div class="wdk-from-group-control wdk_multi_treefield_dropdown_container">
                                                            <?php
                                                            global $Winter_MVC_WDK;
                                                            $Winter_MVC_WDK->load_helper('listing');
                                                            $Winter_MVC_WDK->model('location_m');
                                                            $field_value =  wmvc_show_data('location_id', $db_data, '');
                                                            $field_key = 'location_id';

                                                            $locations = array();
                                                            if (!empty($field_value)) {
                                                                $locations[] = $field_value;
                                                                $location = $Winter_MVC_WDK->location_m->get($field_value, TRUE);

                                                                while (!empty($location->parent_id)) {
                                                                    $location = $Winter_MVC_WDK->location_m->get($location->parent_id, TRUE);
                                                                    $locations[] = $location->idlocation;
                                                                }
                                                                krsort($locations);
                                                            } else {
                                                                $locations[] = 0;
                                                            }

                                                            wp_enqueue_style('wdk-treefield-dropdown');
                                                            wp_enqueue_script('wdk-treefield-dropdown');
                                                            wp_enqueue_style('dashicons');

                                                            $level_max = $Winter_MVC_WDK->location_m->get_max_level();

                                                            $placeholder = [
                                                                0 => esc_html__('Select Country', 'wpdirectorykit'),
                                                                1 => esc_html__('Select City', 'wpdirectorykit'),
                                                                2 => esc_html__('Select Neighborhood', 'wpdirectorykit'),
                                                                3 => esc_html__('Select Sub Area', 'wpdirectorykit'),
                                                                4 => esc_html__('Select Sub Area', 'wpdirectorykit'),
                                                                5 => esc_html__('Select Sub Area', 'wpdirectorykit'),
                                                            ];
                                                            ?>

                                                            <input name="<?php echo esc_attr($field_key); ?>" type="hidden" value="<?php echo esc_attr($field_value); ?>">
                                                            <?php
                                                            $level = 0;
                                                            $current = NULL;
                                                            foreach ($locations as $location) {
                                                                $current = $Winter_MVC_WDK->location_m->get($location, TRUE);

                                                                $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = ' . $current->parent_id => NULL));


                                                                if (isset($placeholder[$level])) {
                                                                    $values_list = array('' => $placeholder[$level]);
                                                                } else {
                                                                    $values_list = array('' => esc_html__('Select Sub Area', 'wpdirectorykit'));
                                                                }

                                                                foreach ($list as $list_value) {
                                                                    $values_list[$list_value->idlocation] = $list_value->location_title;
                                                                }


                                                            ?>

                                                                <div data-level="<?php echo esc_attr($level); ?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                                    <div class="wdk-field-group">
                                                                        <?php echo wmvc_select_option('location_' . $level, $values_list, $location, 'class="wdk-control"'); ?>
                                                                    </div>
                                                                </div>

                                                                <?php
                                                                $level++;
                                                            }

                                                            if ($level < $level_max) {
                                                                for (; $level < $level_max;) {

                                                                    if (isset($placeholder[$level])) {
                                                                        $values_list = array('' => $placeholder[$level]);
                                                                    } else {
                                                                        $values_list = array('' => esc_html__('Select Sub Area', 'wpdirectorykit'));
                                                                    }

                                                                    if ($location) {
                                                                        $list = $Winter_MVC_WDK->location_m->get_by(array('parent_id = ' . $location => NULL));
                                                                        foreach ($list as $list_value) {
                                                                            $values_list[$list_value->idlocation] = $list_value->location_title;
                                                                        }
                                                                        $location = NULL;
                                                                    }

                                                                ?>
                                                                    <div data-level="<?php echo esc_attr($level); ?>" data-field="<?php echo esc_attr($field_key); ?>" class="wdk_multi_treefield_dropdown wdk_treefield_dropdown">
                                                                        <div class="wdk-field-group">
                                                                            <?php echo wmvc_select_option('location_' . $level, $values_list, NULL, 'class="wdk-control"'); ?>
                                                                        </div>
                                                                    </div>

                                                            <?php
                                                                    $level++;
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                <?php else : ?>
                                                    <div class="wdk-from-group">
                                                        <label class="" for="location_id"><?php echo esc_html__('Location', 'wdk-membership'); ?><?php if (wdk_get_option('wdk_listing_location_required')) : ?>*<?php endif; ?></label>
                                                        <div class="wdk-from-group-control">
                                                            <?php
                                                                if(!empty($settings['custom_location_root'])) {
                                                                    $custom_field_value = substr($settings['custom_location_root'], strpos($settings['custom_location_root'],'__')+2);
                                                                    $custom_field_value = intval($custom_field_value);
                                                                    global $Winter_MVC_WDK;
                                                                    $Winter_MVC_WDK->load_helper('listing');
                                                                    $Winter_MVC_WDK->model('location_m');

                                                                    /* if root search childs */
                                                                    $filter_ids = wdk_location_get_all_childs($custom_field_value); 
                                                                  
                                                                } 
                                                            ?>
                                                            <?php echo wdk_treefield_option ('location_id', 'location_m',  wmvc_show_data('location_id', $db_data, ''), 'location_title', '', __('Not Selected', 'wdk-membership'), $filter_ids);?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>

                                            <?php if (get_option('wdk_is_location_enabled', FALSE) && get_option('wdk_multi_locations_other_enable', FALSE)) : ?>
                                                <div class="wdk-from-group">
                                                    <label class="" for="location_id"><?php echo esc_html__('More Locations', 'wdk-membership'); ?></label>
                                                    <div class="wdk-from-group-control">
                                                        <?php echo wdk_treefield_select_ajax('listing_sub_locations[]', 'location_m', wmvc_show_data('listing_sub_locations', $db_data, '', TRUE, TRUE), 'location_title', 'idlocation', '', __('All Locations', 'wdk-membership'), '', 'data-limit="10"'); ?>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            <?php if ($section_1_fields) : ?>
                                                        <div class="wdk-row full-width wdk_generate_fields">
                                                            <?php echo wdk_generate_fields($section_1_fields, $db_data); ?>
                                                        </div>
                                                        <?php endif; ?>
                                        </div>
                                        <div class="<?php if (!wmvc_show_data('step_1', $settings, false)) : ?>wdk-col-4 wdk-col-xs-12 order-xs-1<?php endif; ?>">
                                            <?php if (get_option('wdk_is_address_enabled', FALSE)) : ?>
                                                <div id="map" class="listing_edit_map"></div>
                                                <br />
                                                <p class="alert alert-info"><?php echo esc_html__('Drag and drop pin to desired location', 'wdk-membership'); ?></p>
                                                <div class="wdk-field-edit inline">
                                                    <label for="listing_gps"><?php echo esc_html__('GPS', 'wdk-membership'); ?>:</label>
                                                    <div class="wdk-field-container">
                                                        <input name="lat" readonly="readonly" type="text" id="input_lat" value="<?php echo wmvc_show_data('lat', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lat', 'wdk-membership'); ?>">
                                                        <input name="lng" readonly="readonly" type="text" id="input_lng" value="<?php echo wmvc_show_data('lng', $db_data, ''); ?>" class="regular-text" placeholder="<?php echo esc_html__('lng', 'wdk-membership'); ?>">
                                                    </div>
                                                </div>       
                                            <?php endif; ?>
                                        </div>


                                        <?php if (wmvc_show_data('step_1', $settings, false)) : ?>
                                        </div>
                                        <div class="wdk-col-md-5">
                                            <?php echo do_shortcode(wmvc_show_data('step_1', $settings, false)); ?>
                                        </div>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                        <button type="button" class="wdk-btn wdk-btn-primary wdk-submit-loading out wdk-btn-tab-next <?php if (!is_user_logged_in()) : ?>validation <?php endif; ?>" data-validation="new_user_validation"><?php echo esc_html__('Next', 'wdk-membership'); ?></button>
                    </div>

                    <input type="radio" class="wdk-tab-input" name="wdk_tabs" id="wdk_tab_fields" value="1">
                    <div class="wdk-tab">
                        <div class="postbox" style="display: block;">
                            <div class="inside full-width">

                                <?php if (wmvc_show_data('step_2', $settings, false)) : ?>
                                    <div class="wdk-row">
                                        <div class="wdk-col-md-7">
                                        <?php endif; ?>
                                        <?php if (wdk_get_option('wdk_is_post_content_enable', FALSE)) : ?>
                                            <div class="wdk-row">
                                                <div class="wdk-col-12">
                                                    <div class="wdk-from-group">
                                                        <label class="" for="post_content"><?php echo esc_html__('Content', 'wdk-membership'); ?>*</label>
                                                        <div class="wdk-from-group-control">
                                                            <?php wp_editor(wmvc_show_data('post_content', $db_data, ''), 'post_content', array('media_buttons' => FALSE)); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="wdk-row full-width wdk_generate_fields">
                                            <?php if (count($fields) == 0) : ?>
                                                <div class="wdk-col-12">
                                                    <div class="alert alert-success mb0">
                                                        <p><?php echo esc_html__('Fields doesn\'t exists', 'wdk-membership'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk_fields"; ?>" class="button button-primary" id="add_field_button"><?php echo esc_html__('Manage Fields', 'wdk-membership'); ?></a></p>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php echo wdk_generate_fields($fields, $db_data); ?>
                                        </div>
                                        <?php if (wmvc_show_data('step_2', $settings, false)) : ?>
                                        </div>
                                        <div class="wdk-col-md-5">
                                            <?php echo do_shortcode(wmvc_show_data('step_2', $settings, false)); ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <button type="button" class="wdk-btn wdk-btn-primary wdk-submit-loading out wdk-btn-tab-pre"><?php echo esc_html__('Prev', 'wdk-membership'); ?></button>
                            <button type="button" class="wdk-btn wdk-btn-primary wdk-submit-loading out wdk-btn-tab-next"><?php echo esc_html__('Next', 'wdk-membership'); ?></button>
                        </div>

                        <input type="radio" class="wdk-tab-input" name="wdk_tabs" id="wdk_tab_images" value="1">
                        <div class="wdk-tab">
                            <div class="postbox" style="display: block;">
                                <div class="inside">
                                    <?php if (wmvc_show_data('step_3', $settings, false)) : ?>
                                        <div class="wdk-row">
                                            <div class="wdk-col-md-7">
                                    <?php endif; ?>
                                            <p class="alert alert-info"><?php echo esc_html__('Drag and drop image to change order', 'wdk-membership'); ?></p>
                                            <?php if (!is_user_logged_in()) : ?>
                                                <div class="field_upload">
                                                    <div>
                                                        <label for="image_uploads" class="wdk-btn wdk-btn-primary"><?php echo esc_html__('Choose images to upload (PNG, JPG)', 'wdk-membership'); ?></label>
                                                        <input
                                                        type="file"
                                                        id="image_uploads"
                                                        name="image_uploads[]"
                                                        accept=".jpg, .jpeg, .png"
                                                        multiple />
                                                    </div>
                                                    <div class="preview">
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                            <?php
                                            echo wmvc_upload_multiple('listing_images', wmvc_show_data('listing_images', $db_data, ''));
                                            ?>
                                            <?php endif; ?>
                                    <?php if (wmvc_show_data('step_3', $settings, false)) : ?>
                                            </div>
                                            <div class="wdk-col-md-5">
                                                <?php echo do_shortcode(wmvc_show_data('step_3', $settings, false)); ?>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <button type="button" class="wdk-btn wdk-btn-primary wdk-submit-loading out wdk-btn-tab-pre"><?php echo esc_html__('Prev', 'wdk-membership'); ?></button>
                                <button type="submit" class="wdk-btn wdk-btn-primary wdk-submit-loading out"><?php echo esc_html__('Save Changes', 'wdk-membership'); ?></button>
                            </div>
                        </div>
                    </div>

        </form>
    </div>

    <?php do_action('wdk-membership/view/quicksubmission_listing/after_form', wmvc_show_data('ID', $db_data, '')); ?>
</div>


<?php
wp_enqueue_style('winter_mvc', plugins_url(plugin_basename(WINTER_MVC_PATH) . '/assets/css/winter_mvc.css'));
wp_enqueue_script('wpmediaelement',  plugins_url(plugin_basename(WINTER_MVC_PATH) . '/assets/js/jquery.wpmediaelement.js'), false, false, false);
wp_enqueue_script('wpmediamultiple',  plugins_url(plugin_basename(WINTER_MVC_PATH) . '/assets/js/jquery.wpmediamultiple.js'), false, false, false);
$params = array(
    'text' => array(
        'frame_title' => esc_html__('Select or Upload Media Of Your Chosen Persuasion', 'wdk-membership'),
        'frame_button' => esc_html__('Use this media', 'wdk-membership'),
    ),
);
wp_localize_script('wpmediamultiple', 'wpmediamultiple_parameters', $params);
wp_localize_script('wpmediaelement', 'wpmediaelement_parameters', $params);

wp_enqueue_style('leaflet');
wp_enqueue_script('leaflet');

wp_enqueue_style('wdk-notify');
wp_enqueue_script('wdk-notify');
?>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        <?php if (get_option('wdk_is_address_enabled', FALSE)) : ?>
            var wdk_edit_map_marker, wdk_timerMap, wdk_edit_map;
            wdk_edit_map = L.map('map', {
                center: [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>],
                zoom: 6,
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(wdk_edit_map);

            wdk_edit_map_marker = L.marker(
                [<?php echo (wmvc_show_data('lat', $db_data) ?: esc_js(get_option('wdk_default_lat', 51.505))); ?>, <?php echo (wmvc_show_data('lng', $db_data) ?: esc_js(get_option('wdk_default_lng', -0.09))); ?>], {
                    draggable: true
                }
            ).addTo(wdk_edit_map);

            wdk_edit_map_marker.on('dragend', function(event) {
                clearTimeout(wdk_timerMap);
                var marker = event.target;
                var {
                    lat,
                    lng
                } = marker.getLatLng();
                $('#input_lat').val(lat);
                $('#input_lng').val(lng);
                //retrieved the position
            });

            wdk_edit_map.on('click', function(e){
                let lat = e.latlng.lat;
                let lng = e.latlng.lng;

                wdk_edit_map_marker.setLatLng([lat, lng]).update();
                $('#input_lat').val(lat);
                $('#input_lng').val(lng);
            })

            $('#input_address').on('change keyup', function(e) {
                clearTimeout(wdk_timerMap);
                wdk_timerMap = setTimeout(function() {
                    $.get('https://nominatim.openstreetmap.org/search?format=json&q=' + $('#input_address').val(), function(data) {
                        if (data.length && typeof data[0]) {
                            var {
                                lat,
                                lon
                            } = data[0];
                            wdk_edit_map_marker.setLatLng([lat, lon]).update();
                            wdk_edit_map.panTo(new L.LatLng(lat, lon));
                            $('#input_lat').val(lat);
                            $('#input_lng').val(lon);
                        } else {
                            wdk_log_notify('<?php echo esc_js(__('Address not found', 'wdk-membership')); ?>', 'error');
                            return;
                        }
                    });
                }, 1000);
            });

            $('#input_gps').on('change keyup', function(e) {
                wdk_edit_map.panTo(new L.LatLng($('#input_lat').val(), $('#input_lng').val()));
                wdk_edit_map_marker.setLatLng([parseFloat($('#input_lat').val()), parseFloat($('#input_lng').val())]).update();
            })
        <?php endif; ?>

        wdk_query_submit_listing($('.wdk-tabs-wrapper'));

    });

    
    if(jQuery('.wdk-tabs-navs').length) {
        jQuery('.wdk-tabs-navs').find('label').on('click', function(e){

            if(jQuery(this).hasClass('disable_active')) {
                e.preventDefault();
                return false;
            }

            if(jQuery('.wdk-tabs-navs label.active').hasClass('validation_tab')) {
                jQuery('.wdk-tabs-wrapper input[id="'+jQuery('.wdk-tabs-navs label.active').attr('for')+'"]').next().find('.wdk-btn-tab-next').trigger('click');
                e.preventDefault();
                return false;
            } else {
                jQuery(this).parent().find('label').removeClass('active');
                jQuery(this).addClass('active');
            }
        });
    }

    const wdk_query_submit_listing = (tab_el) => {
        var el_tabs = tab_el,
            a,
            el_form = tab_el.closest('form'),
            el_tabs_list = el_tabs.find('.wdk-tabs-panel'),
            el_tab_navs = el_tabs.find('.wdk-tabs-navs');


        jQuery('form.form_listing input').on('keypress', function(e) {
            if(e.which === 13) {
                e.preventDefault();
                jQuery('.wdk-membership-element .wdk-front-wrap .wdk-tabs-panel input:checked + div.wdk-tab').find('.wdk-btn-tab-next, [type="submit"]').trigger('click')
                return false;
            }
        });



        var event_validation = ($methood = '', self, current_tab) => {
                switch ($methood) {
                    case 'new_user_validation':
                        valid = validation_new_user(self, current_tab);
                        break;
                }
            },
            validation_new_user = (self, current_tab) => {
                var valid = true;
                var ajax_param = el_form.serializeArray();
                ajax_param.push({
                    name: 'action',
                    value: "wdk_membership_public_action"
                });
                ajax_param.push({
                    name: 'page',
                    value: "wdk-membership-frontendajax"
                });
                ajax_param.push({
                    name: 'function',
                    value: "validation_user_exists"
                });
                ajax_param.push({
                    name: '_wpnonce',
                    value: "<?php echo esc_js(wp_create_nonce('wdk-validation')); ?>"
                });
                self.addClass('wdk_btn_load_indicator disabled');
                jQuery.ajax({
                    type: 'POST',
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    data: ajax_param,
                    success: function(data) {
                        current_tab.find('.alert_box').html('');
                        if (data.message) {
                            current_tab.find('.alert_box').html(data.message)
                        }

                        if (data.success) {
                            event_next(current_tab, self);

                            jQuery('.wdk-tabs-navs label').removeClass('disable_active validation_tab');
                        } else {
                            valid = false;
                        }

                    }
                }).done(function() {
                    self.removeClass('wdk_btn_load_indicator disabled');
                });
                return valid;
            },
            event_next = (current_tab, self) => {
                self.removeClass('wdk_btn_load_indicator disabled');
                var next = current_tab.next();
                if (next && next.length) {
                    next.trigger('click')
                    el_tab_navs.find('label').removeClass('active');
                    el_tab_navs.find('label[for="' + next.attr('id') + '"]').addClass('active');
                    tab_el.find('.alert_box').html('');
                    event_scroll_top_tab();
                } else {
                    el_form.submit();
                }
            },
            event_prev = (current_tab, self) => {
                self.removeClass('wdk_btn_load_indicator disabled');
                var pre = current_tab.prev().prev().prev();
                if (pre && pre.length) {
                    pre.trigger('click')
                    el_tab_navs.find('label').removeClass('active');
                    el_tab_navs.find('label[for="' + pre.attr('id') + '"]').addClass('active');
                    tab_el.find('.alert_box').html('');
                    event_scroll_top_tab();
                } else {
                    console.log('already first');
                }
            },
            event_scroll_top_tab = () => {
                jQuery(window).scrollTop(el_tab_navs.scrollTop());
            };

        el_tabs_list.find('.wdk-tab .wdk-btn-tab-next').on('click', function() {
            var valid = true;
            var self = jQuery(this);
            var current_tab = jQuery(this).closest('.wdk-tab');
            var box_alert = tab_el.find('.alert_box').html('');
            self.addClass('wdk_btn_load_indicator disabled');

            /* validation */
            if (self.hasClass('validation')) {
                valid = event_validation(self.attr('data-validation'), self, current_tab);
            } else {
                event_next(current_tab, self);
            }
        });

        el_tabs_list.find('.wdk-tab .wdk-btn-tab-pre').on('click', function() {
            /* validation */
            /* next tab */
            var self = jQuery(this);
            var current_tab = jQuery(this).closest('.wdk-tab');
            if (true) {
                event_prev(current_tab, self);
            }

        });
    };
</script>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        <?php if (!is_user_logged_in()) : ?>

const input = document.querySelector("#image_uploads");
const preview = document.querySelector(".preview");

input.style.opacity = 0;

input.addEventListener("change", updateImageDisplay);

function updateImageDisplay() {
  while (preview.firstChild) {
    preview.removeChild(preview.firstChild);
  }

  const curFiles = input.files;
  if (curFiles.length === 0) {
    const para = document.createElement("p");
    para.textContent = "No files currently selected for upload";
    preview.appendChild(para);
  } else {
    const list = document.createElement("ol");
    preview.appendChild(list);

    for (const file of curFiles) {
      const listItem = document.createElement("li");
      const para = document.createElement("p");
      if (validFileType(file)) {
        para.textContent = `File name ${file.name}, file size ${returnFileSize(
          file.size,
        )}.`;
        const image = document.createElement("img");
        image.src = URL.createObjectURL(file);
        image.alt = image.title = file.name;

        listItem.appendChild(image);
        listItem.appendChild(para);
      } else {
        para.textContent = `File name ${file.name}: Not a valid file type. Update your selection.`;
        listItem.appendChild(para);
      }

      list.appendChild(listItem);
    }
  }
}

// https://developer.mozilla.org/en-US/docs/Web/Media/Formats/Image_types
const fileTypes = [
  "image/apng",
  "image/bmp",
  "image/gif",
  "image/jpeg",
  "image/pjpeg",
  "image/png",
  "image/svg+xml",
  "image/tiff",
  "image/webp",
  "image/x-icon",
];

function validFileType(file) {
  return fileTypes.includes(file.type);
}

function returnFileSize(number) {
  if (number < 1024) {
    return `${number} bytes`;
  } else if (number >= 1024 && number < 1048576) {
    return `${(number / 1024).toFixed(1)} KB`;
  } else if (number >= 1048576) {
    return `${(number / 1048576).toFixed(1)} MB`;
  }
}

const button = document.querySelector("form button");
button.addEventListener("click", (e) => {
  e.preventDefault();
  const para = document.createElement("p");
  para.append("Image uploaded!");
  preview.replaceChildren(para);
});
        <?php endif;?>

    });
</script>

<?php $this->view('general/footer', $data); ?>