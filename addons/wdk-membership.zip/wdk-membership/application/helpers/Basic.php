<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function wdk_membership_view_quicksubmission($data = array())
{

    $page = 'wdk-membership-quicksubmission';
    $function = 'index';
    // view
    global $Winter_MVC_wdk_membership;
    $Winter_MVC_wdk_membership->load_controller($page, $function, $data);
}

function wdk_membership_view_dash()
{

    $page = 'wdk-membership-dash';
    $function = 'index';
    global $Winter_MVC_wdk_membership;

    if(isset($_GET['dash_page']))$page = 'wdk-membership-'.wmvc_xss_clean($_GET['dash_page']);
    if(isset($_GET['function']))$function = wmvc_xss_clean($_GET['function']);
    
    // custom view
    do_action('wdk-membership/wdk_membership_view_dash/view', $page, $function);
    
    if(!file_exists(WDK_MEMBERSHIP_PATH.'application/controllers/'.ucfirst($page).'.php')) {
        // Load view
        $stop_execution = apply_filters('wdk-membership/wdk_membership_view_dash/missing_page/stop_execution', false, $page, $function);

        if (!$stop_execution) {
            $data = array();
            $data['title'] = __('Access denied', 'wdk-membership');
            $data['message'] = sprintf(__('Page %1$s missing', 'wdk-membership'), sanitize_text_field($_GET['dash_page']));

            $Winter_MVC_wdk_membership->view('wdk_membership_dash/basic/notice_page', $data);
        }
    } else {
        $Winter_MVC_wdk_membership->load_controller($page, $function, array());
    }
}

function wdk_dash_url($query = '')
{
    if(!get_option('wdk_membership_dash_page'))
        return ''; 

    return trim(wdk_url_suffix(get_permalink(get_option('wdk_membership_dash_page')),$query), '&');
}

 /**
	 *  Return active class
	 *
	 * @param      string|array    $slugs  GET['dash_page'] for active
	 * @param      string    $active_class    active class name
	 * @param      string   $function_slug  GET['function'] for active
	 * @param      array   $except    GET var which not use for active like [['key'=>'','value'=>''],['key'=>'','value'=>'']]
     *
	 * @return     string active class if item is active or emtpy string
*/
function wdk_dash_menu_active($slugs = '', $active_class="active", $function_slug = NULL, $excepts = NULL)
{

    /* filter */
    if(!empty($excepts)) {
        $filter = true;
        foreach($excepts as $except){
            foreach($except as $key => $value){
                if(isset($_GET[$key]) && $_GET[$key] == $value) {
                } else {
                    $filter = false;
                }
            }
        }

        if($filter) {
            return '';
        }
    }

    if(isset($_GET['dash_page'])) 
        if(is_array($slugs) && in_array(strtolower($_GET['dash_page']),$slugs)){
            if(!empty($function_slug) && isset($_GET['function']) && $_GET['function'] == $function_slug) {
                return $active_class;
            } elseif(empty($function_slug)) {
                return $active_class;
            }
        } else if($slugs == strtolower($_GET['dash_page'])){

            if(!empty($function_slug) && isset($_GET['function']) && $_GET['function'] == $function_slug) {
                return $active_class;
            } elseif(empty($function_slug)) {
                return $active_class;
            }
        }

    return '';
}

function wdk_membership_is_option_page($option = '')
{
    if((get_option($option)) && get_post_status(get_option($option)) == 'publish'){
        return true;
    }

    return false;
}


/*
* Add admin alert with save dissmis
* @param (string) $key unique key of alert, prefix included related plugin
* @param (string) $text test of message
* @param (string) $class alert alert class, by default 'notice notice-error'
* @return echo alert
*/
function wdk_membership_alert ($key = '', $message = 'Custom Text of message', $class = 'notice notice-error') {
    $key = 'wdk_membership_alert_'.$key;
    $key_diss = $key.'_dissmiss';

    global $wpdb;
    $user_id = get_current_user_id();
    if (!get_user_meta($user_id, $key_diss)) {

    $url = trim(wdk_url_suffix('//'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], $key_diss), '&');
        printf('<div class="%1$s" style="position:relative;"><p>%2$s</p><a href="'.esc_url($url).'"><button type="button" class="notice-dismiss"></button></a></div>', esc_html($class), ($message));  // WPCS: XSS ok, sanitization ok.
    }

    $user_id = get_current_user_id();
    if (isset($_GET[$key_diss])) {
        add_user_meta($user_id, $key_diss, 'true', true);
        wp_redirect(str_replace($key_diss,'','//'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']));
    }

}

function wdk_subscriptions_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_membership;
    $WMVC = &$Winter_MVC_wdk_membership;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    /* Пet column names from wdk_package and add to allow search + 
        in _GET_clone replace field_#id to field_id_TYPE*/
    $list_fields = $WMVC->db->list_fields( $WMVC->db->prefix.'wdk_membership_subscription');


    if(isset($_GET_clone['search_location'])) {
        $column_name ='location_id';
        $_GET_clone[$column_name] = $_GET_clone['search_location'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    if(isset($_GET_clone['search_category'])) {
        $column_name ='category_id';
        $_GET_clone[$column_name] = $_GET_clone['search_category'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_payments_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_payments_listings.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

function wdk_subscriptions_user_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_membership;
    $WMVC = &$Winter_MVC_wdk_membership;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    /* Пet column names from wdk_package and add to allow search + 
        in _GET_clone replace field_#id to field_id_TYPE*/
    $list_fields = $WMVC->db->list_fields( $WMVC->db->prefix.'wdk_membership_subscription');


    if(isset($_GET_clone['search_location'])) {
        $column_name ='location_id';
        $_GET_clone[$column_name] = $_GET_clone['search_location'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    if(isset($_GET_clone['search_category'])) {
        $column_name ='category_id';
        $_GET_clone[$column_name] = $_GET_clone['search_category'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_payments_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_payments_listings.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}


if(!function_exists('is_wdk_membership_unique_and_exists_woocommerce_product_id'))
{
    function is_wdk_membership_unique_and_exists_woocommerce_product_id($str)
    {
        global $wpdb;    

        if(empty($str))return TRUE;

        if(!function_exists('wc_get_product'))return FALSE;

        $additional_sql = '';
        if(isset($_REQUEST['id']))
        {
            $current_id = intval($_REQUEST['id']);
            $additional_sql = " AND idsubscription != $current_id";
        }

        $table_name = $wpdb->prefix . 'wdk_membership_subscription';

        $result = $wpdb->get_results( "SELECT * FROM $table_name WHERE woocommerce_product_id = ".intval($str)." $additional_sql");

        $product = wc_get_product( intval($str) );
        
        if(count($result) == 0 && !empty($product))return TRUE;

        return false;
    }
}

if(!function_exists('is_wdk_membership_subscription_limit_listings'))
{
    function is_wdk_membership_subscription_limit_listings($str)
    {
        if(empty($str))return TRUE;
        global $Winter_MVC_wdk_membership;

        $Winter_MVC_wdk_membership->model('subscription_m');

        $subscriptions = $Winter_MVC_wdk_membership->subscription_m->get($str, TRUE);
        $listings_limit = wdk_show_data('listings_limit', $subscriptions, '0');
       
        //if(empty($listings_limit)) return TRUE;
        $where = array();
        
        if(TRUE || wdk_get_option('wdk_membership_multiple_subscriptions_enabled'))
            $where ['subscription_id'] = wdk_show_data('idsubscription', $subscriptions, '0');

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');

        if(isset($_REQUEST['id']))
        {
            $current_id = intval($_REQUEST['id']);
            $where[$Winter_MVC_WDK->listing_m->_table_name.".post_id != $current_id"]=NULL;
        }

        $listings_count = $Winter_MVC_WDK->listing_m->total($where, TRUE, get_current_user_id());
        if($listings_limit == '-1' || ($listings_count+1) <= $listings_limit) return TRUE;

        return FALSE;
    }
}

if(!function_exists('is_wdk_membership_subscription_limit_images'))
{
    function is_wdk_membership_subscription_limit_images($str)
    {
        if(empty($str))return TRUE;

        global $Winter_MVC_wdk_membership;

        $Winter_MVC_wdk_membership->model('subscription_m');
        $subscriptions = $Winter_MVC_wdk_membership->subscription_m->get($str, TRUE);
        $images_limit = wdk_show_data('images_limit', $subscriptions, '0');
      
        if(empty($images_limit)) return TRUE;

       
        if(isset($_REQUEST['listing_images']))
        {
           
            $image_ids = array_filter(explode(',', sanitize_text_field($_REQUEST['listing_images'])));

            if($images_limit == '-1' || count($image_ids) <= $images_limit) return TRUE;

        } else {
            return TRUE;
        }
        
        return FALSE;
    }
}

if(!function_exists('is_wdk_membership_subscription_check'))
{
    function is_wdk_membership_subscription_check($str)
    {
        if(empty($str))return TRUE;

        global $Winter_MVC_wdk_membership;
                
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        $Winter_MVC_wdk_membership->model('subscription_m');
       
        $Winter_MVC_wdk_membership->db->select('*');
        $Winter_MVC_wdk_membership->db->join($Winter_MVC_wdk_membership->subscription_m->_table_name.' ON '.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.idsubscription = '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.subscription_id');
      
        $location_id = NULL;
        if(isset($_POST['location_id']) && !empty($_POST['location_id']) && is_intval($_POST['location_id'])) {
            $location_id =  ' OR location_id ='.sanitize_text_field($_POST['location_id']);
        }

        $category_id = NULL;
        if(isset($_POST['category_id']) && !empty($_POST['category_id']) && is_intval($_POST['category_id'])) {
            $category_id = ' OR location_id = '.sanitize_text_field($_POST['category_id']);
        }

        $Winter_MVC_wdk_membership->db->where(array(
                            '(date_expire   > \''.current_time( 'mysql' ).'\')'=>NULL,
                            '(subscription_id = \''.intval($str).'\')'=>NULL,
                            '(user_id = \''.get_current_user_id().'\')'=>NULL,
                            '(status = \'ACTIVE\')'=>NULL,
                            '(location_id IS NULL '.esc_sql($location_id).')'=>NULL,
                            '(category_id IS NULL '.esc_sql($category_id).')'=>NULL)
                        );
        $subscriptions = $Winter_MVC_wdk_membership->subscription_user_m->get();
       
        if(!empty($subscriptions)) return TRUE;

        return FALSE;
    }
}


/**
 * Get All orders IDs for a given product ID.
 *
 * @param  integer  $product_id (required)
 * @param  array    $order_status (optional) Default is 'wc-completed'
 *
 * @return array
 */
if(!function_exists('wdk_get_orders_ids_by_product_id')) {
    function wdk_get_orders_ids_by_product_id( $product_id ){
        global $wpdb;

        $results = $wpdb->get_col("
            SELECT order_items.order_id
            FROM {$wpdb->prefix}woocommerce_order_items as order_items
            LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
            LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
            WHERE posts.post_type = 'shop_order'
            AND order_items.order_item_type = 'line_item'
            AND order_item_meta.meta_key = '_product_id'
            AND order_item_meta.meta_value = '$product_id'
        ");

        return $results;
    }
}


if(!function_exists('is_wdk_membership_unique_user_subscription'))
{
    function is_wdk_membership_unique_user_subscription($str)
    {

        $user_id = '';
        if(isset($_REQUEST['user_id']))
        {
            $user_id = intval($_REQUEST['user_id']);
        }

        $idsubscription_user = '';
        if(isset($_REQUEST['id']))
        {
            $idsubscription_user = intval($_REQUEST['id']);
        }
       
        if(empty($user_id)) {
            return TRUE;
        }
  
        if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled'))
            return TRUE;
         
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_user_m');

        if(!empty($idsubscription_user)){
            if($Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id, 'subscription_id'=>intval($str), 'idsubscription_user !='=>$idsubscription_user))){
                return FALSE;
            }
        }else if($Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id, 'subscription_id'=>intval($str)))) {
            return FALSE;
        }
        return TRUE;
    }
}

if(!function_exists('is_wdk_membership_user_subs_exists'))
{
    function is_wdk_membership_user_subs_exists($str)
    {
        if(empty($str))return TRUE;

        if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled'))
            return TRUE;
        
        $idsubscription_user = '';
        if(isset($_REQUEST['id']))
        {
            $idsubscription_user = intval($_REQUEST['id']);
            return TRUE;
        } 

        $user_id = '';
        if(isset($_REQUEST['user_id']))
        {
            $user_id = intval($_REQUEST['user_id']);
        }

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        if(!$Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id))) {
            return TRUE;
        }
       
        return FALSE;
    }
}


/**
 * Generate page title path like Dash - Booking - My Reservations
 *
 * @return array
 */

if(!function_exists('wdk_membership_generate_page_title_tags')) {
    function wdk_membership_generate_page_title_tags() {
        $title_tags = array();
        $title_tags[wdk_dash_url()] = esc_html__('Dash', 'wdk-membership');
        if(isset($_GET['dash_page'])) {
            $dash_slug = sanitize_text_field($_GET['dash_page']);
            

            if(stripos($dash_slug, 'booking-') !== FALSE) {
                $title_tags[wdk_dash_url('dash_page=booking-reservations')] = esc_html__('Booking', 'wdk-membership');
            }

            if(isset($_GET['function']) && in_array($dash_slug, array('booking-myreservations'))) {
                switch ($dash_slug) {
                    case 'booking-myreservations':
                            $title_tags[] = esc_html__('View Reservation', 'wdk-membership');
                            break;
                    default:
                        # code...
                        break;
                }
            } else {
                switch ($dash_slug) {
                    case 'booking-myreservations':
                            $title_tags[wdk_dash_url('dash_page=booking-myreservations')] = esc_html__('My Reservations', 'wdk-membership');
                            break;
                    case 'booking-reservations':
                            $title_tags[wdk_dash_url('dash_page=booking-reservations')] = esc_html__('Listings Reservations', 'wdk-membership');
                            break;
                    case 'booking-prices':
                            $title_tags[wdk_dash_url('dash_page=booking-prices')] = esc_html__('Booking Prices', 'wdk-membership');
                            break;
                    case 'booking-calendars':
                            $title_tags[wdk_dash_url('dash_page=booking-calendars')] = esc_html__('Booking Calendars', 'wdk-membership');
                            break;
                    case 'save-search':
                            $title_tags[wdk_dash_url('dash_page=save-search')] = esc_html__('My Save Search', 'wdk-membership');
                            break;
                    case 'reviews':
                            $title_tags[wdk_dash_url('dash_page=reviews')] = esc_html__('My Reviews', 'wdk-membership');
                            break;
                    case 'membership':
                            $title_tags[wdk_dash_url('dash_page=membership')] = esc_html__('Subscription', 'wdk-membership');
                            break;
                    case 'profile':
                            $title_tags[wdk_dash_url('dash_page=profile')] = esc_html__('My Profile', 'wdk-membership');
                            break;
                    case 'favorites':
                            $title_tags[wdk_dash_url('dash_page=favorites')] = esc_html__('My Favorites', 'wdk-membership');
                            break;
                    case 'listings':
                            $title_tags[wdk_dash_url('dash_page=listings')] = esc_html__('My Listings', 'wdk-membership');
                            break;
                    default:
                        # code...
                        break;
                }

                if(isset($_GET['function'])) {
                    switch ($_GET['function']) {
                        case 'edit':
                                $title_tags[] = esc_html__('Edit', 'wdk-membership');
                                break;
                        default:
                            # code...
                            break;
                    }
                }
            }
        }

        return $title_tags; 
    }
}


/**
 * Check if user have membership with booking enabled
* @param (integer) $user_id id of user or if NULL, current user id
* 
* @return boolen
 */

if(!function_exists('wdk_membership_subscription_booking_enabled')) {
    function wdk_membership_subscription_booking_enabled($user_id = NULL) {
        if($user_id == NULL) {
            $user_id = get_current_user_id();
        }

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        $Winter_MVC_wdk_membership->model('subscription_m');

        $Winter_MVC_wdk_membership->db->select('*');
        $Winter_MVC_wdk_membership->db->join($Winter_MVC_wdk_membership->subscription_m->_table_name.' ON '.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.idsubscription = '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.subscription_id', TRUE, 'LEFT');

        if($Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id, 'is_booked_enabled'=>1, '(date_expire   > \''.current_time( 'mysql' ).'\')'=>NULL), TRUE)) {
            return TRUE;
        }

        return false; 
    }
}

/* for compatible if no updated main plugin */
if ( ! function_exists('wdk_is_phone'))
{
    // Validation phone
    /**
    * @param string $value phone in string
    * @return bool
    */
    function wdk_is_phone($value = '') {
        if(preg_match("/.*[0-9]{3,4}-[0-9]{3,4}.*$/", $value)) {
            return true;
        }
        
        return false;
    }	
}	
 
if ( ! function_exists('wdk_filter_phone'))
{
    // Validation phone
    /**
    * @param string $value phone in string
    * @return bool
    */
    function wdk_filter_phone($value = '') {
        return str_replace(array(' ','-','(',')'),'',$value);
    }	
}

/* for compatible if no updated main plugin */
if ( ! function_exists('wdk_sprintf'))
{
    function wdk_sprintf($string = '')
    {
        $arg_list = func_get_args();

        if(count($arg_list)<2) {
            return $string;
        }

        if(stripos($string, '%1$s') === FALSE) {
            return $string;
        }

        return call_user_func_array("sprintf", $arg_list);
    }
}


/*
 validation function for user exists, temporary, can be removed after few updates main plugins, added in main plugin version  1.3.0
*/
if ( ! function_exists('is_wdk_is_useremail_exists'))
{
    function is_wdk_is_useremail_exists($param)
    {
 
        if(null == username_exists( $param ) && !email_exists($param)) {
            return true;
        }

        return false;
    }
}


/*
 Get Favorite item title
*/
if ( ! function_exists('wdk_favorite_item_name'))
{
    // Get Favorite item title
    /**
    * @param object|array $row favorite row include post_type and post_id
    * @return string
    */
    function wdk_favorite_item_name($row)
    {
        $title = '';
        if(wmvc_show_data('post_type', $row, false) == 'profile' && wmvc_show_data('post_id', $row, false)) {
            $wdk_userdata = wdk_get_user_data(wmvc_show_data('post_id', $row));
            $title = $wdk_userdata['userdata']->display_name;
        } else {
            if(wmvc_show_data('post_title', $row)) {
                $title = wmvc_show_data('post_title', $row);
            } else {

            }
        }

        return $title;
    }
}

/*
 Get Favorite item title
*/
if ( ! function_exists('wdk_favorite_item_link'))
{
    // Get Favorite item title
    /**
    * @param object|array $row favorite row include post_type and post_id
    * @return string url
    */
    function wdk_favorite_item_link($row)
    {
        $link = '';
        if(wmvc_show_data('post_type', $row, false) == 'profile' && wmvc_show_data('post_id', $row, false)) {
            $wdk_userdata = wdk_get_user_data(wmvc_show_data('post_id', $row));
            $link = wdk_generate_profile_permalink($wdk_userdata['userdata']);
        } else {
            $link = get_permalink(wmvc_show_data('post_id', $row, '-'));
        }

        return $link;
    }
}

?>