<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;
class Wdk_membership_reviews extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
	public function index()
	{
        if(!function_exists('run_wdk_reviews')) {
            // Load view
            $this->data['title'] = __('Reviews addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate reviews addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_type_m');
        $Winter_MVC_wdk_reviews->model('reviews_m');

        $this->data['post_types'] = $Winter_MVC_wdk_reviews->reviews_type_m->post_types;

        $dbusers =  get_users( array( 'search' => '',
                                    'orderby' => 'display_name', 'order' => 'ASC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }
        /* [End Table Actions Bulk Form] */

        /* [Search Form] */

        $this->data['order_by']   = array(  'idreviews DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idreviews ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-membership').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-membership').' DESC',
                                            'post_title ASC' => __('Post Title', 'wdk-membership').' ASC',
                                            'post_title DESC' => __('Post Title', 'wdk-membership').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'post_type',
                'label' => __('Post Type', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'label' => __('Category', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'label' => __('User', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'review_post_type',
                'label' => __('Post Type', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-membership'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_reviews->reviews_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'reviews';
        $columns = array('idreviews', 'post_title','order_by', 'post_type','user_id', 'review_post_type', 'display_name');
        $external_columns = array('post_title', 'post_type', 'review_post_type', 'display_name');

        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $Winter_MVC_wdk_reviews->reviews_m->total();

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
            
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_reviews_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['reviews'] = $Winter_MVC_wdk_reviews->reviews_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk_membership_dash/reviews/index', $this->data);
    }

    // Edit listing method
	public function edit()
	{
        if(!function_exists('run_wdk_reviews')) {
            // Load view
            $this->data['title'] = __('Reviews addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate reviews addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }
        
        global $Winter_MVC_wdk_reviews;
        
        $Winter_MVC_wdk_reviews->model('reviews_m');
        $Winter_MVC_wdk_reviews->model('reviews_option_m');
        $Winter_MVC_wdk_reviews->model('reviews_type_m');

        $this->data['post_types'] = $Winter_MVC_wdk_reviews->reviews_type_m->post_types;

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('reviews_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['db_data_options'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_wdk_reviews->reviews_m->fields_list_dash;

        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_wdk_reviews->reviews_m->get($id, true);
        }

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-membership'));
        $this->form->add_error_message('wdk_reviewed', __('Listing/Profile already reviewed by current user', 'wdk-membership'));

        if ($this->form->run($this->data['fields'])) {
            // Save procedure for basic data
            $data = $Winter_MVC_wdk_reviews->reviews_m->prepare_data($this->input->post(), $this->data['fields']);
            
            $reviews_type =  $Winter_MVC_wdk_reviews->reviews_type_m->get(wmvc_show_data('reviews_type_id', $this->data['db_data']), true);
            if (wmvc_show_data('review_post_type', $reviews_type) == 'profile') {
                $_POST['post_id'] = $data['post_id'] = $this->input->post('post_id_profile');
            }
            $data['reviews_type_id'] = wmvc_show_data('reviews_type_id', $this->data['db_data']);
            unset($data['post_id']);
            
            $data['is_confirmed'] = NULL;
            $insert_id = $Winter_MVC_wdk_reviews->reviews_m->save_with_options($data, array(), $id);
            
            $subject = __('New or edited review', 'wdk-membership');
          
            
            /* message data */
            $data_message = array();
            $data_message['user'] = get_userdata( wmvc_show_data('user_id', $data) ); /* user data */
            $data_message['review_id'] = $insert_id;  /* review_id */
            $data_message['review'] = $data; /* reveiw data */
            $data_message['reviews_type'] = $reviews_type; /* review type data */
            $data_message['post_link'] = get_permalink( wmvc_show_data('post_id', $data));
            $data_message['post'] = get_post( wmvc_show_data('post_id', $data)); /* post data */

            $ret =  wdk_mail( get_bloginfo('admin_email'), $subject, $data_message, 'new_review_approve');

            if (!empty($insert_id) && empty($id)) {
                $insert_id = $id;
            }
            
        }

        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_wdk_reviews->reviews_m->get($id, true);
            $this->data['db_data_options'] = $Winter_MVC_wdk_reviews->reviews_m->get_options($id);
        } else {
            //unset($this->data['fields']['1']);
        }
        
        $this->data['options'] = $Winter_MVC_wdk_reviews->reviews_option_m->get_options_list();
        
        // Load view
        $this->load->view('wdk_membership_dash/reviews/edit', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_m');
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_reviews->reviews_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_reviews->reviews_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_reviews->reviews_m->check_deletable($post_id))
                $Winter_MVC_wdk_reviews->reviews_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_reviews;
        $Winter_MVC_wdk_reviews->model('reviews_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_reviews->reviews_m->check_deletable($post_id))
                $Winter_MVC_wdk_reviews->reviews_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
}
