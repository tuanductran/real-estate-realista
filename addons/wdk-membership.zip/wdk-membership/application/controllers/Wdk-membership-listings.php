<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_listings extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
    
    public $listing_data = array();

    public function wdk_payments_check_subscription () {

        $this->load->model('subscription_m');
        $this->load->model('subscription_user_m');
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');

        $this->db->select($this->subscription_user_m->_table_name.'.*,'.$this->subscription_m->_table_name.'.*, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS listings_counter');
        $this->db->join($this->subscription_user_m->_table_name.' ON ('.$this->subscription_m->_table_name.'.idsubscription = '.$this->subscription_user_m->_table_name.'.subscription_id AND 
                                            '.$this->subscription_user_m->_table_name.'.user_id = "'.get_current_user_id().'")', TRUE, 'LEFT');
        
        $this->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON (
                                                    '.$Winter_MVC_WDK->listing_m->_table_name.'.subscription_id = '.$this->subscription_m->_table_name.'.idsubscription
                                                    AND '.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor = '.get_current_user_id().'
                                                )',
                                                TRUE, 'LEFT');
                                        
        $this->db->where(array(
            '(
                ((date_from IS NULL OR date_from < \''.current_time( 'mysql' ).'\') AND (date_to IS NULL OR date_to > \''.current_time( 'mysql' ).'\'))
                OR
                ('.$this->subscription_user_m->_table_name.'.date_expire  IS NOT NULL)
            )'
            =>NULL
        ));
        $this->db->group_by('idsubscription');

        $subscriptions = $this->subscription_m->get_by(array($this->subscription_m->_table_name.'.is_activated = 1'=>NULL));

        if(count($subscriptions) > 0)
            {
                $subscription_messages = array();
                if(wdk_get_option('wdk_membership_is_subscription_required')) {
                    if( !empty($this->listing_data) && wmvc_show_data('subscription_id', $this->listing_data, false)) {
                        $subscription_user = $this->subscription_user_m->get_by(array('subscription_id'=>wmvc_show_data('subscription_id', $this->listing_data), 'user_id'=>get_current_user_id()), TRUE);
                        if(strtotime(wmvc_show_data('date_expire', $subscription_user, false, TRUE, TRUE)) < current_time('timestamp'))
                        {
                            $subscription_messages[] = __('Your Membership Subscription expired, please select one:', 'wdk-membership');
                        }
                    }
                }

                foreach($subscription_messages as $subscription_message)
                {
                    ?>
                        <p class="alert alert-danger"><?php echo esc_html($subscription_message); ?></p>
                    <?php
                }

                ?>

                <table class="wdk-table responsive vertical-middle wdk-table-subs">
                <thead>
                    <tr>
                        <th></th>
                        <th><?php echo esc_html__('Subscription Name', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Days', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Featured Positions', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Listings', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Auto Approved', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Price', 'wdk-membership'); ?></th>
                        <th><?php echo esc_html__('Buy', 'wdk-membership'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($subscriptions as $subscription): ?>
                    <tr
                    class="<?php if(!empty($subscription->date_expire) && $subscription->date_expire > date('Y-m-d H:i:s')):?><?php else:?>
                                disabled
                            <?php endif;?>"
                    >
                        <td data-label="<?php echo esc_html__('Select', 'wdk-membership'); ?>" class="title column-title column-primary">
                           <input type="radio" id="subscription_id_<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>" name="subscriptions" 
                                  value="<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>"

                                <?php if(wmvc_show_data('subscription_id', $this->listing_data, '') == wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)):?> checked="checked" <?php endif;?>
                               
                                <?php if(!empty($subscription->date_expire) && $subscription->date_expire > date('Y-m-d H:i:s')):?>
                                <?php else:?>
                                    disabled="disabled"
                                <?php endif;?>
                            />
                        </td>
                        <td data-label="<?php echo esc_html__('Membership Subscription', 'wdk-membership'); ?>" class="title column-title column-primary">
                            <strong>
                                <label style="display: inline-block;" for="subscription_id_<?php echo esc_attr(wmvc_show_data('idsubscription', $subscription, '', TRUE, TRUE)); ?>">
                                    <?php echo esc_html(wmvc_show_data('subscription_name', $subscription, '-')); ?>
                                </label>
                            </strong>
                            <?php if(!empty($subscription->date_expire) && $subscription->date_expire < date('Y-m-d H:i:s')):?>
                                <span class="label label-danger"><?php echo esc_html__('expired', 'wdk-membership'); ?></span>
                            <?php elseif(!empty($subscription->date_expire)):?>
                            
                            <?php endif;?>
                        </td>
                        <td data-label="<?php echo esc_html__('Days', 'wdk-membership'); ?>">
                            <?php echo esc_html(wmvc_show_data('days_limit', $subscription, '-')); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Featured Positions', 'wdk-membership'); ?>">
                            <?php if(wmvc_show_data('is_auto_featured', $subscription, 0)): ?>
                            <span class="label label-info"><span class="dashicons dashicons-saved"></span></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Listings', 'wdk-membership'); ?>">
                            <?php echo wmvc_show_data('listings_counter', $subscription, 0); ?> / 

                            <?php if(wdk_show_data('listings_limit',$subscription, '', TRUE, TRUE) == '-1'): ?>
                                <?php echo esc_html__('Unlimited', 'wdk-membership'); ?>
                            <?php else: ?>
                                <?php echo wmvc_show_data('listings_limit', $subscription, '-'); ?>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Auto Approved', 'wdk-membership'); ?>">
                            <?php if(wmvc_show_data('is_auto_approved', $subscription, 0)): ?>
                            <span class="label label-info"><span class="dashicons dashicons-saved"></span></span>
                            <?php endif; ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Price', 'wdk-membership'); ?>">
                            <?php echo esc_html(wmvc_show_data('price', $subscription, '-')); ?>
                        </td>
                        <td data-label="<?php echo esc_html__('Actions', 'wdk-membership'); ?>" class="actions_column">
                            <?php if(!empty($subscription->date_expire) && $subscription->date_expire < date('Y-m-d H:i:s')):?>
                            <?php elseif(!empty($subscription->date_expire)):?>
                            <?php else:?>
                                <?php if(function_exists('wc_get_cart_url') && !empty($subscription->woocommerce_product_id)): ?>
                                    <a href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($subscription->woocommerce_product_id)); ?>" class="" target="blank"><span class="dashicons dashicons-cart"></span></a>
                                <?php endif; ?>
                            <?php endif;?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <br />
                <?php
            }
    
    }

	public function index()
	{
		global $Winter_MVC_WDK;
		$Winter_MVC_WDK->model('field_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('listingfield_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('category_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'listing';
        $columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by');
        $external_columns = array('location_id', 'category_id', 'post_title');

        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['order_by']   = array('ID DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'ID ASC' => __('ID', 'wdk-membership').' ASC', 
                                          'post_title ASC' => __('Post Title', 'wdk-membership').' ASC',
                                          'post_title DESC' => __('Post Title', 'wdk-membership').' DESC',
                                          'post_date ASC' => __('Post Date', 'wdk-membership').' ASC',
                                          'post_date DESC' => __('Post Date', 'wdk-membership').' DESC',);

        $rules = array(
                array(
                    'field' => 'location_id',
                    'label' => __('Location', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'category_id',
                    'label' => __('Category', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->listing_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $Winter_MVC_WDK->listing_m->total(array(), TRUE, get_current_user_id());

        $current_page = 1;

        if(isset($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);

        $this->data['wmvc_paged'] = $current_page;

        $per_page = 5;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['listings'] = $Winter_MVC_WDK->listing_m->get_pagination($per_page, $offset, array(), TRUE, get_current_user_id());

        $this->load->view('wdk_membership_dash/listings/index', $this->data);
    }

    // Edit listing method
	public function edit()
	{
        global $Winter_MVC_WDK;

        $Winter_MVC_WDK->model('field_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('listingfield_m');
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('user_m');

        $listing_post_id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('listing_m', $listing_post_id);
        $this->data['db_data'] = NULL;

        $this->data['form'] = &$this->form;

        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['agents']  = $Winter_MVC_WDK->user_m->get_agents();
        
        $this->data['db_data']['listing_sub_locations'] = array();
        $this->data['db_data']['listing_sub_categories'] = array();

        if(!empty($listing_post_id))
        {
            $listing_post = get_post( $listing_post_id );

            $listing_db_data = $Winter_MVC_WDK->listing_m->get($listing_post_id, TRUE);

            $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($listing_post_id, TRUE);

            $this->listing_data = $this->data['db_data'] = array_merge((array) $listing_post, 
                                                 (array) $listing_db_data, 
                                                 (array) $listingfield_db_data);

                                                 
            $this->data['db_data']['listing_sub_locations'] = wdk_generate_other_locations_keys($listing_post_id);
            $this->data['db_data']['listing_sub_categories'] = wdk_generate_other_categories_keys($listing_post_id);
        } 

        if(isset($_POST['listing_sub_locations'])) {
            $this->data['db_data']['listing_sub_locations'] = $_POST['listing_sub_locations'];
        }
        
        if(isset($_POST['listing_sub_categories'])) {
            $this->data['db_data']['listing_sub_categories'] = $_POST['listing_sub_categories'];
        }
       
        $this->db->where(array('field_type !='=> 'SECTION'));
        $this->data['listing_fields'] = $Winter_MVC_WDK->field_m->get();
        
        $this->data['fields'] = $Winter_MVC_WDK->field_m->get_by(array('is_visible_dashboard'=>1));
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => __('Title', 'wdk-membership'),
                    'rules' => 'required'
                ),
                array(
                    'field' => 'post_content',
                    'label' => __('Content', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_post_content_enable', FALSE)) ? 'required' : ''
                ),
                array(
                    'field' => 'category_id',
                    'label' => __('Category', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listing_category_required')) ? 'required':''
                ),
                array(
                    'field' => 'location_id',
                    'label' => __('Location', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listing_location_required')) ? 'required':''
                ),
                array(
                    'field' => 'address',
                    'label' => __('Address', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'lat',
                    'label' => __('lat', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_address_enabled')) ? 'wdk_gps_single':''
                ),
                array(
                    'field' => 'lng',
                    'label' => __('lng', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_address_enabled')) ? 'wdk_gps_single':''
                ),
                array(
                    'field' => 'listing_plans_documents',
                    'label' => __('Listing plans and documents', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_images',
                    'label' => __('Listing images', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listings_images_required_enable')) ? 'required' : ''
                ),
                array(
                    'field' => 'is_activated',
                    'label' => __('Is Activated', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'user_id',
                    'label' => __('Agent', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_sub_locations',
                    'label' => __('Locations', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_sub_categories',
                    'label' => __('Categories', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_parent_post_id',
                    'label' => __('Listing parent id', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_related_ids',
                    'label' => __('Listing childs', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        if(wdk_get_option('wdk_membership_is_enable_subscriptions')) {
            if(wdk_get_option('wdk_membership_is_subscription_required') || (isset($_POST['subscription_id']) && !empty($_POST['subscription_id']))) {
                $rules [] = array(
                    'field' => 'subscription_id',
                    'label' => __('Subscription', 'wdk-membership'),
                    'rules' => 'required|wdk_membership_subscription_check|wdk_membership_subscription_limit_listings|wdk_membership_subscription_limit_images'
                );
            } else {
                $rules [] = array(
                    'field' => 'subscription_id',
                    'label' => __('Subscription', 'wdk-membership'),
                    'rules' => ''
                );
            }
        }

        foreach($this->data['fields'] as $field)
        {
            if($field->field_type == 'SECTION' || wmvc_show_data('is_visible_dashboard', $field) != 1) continue;
            
            $rule_required = (wmvc_show_data('is_required', $field) == 1) ? 'required' : '';

            if(wmvc_show_data('validation', $field)) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                $rule_required .= wmvc_show_data('validation', $field);
            }

            if(!empty(wmvc_show_data('min_length', $field))) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                
                if(wmvc_show_data('field_type', $field) == "NUMBER") {
                    $rule_required .= "min_number";
                } else {
                    $rule_required .= "min_length";
                }
                $rule_required .= "[".wmvc_show_data('min_length', $field)."]";

            }

            if(!empty(wmvc_show_data('max_length', $field))) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                if(wmvc_show_data('field_type', $field) == "NUMBER") {
                    $rule_required .= "max_number";
                } else {
                    $rule_required .= "max_length";
                }
                $rule_required .= "[".wmvc_show_data('max_length', $field)."]";
            }


            if(isset($_POST['category_id']) && !empty($_POST['category_id'])) {
                if(wdk_depend_is_hidden_field($field->idfield, intval($_POST['category_id']))) {
                    $rule_required = '';
                } 
            }

            $rules[] = 
                array(
                    'field' => 'field_'.$field->idfield,
                    'label' => $field->field_label,
                    'rules' => $rule_required
                );

            if(isset($this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type]))
                $this->data['db_data']['field_'.$field->idfield] = 
                    $this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type];
        }

        $this->data['subscriptions'] = array();
        $this->data['subscriptions_data'] = array();
        
        if(wdk_get_option('wdk_membership_is_enable_subscriptions')){ 
            $this->load->model('subscription_user_m');
            $this->load->model('subscription_m');

            $this->db->select('*');
            $this->db->join($this->subscription_m->_table_name.' ON '.$this->subscription_m->_table_name.'.idsubscription = '.$this->subscription_user_m->_table_name.'.subscription_id');
            $this->db->join($this->db->prefix.'wdk_categories ON '.$this->db->prefix.'wdk_categories.idcategory = '.$this->subscription_m->_table_name.'.category_id', TRUE, 'LEFT');
            $this->db->join($this->db->prefix.'wdk_locations ON '.$this->db->prefix.'wdk_locations.idlocation = '.$this->subscription_m->_table_name.'.location_id', TRUE, 'LEFT');
          
            $this->db->where(array(
                                    '(user_id = \''.get_current_user_id().'\')'=>NULL,
                                    '(status = \'ACTIVE\')'=>NULL,
                                )
                            );
            if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
                $this->db->where(array(
                                        '(date_expire   > \''.current_time( 'mysql' ).'\')'=>NULL,
                                    )
                                );
            }

            if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
                $this->db->limit(1);
                $this->db->offset(0);
            }
            $this->db->order_by('subscription_id DESC');
            $subscriptions = $this->subscription_user_m->get();

            if (count($subscriptions) > 0) {
                $listings_limit_counter = 0 ;
                    
                foreach($subscriptions as $subscription) {
                    $this->data['subscriptions'][wdk_show_data('subscription_id',$subscription,'', TRUE, TRUE)] = wdk_show_data('subscription_id', $subscription,'', TRUE, TRUE)
                                                                                                .', '.wdk_show_data('subscription_name', $subscription,'', TRUE, TRUE)
                                                                                                .', '.wdk_show_data('location_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE).' '. esc_html__('Location', 'wdk-membership')
                                                                                                .', '.wdk_show_data('category_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE).' '. esc_html__('Category', 'wdk-membership')
                                                                                                .'('.wdk_get_date(wdk_show_data('date_expire', $subscription,'', TRUE, TRUE)).')';

                    $this->data['subscriptions_data'][wdk_show_data('subscription_id',$subscription,'', TRUE, TRUE)] = $subscription;
               
                    /* check listings limit on subscription if new listing*/
                    if(!empty($subscription->date_expire) && strtotime($subscription->date_expire) > time()){
                        if(wdk_show_data('listings_limit', $subscription, '0') == '-1')
                            $listings_limit_counter = '-1';
                            
                        if($listings_limit_counter !='-1')
                            $listings_limit_counter += wdk_show_data('listings_limit', $subscription, '0');
                    }
                }


                $this->data['user_have_active'] = $this->subscription_user_m->total(array('is_activated'=>1,'date_expire >' => date('Y-m-d H:i:s')));
                if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && $this->data['user_have_active'] > 1) {
                    add_action('wdk-membership/view/listing_edit/above_form', array($this,'wdk_payments_check_subscription'));
                }

                /* check listings limit on subscription */
                if(empty($listing_post_id)) {
                    $listings_count = $Winter_MVC_WDK->listing_m->total(array(), TRUE, get_current_user_id());
                    if($listings_limit_counter != '-1' && intval($listings_count) >= $listings_limit_counter) {
                        wp_redirect(wdk_dash_url('dash_page=membership'));
                    }
                }
            } else {
                if(wdk_get_option('wdk_membership_is_subscription_required')) {
                    wp_redirect(wdk_dash_url('dash_page=membership'));
                }
            }
        }

        $this->form->add_error_message('wdk_membership_subscription_check', __('Subscription not available for current listing, category,location or expired', 'wdk-membership'));
        $this->form->add_error_message('wdk_membership_subscription_limit_listings', sprintf(__('You reached subscription limit listings, %1$s check subscription details here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'">','</a>'));
        $this->form->add_error_message('wdk_gps_single', __('Gps field is not valid, should be like xx.xxxxxx (between -180 and 180)', 'wdk-membership'));

        if(isset($_POST['subscription_id']) && !empty($_POST['subscription_id']) && isset($this->data['subscriptions_data'][$_POST['subscription_id']])) {
            $this->form->add_error_message('wdk_membership_subscription_limit_images',wdk_sprintf( __('Your subscription don\'t support such many images, %1$s allowed. %2$s Please check details here %3$s', 'wdk-membership'), wdk_show_data('images_limit', $this->data['subscriptions_data'][intval($_POST['subscription_id'])], 0, TRUE, TRUE) ,'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'">','</a>'));
        } else {
            $this->form->add_error_message('wdk_membership_subscription_limit_images', wdk_sprintf(__('Your subscription don\'t support such many images. %1$s Please check details here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'">','</a>'));
        }
        
        if($this->form->run($rules))
        {
            // Save procedure for basic data
    
            if(function_exists('wdk_get_post')) {
                $data = $Winter_MVC_WDK->listing_m->prepare_data(wdk_get_post(), $rules, FALSE);
            } else {
                $data = $Winter_MVC_WDK->listing_m->prepare_data($this->input->post(), $rules);
            }

            // Save standard wp post
            
            if(!isset($data['post_content'])) {
                $data['post_content'] = '';
            }
            
            // Create post object
            $listing_post = array(
                'ID' => $listing_post_id,
                'post_type'     => 'wdk-listing',
                'post_title'    => wp_strip_all_tags( $data['post_title'] ),
                'post_content'  => $data['post_content'],
                'post_status'   => 'publish',
                'post_author'   => get_current_user_id()
            );
            
            // Insert the post into the database
            $id = wp_insert_post( $listing_post );

            // Save our main listing data

            $listing_data = array('post_id' => $id);

            $listing_data_fields = array('category_id', 'location_id', 'address', 'lat', 'lng', 'listing_images', 'listing_plans_documents', 'is_activated', 'listing_parent_post_id','listing_related_ids');
            
            if(wdk_get_option('wdk_membership_is_enable_subscriptions')) {
                $listing_data_fields[] = 'subscription_id';
            }

            foreach($listing_data_fields as $field_name)
            {
                $listing_data[$field_name] = $data[$field_name];
            }
            
            $image_ids = array();
			if(!empty($data['listing_images']))
            	$image_ids = explode(',', $data['listing_images']);

            $listing_data['listing_images_path'] = '';
            $listing_data['listing_images_path_medium'] = '';

            if(is_array($image_ids)) {
                foreach ($image_ids as $image_id) {
                    if(is_numeric($image_id))
                    {
                        $image_path = wp_get_original_image_path( $image_id);
                        if($image_path) {
                            /* path of image */
                            $next_path = str_replace(WP_CONTENT_DIR . '/uploads/','', $image_path);

                            if(!empty($listing_data['listing_images_path']))
                                $listing_data['listing_images_path'] .= ',';

                            $listing_data['listing_images_path'] .= $next_path;
                        }

                        $image_url = wp_get_attachment_image_url($image_id, 'large');
                        if($image_url) {
                            $parsed = parse_url($image_url);
                            $next_path = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
        
                            if(!empty($listing_data['listing_images_path_medium']))
                                $listing_data['listing_images_path_medium'] .= ',';
        
                            $listing_data['listing_images_path_medium'] .= $next_path;
                        }
                    }
                }
            } 

            if(get_option('wdk_auto_approved') && wmvc_show_data('is_activated', $listing_data) == 1) {
                $listing_data['is_approved'] = 1;
            }
            
            /* dates set */
            if(isset($this->data['db_data']['date']))
                $listing_data['date'] = $this->data['db_data']['date'];

            if(wdk_get_option('wdk_membership_is_enable_subscriptions')) {
                if(wmvc_show_data('subscription_id', $listing_data_field, false)) {
                    $subscription = $this->subscription_m->get(wmvc_show_data('subscription_id', $listing_data_field, false), TRUE);
                    if ($subscription) {
                        if(wmvc_show_data('featured_rank', $subscription, false, TRUE, TRUE))
                            $listing_data['rank'] = wmvc_show_data('featured_rank', $subscription, false, TRUE, TRUE);

                        if(wmvc_show_data('is_auto_featured', $subscription, false, TRUE, TRUE))
                            $listing_data['is_featured'] = 1;

                        if(wmvc_show_data('is_auto_approved', $subscription, false, TRUE, TRUE))
                            $listing_data['is_approved'] = 1;
                    }
                } else {
                    unset($listing_data['rank']);
                }
            }

            $listing_data['date_modified'] = date('Y-m-d H:i:s');

            $listing_data['user_id_editor'] = get_current_user_id();

            if(empty($listing_db_data))
            {
                $Winter_MVC_WDK->listing_m->insert($listing_data, NULL);
            }
            else
            {
                $Winter_MVC_WDK->listing_m->insert($listing_data, $id);
            }

            // insert users/agents

            // Save dynamic fields data

            $data['post_id'] = $id;

            if(empty($listingfield_db_data))
            {
                $Winter_MVC_WDK->listingfield_m->insert_custom_fields($this->data['listing_fields'], $data, NULL);
            }
            else
            {
                $Winter_MVC_WDK->listingfield_m->insert_custom_fields($this->data['listing_fields'], $data, $id);
            }

            do_action('wdk-membership/listing/saved', $id, $this->data['db_data']);
            
            /* multi categories / locations */
            $Winter_MVC_WDK->model('categorieslistings_m');
            $Winter_MVC_WDK->model('locationslistings_m');
            $data_other_categories = array();
            if(isset($data['listing_sub_categories']) || is_null($data['listing_sub_categories'])) {
                $Winter_MVC_WDK->categorieslistings_m->delete_where(array('post_id' => $id));
                if(is_array($data['listing_sub_categories']))
                foreach($data['listing_sub_categories'] as $val)
                {
                    $Winter_MVC_WDK->categorieslistings_m->insert(array('post_id' => $id, 'category_id' => $val), NULL);
                    
                    $data_other_categories []=  $val;
                }
            }

            $data_other_locations = array();
            if(isset($data['listing_sub_locations']) || is_null($data['listing_sub_locations'])) {
                $Winter_MVC_WDK->locationslistings_m->delete_where(array('post_id' => $id));
                if(is_array($data['listing_sub_locations']))
                foreach($data['listing_sub_locations'] as $val)
                {
                    $Winter_MVC_WDK->locationslistings_m->insert(array('post_id' => $id, 'location_id' => $val), NULL);
                    $data_other_locations [] =  $val;
                }
            }

            $data_update = array(
                'categories_list'=> '',
                'locations_list'=>''
            );

            if(!empty($data_other_categories)) {
                $data_update['categories_list'] = ','.join(',',$data_other_categories).',';
            }

            if(!empty($data_other_locations)) {
                $data_update['locations_list'] = ','.join(',',$data_other_locations).',';
            }


            if(!empty($data_update))
                $Winter_MVC_WDK->listing_m->insert($data_update, $id);

            if(wdk_get_option('wdk_sub_listings_enable')) {
                /* generate fast childs ids for parents */

                if(isset($listing_data['listing_parent_post_id']) && !empty($listing_data['listing_parent_post_id'])) {

                    $Winter_MVC_WDK->db->select('post_id');
                    $Winter_MVC_WDK->db->order_by('sublisting_order,idlisting');
                    $Winter_MVC_WDK->db->from($Winter_MVC_WDK->listing_m->_table_name);
                    $Winter_MVC_WDK->db->where(array('listing_parent_post_id' => intval($listing_data['listing_parent_post_id'])));
                    $query = $Winter_MVC_WDK->db->get();

                    $listings_childs = '';
                    if ($Winter_MVC_WDK->db->num_rows() > 0)
                        foreach ($Winter_MVC_WDK->db->results() as $listing) {
                            $listings_childs .= $listing->post_id.',';
                        }

                    if(!empty($listings_childs))
                        $listings_childs = substr($listings_childs,0, -1);

                    $Winter_MVC_WDK->listing_m->insert(array('listing_related_ids' => $listings_childs), intval($listing_data['listing_parent_post_id']));
                }

                if(isset($listing_data['listing_related_ids']) && !empty($listing_data['listing_related_ids'])) {

                    $old_childs_ids = wmvc_show_data('listing_related_ids', $this->data['db_data'],'',TRUE, TRUE);
                    $order_index = 0;
                    $listings_childs = '';

                    $old_childs_ids = explode(',', $old_childs_ids);
                    $old_childs_ids = array_flip($old_childs_ids);
                    foreach (explode(',', $listing_data['listing_related_ids']) as $idlisting) {
                        $Winter_MVC_WDK->listing_m->insert(array('listing_parent_post_id' => $listing_post_id, 'sublisting_order'=>$order_index++), intval($idlisting));

                        if(isset($old_childs_ids[$idlisting])) {
                            unset($old_childs_ids[$idlisting]);
                        }
                    }

                    if(!empty($old_childs_ids)) {
                        foreach ($old_childs_ids as $idlisting => $v) {
                            $Winter_MVC_WDK->listing_m->insert(array('listing_parent_post_id' => NULL), intval($idlisting));
                        }
                    }
                }
            }


            // redirect
            if(!empty($id))
            {
                $listing_post_id = $id;
                $listing_post = get_post( $listing_post_id );
                $listing_db_data = $Winter_MVC_WDK->listing_m->get($listing_post_id, TRUE);
                $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($listing_post_id, TRUE);
                $this->data['db_data'] = array_merge((array) $listing_post, 
                                                        (array) $listing_db_data, 
                                                        (array) $listingfield_db_data);

                                                                
                if(isset($_POST['listing_sub_locations'])) {
                    $this->data['db_data']['listing_sub_locations'] = $_POST['listing_sub_locations'];
                }
                
                if(isset($_POST['listing_sub_categories'])) {
                    $this->data['db_data']['listing_sub_categories'] = $_POST['listing_sub_categories'];
                }
                
                foreach($this->data['fields'] as $field)
                {
                    $rules[] = 
                        array(
                            'field' => 'field_'.$field->idfield,
                            'label' => $field->field_label,
                            'rules' => (wmvc_show_data('is_required', $field) == 1) ? 'required' : ''
                        );
        
                    if(isset($this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type]))
                        $this->data['db_data']['field_'.$field->idfield] = 
                            $this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type];
                }
            }
            
            if($listing_data['is_activated'] == 1 && ( !isset($listing_data['is_approved']) || $listing_data['is_approved'] != 1)) {
                /* message data */
                $data_message = array();
                $data_message['user'] = get_userdata( get_current_user_id()); /* user data */
                $data_message['post_id'] = $id;
                $data_message['listing'] = $this->data['db_data']; /* listing data */
                $data_message['post_link'] = get_permalink($id);
                $ret = wdk_mail( get_bloginfo('admin_email'), __('New Listing waiting for approvement', 'wdk-membership'), $data_message, 'new_listing_approve');
            }
                
        }

        
        $this->data['calendar_id'] = NULL;
        if(!empty($listing_post_id) && function_exists('run_wdk_bookings')) {
            global $Winter_MVC_wdk_bookings;
            $Winter_MVC_wdk_bookings->model('calendar_m');
            $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>$listing_post_id), TRUE);
            if($calendar) {
                $this->data['calendar_id'] = $calendar->idcalendar;
            }
        }
        
        $this->load->view('wdk_membership_dash/listings/edit', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_WDK->listing_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_WDK->listing_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        do_action('wdk-membership/listing/removed');
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_WDK->listing_m->check_deletable($post_id))
                $Winter_MVC_WDK->listing_m->insert(array('is_activated'=>NULL), $post_id);
        }

        do_action('wdk-membership/listing/updated');
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_WDK->listing_m->check_deletable($post_id))
                $Winter_MVC_WDK->listing_m->insert(array('is_activated'=>1), $post_id);
        }

        do_action('wdk-membership/listing/updated');
        return true;
    }
    
}
