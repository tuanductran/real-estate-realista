<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_subscriptions extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('subscription_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'subscription';
        $columns = array('idsubscription', 'location_id', 'category_id', 'subscription_name', 'days_limit', 'price', 'search', 'order_by');
        $external_columns = array('location_id', 'category_id', 'subscription_name');

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['order_by']   = array('idsubscription DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idsubscription ASC' => __('ID', 'wdk-membership').' ASC',  );

        $rules = array(
                array(
                    'field' => 'location_id',
                    'label' => __('Location', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'category_id',
                    'label' => __('Category', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->subscription_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_subscriptions_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->subscription_m->total();

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_subscriptions_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['subscriptions'] = $this->subscription_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-membership-subscriptions/index', $this->data);
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('subscription_m');

        $this->subscription_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_m');
    
            $this->subscription_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('subscription_m', $post_id);
            $this->subscription_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('subscription_m', $post_id);
            $this->subscription_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions"));
    }

}
