<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_messages extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
           
	public function index()
	{

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        $this->data['current_user_id'] = get_current_user_id();

        /* [Table Actions Bulk Form] */
        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                break;
                default:
            } 
        }
        /* [End Table Actions Bulk Form] */

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->messages_m->prepare_data($this->input->get(), $rules);

        $this->data['order_by']   = array('idmessage DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idmessage ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'email_sender ASC' => __('Email Title', 'wdk-membership').' ASC',
                                            'email_sender DESC' => __('Email Title', 'wdk-membership').' DESC',
                                            'date ASC' => __('Date', 'wdk-membership').' ASC',
                                            'date DESC' => __('Date', 'wdk-membership').' DESC',);
        /* end filters */

        $controller = 'messages';
        $columns = array('email_sender', 'message');
        $external_columns = array('email_sender', 'message');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_WDK->messages_m->total_merge( array(), TRUE);

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['results'] = $Winter_MVC_WDK->messages_m->get_pagination_merge($per_page, $offset, array(), NULL, TRUE, NULL, function_exists('run_wdk_messages_chat'));

        // Load view
        $this->load->view('wdk_membership_dash/messages/index', $this->data);
    }
           
	public function inbox()
	{

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        $this->data['current_user_id'] = get_current_user_id();

        /* [Table Actions Bulk Form] */
        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                break;
                default:
            } 
        }
        /* [End Table Actions Bulk Form] */

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->messages_m->prepare_data($this->input->get(), $rules);

        $this->data['order_by']   = array('idmessage DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idmessage ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'email_sender ASC' => __('Email Title', 'wdk-membership').' ASC',
                                            'email_sender DESC' => __('Email Title', 'wdk-membership').' DESC',
                                            'date ASC' => __('Date', 'wdk-membership').' ASC',
                                            'date DESC' => __('Date', 'wdk-membership').' DESC',);
        /* end filters */

        $controller = 'messages';
        $columns = array('email_sender', 'message');
        $external_columns = array('email_sender', 'message');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_WDK->messages_m->total( array(), TRUE);

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['results'] = $Winter_MVC_WDK->messages_m->get_pagination($per_page, $offset, array(), NULL, TRUE, NULL, function_exists('run_wdk_messages_chat'));

        // Load view
        $this->load->view('wdk_membership_dash/messages/inbox', $this->data);
    }

	public function outbox()
	{

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        $this->data['current_user_id'] = get_current_user_id();

        /* [Table Actions Bulk Form] */
        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                break;
                default:
            } 
        }
        /* [End Table Actions Bulk Form] */

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->messages_m->prepare_data($this->input->get(), $rules);

        $this->data['order_by']   = array('idmessage DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idmessage ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'email_sender ASC' => __('Email Title', 'wdk-membership').' ASC',
                                            'email_sender DESC' => __('Email Title', 'wdk-membership').' DESC',
                                            'date ASC' => __('Date', 'wdk-membership').' ASC',
                                            'date DESC' => __('Date', 'wdk-membership').' DESC',);
        /* end filters */

        $controller = 'messages';
        $columns = array('email_sender', 'message');
        $external_columns = array('email_sender', 'message');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_WDK->messages_m->total_outbox( array(), TRUE);

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_messages_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['results'] = $Winter_MVC_WDK->messages_m->get_pagination_outbox($per_page, $offset, array(), NULL, TRUE, NULL, function_exists('run_wdk_messages_chat'));

        // Load view
        $this->load->view('wdk_membership_dash/messages/outbox', $this->data);
    }

    public function view()
	{
        global $Winter_MVC_WDK;
        
        $Winter_MVC_WDK->model('messages_m');

       $id = $this->input->post_get('id');

        if(function_exists('wdk_access_check'))
            wdk_access_check('messages_m', $id, NULL, 'view');

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_WDK->messages_m->fields_list_dash_view;

        $this->data['user_sender'] = NULL;
        
        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_WDK->messages_m->get($id, true);
            $this->data['user_sender'] = wdk_get_user_data(wmvc_show_data('user_id_sender',$this->data['db_data']));
        } else {
            //unset($this->data['fields']['1']);
        }
        
        // Load view
        $this->load->view('wdk_membership_dash/messages/view', $this->data);
    }

    public function edit()
	{
        global $Winter_MVC_WDK;
        
        $Winter_MVC_WDK->model('messages_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('messages_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_WDK->messages_m->fields_list_dash;

        $this->data['user_sender'] = NULL;
        
        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_WDK->messages_m->get($id, true);
            $this->data['user_sender'] = wdk_get_user_data(wmvc_show_data('user_id_sender',$this->data['db_data']));
        } else {
            //unset($this->data['fields']['1']);
        }

        $Winter_MVC_WDK->messages_m->_timestamps = false;
        $Winter_MVC_WDK->messages_m->insert(array('is_readed'=>1), $id);
        
        // Load view
        $this->load->view('wdk_membership_dash/messages/edit', $this->data);
    }

    public function chat()
	{
        if(!function_exists('run_wdk_messages_chat')) {
            // Load view
            $this->data['title'] = __('Messages Chat Addon Error', 'wdk-membership');
            $this->data['message'] = __('Messages Chat Addon is not enabled', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_WDK, $Winter_MVC_wdk_messages_chat;
        
        $Winter_MVC_WDK->model('messages_m');
        $Winter_MVC_wdk_messages_chat->model('messageschat_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('messageschat_m', $id);
 
        $this->data['db_data'] = NULL;
        $this->data['header_title'] = __('Messages Chat', 'wdk-membership');
        $this->data['header_icon_url'] = "";
        $this->data['header_icon_src'] = '';

        $this->data['messages'] = NULL;
        $this->data['chats'] = NULL;
        $this->data['current_user_id'] = get_current_user_id();

        $Winter_MVC_WDK->db->where(array('(user_id_sender != 0 AND user_id_sender IS NOT NULL)'=>NULL));
        $this->data['chats'] = $Winter_MVC_WDK->messages_m->get_pagination_merge(50, 0, array(), NULL, TRUE, NULL, true);
       
        if(empty($id) && $this->data['chats']) {
            $id = current($this->data['chats'])->idmessage;
        }

        if(!empty($id)) {
            $Winter_MVC_wdk_messages_chat->messageschat_m->do_readed_notified($id);
            $this->data['messages'] = $Winter_MVC_wdk_messages_chat->messageschat_m->get_pagination($id, 50);
            $this->data['messages'] = array_reverse( $this->data['messages']);
        }

        if(!empty($id))
            $this->data['db_data'] = $Winter_MVC_WDK->messages_m->get($id, true);

        if($this->data['db_data']) {
            $Winter_MVC_WDK->messages_m->_timestamps = false;
            $Winter_MVC_WDK->messages_m->insert(array('is_readed'=>1), $id);
        }

        if(wmvc_show_data('user_id_sender',$this->data['db_data']) != get_current_user_id()) {
            $userdata = wdk_get_user_data(wmvc_show_data('user_id_sender',$this->data['db_data']));

            $this->data['header_title'] = wdk_get_user_field(wmvc_show_data('user_id', $userdata), 'display_name');
            $this->data['header_icon_url'] = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
            $this->data['header_icon_src'] = (!empty($userdata)) ? $userdata['avatar'] : '#';

        } else {
            if(wmvc_show_data('post_id',$this->data['db_data']) && wdk_field_value('user_id_editor', wmvc_show_data('post_id',$this->data['db_data']))) {
                $userdata = wdk_get_user_data(wdk_field_value('user_id_editor', wmvc_show_data('post_id',$this->data['db_data'])));
                $this->data['header_title'] = wdk_get_user_field(wmvc_show_data('user_id', $userdata), 'display_name');
                $this->data['header_icon_url'] = (!empty($userdata)) ? wdk_generate_profile_permalink($userdata['userdata']) : '#';
                $this->data['header_icon_src'] = (!empty($userdata)) ? $userdata['avatar'] : '#';
            }
        }
        
        // Load view
        $this->load->view('wdk_membership_dash/messages/chat', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_WDK->messages_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_WDK->messages_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        $Winter_MVC_WDK->messages_m->_timestamps = false;
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_WDK->messages_m->check_deletable($post_id))
                $Winter_MVC_WDK->messages_m->insert(array('is_readed'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('messages_m');
        $Winter_MVC_WDK->messages_m->_timestamps = false;
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_WDK->messages_m->check_deletable($post_id))
                $Winter_MVC_WDK->messages_m->insert(array('is_readed'=>1), $post_id);
        }
        return true;
    }
    
}
