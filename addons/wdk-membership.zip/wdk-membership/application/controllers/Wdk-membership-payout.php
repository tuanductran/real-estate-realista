<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_payout extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
           
	public function index()
	{
        global $Winter_MVC_wdk_bookings;
        global $Winter_MVC_WDK;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->model('reportdata_m');
        $Winter_MVC_wdk_bookings->model('report_m');

        $this->data['current_user_id'] = get_current_user_id();

        $owner = get_user_by('id', $this->data['current_user_id']);

        $this->data['owner'] = $owner;

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_bookings->reportdata_m->prepare_data($this->input->get(), $rules);

        $this->data['order_by']   = array('idmessage DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idmessage ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'email_sender ASC' => __('Email Title', 'wdk-membership').' ASC',
                                            'email_sender DESC' => __('Email Title', 'wdk-membership').' DESC',
                                            'date ASC' => __('Date', 'wdk-membership').' ASC',
                                            'date DESC' => __('Date', 'wdk-membership').' DESC',);
        /* end filters */

        $controller = 'reportdata';
        $columns = array('email_sender', 'message');
        $external_columns = array('email_sender', 'message');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_wdk_bookings->reportdata_m->total( array('owner_email' => $owner->user_email), 'report_id');

        //echo($this->db->last_query());

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['results'] = $Winter_MVC_wdk_bookings->reportdata_m->get_pagination($per_page, $offset, array('owner_email' => $owner->user_email), NULL, 'report_id');

        $results_for_calc = $Winter_MVC_wdk_bookings->reportdata_m->get_pagination(NULL, NULL, array('owner_email' => $owner->user_email), NULL, 'report_id');

        $this->data['total_paid'] = 0;
        $this->data['total_remaining'] = 0;

        $this->data['currency_code'] = '';
        if(isset($results_for_calc[0]))
            $this->data['currency_code'] = $results_for_calc[0]->currency_code;

        foreach($results_for_calc as $report)
        {
            if($report->is_payout)
            {
                // Total paid calculation
                $this->data['total_paid'] += (100-$report->fee_percentage)/100*$report->total_price_net_sum;
            }
            else
            {
                // Remaining payment calculation
                $this->data['total_remaining'] += (100-$report->fee_percentage)/100*$report->total_price_net_sum;
            }
        }

        // Load view
        $this->load->view('wdk_membership_dash/payout/index', $this->data);
    }
    
}
