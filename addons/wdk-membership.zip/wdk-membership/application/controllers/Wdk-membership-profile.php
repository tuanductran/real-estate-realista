<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_profile extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('user_m');

        $this->data['current_user'] = wp_get_current_user();
        $this->data['form'] = &$this->form;
        $this->data['credentials_updated'] = false;

        $rules = array(
                /*array(
                    'field' => 'email',
                    'label' => __('Email', 'wdk-membership'),
                    'rules' => 'required|valid_email|email_unique'
                ),*/
                array(
                    'field' => 'first-name',
                    'label' => __('First name', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'last-name',
                    'label' => __('Last name', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'description',
                    'label' => __('Desciption', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'pass1',
                    'label' => __('Password', 'wdk-membership'),
                    'rules' => 'password_double|min_length_8'
                ),
                array(
                    'field' => 'pass2',
                    'label' => __('Password2', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_WDK->user_m->prepare_data($this->input->post(), $rules);

        /* Custom Validation */
        function is_email_unique($email)
        {
            if( email_exists( $email ) && ( email_exists( $email ) != wp_get_current_user()->ID))
                return FALSE;

            return TRUE;
        }
        $this->form->add_error_message('email_unique','Email is already exists');

        function is_password_double($string)
        {
            if ( !empty($_POST['pass1'] ) || !empty( $_POST['pass2'] ) ) {

                if ($_POST['pass1'] !== $_POST['pass2']) {
                    return FALSE;
                }
            }

            return TRUE;
        }

        $this->form->add_error_message('password_double','Password should be same');

        function is_min_length_8($string)
        {
            if (!empty($string) && strlen($string)<8) {
                return FALSE;
            }

            return TRUE;
        }
        $this->form->add_error_message('min_length_8','Password min should have 8 characters');
        /* End Custom Validation */
        wp_set_current_user( $this->data['current_user']->ID);
        if($this->form->run($rules))
        {
            
            $data = $Winter_MVC_WDK->user_m->prepare_data($this->input->post(), $rules);
            /* Update profile fields */
            $display_name = false;
            /*
            if ( isset( $data['email']) && !empty( $data['email'] ) && email_exists( $data['email'] ) != wp_get_current_user()->ID ){
                $this->data['credentials_updated'] = true;
                wp_update_user( array ('ID' => $this->data['current_user']->ID, 'user_email' => sanitize_email($data['email'] )) );
            }*/

            if ( isset( $data['pass1']) && !empty( $data['pass1'] ) ){
               // $this->data['credentials_updated'] = true;
                wp_set_password(trim( $data['pass1'] ), $this->data['current_user']->ID);

                wp_set_current_user($this->data['current_user']->ID, $this->data['current_user']->user_login );
                wp_set_auth_cookie( $this->data['current_user']->ID);
            }

            if ( isset( $data['first-name']) && !empty( $data['first-name'] ) ){
                $display_name = esc_attr($data['first-name']);
                update_user_meta( $this->data['current_user']->ID, 'first_name', esc_attr( $data['first-name'] ) );
            }

            if ( isset( $data['last-name']) && !empty( $data['last-name'] ) ){
                $display_name .= ' ' . esc_attr( $data['last-name'] );
                update_user_meta( $this->data['current_user']->ID, 'last', esc_attr( $data['last-name'] ) );
                update_user_meta( $this->data['current_user']->ID, 'last-name', esc_attr( $data['last-name'] ) );
            }

            if ( isset( $data['description']) && !empty( $data['description'] ) ){
                update_user_meta( $this->data['current_user']->ID, 'description', esc_html( $data['description'] ) );
            }

            if ( $display_name ) {
                wp_update_user( array ('ID' => $this->data['current_user']->ID, 'display_name' => esc_attr( $display_name ) ) );
                $this->data['current_user']->display_name = $display_name;
            }

            /* if user credentials udpated, auto relogin*/
            if( $this->data['credentials_updated'] ) {
                $login_link = wp_login_url();
                if(get_option('wdk_membership_login_page')){
                    $login_link = get_permalink(get_option('wdk_membership_login_page'));
                } 
                echo '<script> setTimeout(function(){document.location.href = "'.$login_link.'"},5000)</script>'; 
            }

            // Let plugins hook in, like ACF who is handling the profile picture all by itself. Got to love the Elliot
            do_action('edit_user_profile_update', $this->data['current_user']->ID);

        }

        $this->load->view('wdk_membership_dash/profile/index', $this->data);
    }

	public function remove()
	{
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('user_m');

        $this->data['current_user'] = wp_get_current_user();
        $this->data['form'] = &$this->form;

        
        function is_username_check($string)
        {
            if ( $string == get_the_author_meta( 'user_login', wp_get_current_user()->ID )) {
                return TRUE;
            }
            return FALSE;
        }
        
    

        $rules = array(
                array(
                    'field' => 'username',
                    'label' => __('Username', 'wdk-membership'),
                    'rules' => 'required|username_check'
                )
        );

        $this->data['db_data'] = $Winter_MVC_WDK->user_m->prepare_data($this->input->post(), $rules);

        wp_set_current_user( $this->data['current_user']->ID);

        $this->form->add_error_message('username_check','Username is wrong');
        if($this->form->run($rules))
        {
            // Check _wpnonce
            check_admin_referer( 'remove-user_'.esc_attr($this->data['current_user']->ID), '_wpnonce' );

            /* remove user data */
            $Winter_MVC_WDK->user_m->remove_user_data($this->data['current_user']->ID);

            wp_delete_user($this->data['current_user']->ID);
            do_action('wdk-membership/profile/remove', $this->data['current_user']->ID);

            wp_logout();
            wp_redirect(wdk_login_url()); exit();
        }

        $this->load->view('wdk_membership_dash/profile/remove', $this->data);
    }

}
