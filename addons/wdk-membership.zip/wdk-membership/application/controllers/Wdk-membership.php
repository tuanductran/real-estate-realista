<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_index extends Winter_MVC_Controller {
    public $import_log = '';
    
	public function __construct(){
		parent::__construct();
	}
    
    // Edit listing method
	public function index()
	{
        $this->load->model('settings_m');
      
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->settings_m->fields_list;

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
    
            $data = $this->settings_m->prepare_data($this->input->post(), array_merge($this->data['fields'], 
                                                                                        array_keys($this->data['fields'][5]['values']), 
                                                                                        array_keys($this->data['fields'][6]['values'])));

            // Save standard wp post

            foreach($data as $key => $val)
            {
                update_option( $key, $val, TRUE);
            }         

            // redirect
            if(empty($listing_post_id) && !empty($id))
            {
                //wp_redirect(admin_url("admin.php?page=wdk_settings&is_updated=true"));
                exit;
            }
                
        }

        // fetch data, after update/insert to get updated last data
        $fields_data = $this->settings_m->get();

        foreach($fields_data as $field)
        {
            $this->data['db_data'][$field->option_name] = $field->option_value;
        }

        $this->load->view('wdk_membership/index', $this->data);
    }


          
    // Import demo data listing method
	public function import_demo()
	{
        $this->data['installed'] = false;

        global $wdk_membership_user_fields_list, $wdk_membership_user_types;

        $this->data['db_data'] = NULL;
        $this->data['fields'] = array( 
            array('field' => 'import_settings', 'field_label' => __('Default Settings', 'wdk-membership'), 'hint' => __('Import default config of settings', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_page_dash', 'field_label' => __('Dash Page', 'wdk-membership'), 'hint' => __('Import demo Dash Page', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_page_login', 'field_label' => __('Login Page', 'wdk-membership'), 'hint' => __('Import demo Login Page', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_page_register', 'field_label' => __('Register Page', 'wdk-membership'), 'hint' => __('Import demo Register Page', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_page_profiles_list', 'field_label' => __('Profiles List Page', 'wdk-membership'), 'hint' => __('Import demo Profiles List Page', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_page_profile', 'field_label' => __('Profile Info Page', 'wdk-membership'), 'hint' => __('Import demo Profile Page', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
            array('field' => 'import_demo_content', 'field_label' => __('Subscription Page', 'wdk-membership'), 'hint' => __('Import demo page and content', 'wdk-membership'), 'field_type' => 'CHECKBOX', 'rules' => ''),
        );

        $this->data['form'] = &$this->form;

        ini_set('max_execution_time', 900);           
        
        foreach($this->data['fields'] as $field)
        {
            $this->data['db_data'][$field['field']] = 1;
        }
        
        if((get_option('wdk_membership_dash_page')) && get_post_status(get_option('wdk_membership_dash_page')) =='publish'){
            $this->data['db_data']['import_page_dash'] = 0;
        }

        if((get_option('wdk_membership_login_page')) && get_post_status(get_option('wdk_membership_login_page')) == 'publish'){
            $this->data['db_data']['import_page_login'] = 0;
        }

        if((get_option('wdk_membership_register_page')) && get_post_status(get_option('wdk_membership_register_page')) == 'publish'){
            $this->data['db_data']['import_page_register'] = 0;
        }

        if((get_option('wdk_membership_profile_search_page')) && get_post_status(get_option('wdk_membership_profile_search_page')) == 'publish'){
            $this->data['db_data']['import_page_profiles_list'] = 0;
        }


        $this->data['import_log'] = '';
        $rules = array(
            array(
                'field' => 'import_settings',
                'label' => __('Settings', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_page_dash',
                'label' => __('Dash Page', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_page_login',
                'label' => __('Login Page', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_page_register',
                'label' => __('Dash Register Page', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_page_profiles_list',
                'label' => __('Profiles List Page', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_page_profile',
                'label' => __('Profile Info Page', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'import_demo_content',
                'label' => __('Subscription page and demo content import', 'wdk-membership'),
                'rules' => ''
            ),
          
        );    
        $this->data['required_plugins'] = false;
        
        $plugin = 'elementor/elementor.php';
        if (in_array( $plugin, apply_filters( 'active_plugins', get_option( 'active_plugins' ))) && !class_exists('Elementor\Plugin') ) {
            $this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Your Elementor Plugin is not fully active, usually this happen because of old PHP version on server, in such case eventually you can try older Elementor Version or Update PHP on your server').'</div>';
            $this->data['required_plugins'] = true;
        }

        if(!$this->data['required_plugins'])
        if($this->form->run($rules))
        {
            // Save procedure for basic data
            $data = $this->input->post();
            
            if( !empty($data['import_settings'])) {
                $this->import_settings();
            }
            
            if( !empty($data['import_page_dash'])) {
                $this->create_page('page-dash.json', __('Dash', 'wdk-membership'), 'wdk_membership_dash_page');
            }
            
            if( !empty($data['import_page_login'])) {
                $this->create_page('page-login.json', __('Login', 'wdk-membership'), 'wdk_membership_login_page');
            }
            
            if( !empty($data['import_page_register'])) {
                $this->create_page('page-register.json', __('Register', 'wdk-membership'), 'wdk_membership_register_page');
            }
            
            if( !empty($data['import_page_profiles_list'])) {
                $page_id = $this->create_page('page-profiles.json', __('Profiles', 'wdk-membership'), 'wdk_membership_profile_search_page', __('Profiles List', 'wdk-membership'));

                if( $page_id){
                    $menu_id = NULL;

                    $locations = get_nav_menu_locations();
                    if(isset($locations['main_menu'])) {
                        $menu_id = $locations['main_menu'];
                    }

                    if (empty($menu_id)) {
                        if($menus = wp_get_nav_menus())
                            $menu_id =(int)$menus[0]->term_id;
                    }

                    if ($menu_id) {
                        $itemData =  array(
                            'menu-item-object-id' => $page_id,
                            'menu-item-title' =>  esc_html__('Profiles', 'wdk-membership'),
                            'menu-item-parent-id' => 0,
                            'menu-item-position' => 11,
                            'menu-item-object' => 'page',
                            'menu-item-type' => 'post_type',
                            'menu-item-status'    => 'publish'
                        );
                        
                        wp_update_nav_menu_item($menu_id, 0, $itemData);
                    }
                }
            }
            
            if( !empty($data['import_page_profile'])) {
                $this->create_page('page-profile.json', __('Profile', 'wdk-membership'), 'wdk_membership_profile_preview_page',__('Profile Info', 'wdk-membership'));
            }
            
            if( !empty($data['import_demo_content'])) {
                $this->subscription_import();
            }

            $this->replace_content_data();

            update_option('wdk_membership_installed', '1');

        } 
        $this->load->view('wdk_membership/import_demo', $this->data);
    }

    public function api_import()
	{
        ini_set('max_execution_time', 900);
        $this->data['import_log'] = '';
        
        $this->import_settings();
        $this->create_page('page-dash.json', __('Dash', 'wdk-membership'), 'wdk_membership_dash_page');
        $this->create_page('page-login.json', __('Login', 'wdk-membership'), 'wdk_membership_login_page');
        $this->create_page('page-register.json', __('Register', 'wdk-membership'), 'wdk_membership_register_page');
        $page_id = $this->create_page('page-profiles.json', __('Profiles', 'wdk-membership'), 'wdk_membership_profile_search_page', __('Profiles List', 'wdk-membership'));
        if( $page_id){

            $menu_id = NULL;
            $locations = get_nav_menu_locations();
            if(isset($locations['main_menu'])) {
                $menu_id = $locations['main_menu'];
            }

            if (empty($menu_id)) {
                if($menus = wp_get_nav_menus())
                    $menu_id =(int)$menus[0]->term_id;
            }

            if ($menu_id) {
                $itemData =  array(
                    'menu-item-object-id' => $page_id,
                    'menu-item-title' =>  esc_html__('Profiles', 'wdk-membership'),
                    'menu-item-parent-id' => 0,
                    'menu-item-position' => 11,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status'    => 'publish'
                );
                wp_update_nav_menu_item($menu_id, 0, $itemData);
            }
        }
        
        $this->create_page('page-profile.json', __('Profile', 'wdk-membership'), 'wdk_membership_profile_preview_page',__('Profile Info', 'wdk-membership'));

        $this->subscription_import();

        $this->replace_content_data();
        
        return true;
    }

    private function subscription_import() {

        $this->load->model('subscription_m');

        if (!$this->subscription_m->get()) {

        /* remove data */
            $this->db->delete($this->subscription_m->_table_name);
            /* end remove data */

            /* reset autoincrement */
            $this->db->query('TRUNCATE TABLE `'.$this->subscription_m->_table_name.'`');

            $demo_data = array();
            $demo_data[] = array(
                'subscription_name' => esc_html__('FREE MEMBERSHIP', 'wdk-subscription'),
                'days_limit' => '30',
                'is_auto_featured' => 0,
                'is_auto_approved' => 1,
                'price' => '0',
                'listings_limit' => '1',
                'images_limit' => '2',
                'featured_rank' => 0,
                'is_view_private_listings' => 0,
            );
            $demo_data[] = array(
                'subscription_name' => esc_html__('SILVER MEMBERSHIP', 'wdk-subscription'),
                'days_limit' => '120',
                'is_auto_featured' => 0,
                'is_auto_approved' => 1,
                'price' => '100',
                'listings_limit' => '10',
                'images_limit' => '5',
                'featured_rank' => '1',
                'is_view_private_listings' => '1',
            );
            $demo_data[] = array(
                'subscription_name' => esc_html__('GOLD MEMBERSHIP', 'wdk-subscription'),
                'days_limit' => '365',
                'is_auto_featured' => 1,
                'is_auto_approved' => 1,
                'price' => '250',
                'listings_limit' => '-1',
                'images_limit' => '-1',
                'featured_rank' => '2',
                'is_view_private_listings' => '1',
            );
           
            foreach ($demo_data as $data) {
                if(class_exists( 'WooCommerce' )) {
                    $post_args = array(
                        'post_author' => get_current_user_id(), // The user's ID
                        'post_title' => wmvc_show_data('subscription_name',$data), // The product's Title
                        'post_type' => 'product',
                        'post_status' => 'publish' // This could also be $data['status'];
                    );
                
                    $post_id = wp_insert_post( $post_args );
                
                    // If the post was created okay, let's try update the WooCommerce values.
                    if ( ! empty( $post_id ) && function_exists( 'wc_get_product' ) ) {
                        $product = wc_get_product( $post_id );
                        $product->set_virtual(true);
                        $product->set_downloadable(true);
                        $product->set_sold_individually(true);
                        $product->set_sku( 'wdk-subscription-' . $post_id ); // Generate a SKU with a prefix. (i.e. 'pre-123') 
                        $product->set_regular_price(  wmvc_show_data('price',$data)); // Be sure to use the correct decimal price.
                        // $product->set_category_ids( array( 16, 17 ) ); // Set multiple category ID's.
                        $product->save(); // Save/update the WooCommerce order object.

                        /* attached image */
                        $wdk_attach_id = wmvc_add_wp_image(WDK_MEMBERSHIP_PATH.'public/img/package-icon.jpg');
                        set_post_thumbnail( $post_id, $wdk_attach_id );

                        $terms = array( 'exclude-from-catalog', 'exclude-from-search' );
                        wp_set_object_terms( $post_id, $terms, 'product_visibility' );
                    }
                    
                   $data['woocommerce_product_id'] = $post_id;
                }
                $this->subscription_m->insert($data, null);
            }
        }
        /* settings */


        /* add new page subscriptions */
        $page_id = $this->create_page('page-subscriptions.json', __('Subscriptions', 'wdk-subscription'));

        if( $page_id){

            $menu_id = NULL;
            $locations = get_nav_menu_locations();
            if(isset($locations['main_menu'])) {
                $menu_id = $locations['main_menu'];
            }

            if (empty($menu_id)) {
                if($menus = wp_get_nav_menus())
                    $menu_id =(int)$menus[0]->term_id;
            }

            $items = wp_get_nav_menu_items($menu_id);
            $parent_id = 0;
            if($items) foreach ($items as $item) {
                if($item->post_title == __('Pages', 'wdk-subscription')) {
                    $parent_id = $item->ID;
                    break;
                }
            }
            
            // first menu defined by template
            if (!empty($menu_id)) {
                $itemData =  array(
                    'menu-item-object-id' => $page_id,
                    'menu-item-title' =>  esc_html__('Subscriptions', 'wdk-subscription'),
                    'menu-item-parent-id' => $parent_id,
                    'menu-item-position' => 10,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status'    => 'publish'
                );
                wp_update_nav_menu_item($menu_id, 0, $itemData);
            }
        }
    }

    public function import_settings() {


        update_option( 'wdk_membership_adminbar_disabled', '1' );
        
        global $wdk_membership_user_fields_list, $wdk_membership_user_types;
        
        foreach($wdk_membership_user_fields_list as $field_id => $field_name) {
            update_option('wdk_membership_custom_field_'.$field_id.'_enable', '1');
        }
        
        foreach($wdk_membership_user_types as $type_id => $type_name) {
            update_option('wdk_membership_user_type_'.$type_id.'_enable', '1');
        }
        
        update_option( 'wdk_membership_register_type', 'wdk_owner' );
        update_option( 'wdk_membership_register_show_user_select', '1' );

        $this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.esc_html__('Settings imported', 'wdk-membership').'</div>';
        return true;
    }

    /* add demo listing preview page */
    public function create_page($layout_json, $page_title = "New Page", $option = '', $custom_message_title = '') {
        $page_title_message = $page_title;
        if(!empty($custom_message_title)){
            $page_title_message = $custom_message_title;
        }

        if(!empty($option) && (get_option($option)) && get_post_status(get_option($option)) =='publish'){
          //  $this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.$page_title_message.' '.esc_html__('Page already exists', 'wdk-membership').'</div>';
           // return false;
        }

        add_action('wdk-membership/elementor-elements/register_widget', function($self){
            $self->add_widget('WdkMembership\Elementor\Extensions\WdkMembershipContactFormExt');
        });
                
        add_action('wdk-membership/elementor-elements/register_widget', function(){
            add_action('eli/includes', function(){
                require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/class-contact-form.php';
            });

            add_action('eli/register_widget', function(){
                $object = new WdkMembership\Elementor\Extensions\WdkMembershipContactFormExt();
                \Elementor\Plugin::instance()->widgets_manager->register( $object );
            });
        });

        add_action('wdk-membership/elementor-elements/register_widget', function($self){
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipContent');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipMenu');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileListings');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileContent');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileContent');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipLoginForm');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipRegisterForm');
            $self->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipBreadcrumb');
        });

        // Import elementor templates
        $page = $this->generate_page($page_title, '', 'elementor_canvas');
        $this->elementor_assign($page->ID, $layout_json);

        // Assign page.
        if($page && !empty($option))
            update_option( $option, $page->ID, TRUE);
        
        $this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.$page_title_message.' '.esc_html__('Page imported', 'wdk-membership').'</div>';

        return $page->ID;
    }

    /* Create Page */
    private function generate_page($post_title, $post_content = '', $post_template = NULL, $post_parent=0)
    {
        $post = wdk_page_by_title($post_title, 'OBJECT', 'page' );
        
        $post_id = NULL;
        
        // Delete posts and rebuild
        if(!empty($post))
        {
            wp_delete_post($post->ID, true);
            $post=NULL;
        }
        
        if(!empty($post))
        $post_id   = $post->ID;

        if(empty($post_id))
        {
            $error_obj = NULL;
            $post_insert = array(
                'post_title'    => wp_strip_all_tags( $post_title ),
                'post_content'  => $post_content,
                'post_status'   => 'publish',
                'post_type'     => 'page',
                'post_author'   => get_current_user_id(),
                'post_category' => array(1,2),
                'page_template' => $post_template,
                'post_parent'   => $post_parent
            );
            $post_id = wp_insert_post( $post_insert, $error_obj );
        }

        $post_insert = get_post( $post_id );
        
        return $post_insert;
    }

    /* Elementor Import Template */
    public function elementor_assign($page_id, $json_template_name = '')
    {
        $file = false;

        if(is_child_theme() && file_exists(get_stylesheet_directory().'/elementor-data/wdk-membership/'.$json_template_name))
        {
            $file = get_stylesheet_directory().'/elementor-data/wdk-membership/'.$json_template_name;
        }
        elseif(file_exists(get_template_directory().'/demo-data/wdk-membership/'.$json_template_name))
        {
            $file = get_template_directory().'/demo-data/wdk-membership/'.$json_template_name;
        }
        elseif(file_exists( WDK_MEMBERSHIP_PATH. '/demo-data/'.$json_template_name))
        {
            $file = WDK_MEMBERSHIP_PATH.'demo-data/'.$json_template_name;
        }
        
        if(!$file || !class_exists('Elementor\Plugin'))
        {
            return false;
        }

        $page_template =  get_page_template_slug( $page_id );

        add_post_meta( $page_id, '_elementor_edit_mode', 'builder' );

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            WP_Filesystem();
        }

        $string =  $wp_filesystem->get_contents($file);
        
        $json_template = json_decode($string, true);

        $elements = $json_template['content'];

        $data = array(
            'elements' => $elements,
            'settings' => array('post_status'=>'autosave', 'template'=>$page_template),
        );   
        // @codingStandardsIgnoreStart
        $document = Elementor\Plugin::$instance->documents->get( $page_id, false );
        // @codingStandardsIgnoreEnd
        return $document->save( $data );
    }

    function replace_content_data() {
        /* Replace Links */
        /* login */
        $from = 'https://www.wpdirectorykit.com/nexproperty/wp-admin/wp-login.php/';
        $to = get_admin_url();
        $this->replace_meta($from, $to);
        $from = 'https://www.wpdirectorykit.com/nexproperty/wp-admin/wp-login.php';
        $to = get_admin_url();
        $this->replace_meta($from, $to);
        
        /* login */
        $from = 'https://www.wpdirectorykit.com/nexproperty/login/';
        $to = get_the_permalink(get_option('wdk_membership_login_page'));
        $this->replace_meta($from, $to);
        
        $from = 'https://www.wpdirectorykit.com/nexproperty/login';
        $to = get_the_permalink(get_option('wdk_membership_login_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty/register/';
        $to = get_the_permalink(get_option('wdk_membership_register_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty/register';
        $to = get_the_permalink(get_option('wdk_membership_register_page'));
        $this->replace_meta($from, $to);

        $from = 'https://www.wpdirectorykit.com/nexproperty';
        $to = get_home_url();
        $this->replace_meta($from, $to);
        
        /* homepage */
        $from = '2020';
        $to = date('Y');
        $this->replace_meta($from, $to);

        return true;
    }

    private function replace_meta($from = '', $to = '') {
        global $wpdb;
        // @codingStandardsIgnoreStart cannot use `$wpdb->prepare` because it remove's the backslashes
        $rows_affected = $wpdb->query(
            "UPDATE ".esc_sql($wpdb->postmeta)." " .
            "SET `meta_value` = REPLACE(`meta_value`, '" . str_replace( '/', '\\\/', esc_sql($from) ) . "', '" . str_replace( '/', '\\\/', esc_sql($to) ) . "') " .
            "WHERE `meta_key` = '_elementor_data' AND `meta_value` LIKE '[%' ;" );
        /* end login */
    }
    
}