<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_booking_reservations extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

        /* booking */
	public function index()
	{

        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {
            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }
        /* [End Table Actions Bulk Form] */

        /* [Search Form] */

        $controller = 'reservation';
        $columns = array('idreservation', 'search', 'order_by', 'post_title', $Winter_MVC_wdk_bookings->db->prefix.'wdk_listings.post_id');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idreservation DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idreservation ASC' => __('ID', 'wdk-membership').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_bookings->reservation_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_wdk_bookings->reservation_m->total(array(), TRUE, get_current_user_id());

        $current_page = 1;

        if(isset($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);

        $this->data['wmvc_paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

  
        $this->data['reservations'] = $Winter_MVC_wdk_bookings->reservation_m->get_pagination($per_page, $offset, array(), NULL, TRUE, get_current_user_id());

        // Load view
        $this->load->view('wdk_membership_dash/bookings/reservations', $this->data);
    }


     // Edit listing method
	public function edit()
	{
        
        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }
        
        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {
            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->model('price_m');

        $id = $this->input->post_get('id');

        if(function_exists('wdk_access_check'))
            wdk_access_check('reservation_m', $id, NULL, 'dash_edit_reservation');
            
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['price_reservation'] = NULL;
        $this->data['url_pay'] = NULL;
        $this->data['user_data_owner'] = NULL;

        $this->data['fields'] = $Winter_MVC_wdk_bookings->reservation_m->fields_list_calendar;

        if(wdk_get_option('wdk_bookings_enable_woocommerce_payments'))
            $this->data['fields'] = $Winter_MVC_wdk_bookings->reservation_m->fields_list_calendar_woo_enabled;

        $this->data['fields'][0]['field_type'] = 'LISTING_USER';
        $this->data['fields'][4]['field_type'] = 'USERS_READONLY';
        $this->data['fields'][4]['rules'] = '';

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-membership'));
        $this->form->add_error_message('reservation_date_exists', __('Date already in use for this Listing/Post', 'wdk-membership'));
        $this->form->add_error_message('reservation_date_range', __('\'Date to\' can\'t be after \'date from\'', 'wdk-membership'));
        $this->form->add_error_message('reservation_date_availability', __('Date not available', 'wdk-membership'));
        $this->form->add_error_message('reservation_calendar_availability', __('Calendar not available, for this listing', 'wdk-membership'));
        $this->form->add_error_message('reservation_check_availability', __('Dates already booked', 'wdk-membership'));
        
        if($this->form->run($this->data['fields']))
        {

            // Save procedure for basic data
            $data = $Winter_MVC_wdk_bookings->reservation_m->prepare_data($this->input->post(), $this->data['fields']);
            
            unset($data['calendar_dates'],$data['user_id']);

            if(wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
                unset($data['price'],$data['price_paid'],$data['currency_code'],$data['is_booked'],$data['is_paid'],$data['is_approved']);
            }
                
            // get calendar
            $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id' => $data['post_id']), TRUE);
            $data['calendar_id'] = $calendar->idcalendar;
            $calendar_fees = array();
            if($calendar && !empty($calendar->json_data_fees))
                $calendar_fees = json_decode($calendar->json_data_fees );

            /* message data */

            if ((empty( $data['price']) ||  $data['price'] == '0.00') && !empty($data['date_from']) && !empty($data['date_to'])) {
                if ((bool)strtotime($data['date_from'])) {
                    $data['date_from'] = date('Y-m-d H:i:s', strtotime($data['date_from']));
                }
            
                if ((bool)strtotime($data['date_to'])) {
                    $data['date_to'] = date('Y-m-d H:i:s', strtotime($data['date_to']));
                }

                $price = $Winter_MVC_wdk_bookings->reservation_m->calculate_price($data['post_id'], $data['date_from'], $data['date_to']);
                $_POST['price'] = $data['price'] = $price['price'];
                $_POST['currency_code'] = $data['currency_code'] = $price['currency_code'];
            }   

            /* if approved */
            if (!empty($id)) {
                $reservation = $Winter_MVC_wdk_bookings->reservation_m->get($id, true);
            }
            if(!$calendar->is_hour_enabled && !empty($data['date_from']) && !empty($data['date_to'])) {
                $data['date_from'] = date('Y-m-d 00:00:00', strtotime($data['date_from']));
                $data['date_to'] = date('Y-m-d 00:00:00', strtotime($data['date_to']));
            }

            $insert_id = $Winter_MVC_wdk_bookings->reservation_m->insert($data, $id);

            if (!empty($insert_id) && !empty($id) && wmvc_show_data('user_id', $reservation, false)) {
                /* if approved message */
                if( $reservation->is_approved != 1 && wmvc_show_data('is_approved', $data) == 1) {
                    global $Winter_MVC_WDK;
                    $Winter_MVC_WDK->model('listingusers_m');
                    $Winter_MVC_WDK->model('listing_m');
                    $Winter_MVC_WDK->load_helper('listing');
                    $user = get_userdata( wmvc_show_data('user_id', $reservation) ); /* user data */
                    $listing_data =  $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $data), TRUE);

                    $user_owner_id = NULL;
                    $user_data_owner = NULL;

                    if($listing_data) {
                        $user_owner_id = wmvc_show_data('user_id_editor', $listing_data, '', TRUE, TRUE );
                        if(wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE )) {
                            $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE ) );
                        }
                    }
                        
                    if(empty($user_data_owner)) {
                        $user_data_owner = array(
                            'display_name' => __('Administrator', 'wdk-bookings'),
                            'user_email' => get_bloginfo('admin_email'),
                        );
                    }

                    /* message */
                    $data_message = array();
                    $data_message['user'] = $user ; /* user data */
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['reservation'] = $data;
                    $data_message['listing'] = $listing_data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_to', $data)),
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-membership').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-membership')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();


                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments') && wmvc_show_data('payment_info', $price, false)) {
                        $data_message['data'][__('Payment info', 'wdk-bookings')] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('payment_info', $price, '-'));
                    }
                    
                    if(!wdk_get_option('wdk_bookings_enable_woocommerce_payments')) {
                        $ret = wdk_mail(wdk_show_data('user_email', $user_data_owner, '' , TRUE, TRUE), __('New Reservation approved, please confirm as paid when you receive payment', 'wdk-membership'), $data_message, 'reservation_approved_owner');
                        $ret = wdk_mail($user->user_email, __('Reservation approved, waiting for payment', 'wdk-membership'), $data_message, 'reservation_approved_visitor');
                    } else {
                        /* auto create woo only if is_enable_noapprovements enabled */
                        global $Winter_MVC_WDK;
                        $user_owner_id = NULL;
                        $Winter_MVC_WDK->model('listingusers_m');
                        $Winter_MVC_WDK->model('listing_m');
                        $Winter_MVC_WDK->load_helper('listing');

                        if(wmvc_show_data('user_id_editor', $listing_data, '', TRUE, TRUE )) {
                            $user_owner_id = wmvc_show_data('user_id_editor', $listing_data, '', TRUE, TRUE );
                        }
                        
                        /* auto create woo item and redirect to order */
                        if(class_exists( 'WooCommerce' )) {
                            $url_pay = '';
                            $title = __('Reservation for', 'wdk-membership').' '.wdk_field_value ('post_title', wmvc_show_data('post_id', $data)).' #'.wmvc_show_data('post_id', $data);
                            if($user_owner_id) {
                                $title .= ' A'.$user_owner_id;
                            }
                            $title .= ' '.wmvc_show_data('date_from', $data).' - '.wmvc_show_data('date_to', $data); // The product's Title
                            
                            $post_args = array (
                                'post_author' => $user_owner_id, // The user's ID
                                'post_title' => $title, // The product's Title
                                'post_content' => str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-')), // The product's Title
                                'post_type' => 'product',
                                'post_status' => 'publish' // This could also be $data['status'];
                            );
                        
                            $_POST['woocommerce_product_id'] = $woo_id = wp_insert_post( $post_args );
                            // If the post was created okay, let's try update the WooCommerce values.
                            if ( ! empty( $woo_id ) && function_exists( 'wc_get_product' ) ) {
                                $product = wc_get_product( $woo_id );
                                $product->set_virtual(true);
                                $product->set_downloadable(true);
                                $product->set_sold_individually(true);
                                $product->set_sku( 'wdk-booking-' . $woo_id ); // Generate a SKU with a prefix. (i.e. 'pre-123') 
                                $product->set_regular_price(wmvc_show_data('price', $price)); // Be sure to use the correct decimal price.
                                $product->save(); // Save/update the WooCommerce order object.

                                $terms = array( 'exclude-from-catalog', 'exclude-from-search' );
                                wp_set_object_terms( $woo_id, $terms, 'product_visibility' );

                                update_post_meta($woo_id, '_manage_stock', 'yes');
                                update_post_meta($woo_id, '_stock', 1);

                                $wdk_attach_id = NULL;
                                $image_ids = explode(',', trim(wdk_show_data('listing_images' , $listing_data, '', TRUE, TRUE), ','));

                                if(is_array($image_ids))
                                    $wdk_attach_id = $image_ids[0];
                        
                                set_post_thumbnail( $woo_id, $wdk_attach_id );

                                /* set woo product id for reservation */
                                $update_data = array('woocommerce_product_id'=>$woo_id);
                                $Winter_MVC_wdk_bookings->reservation_m->insert($update_data, $insert_id);

                                if(function_exists('wc_get_cart_url')) {
                                    $url_pay = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($woo_id).'&reservation_id='.esc_attr($insert_id));
                                }
                            }
                            /* message */
                            $data_message['pay_link'] = $url_pay;
                            $ret = wdk_mail(wdk_show_data('user_email', $user, '' , TRUE, TRUE), __('Reservation approved, waiting for payment by', 'wdk-membership').' '.get_bloginfo('name'), $data_message, 'reservation_user_payment_notify_not_expired');
                        }
                        
                    }
                    
                }

                /* reservation completed when is_booked selected */
                if($reservation->is_booked != 1 && wmvc_show_data('is_booked', $data) == 1) {
                    global $Winter_MVC_WDK;
                    $Winter_MVC_WDK->model('listingusers_m');
                    $Winter_MVC_WDK->model('listing_m');
                    $Winter_MVC_WDK->load_helper('listing');
                    $user_client = get_userdata( wmvc_show_data('user_id', $reservation) ); /* user data */
                    $listing_data =  $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $data), TRUE);
                    
                    /* send message to owner */
                    $owner_email = get_bloginfo('admin_email');
                    $user_data_owner = NULL;
                    if(wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE )) {
                        $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE ) );
                        if($user_data_owner && isset($user_data_owner->user_email))
                            $owner_email = $user_data_owner->user_email;
                    }
                        
                    if(empty($user_data_owner)) {
                        $user_data_owner = array(
                            'display_name' => __('Administrator', 'wdk-bookings'),
                            'user_email' => get_bloginfo('admin_email'),
                        );
                    }
                    
                    $data_message = array();
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['user_client'] = $user_client;
                    $data_message['listing'] = $listing_data;
                    $data_message['reservation'] = $data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_to', $data))
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-membership').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-membership')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();

                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    wdk_mail($owner_email, __('Reservation Completed', 'wdk-membership'), $data_message, 'reservation_completed_owner');
                    

                    /* send message to visitor */
                    $data_message = array();
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['user_client'] = $user_client;
                    $data_message['listing'] = $listing_data;
                    $data_message['reservation'] = $data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_from', $data)),
                        __('Date To', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_to', $data)),
                    );

                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-membership').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-membership')] = wmvc_show_data('price', $data).wdk_booking_currency_symbol();


                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $data, '-'));
                    $ics_file = wp_upload_bits('reservation_'.$insert_id.'.ics', NULL, wdk_calendar_ical_export($insert_id));
                
                    $attachments  = array();
                    if($ics_file)
                        $attachments[] = $ics_file['file'];

                    if( $user_client )
                        $ret = wdk_mail(wdk_show_data('user_email', $user_client, '' , TRUE, TRUE), __('Reservation Completed', 'wdk-membership'), $data_message, 'reservation_completed_visitor', NULL, $attachments);
                }
            }

            // redirect
            if(!empty($insert_id))
            {
                $id = $insert_id;
            }
        }

        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_wdk_bookings->reservation_m->get($id, true);

            $Winter_MVC_wdk_bookings->db->where("date_from <='".wmvc_show_data('date_from',$this->data['db_data'])."'");
            $Winter_MVC_wdk_bookings->db->where("date_to >= '".wmvc_show_data('date_to',$this->data['db_data'])."'");
            $this->data['price_reservation'] = $Winter_MVC_wdk_bookings->price_m->get_by(array('post_id'=>wmvc_show_data('post_id',$this->data['db_data'])), TRUE);
       
            if(wdk_get_option('wdk_bookings_enable_woocommerce_payments') 
                && function_exists('wc_get_cart_url') 
                && wmvc_show_data('woocommerce_product_id',$this->data['db_data'], false)) {
                $this->data['url_pay'] = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr(wmvc_show_data('woocommerce_product_id',$this->data['db_data'])).'&reservation_id='.esc_attr($id));
            }

            global $Winter_MVC_WDK;
            $Winter_MVC_WDK->model('listingusers_m');
            $Winter_MVC_WDK->model('listing_m');
            $Winter_MVC_WDK->load_helper('listing');
            $this->data['listing'] = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $this->data['db_data'], false, TRUE, TRUE), TRUE);

            if(wmvc_show_data('user_id_editor', $this->data['listing'], false, TRUE, TRUE )) {
                $this->data['user_data_owner'] = get_userdata( wmvc_show_data('user_id_editor', $this->data['listing'], false, TRUE, TRUE ) );
            }
          
            if(empty($this->data['user_data_owner'])) {
                $this->data['user_data_owner'] = array(
                    'display_name' => __('Administrator', 'wdk-bookings'),
                    'user_email' => get_bloginfo('admin_email'),
                );
            }

            $this->data['user_data_client'] = array();
            if(wmvc_show_data('user_id', $this->data['db_data'], false, TRUE, TRUE )) {
                $this->data['user_data_client'] = get_userdata(wmvc_show_data('user_id', $this->data['db_data'], false, TRUE, TRUE ));
            } 
            
            $Winter_MVC_wdk_bookings->model('calendar_m');
            $this->data['calendar'] = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>wmvc_show_data('post_id', $this->data['db_data'], false, TRUE, TRUE)), TRUE); // date_package_expire package_id
         
        } else {
        }
        
        // Load view
        $this->load->view('wdk_membership_dash/bookings/reservation_edit', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_bookings->reservation_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_bookings->reservation_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->reservation_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_approved'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->reservation_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_approved'=>1), $post_id);
        }
        return true;
    }
    
}
