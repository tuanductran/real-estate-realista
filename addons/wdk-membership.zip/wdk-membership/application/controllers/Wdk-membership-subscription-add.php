<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_subscription_add extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('subscription_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('subscription_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->subscription_m->fields_list;

        //exit($this->db->last_query());

        $this->form->add_error_message('wdk_membership_unique_and_exists_woocommerce_product_id', __('WooCommerce Product ID not exists or already using for subscription', 'wdk-membership'));
        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->subscription_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post

            if(empty($data['date_from']))
                $data['date_from'] = NULL;

            if(empty($data['date_to']))
                $data['date_to'] = NULL;

            if(isset($data['woocommerce_product_id']) && !empty($data['woocommerce_product_id']) && class_exists( 'WooCommerce' )) {
                $product = wc_get_product( $data['woocommerce_product_id'] );
                $product->set_regular_price( wmvc_show_data('price',$data));
                $product->save(); // Save/update the WooCommerce order object.
            }

            if(class_exists( 'WooCommerce' ) && !wmvc_show_data('woocommerce_product_id',$data, false)) {
                $post_args = array(
                    'post_author' => get_current_user_id(), // The user's ID
                    'post_title' => wmvc_show_data('subscription_name',$data), // The product's Title
                    'post_type' => 'product',
                    'post_status' => 'publish' // This could also be $data['status'];
                );
            
                $post_id = wp_insert_post( $post_args );

                // If the post was created okay, let's try update the WooCommerce values.
                if ( ! empty( $post_id ) && function_exists( 'wc_get_product' ) ) {
                    $product = wc_get_product( $post_id );
                    $product->set_sku( 'wdk-subscription-' . $post_id ); // Generate a SKU with a prefix. (i.e. 'pre-123') 
                    $product->set_virtual(true);
                    $product->set_downloadable(true);
                    $product->set_sold_individually(true);
                    $product->set_regular_price(  wmvc_show_data('price',$data)); // Be sure to use the correct decimal price.
                    $product->save(); // Save/update the WooCommerce order object.

                    /* attached image */
                    $wdk_attach_id = wmvc_add_wp_image(WDK_MEMBERSHIP_PATH.'public/img/package-icon.jpg');
                    set_post_thumbnail( $post_id, $wdk_attach_id );

                    $terms = array( 'exclude-from-catalog', 'exclude-from-search' );
                    wp_set_object_terms( $post_id, $terms, 'product_visibility' );
                }
                $_POST['woocommerce_product_id'] = $data['woocommerce_product_id'] = $post_id;
            }
            
            if(isset($_POST['user_types'])) {
                $data['user_types'] = ','.join(',',$_POST['user_types']).','; 
            }

            $insert_id = $this->subscription_m->insert($data, $id);

            /* indexes by new order and reorder */
            $results = $this->subscription_m->get();
            $values = array();
            $order_index = 1;
            foreach( $results as $item)
            {
                $values[] = array('order_index' => $order_index, 'idsubscription' => $item->idsubscription);
                $order_index++;
            }
           
            $this->db->updateBatch( $this->subscription_m->_table_name, $values, 'idsubscription');

            //exit($this->db->last_error());

            // redirect
            
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-membership-subscription-add&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->subscription_m->get($id, TRUE);
        }

        // Load view
        $this->load->view('wdk-membership-subscription-add/index', $this->data);
    }


}
