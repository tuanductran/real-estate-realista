<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_save_search extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
           
	public function index()
	{
        if(!function_exists('run_wdk_save_search')) {
            // Load view
            $this->data['title'] = __('Save Search addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate Save Search addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_save_search;
        $Winter_MVC_wdk_save_search->model('save_search_m');

            /* [Table Actions Bulk Form] */

            $table_action = $this->input->post_get('table_action');
            $action = $this->input->post_get('action');
            $posts_selected = $this->input->post_get('ids');
            if(!empty($table_action))
            {
                switch ($action) {
                    case 'delete':
                        $this->bulk_delete($posts_selected);
                    break;
                    case 'deactivate':
                        $this->bulk_deactivate($posts_selected);
                    break;
                    case 'activate':
                        $this->bulk_activate($posts_selected);
                    break;
                    default:
                } 
            }
            /* [End Table Actions Bulk Form] */

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
        );
        $this->data['db_data'] = $Winter_MVC_wdk_save_search->save_search_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'save_search';
        $columns = array('parameters', 'date');
        $external_columns = array('parameters', 'date');

        wdk_save_search_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_wdk_save_search->save_search_m->total( array(), TRUE);

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_save_search_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['results'] = $Winter_MVC_wdk_save_search->save_search_m->get_pagination($per_page, $offset, array(), NULL, TRUE);
        
        // Load view
        $this->load->view('wdk_membership_dash/save_search/index', $this->data);
    }

    public function edit()
	{
        if(!function_exists('run_wdk_save_search')) {
            // Load view
            $this->data['title'] = __('Save Search addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate Save Search addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }
        
        global $Winter_MVC_wdk_save_search;
        
        $Winter_MVC_wdk_save_search->model('save_search_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('save_search_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_wdk_save_search->save_search_m->fields_list_dash;

        if ($this->form->run($this->data['fields'])) {
            // Save procedure for basic data
            $data = $Winter_MVC_wdk_save_search->save_search_m->prepare_data($this->input->post(), $this->data['fields']);
            unset($data['date_notify'],$data['date'],$data['user_id'],$data['parameters']);
            
            $Winter_MVC_wdk_save_search->save_search_m->_timestamps = false;
            $insert_id = $Winter_MVC_wdk_save_search->save_search_m->insert($data, $id);
            
            if (!empty($insert_id) && empty($id)) {
                $insert_id = $id;
            }
        }

        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_wdk_save_search->save_search_m->get($id, true);
        } else {
            //unset($this->data['fields']['1']);
        }
        
        // Load view
        $this->load->view('wdk_membership_dash/save_search/edit', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_save_search;
        $Winter_MVC_wdk_save_search->model('save_search_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_save_search->save_search_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_save_search->save_search_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_save_search;
        $Winter_MVC_wdk_save_search->model('save_search_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_save_search->save_search_m->check_deletable($post_id))
                $Winter_MVC_wdk_save_search->save_search_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_save_search;
        $Winter_MVC_wdk_save_search->model('save_search_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_save_search->save_search_m->check_deletable($post_id))
                $Winter_MVC_wdk_save_search->save_search_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
}
