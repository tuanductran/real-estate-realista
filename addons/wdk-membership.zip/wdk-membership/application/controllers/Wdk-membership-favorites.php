<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_favorites extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{
        global $Winter_MVC_wdk_favorites;
        $Winter_MVC_wdk_favorites->model('favorite_m');
        $Winter_MVC_wdk_favorites->model('favoritecategory_m');
       
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('category_m');
       
        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }
        /* [End Table Actions Bulk Form] */

        /* filters */
        $this->data['favorite_categories'] = array();
        foreach($Winter_MVC_wdk_favorites->favoritecategory_m->get() as $category) {
            $this->data['favorite_categories'][wmvc_show_data('idcategory', $category)] = wmvc_show_data('title', $category);
        }

        $this->data['post_types'] = array();

        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['post_types']['profile'] = __('Profile', 'wdk-membership');
        $this->data['post_types']['wdk-listing'] = __('Listing', 'wdk-membership');

        $this->data['order_by']   = array(  'idfavorite DESC' => __('ID', 'wdk-membership').' DESC', 
                                            'idfavorite ASC' => __('ID', 'wdk-membership').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-membership').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-membership').' DESC',
                                            'post_title ASC' => __('Post Title', 'wdk-membership').' ASC',
                                            'post_title DESC' => __('Post Title', 'wdk-membership').' DESC',
                                        );

        if(isset($_GET['f_post_type'])) {
            $_GET['post_type'] = $_GET['f_post_type'];
        }


        $rules = array(
            array(
                'field' => 'f_post_type',
                'label' => __('Post Type', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'post_type',
                'label' => __('Post Type', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'listing_location_id',
                'label' => __('Location', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'listing_category_id',
                'label' => __('Category', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-membership'),
                'rules' => ''
            ),
        );
        $this->data['db_data'] = $Winter_MVC_wdk_favorites->favorite_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'favorite';
        $columns = array('idfavorite', 'post_title','order_by', 'post_type','listing_category_id', 'listing_location_id');
        $external_columns = array('post_title', 'post_type','listing_category_id', 'listing_location_id');

        wdk_favorites_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_wdk_favorites->favorite_m->total_data();
        
        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_favorites_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
        $this->data['favorites'] = $Winter_MVC_wdk_favorites->favorite_m->get_pagination($per_page, $offset);
        
        // Load view
        $this->load->view('wdk_membership_dash/favorites/index', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_favorites;
        $Winter_MVC_wdk_favorites->model('favorite_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_favorites->favorite_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_favorites->favorite_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_favorites;
        $Winter_MVC_wdk_favorites->model('favorite_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_favorites->favorite_m->check_deletable($post_id))
                $Winter_MVC_wdk_favorites->favorite_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_favorites;
        $Winter_MVC_wdk_favorites->model('favorite_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_favorites->favorite_m->check_deletable($post_id))
                $Winter_MVC_wdk_favorites->favorite_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
}
