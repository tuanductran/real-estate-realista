<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_dash extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
    
	public function index()
	{
        $this->load->view('wdk_membership_dash/basic/index', $this->data);
    }

	public function api_import()
	{
    }

	public function import_demo()
	{
    }

}
