<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_membership extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{

        if(!wdk_get_option('wdk_membership_is_enable_subscriptions')) {
            // Load view
            $this->data['title'] = __('Membership Subscription', 'wdk-membership');
            $this->data['message'] = __('Membership Subscription is not enabled', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_membership, $Winter_MVC_WDK;
        $Winter_MVC_wdk_membership->model('subscription_m');
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        $Winter_MVC_WDK->model('listing_m');
       
        /* [Table Actions Bulk Form] */
        /*
        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }*/
        /* [End Table Actions Bulk Form] */

        $this->data['order_by']   = array('idsubscription DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idsubscription ASC' => __('ID', 'wdk-membership').' ASC',  );

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-membership'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-membership'),
                'rules' => ''
            ),
        );
        $this->data['db_data'] = $Winter_MVC_wdk_membership->subscription_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'subscription';
        $columns = array('idsubscription', 'location_id', 'category_id', 'subscription_name', 'days_limit', 'price', 'search', 'order_by');
        $external_columns = array('location_id', 'category_id', 'subscription_name');

        wdk_subscriptions_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $Winter_MVC_wdk_membership->db->where(array(
            '(user_types LIKE "%,'.wmvc_get_current_user_role().',%" OR user_types IS NULL)'=>NULL
        ));
        
        $total_items = $Winter_MVC_wdk_membership->subscription_m->total(array('is_activated'=>1));

        $current_page = 1;
        if(isset($_GET['wmvc_paged']) && !empty($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);
        
        $this->data['wmvc_paged'] = $current_page;

        $per_page = NULL;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(false && function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_subscriptions_prepare_search_query_GET($columns, $controller.'_m', $external_columns);  
        
        $Winter_MVC_wdk_membership->db->join($Winter_MVC_wdk_membership->subscription_user_m->_table_name.' ON ('.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.idsubscription = '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.subscription_id AND 
                                            '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.user_id = "'.get_current_user_id().'")', TRUE, 'LEFT');
        
        $Winter_MVC_wdk_membership->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON ('.$Winter_MVC_WDK->listing_m->_table_name.'.subscription_id = '.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.idsubscription AND user_id_editor = '.get_current_user_id().' )', TRUE, 'LEFT');
                                        
        $Winter_MVC_wdk_membership->db->where(array(
            '(
                ((date_from IS NULL OR date_from < \''.current_time( 'mysql' ).'\') AND (date_to IS NULL OR date_to > \''.current_time( 'mysql' ).'\'))
                OR
                ('.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.date_expire  IS NOT NULL)
            )'
            =>NULL
        ));

        $Winter_MVC_wdk_membership->db->where(array(
            '(user_types LIKE "%,'.wmvc_get_current_user_role().',%" OR user_types IS NULL)'=>NULL
        ));

        $Winter_MVC_wdk_membership->db->group_by('idsubscription');

        $this->data['subscriptions'] = $Winter_MVC_wdk_membership->subscription_m->get_pagination($per_page, $offset, array($Winter_MVC_wdk_membership->subscription_m->_table_name.'.is_activated = 1'=>NULL), 
                                        NULL, $Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.*,'.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.*, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS listings_counter,'.
                                        $Winter_MVC_WDK->location_m->_table_name.'.*,'.$Winter_MVC_WDK->category_m->_table_name.'.*');
      
        $limit = NULL;
        if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled'))
            $limit = 1;

        $this->data['user_subscriptions'] = array();
        $user_subscriptions = $Winter_MVC_wdk_membership->subscription_user_m->get_pagination($limit, FALSE, array('is_activated'=>1, 'status !='=>'DEPRECATED'),'subscription_id DESC');

        if($user_subscriptions){
            foreach($user_subscriptions as $subscription) {
                $this->data['user_subscriptions'][wdk_show_data('subscription_id',$subscription,'',TRUE,TRUE)] = $subscription;
            }
        }

        $this->data['user_have_active'] = $Winter_MVC_wdk_membership->subscription_user_m->check_have_active();

        /* check if all subscriptions have limit listings */
        $this->data['listings_limit'] = false;
        $this->data['listings_count'] = 0;
        if (count($this->data['user_subscriptions']) > 0) {
            global $Winter_MVC_WDK;
            $Winter_MVC_WDK->model('listing_m');
            $listings_limit_counter = 0 ;
            foreach($this->data['user_subscriptions'] as $subscription) {

                if(empty($subscription->date_expire) || strtotime($subscription->date_expire) < time()) continue;

                if(wdk_show_data('listings_limit', $subscription, '0') == '-1') {
                    $listings_limit_counter = '-1';
                    break;
                }
                $listings_limit_counter += wdk_show_data('listings_limit', $subscription, '0');
            }

            $listings_count = $Winter_MVC_WDK->listing_m->total(array(), TRUE, get_current_user_id());
            if($listings_limit_counter != '-1' && intval($listings_count) >= $listings_limit_counter) $this->data['listings_limit'] = true;

            $this->data['listings_count'] = $listings_count;
        }


        // Load view
        $this->load->view('wdk_membership_dash/membership/index', $this->data);
    }

    /*
    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_membership->subscription_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_membership->subscription_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_membership->subscription_m->check_deletable($post_id))
                $Winter_MVC_wdk_membership->subscription_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_membership->subscription_m->check_deletable($post_id))
                $Winter_MVC_wdk_membership->subscription_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }*/
    
}
