<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_booking_calendars extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{
        if(!current_user_can('edit_own_listings') && !wmvc_user_in_role('administrator')){
            // Load view
            $this->data['title'] = __('Access denied', 'wdk-membership');
            $this->data['message'] = __('Current User not have access for open this page', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        } 

        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        
        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {
            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }
        /* [End Table Actions Bulk Form] */

        /* [Search Form] */

        $controller = 'calendar';
        $columns = array('idcalendar', 'search', 'order_by', 'post_title');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idcalendar DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idcalendar ASC' => __('ID', 'wdk-membership').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_bookings->calendar_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $Winter_MVC_wdk_bookings->calendar_m->total(array(), TRUE, get_current_user_id());

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);

        $this->data['wmvc_paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['calendars'] = $Winter_MVC_wdk_bookings->calendar_m->get_pagination($per_page, $offset, array(), NULL, TRUE, get_current_user_id());

        // Load view
        $this->load->view('wdk_membership_dash/bookings/calendars', $this->data);
    }
  

     // Edit listing method
	public function edit()
	{
        
        if(!current_user_can('edit_own_listings') && !wmvc_user_in_role('administrator')){
            // Load view
            $this->data['title'] = __('Access denied', 'wdk-membership');
            $this->data['message'] = __('Current User not have access for open this page', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        } 

        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        
        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {
            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('calendar_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_wdk_bookings->calendar_m->fields_list;
        $this->data['fields'][0]['field_type'] = 'LISTING_USER';
        $this->data['calendar_fees'] = array();

        //exit($this->db->last_query());

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-membership'));
        $this->form->add_error_message('calendar_date_exists', __('Date already in use for this Listing/Post', 'wdk-membership'));

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-membership'));
        $this->form->add_error_message('unique_post_id_calendar', __('Calender already defined for this Listing/Post ID', 'wdk-membership'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $Winter_MVC_wdk_bookings->calendar_m->prepare_data($this->input->post(), $this->data['fields']);
            $data['json_data_fees'] = $this->input->post('json_data_fees');
            
            $insert_id = $Winter_MVC_wdk_bookings->calendar_m->insert($data, $id);

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                $id = $insert_id;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $Winter_MVC_wdk_bookings->calendar_m->get($id, TRUE);
            if(!empty($this->data['db_data']->json_data_fees))
                $this->data['calendar_fees'] = json_decode($this->data['db_data']->json_data_fees );
        } else {
            $this->data['db_data'] = array();
            if(wmvc_show_data('post_id', $_GET, false)) {
                $this->data['db_data']['post_id'] = wmvc_show_data('post_id', $_GET, false);
            }
        }

        // Load view
        $this->load->view('wdk_membership_dash/bookings/calendar_edit', $this->data);
    }

    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_bookings->calendar_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_bookings->calendar_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->calendar_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->calendar_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->calendar_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->calendar_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
    public function calendar_ical_export()
    {
        ob_clean();
        global $Winter_MVC_wdk_bookings;
        $calendar_id = sanitize_text_field($this->input->post_get('calendar_id'));
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->model('calendar_m');

        if(!$Winter_MVC_wdk_bookings->calendar_m->check_deletable($calendar_id))   exit(__('Permission denied', 'wdk-membership'));

        $this->data['reservations'] = $Winter_MVC_wdk_bookings->reservation_m->get_pagination(NULL, NULL, array('calendar_id'=>$calendar_id, 'is_approved' =>1));
 
		$print_data = [];
		$print_data [] = 'BEGIN:VCALENDAR';
		$print_data [] = 'VERSION:2.0';
		$print_data [] = 'PRODID:-//'.get_bloginfo("name").'//EN';
		$print_data [] = 'X-WR-CALNAME:'.get_bloginfo("name").'';
		$print_data [] = 'X-WR-CALDESC:Public '.get_bloginfo("name").' Reservations Provided by '.site_url();
		$print_data [] = 'X-PUBLISHED-TTL:PT1H';
		$print_data [] = 'REFRESH-INTERVAL;VALUE=DURATION:P1H';
		$print_data [] = 'NAME:'.get_bloginfo("name").'';
		$print_data [] = 'CALSCALE:GREGORIAN';
		$print_data [] = 'METHOD:PUBLISH';
		
		foreach ($this->data['reservations'] as $key => $reservation) {
				$print_data [] = 'BEGIN:VEVENT';
				$print_data [] = 'DTEND;VALUE=DATE:'. date('YmdTHis', strtotime(wmvc_show_data('date_to', $reservation)));
				$print_data [] = 'DTSTART;VALUE=DATE:'.date('YmdTHis', strtotime(wmvc_show_data('date_from', $reservation)));
				$print_data [] = 'URL;VALUE=URI:' . admin_url('admin.php?page=wdk-bookings-add&id='.wmvc_show_data('idreservation', $reservation));
				$print_data [] = 'UID:reservation_' .wmvc_show_data('idreservation', $reservation);
				$print_data [] = 'SUMMARY:'.get_bloginfo("name").' Reservation Id '.wmvc_show_data('idreservation', $reservation); 
				$print_data [] = 'DESCRIPTION:<strong>Price</strong> '.wmvc_show_data('price', $reservation).wmvc_show_data('currency_code', $reservation).'\n'.wmvc_show_data('notes', $reservation) ;
				$print_data [] = 'END:VEVENT';
			
		}
        
		$print_data [] = 'END:VCALENDAR';

		$print_data = preg_replace('/^[ \t]*[\r\n]+/m', '', implode(PHP_EOL, $print_data));


        header('Content-type: text/calendar; charset=utf-8');
        header("Content-Length:".strlen($print_data));
        header("Content-Disposition: attachment; filename=export_icl_calendar".$calendar_id.".ics");
		
        echo $print_data;
        
        exit();
    }

    public function ical_import()
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('calendar_m', $id);
            
        $this->data['calendar'] = $Winter_MVC_wdk_bookings->calendar_m->get($id, TRUE);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['fields'] = array( 
            array(
                'field' => 'hidden_valid', 
                'field_label' => __('Url', 'wdk-membership'), 
                'label' => __('Url', 'wdk-membership'), 
                'hint' => __('Import reservations to ics link', 'wdk-membership'), 
                'field_type' => 'INPUTBOX', 
                'class' => 'wdk-hidden', 
                'rules' => 'required|wdkbooking_file_exists'
            ),
            array(
                'field' => 'import_public_url', 
                'field_label' => __('Url', 'wdk-membership'), 
                'label' => __('Url', 'wdk-membership'), 
                'hint' => __('Import reservations to ics link', 'wdk-membership'), 
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'icl_file', 
                'field_label' => __('File', 'wdk-membership'), 
                'label' => __('File', 'wdk-membership'), 
                'hint' => __('Import reservations from ics file', 'wdk-membership'), 
                'field_type' => 'UPLOAD_FILE', 
                'rules' => ''
            )
        );
        $this->data['db_data']['hidden_valid'] = 'valid';

        $this->form->add_error_message('wdkbooking_file_exists', __('Link/File doesn\'t exists', 'wdk-membership'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $Winter_MVC_wdk_bookings->calendar_m->prepare_data($this->input->post(), $this->data['fields']);

            if(!empty($data['icl_file']))
                $file = get_attached_file(intval($data['icl_file']));

            if(!empty($data['import_public_url']))
                $file = sanitize_text_field($data['import_public_url']);

            global $wp_filesystem;
            // Initialize the WP filesystem, no more using 'file-put-contents' function
            if (empty($wp_filesystem)) {
                WP_Filesystem();
            }
            $string =  $wp_filesystem->get_contents($file);

            $reservations = $this->parse_icl($string);

            if($reservations && !empty($reservations['reservations'])) {
                $date = date("Y-m-d H:i:s");
                foreach ($reservations['reservations'] as $reservation) {
                    /* price */
                    $data_res = array();
                    $data_res['calendar_id'] = $id;
                    $data_res['post_id'] = wmvc_show_data('post_id', $this->data['calendar']);
                    $data_res['user_id'] = NULL;
                    $data_res['date'] = $date;
                    $data_res['date_from'] = wmvc_show_data('dateStart', $reservation);
                    $data_res['date_to'] =  wmvc_show_data('dateEnd', $reservation);
                    $data_res['is_approved'] = 1;
                    $data_res['is_paid'] = 1;
                    $data_res['is_booked'] = 1;
                    $data_res['notes'] = 'UID:'.wmvc_show_data('uid', $reservation).' '. wmvc_show_data('description', $reservation);
                    $results = $Winter_MVC_wdk_bookings->reservation_m->is_booked(wmvc_show_data('post_id', $this->data['calendar']), $data_res['date_from'], $data_res['date_to']);
                    if( $results ) {
                        continue;
                    }

                    if(!$this->data['calendar']->is_hour_enabled && !empty($data_res['date_from']) && !empty($data_res['date_to'])) {
                        $data_res['date_from'] = date('Y-m-d 00:00:00', strtotime($data_res['date_from']));
                        $data_res['date_to'] = date('Y-m-d 00:00:00', strtotime($data_res['date_to']));
                    }
                    $insert_id = $Winter_MVC_wdk_bookings->reservation_m->insert($data_res, NULL);
                }
            }

            // redirect
            /*
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?wdk-bookings-calendar&function=import_icl_calendar&id={$id}&is_updated=true"));
                exit;
            }*/
                
        }

        // Load view
        $this->load->view('wdk_membership_dash/bookings/calendar_ical_import', $this->data);

    }

    public function parse_icl ($content = '') {
        $this->icl_data = array(
            'title'=>'',
            'description'=>'',
            'reservations'=>array(),
        );
        try {
            //code...
            $content = str_replace("\r\n ", '', $content);

            // Title
            preg_match('`^X-WR-CALNAME:(.*)$`m', $content, $m);
            $this->icl_data['title'] = $m ? trim($m[1]) : null;

            // Description
            preg_match('`^X-WR-CALDESC:(.*)$`m', $content, $m);
            $this->icl_data['description'] = $m ? trim($m[1]) : null;

            // Events
            preg_match_all('`BEGIN:VEVENT(.+)END:VEVENT`Us', $content, $m);
            foreach ((array)$m[0] as $c) {
                $event = $this->_parse_icl_event($c);
                $this->icl_data['reservations'][] = $event;
            }
        } catch (\Throwable $th) {
            var_dump('error');
            return false;
        } 

        return $this->icl_data;
    }

    private function _parse_icl_event($content)
	{
		$content = str_replace("\r\n ", '', $content);
        $event = array();
		// UID
		if (preg_match('`^UID:(.*)$`m', $content, $m))
			$event['uid'] = trim($m[1]);

		// Summary
		if (preg_match('`^SUMMARY:(.*)$`m', $content, $m))
			$event['summary'] = trim($m[1]);

		// Description
		if (preg_match('`^DESCRIPTION:(.*)$`m', $content, $m))
			$event['description'] = trim($m[1]);

		// Date start
		if (preg_match('`^DTSTART(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_timeStart'] = strtotime($m[1]);
			$event['dateStart'] = date('Y-m-d H:i:s', $event['_timeStart']);
		}

		// Date end
		if (preg_match('`^DTEND(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_timeEnd'] = strtotime($m[1]);
			$event['dateEnd'] = date('Y-m-d H:i:s', $event['_timeEnd']);
		}

		// Recurrence-Id
		if (preg_match('`^RECURRENCE-ID(?:;.+)?:([0-9]+(T[0-9]+Z?)?)`m', $content, $m)) {
			$event['_recurrenceId'] = strtotime($m[1]);
			$event['recurrenceId'] = date('Y-m-d H:i:s', $event['_recurrenceId']);
		}

		// Recurrence
		if (preg_match('`^RRULE:(.*)`m', $content, $m)) {
			$rules = (object) array();
			$rule = trim($m[1]);

			$rule = explode(';', $rule);
			foreach ($rule as $r) {
				list($key, $value) = explode('=', $r);
				$rules->{ strtolower($key) } = $value;
			}

			if (isset($rules->until)) {
				$rules->until = date('Y-m-d H:i:s', strtotime($rules->until));
			}
			if (isset($rules->count)) {
				$rules->count = intval($rules->count);
			}
			if (isset($rules->interval)) {
				$rules->interval = intval($rules->interval);
			}
			if (isset($rules->byday)) {
				$rules->byday = explode(',', $rules->byday);
			}

			// Avoid infinite recurrences
			if (! isset($rules->until) && ! isset($rules->count)) {
				$rules->count = 500;
			}

			$event['recurrence'] = $rules;
		}


		// Location
		if (preg_match('`^LOCATION:(.*)$`m', $content, $m))
			$event['location'] = trim($m[1]);

		// Status
		if (preg_match('`^STATUS:(.*)$`m', $content, $m))
			$event['status'] = trim($m[1]);


		// Created
		if (preg_match('`^CREATED:(.*)`m', $content, $m))
			$event['created'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

		// Updated
		if (preg_match('`^LAST-MODIFIED:(.*)`m', $content, $m))
			$event['updated'] = date('Y-m-d H:i:s', strtotime(trim($m[1])));

		return $event;
	}

    private function _filter_icl_data($data = '') {
        return str_replace('','',($data));
    }

}
