<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_subscriptions_users extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('subscription_user_m');

        $dbusers =  get_users( array( 'search' => '',
                                      'orderby' => 'display_name', 'order' => 'ASC'));
        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */
        
        $controller = 'subscription_user';
        $columns = array('user_id','display_name','user_login', 'idsubscription', 'subscription_name', 'days_limit', 'price', 'search', 'order_by');
        $external_columns = array('user_id','display_name','user_login', 'subscription_name');

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['order_by']   = array('idsubscription_user DESC' => __('ID DESC', 'wdk-membership'), 
                                          'idsubscription_user ASC' => __('ID ASC', 'wdk-membership'),  
                                          'display_name DESC' => __('User DESC', 'wdk-membership'),  
                                          'display_name ASC' => __('User ASC', 'wdk-membership'),  
                                          'date_expire ASC' => __('Date Expire ASC', 'wdk-membership'),  
                                          'date_expire DESC' => __('Date Expire DESC', 'wdk-membership'),  
                                        );

        $rules = array(
                array(
                    'field' => 'location_id',
                    'label' => __('Location', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'category_id',
                    'label' => __('Category', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'user_id',
                    'label' => __('User', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->subscription_user_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */
        global $wpdb;
        $wp_usermeta_table = $wpdb->users;
        $this->db->join($wp_usermeta_table.' ON '.$this->subscription_user_m->_table_name.'.user_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');

        wdk_subscriptions_user_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->subscription_user_m->total_belongs_listings(array(), FALSE);

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_subscriptions_user_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $this->data['subscriptions'] = $this->subscription_user_m->get_pagination_belongs_listings($per_page, $offset,array(), NULL, FALSE);
       
        // Load view
        $this->load->view('wdk-membership-subscriptions-users/index', $this->data);
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('subscription_user_m');

        $this->subscription_user_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions-users&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_user_m');
    
            $this->subscription_user_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions-users"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_user_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('subscription_user_m', $post_id);
            $this->subscription_user_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions-users"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('subscription_user_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('subscription_user_m', $post_id);
            $this->subscription_user_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions-users"));
    }

    public function edit()
	{
        $this->load->model('subscription_user_m');
        $this->load->model('subscription_m');

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->load_helper('listing');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('subscription_user_m', $id);

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->subscription_user_m->fields_list;
        $this->data['listings'] = array();
   
        $this->form->add_error_message('wdk_membership_unique_user_subscription', __('User already have this membership subscription', 'wdk-membership'));
        $this->form->add_error_message('wdk_membership_user_subs_exists', __('User can have only one membership subscription', 'wdk-membership'));
        
        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->subscription_user_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post
            $insert_id = $this->subscription_user_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-membership-subscriptions-users&function=edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->subscription_user_m->get($id, TRUE);
            $this->data['listings'] = $Winter_MVC_WDK->listing_m->get_pagination(5, NULL, array('subscription_id'=>$id), TRUE, wmvc_show_data('user_id',$this->data['db_data'], '', TRUE, TRUE));
        }

        
        /* get subscriptions list */
        $this->db->select($this->subscription_user_m->_table_name.'.*,'.$this->subscription_m->_table_name.'.*, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS listings_counter');
        
        $subscription_user = NULL;
        if(!empty($id)) {
            $subscription_user = wmvc_show_data('user_id', $this->data['db_data']);
        }

        $this->db->join($this->subscription_user_m->_table_name.' ON ('.$this->subscription_m->_table_name.'.idsubscription = '.$this->subscription_user_m->_table_name.'.subscription_id AND 
                                            '.$this->subscription_user_m->_table_name.'.user_id = "'.$subscription_user.'")', TRUE, 'LEFT');
        
        $this->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON (
                                                        '.$Winter_MVC_WDK->listing_m->_table_name.'.subscription_id = '.$this->subscription_m->_table_name.'.idsubscription
                                                        AND '.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor = "'.$subscription_user.'"
                                                    )',
                                                    TRUE, 'LEFT');
                                        
        $this->db->where(array(
            '(
                ((date_from IS NULL OR date_from < \''.current_time( 'mysql' ).'\') AND (date_to IS NULL OR date_to > \''.current_time( 'mysql' ).'\'))
                OR
                ('.$this->subscription_user_m->_table_name.'.date_expire  IS NOT NULL)
            )'
            =>NULL
        ));
        
        $this->db->group_by('idsubscription');
        $this->data['subscriptions'] = $this->subscription_m->get_by(array($this->subscription_m->_table_name.'.is_activated = 1'=>NULL));
        //exit($this->db->last_query());

        // Load view
        $this->load->view('wdk-membership-subscriptions-users/edit', $this->data);
    }

}
