<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_booking_prices extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{

        if(!current_user_can('edit_own_listings') && !wmvc_user_in_role('administrator')){
            // Load view
            $this->data['title'] = __('Access denied', 'wdk-membership');
            $this->data['message'] = __('Current User not have access for open this page', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        } 

        if(!function_exists('run_wdk_bookings')) {
            
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }
        
        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {

            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                    break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                    break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                    break;
                default:
                } 
        }
        /* [End Table Actions Bulk Form] */

        $controller = 'price';
        $columns = array('idprice', 'search', 'order_by', 'post_title', $Winter_MVC_wdk_bookings->db->prefix.'wdk_listings.post_id');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idprice DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idprice ASC' => __('ID', 'wdk-membership').' ASC',  
                                          'date_from DESC' => __('Date From DESC', 'wdk-membership'),  
                                          'date_from ASC' => __('Date From ASC', 'wdk-membership'),  
                                          'date_to DESC' => __('Date To DESC', 'wdk-membership'),  
                                          'date_to ASC' => __('Date To ASC', 'wdk-membership'),  
                                        );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_bookings->price_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $Winter_MVC_wdk_bookings->price_m->total(array(), TRUE, get_current_user_id());

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);

        $this->data['wmvc_paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['prices'] = $Winter_MVC_wdk_bookings->price_m->get_pagination($per_page, $offset, array(), wmvc_show_data('order_by', $db_data, 'date_from DESC'), TRUE, get_current_user_id());

        // Load view
        $this->load->view('wdk_membership_dash/bookings/prices', $this->data);
    }

     // Edit listing method
	public function edit()
	{
        
        if(!current_user_can('edit_own_listings') && !wmvc_user_in_role('administrator')){
            // Load view
            $this->data['title'] = __('Access denied', 'wdk-membership');
            $this->data['message'] = __('Current User not have access for open this page', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        } 

        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        if(wdk_get_option('wdk_bookings_disable_bookings_by_default') && !wdk_membership_subscription_booking_enabled()) {
            // Load view
            $this->data['title'] = __('Bookings feature not activated for you', 'wdk-membership');
            $this->data['message'] = sprintf(__('To activate booking addon, please %1$s purchase membership subscription with allow booking here %2$s', 'wdk-membership'),'<a target="_blank" href="'.esc_url(wdk_dash_url('dash_page=membership')).'" class="underline">','</a>');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('price_m');

        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('price_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $Winter_MVC_wdk_bookings->price_m->fields_list_calendar;
        $this->data['fields'][0]['field_type'] = 'LISTING_USER_CALENDAR';
        $this->data['fields'][0]['hint'] = sprintf(__('You can only define rates for listings which have %1$s calendar defined %2$s', 'wdk-bookings'),'<a href="'.wdk_dash_url("dash_page=booking-calendars").'">','</a>');
        //exit($this->db->last_query());

        $this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-membership'));
        $this->form->add_error_message('price_date_exists', __('Date already in use for this Listing/Post', 'wdk-membership'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $Winter_MVC_wdk_bookings->price_m->prepare_data($this->input->post(), $this->data['fields']);
            unset($data['calendar_dates']);

            // get calendar
            $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id' => $data['post_id']), TRUE);
            $data['calendar_id'] = $calendar->idcalendar;
            if(!$calendar->is_hour_enabled && !empty($data['date_from']) && !empty($data['date_to'])) {
                $data['date_from'] = date('Y-m-d 00:00:00', strtotime($data['date_from']));
                $data['date_to'] = date('Y-m-d 00:00:00', strtotime($data['date_to']));
            }
            $insert_id = $Winter_MVC_wdk_bookings->price_m->insert($data, $id);

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                $id = $insert_id;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $Winter_MVC_wdk_bookings->price_m->get($id, TRUE);
        } else {
            $this->data['db_data'] = array();
            if(wmvc_show_data('post_id', $_GET, false)) {
                $this->data['db_data']['post_id'] = wmvc_show_data('post_id', $_GET, false);
            }
        }

        // Load view
        $this->load->view('wdk_membership_dash/bookings/price_edit', $this->data);
    }


    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('price_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_bookings->price_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_bookings->price_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('price_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->price_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->price_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('price_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->price_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->price_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
}
