<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_quicksubmission extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}
    
	public function index($settings = array())
	{
		$this->submit($settings);
       // $this->load->view('wdk_membership_dash/basic/index', $this->data);
    }

    
    public $listing_data = array();

	// Edit listing method
	public function submit($settings = array())
	{
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('field_m');
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('listingfield_m');
        $Winter_MVC_WDK->model('listingusers_m');
        $Winter_MVC_WDK->model('category_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('user_m');

        $listing_post_id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('listing_m', $listing_post_id);
        $this->data['db_data'] = NULL;
        $this->data['settings'] = $settings;

        $this->data['form'] = &$this->form;

        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();
        $this->data['agents']  = $Winter_MVC_WDK->user_m->get_agents();
        
        $this->data['db_data']['listing_sub_locations'] = array();
        $this->data['db_data']['listing_sub_categories'] = array();

        if(!empty($listing_post_id))
        {
            $listing_post = get_post( $listing_post_id );

            $listing_db_data = $Winter_MVC_WDK->listing_m->get($listing_post_id, TRUE);

            $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($listing_post_id, TRUE);

            $this->listing_data = $this->data['db_data'] = array_merge((array) $listing_post, 
                                                 (array) $listing_db_data, 
                                                 (array) $listingfield_db_data);

                                                 
            $this->data['db_data']['listing_sub_locations'] = wdk_generate_other_locations_keys($listing_post_id);
            $this->data['db_data']['listing_sub_categories'] = wdk_generate_other_categories_keys($listing_post_id);
        } 

        if(isset($_POST['listing_sub_locations'])) {
            $this->data['db_data']['listing_sub_locations'] = $_POST['listing_sub_locations'];
        }
        
        if(isset($_POST['listing_sub_categories'])) {
            $this->data['db_data']['listing_sub_categories'] = $_POST['listing_sub_categories'];
        }
       
        $this->db->where(array('field_type !='=> 'SECTION'));
        $this->data['listing_fields'] = $Winter_MVC_WDK->field_m->get();
        
        $this->data['fields'] = $Winter_MVC_WDK->field_m->get_by(array('is_visible_dashboard'=>1));
        $rules = array(
                array(
                    'field' => 'post_title',
                    'label' => __('Title', 'wdk-membership'),
                    'rules' => 'required'
                ),
                array(
                    'field' => 'post_content',
                    'label' => __('Content', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_post_content_enable', FALSE)) ? 'required' : ''
                ),
                array(
                    'field' => 'category_id',
                    'label' => __('Category', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listing_category_required')) ? 'required':''
                ),
                array(
                    'field' => 'location_id',
                    'label' => __('Location', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listing_location_required')) ? 'required':''
                ),
                array(
                    'field' => 'address',
                    'label' => __('Address', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'lat',
                    'label' => __('lat', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_address_enabled')) ? 'wdk_gps_single':''
                ),
                array(
                    'field' => 'lng',
                    'label' => __('lng', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_is_address_enabled')) ? 'wdk_gps_single':''
                ),
                array(
                    'field' => 'listing_plans_documents',
                    'label' => __('Listing plans and documents', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_images',
                    'label' => __('Listing images', 'wdk-membership'),
                    'rules' => (wdk_get_option('wdk_listings_images_required_enable')) ? 'required' : ''
                ),
                array(
                    'field' => 'is_activated',
                    'label' => __('Is Activated', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'user_id',
                    'label' => __('Agent', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_sub_locations',
                    'label' => __('Locations', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_sub_categories',
                    'label' => __('Categories', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'listing_related_ids',
                    'label' => __('Listing childs', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'user_name',
                    'label' => __('You Name', 'wdk-membership'),
                    'rules' => (!get_current_user_id()) ? 'required' : ''
                ),
                array(
                    'field' => 'user_email',
                    'label' => __('You Email', 'wdk-membership'),
                    'rules' => (!get_current_user_id()) ? 'required|wdk_is_useremail_exists' : ''
                ),

        );      

        foreach($this->data['fields'] as $field)
        {
            if($field->field_type == 'SECTION' || wmvc_show_data('is_visible_dashboard', $field) != 1) continue;
            
            $rule_required = (wmvc_show_data('is_required', $field) == 1) ? 'required' : '';

            if(wmvc_show_data('validation', $field)) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                $rule_required .= wmvc_show_data('validation', $field);
            }

            if(!empty(wmvc_show_data('min_length', $field))) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                
                if(wmvc_show_data('field_type', $field) == "NUMBER") {
                    $rule_required .= "min_number";
                } else {
                    $rule_required .= "min_length";
                }
                $rule_required .= "[".wmvc_show_data('min_length', $field)."]";

            }

            if(!empty(wmvc_show_data('max_length', $field))) {
                if(!empty($rule_required)) {
                    $rule_required .= '|';
                }
                if(wmvc_show_data('field_type', $field) == "NUMBER") {
                    $rule_required .= "max_number";
                } else {
                    $rule_required .= "max_length";
                }
                $rule_required .= "[".wmvc_show_data('max_length', $field)."]";
            }


            if(isset($_POST['category_id']) && !empty($_POST['category_id'])) {
                if(wdk_depend_is_hidden_field($field->idfield, intval($_POST['category_id']))) {
                    $rule_required = '';
                } 
            }

            $rules[] = 
                array(
                    'field' => 'field_'.$field->idfield,
                    'label' => $field->field_label,
                    'rules' => $rule_required
                );

            if(isset($this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type]))
                $this->data['db_data']['field_'.$field->idfield] = 
                    $this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type];
        }

        
        $this->data['section_1_fields'] = array();

        $section_1_fields_data = array();
        $this->data['sections_data'] =  $Winter_MVC_WDK->field_m->get_fields_section();

        if(!empty($this->data['settings']['section_fields_id_step_1'])){
            $this->data['section_label'] = wdk_field_label($this->data['settings']['section_fields_id_step_1']);
            if(isset($this->data['sections_data'][$this->data['settings']['section_fields_id_step_1']]))
                $section_1_fields_data =  $this->data['sections_data'][$this->data['settings']['section_fields_id_step_1']];

            $skip_fields_ids = array();
            $skip_fields_ids[] = $this->data['settings']['section_fields_id_step_1'];

            foreach($section_1_fields_data['fields'] as $v_fields)
            {
                $skip_fields_ids[] = wmvc_show_data('idfield', $v_fields);
            }
            
            foreach($this->data['fields'] as $key=>$field)
            {
                if(in_array(wmvc_show_data('idfield', $field), $skip_fields_ids)) {
                    $this->data['section_1_fields'][]=$this->data['fields'][$key];
                    unset($this->data['fields'][$key]);
                }
            }
        }


        $this->form->add_error_message('wdk_gps_single', __('Gps field is not valid, should be like xx.xxxxxx (between -180 and 180)', 'wdk-membership'));
        $this->form->add_error_message('wdk_is_useremail_exists', __('User with current email already exists, please login and add listing', 'wdk-membership'));
        
        if($this->form->run($rules))
        {
            // Save procedure for basic data
    
            if(function_exists('wdk_get_post')) {
                $data = $Winter_MVC_WDK->listing_m->prepare_data(wdk_get_post(), $rules, FALSE);
            } else {
                $data = $Winter_MVC_WDK->listing_m->prepare_data($this->input->post(), $rules);
            }

            // Save standard wp post
            
            if(!isset($data['post_content'])) {
                $data['post_content'] = '';
            }
            
            // Create post object
            $listing_post = array(
                'ID' => $listing_post_id,
                'post_type'     => 'wdk-listing',
                'post_title'    => wp_strip_all_tags( $data['post_title'] ),
                'post_content'  => $data['post_content'],
                'post_status'   => 'publish',
                'post_author'   => get_current_user_id()
            );
            
            // Insert the post into the database
            $id = wp_insert_post( $listing_post );

            // Save our main listing data

            $listing_data = array('post_id' => $id);

            $listing_data_fields = array('category_id', 'location_id', 'address', 'lat', 'lng', 'listing_images', 'listing_plans_documents');

            foreach($listing_data_fields as $field_name)
            {
                $listing_data[$field_name] = $data[$field_name];
            }

            if ( isset($_FILES['image_uploads']) &&  !empty($_FILES['image_uploads'])  ) {
                $upload_dir = wp_upload_dir();
                $upload_path = $upload_dir['path'] . '/';

                $data['listing_images'] = '';
                // Loop through each uploaded file
                foreach ($_FILES['image_uploads']['name'] as $key => $file_name) {
                    $file_tmp_name = $_FILES['image_uploads']['tmp_name'][$key];
                    $file_name = sanitize_file_name( $file_name );
                    $upload_file = $upload_path . $file_name;

                    if ( move_uploaded_file( $file_tmp_name, $upload_file ) ) {
                        $data['listing_images'] .= wmvc_add_wp_image($upload_file).',';
                    } else {
                        // Error handling if file upload fails
                    }
                }

                $listing_data['listing_images'] = $data['listing_images'] = substr( $data['listing_images'], 0, -1);
            }

            $image_ids = [];
            if(!empty($data['listing_images']))
                $image_ids = explode(',', $data['listing_images']);
        
            $listing_data['listing_images_path'] = '';
            $listing_data['listing_images_path_medium'] = '';

            if(is_array($image_ids)) {
                foreach ($image_ids as $image_id) {
                    if(is_numeric($image_id))
                    {
                        $image_path = wp_get_original_image_path( $image_id);
                        if($image_path) {
                            /* path of image */
                            $next_path = str_replace(WP_CONTENT_DIR . '/uploads/','', $image_path);

                            if(!empty($listing_data['listing_images_path']))
                                $listing_data['listing_images_path'] .= ',';

                            $listing_data['listing_images_path'] .= $next_path;
                        }

                        $image_url = wp_get_attachment_image_url($image_id, 'large');
                        if($image_url) {
                            $parsed = parse_url($image_url);
                            $next_path = substr($parsed['path'], strpos($parsed['path'], 'uploads/')+8);
        
                            if(!empty($listing_data['listing_images_path_medium']))
                                $listing_data['listing_images_path_medium'] .= ',';
        
                            $listing_data['listing_images_path_medium'] .= $next_path;
                        }
                    }
                }
            } 

            if(get_option('wdk_auto_approved') && wmvc_show_data('is_activated', $listing_data) == 1) {
                $listing_data['is_approved'] = 1;
            }
            
            /* dates set */
            if(isset($this->data['db_data']['date']))
                $listing_data['date'] = $this->data['db_data']['date'];

            $listing_data['date_modified'] = date('Y-m-d H:i:s');
            $listing_data['is_activated'] = 1;
            $listing_data['user_id_editor'] = get_current_user_id();

			/* create user if guest */
			if($this->input->post_get('user_email') && !is_user_logged_in()) {
				$username = $this->input->post_get('user_email');
				$email_address = $this->input->post_get('user_email');
				$password = wp_generate_password();

				$user_id = wp_create_user( $username, $password, $email_address );
                $listing_data['user_id_editor'] = $user_id;
				if(is_intval($user_id)){
					// Set the nickname
					wp_update_user(
						array(
							'ID'          =>    $user_id,
							'nickname'    =>    $username
						)
					);

					$available_acc_types = 'wdk_agent';

					$user = new WP_User( $user_id );
					$user->set_role($available_acc_types);

					$userdata = get_userdata($user_id);

					$subject = __('New user on our website!', 'wdk-membership');
					$data_message = array();
					$data_message['login'] = $username;
					$data_message['password'] = $password;
					$data_message['user'] = $userdata;
					$data_message['data'] = '';

					update_user_meta( $user_id, 'first_name', $this->input->post_get('user_name'));
					$ret = wdk_mail($email_address, $subject, $data_message, 'new_user_auto_created');
				}
			}

            if(empty($listing_db_data))
            {
                $Winter_MVC_WDK->listing_m->insert($listing_data, NULL);
            }
            else
            {
                $Winter_MVC_WDK->listing_m->insert($listing_data, $id);
            }

            // insert users/agents

            // Save dynamic fields data

            $data['post_id'] = $id;

            if(empty($listingfield_db_data))
            {
                $Winter_MVC_WDK->listingfield_m->insert_custom_fields($this->data['listing_fields'], $data, NULL);
            }
            else
            {
                $Winter_MVC_WDK->listingfield_m->insert_custom_fields($this->data['listing_fields'], $data, $id);
            }

            do_action('wdk-membership/listing/saved', $id, $this->data['db_data']);
            
            /* multi categories / locations */
            $Winter_MVC_WDK->model('categorieslistings_m');
            $Winter_MVC_WDK->model('locationslistings_m');
            $data_other_categories = array();
            if(isset($data['listing_sub_categories']) || is_null($data['listing_sub_categories'])) {
                $Winter_MVC_WDK->categorieslistings_m->delete_where(array('post_id' => $id));
                if(is_array($data['listing_sub_categories']))
                foreach($data['listing_sub_categories'] as $val)
                {
                    $Winter_MVC_WDK->categorieslistings_m->insert(array('post_id' => $id, 'category_id' => $val), NULL);
                    
                    $data_other_categories []=  $val;
                }
            }

            $data_other_locations = array();
            if(isset($data['listing_sub_locations']) || is_null($data['listing_sub_locations'])) {
                $Winter_MVC_WDK->locationslistings_m->delete_where(array('post_id' => $id));
                if(is_array($data['listing_sub_locations']))
                foreach($data['listing_sub_locations'] as $val)
                {
                    $Winter_MVC_WDK->locationslistings_m->insert(array('post_id' => $id, 'location_id' => $val), NULL);
                    $data_other_locations [] =  $val;
                }
            }

            $data_update = array(
                'categories_list'=> '',
                'locations_list'=>''
            );

            if(!empty($data_other_categories)) {
                $data_update['categories_list'] = ','.join(',',$data_other_categories).',';
            }

            if(!empty($data_other_locations)) {
                $data_update['locations_list'] = ','.join(',',$data_other_locations).',';
            }

            if(!empty($data_update))
                $Winter_MVC_WDK->listing_m->insert($data_update, $id);

            // redirect
            if(!empty($id))
            {
                $listing_post_id = $id;
                $listing_post = get_post( $listing_post_id );
                $listing_db_data = $Winter_MVC_WDK->listing_m->get($listing_post_id, TRUE);
                $listingfield_db_data = $Winter_MVC_WDK->listingfield_m->get($listing_post_id, TRUE);
                $this->data['db_data'] = array_merge((array) $listing_post, 
                                                        (array) $listing_db_data, 
                                                        (array) $listingfield_db_data);

                                                                
                if(isset($_POST['listing_sub_locations'])) {
                    $this->data['db_data']['listing_sub_locations'] = $_POST['listing_sub_locations'];
                }
                
                if(isset($_POST['listing_sub_categories'])) {
                    $this->data['db_data']['listing_sub_categories'] = $_POST['listing_sub_categories'];
                }
                
                foreach($this->data['fields'] as $field)
                {
                    $rules[] = 
                        array(
                            'field' => 'field_'.$field->idfield,
                            'label' => $field->field_label,
                            'rules' => (wmvc_show_data('is_required', $field) == 1) ? 'required' : ''
                        );
        
                    if(isset($this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type]))
                        $this->data['db_data']['field_'.$field->idfield] = 
                            $this->data['db_data']['field_'.$field->idfield.'_'.$field->field_type];
                }
            }
            
            if($listing_data['is_activated'] == 1 && ( !isset($listing_data['is_approved']) || $listing_data['is_approved'] != 1)) {
                /* message data */
                $data_message = array();
                $data_message['user'] = get_userdata( get_current_user_id()); /* user data */
                $data_message['post_id'] = $id;
                $data_message['listing'] = $this->data['db_data']; /* listing data */
                $data_message['post_link'] = get_permalink($id);
                $ret = wdk_mail( get_bloginfo('admin_email'), __('New Listing waiting for approvement', 'wdk-membership'), $data_message, 'new_listing_approve');
            }

            $this->data['db_data'] = null;
            $_POST = array('success_saved'=>1);
        }
     
        if(isset($_POST['success_saved'])) {
            $this->load->view('wdk_membership_quicksubmission/submited_success', $this->data);
        } else {
            $this->load->view('wdk_membership_quicksubmission/submit', $this->data);
        }
    }
}