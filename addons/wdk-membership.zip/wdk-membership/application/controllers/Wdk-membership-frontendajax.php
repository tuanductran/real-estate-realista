<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function agency_agent_submit($output="", $atts=array(), $instance=NULL)
    {

        // Check _wpnonce
        check_admin_referer( 'wdk_agency_agent_submit', '_wpnonce' );

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('agency_agent_m');

        $data = array();
        $data['message'] = esc_html__('Something goes wrong', 'wdk-membership');;
		$data['success'] = false;

        if (defined('WP_DEBUG') && true === WP_DEBUG)
        {
            $data['parameters'] = $_POST;
        }

        $email = sanitize_email( $_POST['agent_email'] );
        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        if(!wmvc_is_valid_email($email) || empty($email))
        {
            $data['message'] = esc_html__('Please enter valid email', 'wdk-membership');
            $this->output($data);
            return;
        }

        if(!wmvc_is_user_in_role( $user, 'wdk_agency' ))
        {
            $data['message'] = esc_html__('Only Agency can add Agents', 'wdk-membership');
            $this->output($data);
            return;
        }

        // get agent info

        $agent = get_user_by('email', $email);

        if(!$agent || !wmvc_is_user_in_role($agent, 'wdk_agent'))
        {
            $data['message'] = esc_html__('Agent account with this email not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // check if already exists

        $agency_agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agency_id'=>$user_id, 'agent_id'=>$agent->ID), FALSE);

        if(count($agency_agent_list) > 0)
        {
            $data['message'] = esc_html__('Agent already invited', 'wdk-membership');
            $this->output($data);
            return;
        }

        // add agency to agent

        $insert_id = $Winter_MVC_wdk_membership->agency_agent_m->insert(array(
            'date' => wp_date('Y-m-d H:i:s'),
            'agency_id' => $user_id,
            'agent_id' => $agent->ID,
            'date_send' => wp_date('Y-m-d H:i:s'),
            'status' => 'PENDING'
        ));

        // send email to agent for confirmation
        $url_confirmation = trim(wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')), 'wdk_confirm_agency=' . $insert_id.'-'.substr(md5($agent->ID.NONCE_SALT), 0, 5), '&'));

        $subject = __('Invitation to become part of agency', 'wdk-membership').' '.wdk_get_user_field ($user_id, 'display_name').' '.wdk_get_user_field ($user_id, 'wdk_company_name');
          
        /* message data */
        $data_message = array();
        $data_message['agency'] = wdk_get_user_field ($user_id, 'display_name').' '.wdk_get_user_field ($user_id, 'wdk_company_name');
        $data_message['agent'] = wdk_get_user_field ($agent->ID, 'display_name');
        $data_message['agency_profile_link'] = '<a href="'.esc_url(wdk_generate_profile_permalink($user)).'">'.esc_html__('Open agency profile page', 'wdk-membership').'</a>';
        $data_message['confirmation_link'] = '<a href="'.esc_url($url_confirmation).'">'.esc_html__('Click to confirm invitation', 'wdk-membership').'</a>';

        $ret =  wdk_mail( $email, $subject, $data_message, 'default');

        $data['message'] = esc_html__('Agent invited and now should accept invitation in email', 'wdk-membership');
        $data['success'] = true;
        $this->output($data);
    }

    public function agency_agent_remove($output="", $atts=array(), $instance=NULL)
    {

        // Check _wpnonce
        check_admin_referer( 'wdk_agency_agent_remove', '_wpnonce' );

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('agency_agent_m');

        $data = array();
        $data['message'] = 'Something goes wrong';
		$data['success'] = false;

        if (defined('WP_DEBUG') && true === WP_DEBUG)
        {
            $data['parameters'] = $_POST;
        }

        $email = sanitize_email( $_POST['agent_email'] );
        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        if(!wmvc_is_valid_email($email) || empty($email))
        {
            $data['message'] = esc_html__('Please enter valid email', 'wdk-membership');
            $this->output($data);
            return;
        }

        if(!wmvc_is_user_in_role( $user, 'wdk_agency' ))
        {
            $data['message'] = esc_html__('Only Agency can remove Agents', 'wdk-membership');
            $this->output($data);
            return;
        }

        // get agent info

        $agent = get_user_by('email', $email);

        if(!$agent || !wmvc_is_user_in_role($agent, 'wdk_agent'))
        {
            $data['message'] = esc_html__('Agent account with this email not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // check if already exists

        $agency_agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agency_id'=>$user_id, 'agent_id'=>$agent->ID), FALSE);

        if(count($agency_agent_list) == 0)
        {
            $data['message'] = esc_html__('Agent connection not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // remove agent from agency

        $Winter_MVC_wdk_membership->agency_agent_m->delete($agency_agent_list[0]->idagency_agent);

        // send email to agent for confirmation
        $subject = __('Agency removed you from agent list', 'wdk-membership').' '.wdk_get_user_field ($user_id, 'display_name').' '.wdk_get_user_field ($user_id, 'wdk_company_name');
          
        /* message data */
        $data_message = array();
        $data_message['agency'] = wdk_get_user_field ($user_id, 'display_name').' '.wdk_get_user_field ($user_id, 'wdk_company_name');
        $data_message['agent'] = wdk_get_user_field ($agent->ID, 'display_name');

        $ret =  wdk_mail( $email, $subject, $data_message, 'default');

        $data['message'] = esc_html__('Agent removed, info sent to their email', 'wdk-membership');
        $data['success'] = true;
        $this->output($data);
    }

    public function agent_agency_remove($output="", $atts=array(), $instance=NULL)
    {
        // Check _wpnonce
        check_admin_referer( 'wdk_agent_agency_remove', '_wpnonce' );

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('agency_agent_m');

        $data = array();
        $data['message'] = 'Something goes wrong';
		$data['success'] = false;

        if (defined('WP_DEBUG') && true === WP_DEBUG)
        {
            $data['parameters'] = $_POST;
        }

        $email = sanitize_email( $_POST['agency_email'] );
        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        if(!wmvc_is_valid_email($email) || empty($email))
        {
            $data['message'] = esc_html__('Please enter valid email', 'wdk-membership');
            $this->output($data);
            return;
        }

        if(!wmvc_is_user_in_role( $user, 'wdk_agent' ))
        {
            $data['message'] = esc_html__('Only Agent can disconenct themself from Agency', 'wdk-membership');
            $this->output($data);
            return;
        }

        // get agent info

        $agency = get_user_by('email', $email);

        if(!$agency || !wmvc_is_user_in_role($agency, 'wdk_agency'))
        {
            $data['message'] = esc_html__('Agency account with this email not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // check if already exists

        $agency_agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agency_id'=>$agency->ID, 'agent_id'=>$user_id), FALSE);

        if(count($agency_agent_list) == 0)
        {
            $data['message'] = esc_html__('Agency connection not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // remove agent from agency

        $Winter_MVC_wdk_membership->agency_agent_m->delete($agency_agent_list[0]->idagency_agent);

        // send email to agent for confirmation
        $subject = __('Agent removed from your Agency', 'wdk-membership').' '.wdk_get_user_field ($user_id, 'display_name');
          
        /* message data */
        $data_message = array();
        $data_message['agency'] = wdk_get_user_field ($agency->ID, 'display_name').' '.wdk_get_user_field ($agency->ID, 'wdk_company_name');
        $data_message['agent'] = wdk_get_user_field ($user_id, 'display_name');

        $ret =  wdk_mail( $email, $subject, $data_message, 'default');

        $data['message'] = esc_html__('Agency removed, info sent to their email', 'wdk-membership');
        $data['success'] = true;
        $this->output($data);
    }

    public function agent_agency_approve($output="", $atts=array(), $instance=NULL)
    {
        // Check _wpnonce
        check_admin_referer( 'wdk_agent_agency_approve', '_wpnonce' );

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->load_helper('listing');

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('agency_agent_m');

        $data = array();
        $data['message'] = 'Something goes wrong';
		$data['success'] = false;

        if (defined('WP_DEBUG') && true === WP_DEBUG)
        {
            $data['parameters'] = $_POST;
        }

        $email = sanitize_email( $_POST['agency_email'] );
        $user_id = get_current_user_id();
        $user = get_userdata( $user_id );

        if(!wmvc_is_valid_email($email) || empty($email))
        {
            $data['message'] = esc_html__('Please enter valid email', 'wdk-membership');
            $this->output($data);
            return;
        }

        if(!wmvc_is_user_in_role( $user, 'wdk_agent' ))
        {
            $data['message'] = esc_html__('Only Agent can approve invitation', 'wdk-membership');
            $this->output($data);
            return;
        }

        // get agent info

        $agency = get_user_by('email', $email);

        if(!$agency || !wmvc_is_user_in_role($agency, 'wdk_agency'))
        {
            $data['message'] = esc_html__('Agency account with this email not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // check if already exists

        $agency_agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agency_id'=>$agency->ID, 'agent_id'=>$user_id), FALSE);

        if(count($agency_agent_list) == 0)
        {
            $data['message'] = esc_html__('Agency connection not detected', 'wdk-membership');
            $this->output($data);
            return;
        }

        // remove agent from agency

        $Winter_MVC_wdk_membership->agency_agent_m->update(array('date_confirmed' => wp_date('Y-m-d H:i:s'), 'status' => 'CONFIRMED'), $agency_agent_list[0]->idagency_agent);

        // send email to agency for confirmation
        $subject = __('Agent confirmed your invitation', 'wdk-membership').' '.wdk_get_user_field ($user_id, 'display_name');
        $data_message = array();
        $data_message['agent'] = wdk_get_user_field ($user_id, 'display_name');

        $ret =  wdk_mail( $email, $subject, $data_message, 'default');

        $data['message'] = esc_html__('You approved invitation', 'wdk-membership');
        $data['success'] = true;
        $this->output($data);
    }

    public function login($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');

        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['parameters'] = $_POST;
		$data['success'] = false;
        $redirect = home_url();
		if(get_option('login_redirect'))
			$redirect = get_permalink(get_option('login_redirect'));
			
		if(wmvc_show_data('redirect_to', $_POST, false))
			$redirect = esc_url(wmvc_show_data('redirect_to', $_POST, false));

        $user_id = get_current_user_id();

		/* recaptcha */
		if(get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key')) {
			if(!is_wdk_valid_recaptcha()) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'. esc_html__('Recaptcha is wrong', 'wdk-membership').'</p>';
			}
		}
		/* end recaptcha */

		if(!empty($data['message'])) {
			/* break and return form message */
		} elseif(!empty($user_id))
        {
            $data['message'] .= '<p class="wdk_alert wdk_alert-success">'.__('You already logged', 'wdk-membership').'</p>';
        } else {
			if(isset($data['parameters']['username']) && isset($data['parameters']['password']) && 
				!empty($data['parameters']['username']) && !empty($data['parameters']['password']))
            {
                if(get_option('app_disable_login'))
                {
                    $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'. esc_html__('Access temporarly disabled in demo.', 'wdk-membership').'</p>';
                } else {

					$data_fields = $this->input->post();
					$credentials = array('user_login' => sanitize_user($data_fields['username']),
										'user_password' => trim($data_fields['password']),
										'remember' => true);
										
					remove_filter('wp_authenticate_user', 'advanced_google_recaptcha_process_login_form');

					$ret = wp_signon($credentials);
					
					wp_clean_plugins_cache();

					// it clears all the cache
					if(function_exists('wpfc_clear_all_cache'))
						wpfc_clear_all_cache();
					
					// it clears cache of all sites
					if(function_exists('wpfc_clear_all_site_cache'))
						wpfc_clear_all_site_cache();
					
					// it clears all the cache with the minified sources
					if(function_exists('wpfc_clear_all_cache'))
						wpfc_clear_all_cache(true);

					$_POST = array();
					$_POST['updated'] = 'true';
					$_POST['widget_id'] = 'login';

					if(get_class($ret) == 'WP_Error')
					{
						$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'. esc_html__('That email/password combination does not exist', 'wdk-membership').'</p>';
					}
					else
					{
						/* login success */
						$data['success'] = true;
						$data['popup_text_success'] = esc_html__('Login successfully', 'wdk-membership');
					}
                }
            } else {

				if(!isset($data['parameters']['username']) || empty($data['parameters']['username'])) {
					$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Email', 'wdk-membership').'</p>';
				}

				if(!isset($data['parameters']['password']) || empty($data['parameters']['password'])) {
					$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Password', 'wdk-membership').'</p>';
				}
            }
        }

        $data['redirect'] = $redirect;
        
		$this->output($data);
    }

    public function register($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');

        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['parameters'] = ($_POST);
		$data['success'] = false;
        $redirect= home_url();
		if(get_option('login_redirect'))
			$redirect = get_permalink(get_option('login_redirect'));


		/* recaptcha */
		if(get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key')) {
			if(!is_wdk_valid_recaptcha()) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'. esc_html__('Recaptcha is wrong', 'wdk-membership').'</p>';
			}
		}
		/* end recaptcha */

        $user_id = get_current_user_id();
		
		if(!empty($data['message'])) {
			/* break and return form message */
		} elseif(get_option('wdk_membership_disable_registration')) {
			if(!get_option('wdk_membership_disable_registration_custom_message')){
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html('New user registration disabled', 'wdk-membership').'</p>';
			} else {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html(get_option('wdk_membership_disable_registration_custom_message')).'</p>';
			}
		} elseif(!empty($user_id))
        {
            $data['message'] .= '<p class="wdk_alert wdk_alert-success">'.__('You already logged', 'wdk-membership').'</p>';
        } else {

			/* validation */
			$is_valid = true;
			if(!isset($data['parameters']['username']) || empty($data['parameters']['username'])) {
				/*
				field is not required
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The username field should be not empty', 'wdk-membership').'</p>';
				$is_valid = false;*/
			} elseif(username_exists( sanitize_email($data['parameters']['email']) )) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The username already exists', 'wdk-membership').'</p>';
				$is_valid = false;
			}
			if(!isset($data['parameters']['email']) || empty(sanitize_email($data['parameters']['email']))) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Email', 'wdk-membership').'</p>';
				$is_valid = false;
			} elseif(email_exists( sanitize_email($data['parameters']['email'] ))) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The email already exists', 'wdk-membership').'</p>';
				$is_valid = false;
			}

			if(!isset($data['parameters']['password']) || empty($data['parameters']['password']) &&
			   !isset($data['parameters']['repassword']) || empty($data['parameters']['repassword'])) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Password', 'wdk-membership').'</p>';
				$is_valid = false;
			}	elseif($data['parameters']['repassword'] != $data['parameters']['password']) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The passwords should be same', 'wdk-membership').'</p>';
				$is_valid = false;
			}	elseif(
					   strlen($data['parameters']['password']) < 5 ||
					   strlen(preg_replace('/\D/', '', $data['parameters']['password']) < 1)
					   ) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The password should be min 5 characters and one number', 'wdk-membership').'</p>';
				$is_valid = false;
			}

            if(get_option('wdk_membership_enable_unique_phone_number') && (isset($data['parameters']['wdk_phone']) && !empty($data['parameters']['wdk_phone']))) {

                global $wpdb;
                $query = $wpdb->prepare(
                    "SELECT user_id FROM $wpdb->usermeta
                    WHERE meta_key = %s AND REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(meta_value, '(', ''), ')', ''), '-', ''), '+', ''), ' ', '') = %s LIMIT 1",
                    'wdk_phone',
                    str_replace(array('(',')','-','+',' '),'',$data['parameters']['wdk_phone'])
                );
                $check_in_meta = $wpdb->get_results($query);

                // Add your own validation logic here
                if (!empty($check_in_meta)) {
                    $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.wdk_sprintf(__( 'User with phone %1$s already exists', 'wdk-membership' ),$data['parameters']['wdk_phone']).'</p>';
                    $is_valid = false;
                }

			}

            if(get_option('wdk_membership_register_show_user_select') && (!isset($data['parameters']['user_role']) || empty($data['parameters']['user_role']))) {
				$data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please Select user role', 'wdk-membership').'</p>';
				$is_valid = false;
			}

			if($is_valid)
            {
                if(get_option('app_disable_login'))
                {
                    $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'. esc_html__('Access temporarly disabled in demo.', 'wdk-membership').'</p>';
                } else {

					$data_fields = $this->input->post();
					$username = sanitize_email($data_fields['email']);
					
					if(isset($data_fields['username']))
                    	$username = sanitize_user($data_fields['username']);

                    $email_address = sanitize_email($data_fields['email']);
                    $password = trim($data_fields['password']);

					$user_id = wp_create_user( $username, $password, $email_address );
					// Set the nickname
					wp_update_user(
						array(
							'ID'          =>    $user_id,
							'nickname'    =>    $username
						)
					);
					
					$available_acc_types = 'wdk_visitor';

					if(get_option('wdk_membership_register_type')){
						$available_acc_types = get_option('wdk_membership_register_type');
					}

					if(get_option('wdk_membership_register_show_user_select') && isset($data_fields['user_role']) && !empty($data_fields['user_role'])){
						$available_acc_types =  sanitize_text_field($data_fields['user_role']);
					}

					$user = new WP_User( $user_id );
					$user->set_role($available_acc_types);

					$additional_fields = array(
						'' => __('Not Selected', 'wdk-membership'),
						'wdk_phone' => __('Phone', 'wdk-membership'),
						'user_url' => __('Url', 'wdk-membership'),
						'first_name' => __('First Name', 'wdk-membership'),
						'last_name' => __('Last Name', 'wdk-membership'),
						'wdk_facebook' => __('Facebook', 'wdk-membership'),
						'wdk_youtube' => __('Youtube', 'wdk-membership'),
						'wdk_address' => __('Address', 'wdk-membership'),
						'wdk_city' => __('City', 'wdk-membership'),
						'wdk_position_title' => __('Position Title', 'wdk-membership'),
						'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
						'wdk_twitter' => __('Twitter', 'wdk-membership'),
						'wdk_telegram' => __('Telegram', 'wdk-membership'),
						'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
						'wdk_viber' => __('Viber', 'wdk-membership'),
						'wdk_iban' => __('IBAN', 'wdk-membership'),
						'wdk_company_name' => __('Company name', 'wdk-membership'),
					);
					foreach ($additional_fields as  $field_id => $field_name) {
						if(isset($_POST[$field_id])){
							if($field_id == 'last_name') {
								update_user_meta( $user_id, 'last', wmvc_xss_clean($_POST[$field_id]) );
								update_user_meta( $user_id, 'last_name', wmvc_xss_clean($_POST[$field_id]) );
							} else {
								update_user_meta( $user_id, $field_id, wmvc_xss_clean($_POST[$field_id]) );
							}
						}
					}

					$display_name = '';

					if ( isset( $_POST['first_name']) && !empty( $_POST['first_name'] ) ){
						$display_name .= wmvc_xss_clean($_POST['first_name']);
					}
		
					if ( isset( $_POST['last_name']) && !empty( $_POST['last_name'] ) ){
						$display_name .= ' ' . wmvc_xss_clean($_POST['last_name']);
					}

					if ( !empty($display_name) ) {
						wp_update_user( array ('ID' => $user_id, 'display_name' => esc_html( $display_name ) ) );
					}

					/* Set default membership subscription if subscription enabled and defined default subscription */
					if(wdk_get_option('wdk_membership_is_enable_subscriptions') && !empty(wdk_get_option('wdk_membership_subscriptions_default_on_registration'))) {
						global $Winter_MVC_wdk_membership;
						$Winter_MVC_wdk_membership->model('subscription_user_m');
						$Winter_MVC_wdk_membership->model('subscription_m');
				
						$subscription = $Winter_MVC_wdk_membership->subscription_m->get(wdk_get_option('wdk_membership_subscriptions_default_on_registration'), TRUE);
						if($subscription){
							$update_data = array();
							$update_data['subscription_id'] = $subscription->idsubscription;
							$update_data['user_id'] = $user_id;
							$update_data['date_expire'] = date('Y-m-d H:i:s', strtotime('+'.$subscription->days_limit.' days', current_time('timestamp')));
							$update_data['status'] = 'ACTIVE';

							$Winter_MVC_wdk_membership->subscription_user_m->insert($update_data);
						}
					}
					$userdata = get_userdata($user_id);

					do_action('wdk-membership/extension/registration/user_created', $user_id);

					$enable_mail_send = true;

					if(has_filter('wdk-membership/extension/registration/filter_output/enable_mail_send'))
						$enable_mail_send = apply_filters('wdk-membership/extension/registration/filter_output/enable_mail_send', $enable_mail_send);

					// Email the admin
					if($enable_mail_send){
						$subject = __('New user on our website!', 'wdk-membership');

						$data_message = array();
						$data_message['user'] = $userdata;
						$data_message['data'] =  __('New user registered on website, please check account', 'wdk-membership').': <a href="'. admin_url('user-edit.php?user_id='.$user_id).'">'.$username.'</a>';
						$ret = wdk_mail( get_bloginfo('admin_email'), $subject, $data_message);
					}
					
					/* register success */
					$data['success'] = true;
					$data['message'] .= '<p class="wdk_alert wdk_alert-info">'. wdk_sprintf(__( 'New account created, please use your credentials for %1$s login %2$s', 'wdk-membership' ), '<a href="'.wdk_login_url().'" style="text-decoration: underline;">', '</a>').'</p>';

                }
            } 
        }
    
		if(has_filter('wdk-membership/extension/registration/filter_output'))
			$data = apply_filters('wdk-membership/extension/registration/filter_output', $data);

        $data['redirect'] = '';
        
		$this->output($data);
    }
     

    public function validation_user_exists($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');

        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['parameters'] = ($_POST);
		$data['success'] = false;

        // Check _wpnonce
        check_admin_referer( 'wdk-validation', '_wpnonce' );

        /* validation */
        $is_valid = true;
        if(!isset($data['parameters']['user_name']) || empty($data['parameters']['user_name'])) {
            /*field is not required*/
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The Name field should be not empty', 'wdk-membership').'</p>';
            $is_valid = false;
        } elseif(username_exists( sanitize_text_field($data['parameters']['user_name']) )) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The Name already exists', 'wdk-membership').'</p>';
            $is_valid = false;
        }
        
        if(!isset($data['parameters']['user_email']) || empty(sanitize_email($data['parameters']['user_email']))) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Email', 'wdk-membership').'</p>';
            $is_valid = false;
        } elseif(email_exists( sanitize_email($data['parameters']['user_email'] ))) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The Email already exists', 'wdk-membership').'</p>';
            $is_valid = false;
        }

        /*
        if(!isset($data['parameters']['password']) || empty($data['parameters']['password']) &&
            !isset($data['parameters']['repassword']) || empty($data['parameters']['repassword'])) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('Please populate field Password', 'wdk-membership').'</p>';
            $is_valid = false;
        }	elseif($data['parameters']['repassword'] != $data['parameters']['password']) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The passwords should be same', 'wdk-membership').'</p>';
            $is_valid = false;
        }	elseif(
                    strlen($data['parameters']['password']) < 5 ||
                    strlen(preg_replace('/\D/', '', $data['parameters']['password']) < 1)
                    ) {
            $data['message'] .= '<p class="wdk_alert wdk_alert-danger">'.esc_html__('The password should be min 5 characters and one number', 'wdk-membership').'</p>';
            $is_valid = false;
        }
        */
        $data['success'] = $is_valid;
		$this->output($data);
    }
     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
