<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_membership_booking_myreservations extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
        wp_enqueue_style( 'dashicons' );
	}

	public function index()
	{

        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('price_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $this->data['total_listings'] = $Winter_MVC_WDK->listing_m->total(array(), TRUE, get_current_user_id());

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('ids');
        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                break;
                default:
            } 
        }
        /* [End Table Actions Bulk Form] */


        /* [Search Form] */

        $controller = 'reservation';
        $columns = array('idreservation', 'search', 'order_by', 'post_title');
        $external_columns = array('post_title');

        $this->data['order_by']   = array('idreservation DESC' => __('ID', 'wdk-membership').' DESC', 
                                          'idreservation ASC' => __('ID', 'wdk-membership').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-membership'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-membership'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $Winter_MVC_wdk_bookings->reservation_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $total_items = $Winter_MVC_wdk_bookings->reservation_m->total_visitor(array(), TRUE, get_current_user_id());
        
        $current_page = 1;

        if(isset($_GET['wmvc_paged']))
            $current_page = intval($_GET['wmvc_paged']);

        $this->data['wmvc_paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page, 'wmvc_paged');

        wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $this->data['reservations'] = $Winter_MVC_wdk_bookings->reservation_m->get_pagination_visitor($per_page, $offset);

        // Load view
        $this->load->view('wdk_membership_dash/bookings/myreservations', $this->data);
    }

    // Edit listing method
	public function edit()
	{
        
        if(!function_exists('run_wdk_bookings')) {
            // Load view
            $this->data['title'] = __('Bookings addon missing', 'wdk-membership');
            $this->data['message'] = __('Please install or activate booking addon', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }
      
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('calendar_m');
        $Winter_MVC_wdk_bookings->model('reservation_m');
        $Winter_MVC_wdk_bookings->model('price_m');

        $id = $this->input->post_get('id');
        /* moved on front view line 137 */
        /*
        if(function_exists('wdk_access_check'))
            wdk_access_check('reservation_m', $id);
        */
       
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['price_reservation'] = NULL;
        $this->data['url_pay'] = NULL;
        $this->data['user_data_owner'] = NULL;

        if($Winter_MVC_wdk_bookings->reservation_m->is_owner($id)){
            $this->data['fields'] = $Winter_MVC_wdk_bookings->reservation_m->fields_list_visitor;
        } else {
            // Load view
            $this->data['title'] = __('My Reservation not allowed', 'wdk-membership').' #'.$id;
            $this->data['message'] = __('Please open only reservation from My Reservation page', 'wdk-membership');
            $this->load->view('wdk_membership_dash/basic/notice_page',  $this->data);
            return true;
        }

        $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>$id), TRUE); // date_package_expire package_id

        if(wmvc_show_data('is_hour_enabled', $calendar, false, TRUE, TRUE )) {
            $this->data['fields'][1]['field_type'] = 'DATETIME_READONLY';
            $this->data['fields'][2]['field_type'] = 'DATETIME_READONLY';
        }
        
        if($this->form->run($this->data['fields']))
        {

            // Save procedure for basic data
            $data = array();
            $data['notes'] = $this->input->post('notes');


            /* if approved */
            $reservation = array();
            if (!empty($id)) {
                $reservation = $Winter_MVC_wdk_bookings->reservation_m->get($id, true);
            }
            $this->data['db_data'] = $Winter_MVC_wdk_bookings->reservation_m->get($id, true);

            if(wmvc_show_data('notes', $reservation, false )) {
                $data['notes'] = wmvc_show_data('notes', $this->data['db_data'], false, TRUE, TRUE).'<br>--------------------------<br>'.wmvc_show_data('notes', $reservation, false );
            } else {
                unset($data['notes']);
            }

            $insert_id = $Winter_MVC_wdk_bookings->reservation_m->insert($data, $id);
                
            // redirect
            if(!empty($insert_id))
            {
                $id = $insert_id;
            }

            if (!empty($reservation) && !empty($insert_id) && !empty($id)) {
                /* if notest changed message */
              
                if(wmvc_show_data('notes', $reservation, false )) {
                    global $Winter_MVC_WDK;
                    $Winter_MVC_WDK->model('listingusers_m');
                    $Winter_MVC_WDK->load_helper('listing');

                    $listing_data = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $this->data['db_data'], false, TRUE, TRUE), TRUE);
                    if( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE )) {
                        $user_data_owner = get_userdata( wmvc_show_data('user_id_editor', $listing_data, false, TRUE, TRUE ) );
                    }
                  
                    if(empty($user_data_owner)) {
                        $user_data_owner = array(
                            'display_name' => __('Administrator', 'wdk-bookings'),
                            'user_email' => get_bloginfo('admin_email'),
                        );
                    }
        
                    $user_data_client = get_userdata(get_current_user_id());

                    $data_message = array();
                    $data_message['user_visitor'] = $user_data_client ; /* user data */
                    $data_message['user_owner'] = $user_data_owner;
                    $data_message['reservation'] = $reservation;
                    $data_message['listing'] = $listing_data;
                    $data_message['reservation_id'] = $insert_id;
                    $data_message['data'] = array(
                        __('Reservation ID', 'wdk-bookings')=> $insert_id,
                        __('Date From', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_from', $reservation)),
                        __('Date To', 'wdk-membership')=> wdk_get_date(wmvc_show_data('date_to', $reservation)),
                    );

                    $calendar = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>wmvc_show_data('post_id', $reservation, false, TRUE, TRUE)), TRUE); // date_package_expire package_id
                    $calendar_fees = array();
                    if($calendar && !empty($calendar->json_data_fees))
                        $calendar_fees = json_decode($calendar->json_data_fees );
                    foreach ($calendar_fees as $fee) {
                        if(!wmvc_show_data('is_activated', $fee, false,TRUE,TRUE)) continue;
                        $data_message['data'][__('Price', 'wdk-membership').' '.wmvc_show_data('title', $fee, '-', TRUE, TRUE)] = wmvc_show_data('value', $fee, '-', TRUE, TRUE).wdk_booking_currency_symbol();
                    }

                    $data_message['data'][__('Total Price', 'wdk-membership')] = wmvc_show_data('price', $reservation).wdk_booking_currency_symbol();

                    $data_message['notes'] = str_replace(PHP_EOL,'<br style="line-height: 0;">', wmvc_show_data('notes', $reservation, '-'));
                    $ret = wdk_mail($user_data_owner->user_email, __('Visitor changed notes on reservation', 'wdk-membership').' #'.$insert_id, $data_message, 'reservation_changed_owner');
                }
            }
        }

        if (!empty($id)) {
            $this->data['db_data'] = $Winter_MVC_wdk_bookings->reservation_m->get($id, true);

            $Winter_MVC_wdk_bookings->db->where("date_from <='".wmvc_show_data('date_from',$this->data['db_data'])."'");
            $Winter_MVC_wdk_bookings->db->where("date_to >= '".wmvc_show_data('date_to',$this->data['db_data'])."'");
            $this->data['price_reservation'] = $Winter_MVC_wdk_bookings->price_m->get_by(array('post_id'=>wmvc_show_data('post_id',$this->data['db_data'])), TRUE);
       
            if(wdk_get_option('wdk_bookings_enable_woocommerce_payments') 
                && function_exists('wc_get_cart_url') 
                && wmvc_show_data('woocommerce_product_id',$this->data['db_data'], false)) {
                $this->data['url_pay'] = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr(wmvc_show_data('woocommerce_product_id',$this->data['db_data'])).'&reservation_id='.esc_attr($id));
            }

            
            global $Winter_MVC_WDK;
            $Winter_MVC_wdk_bookings->model('calendar_m');
            $Winter_MVC_WDK->model('listingusers_m');
            $Winter_MVC_WDK->load_helper('listing');
           
            $this->data['listing'] = $Winter_MVC_WDK->listing_m->get(wmvc_show_data('post_id', $this->data['db_data'], false, TRUE, TRUE), TRUE);

            if( wmvc_show_data('user_id_editor', $this->data['listing'], false, TRUE, TRUE )) {
                $this->data['user_data_owner'] = get_userdata( wmvc_show_data('user_id_editor', $this->data['listing'], false, TRUE, TRUE ) );
            }
          
            if(empty($this->data['user_data_owner'])) {
                $this->data['user_data_owner'] = array(
                    'display_name' => __('Administrator', 'wdk-bookings'),
                    'user_email' => get_bloginfo('admin_email'),
                );
            }

            $this->data['user_data_client'] = array();
            if(wmvc_show_data('user_id', $this->data['db_data'], false, TRUE, TRUE )) {
                $this->data['user_data_client'] = get_userdata(wmvc_show_data('user_id', $this->data['db_data'], false, TRUE, TRUE ));
            } 

            $this->data['calendar'] = $Winter_MVC_wdk_bookings->calendar_m->get_by(array('post_id'=>wmvc_show_data('post_id', $this->data['db_data'], false, TRUE, TRUE)), TRUE); // date_package_expire package_id
        } else {
        }
        
        // Load view
        $this->load->view('wdk_membership_dash/bookings/myreservations_view', $this->data);
    }

    
    public function bulk_delete($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        
        if(!empty($posts_selected)) {
            if(is_array(($posts_selected))) {
                foreach($posts_selected as $key=>$post_id)
                {
                    $Winter_MVC_wdk_bookings->reservation_m->delete($post_id);
                }
            } else {
                if($Winter_MVC_wdk_bookings->reservation_m->delete($posts_selected)) {
                    return true;
                } 
            }

        }
        return true;
    }
    
    public function bulk_deactivate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');

        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->reservation_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_activated'=>NULL), $post_id);
        }
        return true;
    }

    public function bulk_activate($posts_selected)
    {
        global $Winter_MVC_wdk_bookings;
        $Winter_MVC_wdk_bookings->model('reservation_m');
        if(!empty($posts_selected))
        foreach($posts_selected as $key=>$post_id)
        {
            if($Winter_MVC_wdk_bookings->reservation_m->check_deletable($post_id))
                $Winter_MVC_wdk_bookings->reservation_m->insert(array('is_activated'=>1), $post_id);
        }
        return true;
    }
    
}
