<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $wdk_membership_user_types;

$wdk_membership_user_types = array(
    'wdk_visitor' => __('Visitor', 'wdk-membership'),
    'wdk_agency' => __('Agency', 'wdk-membership'),
    'wdk_agent' => __('Agent', 'wdk-membership'),
    'wdk_owner' => __('Owner', 'wdk-membership'),
    'wdk_developer' => __('Developer', 'wdk-membership'),
);

add_action( 'init', 'wdk_membership_custom_user_roles' );

function wdk_membership_custom_user_roles()
{
    global $wdk_membership_user_types;

    foreach($wdk_membership_user_types as $role =>$label)
    {
        if($role == 'wdk_agent') continue;
        
        if(get_option('wdk_membership_user_type_'.$role.'_enable')) {
            add_role($role , $label, array( 'read' => true, 'level_0' => true ) );
        } else {
            remove_role( $role  );
        }
    }

    if (get_option('wdk_membership_user_type_wdk_agency_enable')) {
        $role = get_role('wdk_agency');
        $role->add_cap('edit_own_listings');
        $role->add_cap('edit_own_profile');
        $role->add_cap('upload_files');
    }
    
    if (get_option('wdk_membership_user_type_wdk_owner_enable')) {
        $role = get_role('wdk_owner');
        $role->add_cap('edit_own_listings');
        $role->add_cap('edit_own_profile');
        $role->add_cap('upload_files');
    }

    if (get_option('wdk_membership_user_type_wdk_agent_enable')) {
        $role = get_role('wdk_agent');
        $role->add_cap('edit_own_listings');
        $role->add_cap('edit_own_profile');
        $role->add_cap('upload_files');
    }

    if (get_option('wdk_membership_user_type_wdk_developer_enable')) {
        $role = get_role('wdk_developer');
        $role->add_cap('edit_own_listings'); 
        $role->add_cap('edit_own_profile');
        $role->add_cap('upload_files');
    }
    
    if (get_option('wdk_membership_user_type_wdk_visitor_enable')) {
        $role = get_role('wdk_visitor');
        $role->add_cap('edit_own_profile');
    }
}

?>