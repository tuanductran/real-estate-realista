<?php

namespace WdkMembership\Elementor\Widgets;

use WdkMembership\Elementor\Widgets\WdkMembershipElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipRegisterForm extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );
   
		if ($this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }
        
        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-register-form';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Register Form', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-person';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        $this->enqueue_styles_scripts();
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

       
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()) {
            $this->data['is_edit_mode']= true;
        } else {

        }
      
        echo $this->view('wdk-register-form', $this->data); 
    }


    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );
                        
        $this->add_responsive_control(
            'disable_eye_on_password',
                [
                    'label' => esc_html__( 'Disable eye on password', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'yes',
                    'default' => '',
                ]
        );
        
        $this->add_responsive_control(
            'field_email_labels',
                [
                    'label' => esc_html__( 'Hide Labels', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-register-form .wdk-form-group label:not(.remember_btn)' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_control(
            'field_email',
            [
                'label' => __( 'Label Email', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Email', 'wdk-membership' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_email_placeholder',
            [
                'label' => __( 'Placeholder Email', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Email', 'wdk-membership' ),
            ]
        );

        /* hide username */
        if (false) {
            $this->add_control(
                'field_username',
                [
                    'label' => __('Label Username', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __('Username', 'wdk-membership'),
                    'separator' => 'before',
                ]
            );

    
            $this->add_control(
                'field_username_placeholder',
                [
                    'label' => __('Placeholder Username', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __('Username', 'wdk-membership'),
                ]
            );
        }
    
        $this->add_control(
            'field_password',
            [
                'label' => __('Label Password', 'wdk-membership'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Password', 'wdk-membership'),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_password_placeholder',
            [
                'label' => __( 'Placeholder Passwords', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Passwords', 'wdk-membership' ),
            ]
        );
        
        $this->add_control(
            'field_repassword',
            [
                'label' => __( 'Label Retype Password', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Retype Password', 'wdk-membership' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_repassword_placeholder',
            [
                'label' => __( 'Placeholder Retype Password', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Retype Password', 'wdk-membership' ),
            ]
        );

        $this->add_control(
            'field_submit',
            [
                'label' => __( 'Text Submit Button', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Register', 'wdk-membership' ),
                'separator' => 'before',
            ]
        );
         

        $additional_fields = array(
            '' => __('Not Selected', 'wdk-membership'),
            'username' => __('Username', 'wdk-membership'),
            'wdk_phone' => __('Phone', 'wdk-membership'),
            'user_url' => __('Url', 'wdk-membership'),
            'first_name' => __('First Name', 'wdk-membership'),
            'last_name' => __('Last Name', 'wdk-membership'),
            'wdk_facebook' => __('Facebook', 'wdk-membership'),
            'wdk_youtube' => __('Youtube', 'wdk-membership'),
            'wdk_address' => __('Address', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_city' => __('City', 'wdk-membership'),
            'wdk_position_title' => __('Position Title', 'wdk-membership'),
            'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
            'wdk_twitter' => __('Twitter', 'wdk-membership'),
            'wdk_telegram' => __('Telegram', 'wdk-membership'),
            'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
            'wdk_viber' => __('Viber', 'wdk-membership'),
            'wdk_iban' => __('IBAN', 'wdk-membership'),
            'wdk_accept_terms' => __('Accept terms link', 'wdk-membership'),
            'agency_name' => __('Agency Name', 'wdk-membership'),
        );

        $repeater = new Repeater();
        $repeater->start_controls_tabs( 'additional_fields' );
        $repeater->add_control(
            'field_id',
			[
				'label' => __( 'Field', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '',
                'description' => __( 'Only one field per type will be visible', 'wdk-membership' ),
				'options' => $additional_fields
			]
        );
        
        $repeater->add_control(
            'field_label',
            [
                'label' => __( 'Label Name', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'field_label_text',
            [
                'label' => __( 'Terms text', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'field_id',
                            'operator' => '==',
                            'value' => 'wdk_accept_terms',
                        ]
                    ],
                ],
            ]
        );
        
        $repeater->add_control(
            'field_placeholder',
            [
                'label' => __( 'Placeholder', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'field_id',
                            'operator' => '!=',
                            'value' => 'wdk_accept_terms',
                        ]
                    ],
                ],
            ]
        );

        $repeater->add_responsive_control(
            'is_required',
                [
                    'label' => esc_html__( 'Required', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'yes',
                    'default' => '',
                ]
        );

        $repeater->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'wdk-membership' ),
				'desciption' => esc_html__( 'Link for terms', 'wdk-membership' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'wdk-membership' ),
				'options' => [ 'url', 'is_external' ],
				'default' => [
					'url' => '',
					'is_external' => true,
				],
				'label_block' => true,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'field_id',
                            'operator' => '==',
                            'value' => 'wdk_accept_terms',
                        ]
                    ],
                ],
			]
		);

        $repeater->end_controls_tabs();

        $this->add_responsive_control(
            'additional_fields_list_header',
            [
                'label' => esc_html__('Custom Fields', 'wdk-membership'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'additional_fields_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                ],
                'title_field' => '{{{ field_id }}}',
            ]
        );

        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'form_group',
                'label'=> esc_html__('Form group', 'wdk-membership'),
                'selector'=>'.wdk-register-form .wdk-form-group',
                'options'=>'block',
            ],
            [
                'key'=>'style_label',
                'label'=> esc_html__('Label', 'wdk-membership'),
                'selector'=>'.wdk-register-form .wdk-form-group label:not(.remember_btn)',
                'options'=>'full',
            ],
            [
                'key'=>'style_field',
                'label'=> esc_html__('Fields', 'wdk-membership'),
                'selector'=>'.wdk-element .wdk-register-form .wdk-form-group .wdk-control:not([type="checkbox"])',
                'options'=>'full',
            ],
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-membership'),
                'selector'=>'.wdk-element .wdk-register-form .wdk-btn',
                'options'=>'full',
            ],
            [
                'key'=>'style_links',
                'label'=> esc_html__('Links', 'wdk-membership'),
                'selector'=>'.wdk-element .wdk-register-form .wdk-form-group.checkbox label a',
                'options'=>['typo','color','transition'],
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if( $item ['key'] == 'field_value'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} .wdk-field-value',
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }
            
            if( $item ['key'] == 'style_field'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} .wdk-register-form .wdk-form-group .wdk-control:not([type="checkbox"])',
                );
                $this->generate_renders_tabs($selectors, $item['key'].'style_field_height', ['height']);
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style( 'wdk-register-form' );
        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
        wp_enqueue_style( 'dashicons' );
    }
}
