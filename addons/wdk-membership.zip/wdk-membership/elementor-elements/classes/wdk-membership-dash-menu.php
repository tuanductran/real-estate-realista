<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipMenu extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-dash-menu';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Dash Menu', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-menu-bar';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        
        $this->WMVC_Membership->model('subscription_m');

        $this->data['has_subscription'] = false;
        if( $this->WMVC_Membership->subscription_m->get(NULL, TRUE))
            $this->data['has_subscription'] = true;

        $this->data['has_subscription_private_listings'] = false;
        if($this->WMVC_Membership->subscription_m->get_by(array('is_view_private_listings'=>1), TRUE))
            $this->data['has_subscription_private_listings'] = true;
            
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }


        echo $this->view('wdk-membership-dash-menu', $this->data); 
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'menu_items_list_header',
            [
                'label' => esc_html__('Hide Menu Items', 'wdk-membership'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $menu_items = array(
            'add_listing'=>esc_html__('Add Listing', 'wdk-membership'),
            'manager_listings'=>esc_html__('Listings', 'wdk-membership'),
            'savesearch'=>esc_html__('Save Search', 'wdk-membership'),
            'messages'=>esc_html__('Messages', 'wdk-membership'),
            'bookings'=>esc_html__('Booking', 'wdk-membership'),
            'membership'=>esc_html__('Membership', 'wdk-membership'),
            'favorites'=>esc_html__('Favorites', 'wdk-membership'),
            'reviews'=>esc_html__('Reviews', 'wdk-membership'),
            'payout'=>esc_html__('Payout', 'wdk-membership'),
            'profile'=>esc_html__('Profile', 'wdk-membership'),
            'wooorder'=>esc_html__('Orders', 'wdk-membership'),
            'logout'=>esc_html__('Logout', 'wdk-membership'),
        );

        foreach ($menu_items as $menu_key => $menu_item) {

            if($menu_key == 'bookings') {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '.wdk-front-wrap.wdk_membership_dash_index .wdk_dash_widgets .wdk-membership-dash-widget_booking' => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } 
            else if($menu_key == 'manager_listings') {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '.wdk-front-wrap.wdk_membership_dash_index .wdk_dash_widgets .wdk-membership-dash-widget_listings' => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } 
            else if($menu_key == 'reviews') {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '.wdk-front-wrap.wdk_membership_dash_index .wdk_dash_widgets .wdk-membership-dash-widget_reviews' => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } 
            else if($menu_key == 'favorites') {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '.wdk-front-wrap.wdk_membership_dash_index .wdk_dash_widgets .wdk-membership-dash-widget_favorites' => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } 
            else if($menu_key == 'savesearch') {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '.wdk-front-wrap.wdk_membership_dash_index .wdk_dash_widgets .wdk-membership-dash-widget_savesearch' => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } 
            else {
                $this->add_control(
                    $menu_key.'_disable',
                    [
                        'label' => $menu_item,
                        'type' => \Elementor\Controls_Manager::SWITCHER,
                        'label_on' => __( 'Show', 'wdk-membership' ),
                        'label_off' => __( 'Hide', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                        ],
                    ]
                );
            }
        }

        $this->add_responsive_control(
            'row_gap_col',
            [
                    'label' => __( 'Columns', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '100%' => '1',
                        '50%' => '2',
                        'auto_flexible' => 'inline',
                    ],
                    'selectors_dictionary' => [
                        '100%' =>  'width:100%;-webkit-flex:0 0 100%;flex:0 0 100%',
                        '50%' =>  'width:50%;-webkit-flex:0 0 50%;flex:0 0 50%',
                        'auto_flexible' =>  'width:auto;-webkit-flex:1 2 auto;flex:1 2 auto',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-menu-item' => '{{UNIT}}',
                    ],
                    'default' => '100%', 
                    'separator' => 'before',
                ]
        );

        $this->add_responsive_control(
                'column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 0,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-menu-item' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
                'row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-menu-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_control(
            'link_text',
            [
                'label' => __('Text Add Listing Button', 'wdk-membership'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Add Listing', 'wdk-membership'),
                'separator' => 'before',
            ]
        );
       
        $this->add_control(
            'link_icon',
            [
                'label' => esc_html__('Icon', 'wdk-membership'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-plus',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'link_icon_position',
            [
                'label' => esc_html__('icon Position', 'wdk-membership'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__('Left', 'wdk-membership'),
                    'right' => esc_html__('Right', 'wdk-membership'),
                ],
                'default' => 'left',
            ]
        );

        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'btn',
                'label'=> esc_html__('Button', 'wdk-membership'),
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-btn',
                'hover'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-btn.active,{{WRAPPER}} .wdk-membership-element .wdk-membership-menu .wdkm-btn%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
            /* END special for some elements */
        }

        $items = [
            [
                'key'=>'btn_property',
                'label'=> esc_html__('Button Add Listing', 'wdk-membership'),
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btn',
                'hover'=>'{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btn%1$s,{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btn.active'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
            /* END special for some elements */
        }

        $items = [
            [
                'key'=>'icon',
                'label'=> esc_html__('Icon', 'wdk-membership'),
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btn i,{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btn svg',
                'hover'=>'{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btnn%1$s i,{{WRAPPER}} .wdk-membership-menu .wdk-membership-add-btnn%1$s svg'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-dash-menu');
        wp_enqueue_style( 'dashicons' );
    }
}
