<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkUserDetails extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-user-details';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk User Details', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-person';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $Winter_MVC_WDK;

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['field_value'] = '';
        $this->data['url'] = '';
        $this->data['field_prefix'] = $this->data['settings']['field_prefix'];
        $this->data['field_suffix'] = $this->data['settings']['field_suffix'];

        $field_key = '';
        if(wmvc_show_data($this->data['settings']['custom_meta'], $userdata) == 'avatar') {
            $field_key = 'avatar';
        } elseif(wmvc_show_data($this->data['settings']['custom_meta'], $userdata) == 'link') {
            $field_key = 'avatar';
        } elseif(!empty($this->data['settings']['custom_meta'])) {
            $field_key = $this->data['settings']['custom_meta'];
        } elseif(!empty($this->data['settings']['meta_key'])){
            $field_key = $this->data['settings']['meta_key'];
        }
        $this->data['field_key'] = $field_key;

        if(!empty($this->data['settings']['user_id'])) {
            $userdata = get_userdata(intval(substr($this->data['settings']['user_id'],1, strpos($this->data['settings']['user_id'],' ')-1)));
            $this->data['url'] = wdk_generate_profile_permalink($userdata);
            if($field_key == 'link') {
                $this->data['field_value'] = wdk_generate_profile_permalink($userdata);
            } elseif($field_key == 'avatar') {
                $this->data['field_value'] = get_avatar_url(intval(substr($this->data['settings']['user_id'],1, strpos($this->data['settings']['user_id'],' ')-1)));
            } elseif($userdata && !empty(wmvc_show_data($field_key, $userdata))){
                $this->data['field_value'] = wmvc_show_data($field_key, $userdata);
            }
        }

        if(in_array($field_key, ['user_email','wdk_facebook', 'wdk_youtube','wdk_address','wdk_phone','wdk_linkedin','wdk_twitter','wdk_telegram']) && !empty($this->data['settings']['field_default_value'])) {
            $this->data['field_value'] = $this->data['settings']['field_default_value'];
        }
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
            if(!empty($this->data['field_value'])) {

            } else {
                if(!empty($this->data['settings']['custom_meta'])) {
                    $this->data['field_value'] =  esc_html__('Example').' '.$this->data['settings']['custom_meta'];
                } elseif(!empty($this->data['settings']['meta_key'])){
                    $this->data['field_value'] =  esc_html__('Example').' '.$this->data['settings']['meta_key'];
                }
            }

        } else {
            /* return false if no content */
            if(empty($this->data['field_value']))
                return false;
        }


        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-user-details', $this->data); 
    }

    private function generate_controls_conf() {

        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );
        
        $dbusers =  get_users( array( 'search' => '',
                                            'orderby' => 'display_name', 'order' => 'ASC'));
        $users = array('0'=>esc_html__('Not Selected', 'wdk-membership'));
            foreach($dbusers as $dbuser) {
            $users['#'.wmvc_show_data('ID', $dbuser).' '.wmvc_show_data('display_name', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->add_control(
            'user_id',
            [
                'label' => __( 'ID User', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'label_block' => true,
                'options' => $users,
            ]
        );

        $this->add_control(
            'per_page_hr',
            [
                    'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $meta_fields = array(
            '' => __('Not Selected', 'wdk-membership'),
            'avatar' => __('Avatar', 'wdk-membership'),
            'link' => __('Link', 'wdk-membership'),
            'wdk_phone' => __('Phone', 'wdk-membership'),
            'user_email' => __('Email', 'wdk-membership'),
            'user_url' => __('Url', 'wdk-membership'),
            'display_name' => __('Display Name', 'wdk-membership'),
            'wdk_facebook' => __('Facebook', 'wdk-membership'),
            'wdk_youtube' => __('Youtube', 'wdk-membership'),
            'wdk_address' => __('Address', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_city' => __('City', 'wdk-membership'),
            'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
            'wdk_twitter' => __('Twitter', 'wdk-membership'),
            'wdk_telegram' => __('Telegram', 'wdk-membership'),
            'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
            'wdk_viber' => __('Viber', 'wdk-membership'),
            'wdk_iban' => __('IBAN', 'wdk-membership'),
            'wdk_company_name' => __('Company name', 'wdk-membership'),
            'agency_name' => __('Agency Name', 'wdk-membership'),
        );

        
        $this->add_control(
            'meta_key',
            [
                'label' => __( 'Field', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'display_name',
                'label_block' => true,
                'options' => $meta_fields,
            ]
        );

        $this->add_control(
            'custom_meta',
            [
                'label' => __( 'Custom User Field', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'field_suffix',
            [
                'label' => __( 'Label suffix', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_control(
            'field_prefix',
            [
                'label' => __( 'Label prefix', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        
        $this->end_controls_section();


        $this->start_controls_section(
            'tab_conf_main_section_field_with_icons',
            [
                'label' => esc_html__('Details', 'wdk-membership'),
                'tab' => '1',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'meta_key',
                            'operator' => 'in',
                            'value' => [
                                'user_email',
                                'wdk_facebook',
                                'wdk_youtube',
                                'wdk_address',
                                'wdk_phone',
                                'wdk_linkedin',
                                'wdk_twitter',
                                'wdk_whatsapp',
                                'wdk_viber',
                                'wdk_telegram',
                            ],
                        ],
                    ],    
                ],
            ]
        );
       
        $this->add_control(
            'field_default_value',
            [
                'label' => __( 'Value', 'wdk-membership' ),
                'description' => __( 'Show custom text instead link/email/phone', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'field_labels',
                [
                    'label' => esc_html__( 'Hide Icon', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-login-form .wdk-form-group label:not(.remember_btn)' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'field_icon_hide',
                [
                    'label' => esc_html__( 'Hide Icon', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-user-details i, {{WRAPPER}} .wdk-membership-user-details svg' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'field_label_hide',
                [
                    'label' => esc_html__( 'Hide Label', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-user-details span.text' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $fields_icons = array(
            'user_email'=>'fa fa-envelope',
            'wdk_youtube'=>'fab fa-youtube',
            'wdk_facebook'=>'fab fa-facebook',
            'wdk_linkedin'=>'fab fa-linkedin',
            'wdk_twitter'=>'fab fa-twitter',
            'wdk_telegram'=>'fab fa-telegram',
            'wdk_whatsapp' => 'fab fa-whatsapp',
            'wdk_viber' => 'fab fa-viber',
            'link'=>'fa fa-anchor',
            'wdk_phone'=>'fa fa-phone',
        );

        foreach ($fields_icons as $key => $value) {
            # code...
            $this->add_control(
                'icon_'.$key,
                [
                    'label' => esc_html__('Icon', 'wdk-membership'),
                    'type' => Controls_Manager::ICONS,
                    'label_block' => true,
                    'default' => [
                        'value' => $value,
                        'library' => 'solid',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'meta_key',
                                'operator' => '==',
                                'value' => $key,
                            ],
                        ],
                    ],
                ]
            );
        }

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-membership-user-details i,{{WRAPPER}} .wdk-membership-user-details svg',
            'hover' => '{{WRAPPER}} .wdk-membership-user-details%1$s i,{{WRAPPER}} .wdk-membership-user-details%1$s svg'
        );
        $this->generate_renders_tabs($selectors, 'icons_dynamic', ['margin','color','font-size','hover_animation']);

        $this->end_controls_section();
        
    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'field_value',
                'label'=> esc_html__('Field Label', 'wdk-membership'),
                'selector'=>'.wdk-membership-user-details',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition'],
            ],
            [
                'key'=>'field_value_avatar',
                'label'=> esc_html__('Avatar', 'wdk-membership'),
                'selector'=>'.wdk-membership-user-details .wdk-avatar',
                'options'=>['margin','border','border_radius','padding','shadow','transition','image_size_control','css_filters','background_group','hover_animation'],
            ]
        ];


        foreach ($items as $item) {
            if($item['key'] == 'field_value_avatar') {
                $this->start_controls_section(
                    $item['key'].'_section',
                    [
                        'label' => $item['label'],
                        'tab' => 'tab_layout',
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'meta_key',
                                    'operator' => '==',
                                    'value' => 'avatar',
                                ],
                            ],
                        ],
                    ]
                );
            } else {
                $this->start_controls_section(
                    $item['key'].'_section',
                    [
                        'label' => $item['label'],
                        'tab' => 'tab_layout',
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'meta_key',
                                    'operator' => '!=',
                                    'value' => 'avatar',
                                ],
                            ],
                        ],
                    ]
                );
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);


            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-user-details');
    }
}
