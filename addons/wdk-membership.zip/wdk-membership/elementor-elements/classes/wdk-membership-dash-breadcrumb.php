<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipBreadcrumb extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-dash-breadcrumb';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Dash Breadcrumb', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-product-breadcrumbs';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['breadcrumb_items'] = wdk_membership_generate_page_title_tags();
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-dash-breadcrumb', $this->data); 
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('icon', 'wdk-membership'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-chevron-right',
                    'library' => 'solid',
                ],
            ]
        );


        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {

        $items = [
            [
                'key'=>'breadcrumb',
                'label'=> esc_html__('Breadcrumb', 'wdk-listing-sliders'),
                'selector'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb',
                'options'=>['align','background','border','border_radius','margin','padding','shadow','transition'],
            ],
            [
                'key'=>'link_item',
                'label'=> esc_html__('Link', 'wdk-listing-sliders'),
                'selector'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb .wdk-breadcrumb-item',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb .wdk-breadcrumb-item%1$s',
                'options'=>['background','border','border_radius','margin','padding','color','typo','shadow','transition'],
            ],
            [
                'key'=>'icon',
                'label'=> esc_html__('Icon', 'wdk-listing-sliders'),
                'selector'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb i,{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb svg',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb i%1$s,{{WRAPPER}} .wdk-membership-element .wdk-membership-dash-breadcrumb svg%1$s',
                'options'=>['background','border','border_radius','margin','padding','color','font-size','shadow','transition'],
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => Controls_Manager::TAB_STYLE,
                ]
            );
    
            $selectors = array(
                'normal' => $item['selector'],
                'hover'=> $item['selector_hover'],
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
        }

    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-dash-breadcrumb');
        wp_enqueue_style( 'dashicons' );
    }
}
