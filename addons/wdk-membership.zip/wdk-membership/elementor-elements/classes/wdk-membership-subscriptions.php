<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipSubscriptions extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-subscriptions';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Membership Subscriptions', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-cart';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->WMVC_Membership->model('subscription_m');
        $this->WMVC_Membership->model('subscription_user_m');
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('listing_m');
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('category_m');
        $this->data['results'] = array();
        $this->data['listings_custom'] = array();

        if($this->data['settings']['conf_results_type'] == 'results_listings') {
            


        } else if($this->data['settings']['conf_results_type'] == 'custom_listings') {
            $listings_ids = array();
            $this->data['listings_custom'] = array();
            foreach($this->data['settings']['conf_custom_results'] as $listing) {
                if(isset($listing['listing_post_id']) && !empty($listing['listing_post_id']) && is_intval($listing['listing_post_id'])) {
                    $listings_ids [] = $listing['listing_post_id'];
                    $this->data['listings_custom'][$listing['listing_post_id']] = $listing;
                }
            }

            /* where in */
            if(!empty($listings_ids)){
                $this->WMVC_Membership->db->where( $this->WMVC_Membership->subscription_m->_table_name.'.idsubscription IN(' . implode(',', $listings_ids) . ')', null, false);
                $this->WMVC_Membership->db->order_by('FIELD('.$this->WMVC_Membership->subscription_m->_table_name.'.idsubscription, '. implode(',', $listings_ids) . ')');
            }
        }


        if(is_user_logged_in()){
            $this->WMVC_Membership->db->join($this->WMVC_Membership->subscription_user_m->_table_name.' ON ('.$this->WMVC_Membership->subscription_m->_table_name.'.idsubscription = '.$this->WMVC_Membership->subscription_user_m->_table_name.'.subscription_id AND 
                    '.$this->WMVC_Membership->subscription_user_m->_table_name.'.user_id = "'.get_current_user_id().'")', TRUE, 'LEFT');

            $this->WMVC_Membership->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON '.$Winter_MVC_WDK->listing_m->_table_name.'.subscription_id = '.$this->WMVC_Membership->subscription_m->_table_name.'.idsubscription', TRUE, 'LEFT');
                
            $this->WMVC_Membership->db->where(array(
                                '(
                                ((date_from IS NULL OR date_from < \''.current_time( 'mysql' ).'\') AND (date_to IS NULL OR date_to > \''.current_time( 'mysql' ).'\'))
                                OR
                                ('.$this->WMVC_Membership->subscription_user_m->_table_name.'.date_expire  IS NOT NULL)
                                )'
                                =>NULL
                            ));

            
            $this->WMVC_Membership->db->where(array(
                                                '(user_types LIKE "%,'.wmvc_get_current_user_role().',%" OR user_types IS NULL)'=>NULL
                                            ));


            $this->WMVC_Membership->db->group_by('idsubscription');

            $this->data['results'] = $this->WMVC_Membership->subscription_m->get_pagination($this->data['settings']['limit'], NULL, array($this->WMVC_Membership->subscription_m->_table_name.'.is_activated = 1'=>NULL), 
                                        NULL, $this->WMVC_Membership->subscription_user_m->_table_name.'.*,'.$this->WMVC_Membership->subscription_m->_table_name.'.*, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.post_id) AS listings_counter,'.
                                        $Winter_MVC_WDK->location_m->_table_name.'.*,'.$Winter_MVC_WDK->category_m->_table_name.'.*');

        } else {  

            $this->WMVC_Membership->db->where(array(
                '((date_from IS NULL OR date_from < \''.current_time( 'mysql' ).'\') AND (date_to IS NULL OR date_to > \''.current_time( 'mysql' ).'\'))' =>NULL
            ));

            $this->WMVC_Membership->db->where(array(
                '(is_only_login_user IS NULL OR is_only_login_user = 0)'=>NULL
            ));

            $this->data['results'] = $this->WMVC_Membership->subscription_m->get_pagination($this->data['settings']['limit'], NULL, array('is_activated'=>1));
        
        }

        $this->data['settings']['login_url'] =  wp_login_url();
        $this->data['user_subscriptions'] = array();
        if(wdk_get_option('wdk_membership_login_page')){
            $this->data['settings']['login_url'] = get_permalink(wdk_get_option('wdk_membership_login_page'));
        } 
        
        $this->data['listings_limit'] = false;

        if(is_user_logged_in()){
            $limit = NULL;
            if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled'))
                $limit = 1;
            
            $user_subscriptions = $this->WMVC_Membership->subscription_user_m->get_pagination($limit, FALSE, array('is_activated'=>1, 'status !='=>'DEPRECATED'),'subscription_id DESC');
            if($user_subscriptions){
                foreach($user_subscriptions as $subscription) {
                    $this->data['user_subscriptions'][wdk_show_data('subscription_id',$subscription,'',TRUE,TRUE)] = $subscription;
                }
            }
           
            $this->data['user_have_active'] = $this->WMVC_Membership->subscription_user_m->check_have_active();

            /* check if all subscriptions have limit listings */
            $this->data['listings_limit'] = false;
            if (count($this->data['user_subscriptions']) > 0) {
                global $Winter_MVC_WDK;
                $Winter_MVC_WDK->model('listing_m');
                $listings_limit_counter = 0 ;
                foreach($this->data['user_subscriptions'] as $subscription) {

                    if(empty($subscription->date_expire) || strtotime($subscription->date_expire) < time()) continue;

                    if(wdk_show_data('listings_limit', $subscription, '0') == '-1') {
                        $listings_limit_counter = '-1';
                        break;
                    }
                    $listings_limit_counter += wdk_show_data('listings_limit', $subscription, '0');
                }

                $listings_count = $Winter_MVC_WDK->listing_m->total(array(), TRUE, get_current_user_id());
                if($listings_limit_counter != '-1' && intval($listings_count) >= $listings_limit_counter) $this->data['listings_limit'] = true;
            }

        }
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-subscriptions', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'conf_results_type',
            [
                'label' => __( 'Subscription type results', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'results_listings',
                'options' => [
                    'results_listings'  => __( 'Results Subscription', 'wdk-membership' ),
                    'custom_listings' => __( 'Specific Subscription', 'wdk-membership' ),
                ],
                'separator' => 'after',
            ]
        );

         /* conf_results_type :: results_listings */
         if(true){
            $this->add_control(
                    'conf_results_type_results_listings_header',
                    [
                        'label' => esc_html__('Subscription listings', 'wdk-membership'),
                        'type' => Controls_Manager::HEADING,
                        'separator' => 'before',
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'conf_results_type',
                                    'operator' => '==',
                                    'value' => 'results_listings',
                                ]
                            ],
                        ],
                    ]
            );

            $this->add_control(
                'limit',
                [
                    'label' => __( 'Limit Listing Subscription (Per page)', 'wdk-membership' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 1,
                    'max' => 50,
                    'step' => 1,
                    'default' => 3,
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'conf_results_type',
                                'operator' => '==',
                                'value' => 'results_listings',
                            ]
                        ],
                    ],
                ]
            );
        }

        if(true) {
            $this->add_control(
                'conf_results_type_custom_listings_header',
                [
                    'label' => esc_html__('Custom listings', 'wdk-membership'),
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'conf_results_type',
                                'operator' => '==',
                                'value' => 'custom_listings',
                            ]
                        ],
                    ],
                ]
            );

            
            if(true){
                $subscriptions = array();
                $this->WMVC_Membership->model('subscription_m');
                $subscriptions_list = $this->WMVC_Membership->subscription_m->get();
                if (count($subscriptions_list) > 0) {
                    foreach($subscriptions_list as $subscription) {
                        $subscriptions[wdk_show_data('idsubscription', $subscription, TRUE, TRUE)] = wdk_show_data('idsubscription', $subscription,'', TRUE, TRUE)
                                                                                                    .', '.wdk_show_data('subscription_name', $subscription,'', TRUE, TRUE);
                    }
                }

                $repeater = new Repeater();
                $repeater->start_controls_tabs( 'listings' );
                $repeater->add_control(
                    'listing_post_id',
                    [
                        'label' => __( 'ID Post Listing', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::SELECT,
                        'default' => '',
                        'options' => $subscriptions,
                    ]
                );

                $repeater->add_responsive_control(
                    'is_auto_featured',
                        [
                            'label' => esc_html__( 'Featured', 'wdk-membership' ),
                            'type' => Controls_Manager::SWITCHER,
                            'none' => esc_html__( 'false', 'wdk-membership' ),
                            'block' => esc_html__( 'True', 'wdk-membership' ),
                            'return_value' => '1',
                            'default' => 0,
                        ]
                );

                $repeater->end_controls_tabs();

                                
                $this->add_control(
                    'conf_custom_results',
                    [
                        'type' => Controls_Manager::REPEATER,
                        'fields' => $repeater->get_controls(),
                        'default' => [
                        ],
                        'title_field' => '{{{ listing_post_id }}}',
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'conf_results_type',
                                    'operator' => '==',
                                    'value' => 'custom_listings',
                                ]
                            ],
                        ],
                    ]
                );

            }
        }
                    
        $this->end_controls_section();

    }

    private function generate_controls_layout() {
        $this->start_controls_section(
            'tab_content',
            [
                'label' => esc_html__('Basic', 'wdk-membership'),
                'tab' => 'tab_layout',
            ]
        );

        $this->add_responsive_control(
            'row_gap_col',
            [
                    'label' => __( 'Columns', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('Default', 'wdk-membership'),
                        'auto' => esc_html__('Auto', 'wdk-membership'),
                        '100%' => '1',
                        '50%' => '2',
                        'calc(100% / 3)' => '3',
                        '25%' => '4',
                        '20%' => '5',
                        'auto_flexible' => 'auto flexible',
                    ],
                    'selectors_dictionary' => [
                        'auto' => '-webkit-flex:0 0 auto;flex:0 0 auto',
                        '100%' =>  '-webkit-flex:0 0 100%;flex:0 0 100%',
                        '50%' =>  '-webkit-flex:0 0 50%;flex:0 0 50%',
                        'calc(100% / 3)' =>  '-webkit-flex:0 0 calc(100% / 3);flex:0 0 calc(100% / 3)',
                        '25%' =>  '-webkit-flex:0 0 25%;flex:0 0 25%',
                        '20%' =>  '-webkit-flex:0 0 20%;flex:0 0 20%',
                        'auto' =>  'width:auto;-webkit-flex:0 0 auto;flex:0 0 auto',
                        'auto_flexible' =>  '-webkit-flex:0 0 auto;flex:0 0 auto',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => '{{UNIT}}',
                    ],
                    'default' => 'calc(100% / 3)', 
                    'separator' => 'before',
            ]
    );

    $this->add_responsive_control (
            'column_gap',
            [
                'label' => esc_html__('Columns Gap', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-row .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                    '{{WRAPPER}} .wdk-row' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                ],
            ]
    );

    $this->add_responsive_control (
            'row_gap',
            [
                'label' => esc_html__('Rows Gap', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 10,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-row  .wdk-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wdk-row' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                ],
            ]
    );
    $this->end_controls_section();

    }

    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'card',
                'label'=> esc_html__('Card', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured',
                'options'=>['background','border','border_radius','padding','shadow','transition'],
            ],
            [
                'key'=>'card_name',
                'label'=> esc_html__('Package Name (top)', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .top',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .top',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .top',
                'options'=>'full',
            ],
            [
                'key'=>'card_header',
                'label'=> esc_html__('Header', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .header',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .header',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .header',
                'options'=>['margin','typo','color','background','padding','transition'],
            ],
            [
                'key'=>'card_subname',
                'label'=> esc_html__('Expire Text', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .header .expired',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .header .expired',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .header .expired',
                'options'=>['color','typo'],
            ],
            [
                'key'=>'card_price',
                'label'=> esc_html__('Price', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .pricing-value .price',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .pricing-value .price',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .pricing-value .price',
                'options'=>['color','typo'],
            ],
            [
                'key'=>'card_item',
                'label'=> esc_html__('Item', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .list-items .item',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .list-items .item',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .list-items .item',
                'options'=>'full',
            ],
            [
                'key'=>'card_item_border',
                'label'=> esc_html__('Item border', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .list-items .item:not(:first-child)',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .list-items .item:not(:first-child)',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .list-items .item:not(:first-child)',
                'options'=>['border'],
            ],
            [
                'key'=>'card_footer',
                'label'=> esc_html__('Footer', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .wdk-pac-footer',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .wdk-pac-footer',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .wdk-pac-footer',
                'options'=>'full',
            ],
            [
                'key'=>'card_footer_link',
                'label'=> esc_html__('Buy Button', 'wdk-membership'),
                'selector'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac .wdk-pac-footer .btn',
                'selector_hover'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac%1$s .wdk-pac-footer .btn',
                'featured'=>'{{WRAPPER}} .wdk-membership-subscriptions .wdk-pac.featured .wdk-pac-footer .btn',
                'options'=>'full',
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' =>  Controls_Manager::TAB_STYLE,
                ]
            );
            $this->add_responsive_control(
                $item['key'].'_hide',
                    [
                        'label' => esc_html__( 'Hide Element', 'wdk-membership' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-membership' ),
                        'block' => esc_html__( 'Show', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            $item['selector'] => 'display: {{VALUE}};',
                        ],
                    ]
            );
            
            $selectors = array(
                'normal' => $item['selector'],
            );

            if(isset($item['selector_hover']))
                $selectors['hover'] = $item['selector_hover'];

            if(isset($item['featured']))
                $selectors['featured'] = $item['featured'];

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            if( $item['key'] =='card_footer_link') {
                $this->add_control(
                    'link_text',
                    [
                        'label' => __( 'Link Text', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __( 'Buy', 'wdk-membership' ),
                        'separator' => 'before',
                    ]
                );
            }

            $this->end_controls_section();
        }
    }
    
    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-subscriptions');
        wp_enqueue_style( 'dashicons' );
    }
}
