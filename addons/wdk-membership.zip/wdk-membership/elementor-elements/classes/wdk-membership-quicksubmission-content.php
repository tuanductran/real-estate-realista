<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipQuickSubmissionContent extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-quicksubmission-content';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Quick Submission Listing', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-post-content';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        if (Plugin::$instance->editor->is_edit_mode()) {
            echo $this->view('wdk-membership-quicksubmission-content', $this->data);
        } else {
            echo $this->view('wdk-membership-quicksubmission-content', $this->data);
        }
    }

    private function generate_controls_conf() {
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {
        $this->start_controls_section(
            'colors_sections',
            [
                    'label' => esc_html__('Colors', 'wdk-membership'),
                    'tab' => '1'
                ]
        );

        $WMVC = &wdk_get_instance();
        $WMVC->model('category_m');
        $WMVC->model('location_m');
		$categories_data = $WMVC->category_m->get_by(array('(parent_id = 0 OR parent_id IS NULL)' => NULL));
        $categories_list = array('' => esc_html__('Not Selected', 'wpdirectorykit'));
        $order_i = 0;

        foreach($categories_data as $category)
        {
            $categories_list[(++$order_i).'__'.wmvc_show_data('idcategory', $category)] = '#'.wmvc_show_data('idcategory', $category).' '.wmvc_show_data('category_title', $category);
        }
        $this->add_control(
            'custom_category_root',
            [
                    'label' => __( 'Custom Category Root', 'wpdirectorykit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => $categories_list,
                    'default' => 'results', 
            ]
        );
        
		$locations_data = $WMVC->location_m->get_by(array('(parent_id = 0 OR parent_id IS NULL)' => NULL));
        $locations_list = array('' => esc_html__('Not Selected', 'wpdirectorykit'));
        $order_i = 0;

        foreach($locations_data as $location)
        {
            $locations_list[(++$order_i).'__'.wmvc_show_data('idlocation', $location)] = '#'.wmvc_show_data('idlocation', $location).' '.wmvc_show_data('location_title', $location);
        }
        $this->add_control(
            'custom_location_root',
            [
                    'label' => __( 'Custom Location Root', 'wpdirectorykit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => $locations_list,
                    'default' => 'results', 
            ]
        );

        $this->add_control(
            'color_primary',
            [
                    'label' => __('Primary', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_primary:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_hover',
            [
                    'label' => __('Primary Hover', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_primary_hover:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_secondary',
            [
                    'label' => __('Secondary', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_secondary:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_secondary_hover',
            [
                    'label' => __('Secondary Hover', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_secondary_hover:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_link',
            [
                    'label' => __('Links', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_link:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_link_hover',
            [
                    'label' => __('Links Hover', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_link_hover:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_text',
            [
                    'label' => __('Text', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_text:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_bkg_default',
            [
                    'label' => __('Background Default Elements', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--color_bkg_default:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_background',
            [
                    'label' => __('Background', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .postbox .inside,{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .postbox, 
                        {{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk_postbox,{{WRAPPER}} table.wdk-table' => 'background:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'color_main_texts',
            [
                    'label' => __('Text main', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => 'color:{{VALUE}}',
                    ],
                ]
        );


        $this->add_control(
            'tabs_color_text',
            [
                    'label' => __('Tabs color text', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label' => 'color:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'tabs_color_text_hover',
            [
                'label' => __('Tabs color text hover/active', 'wdk-membership'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label.active, 
                     {{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label:hover' => 'color:{{VALUE}}',
                ],
            ]
        );


        $this->add_control(
            'tabs_color_bcg',
            [
                'label' => __('Tabs color background', 'wdk-membership'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label' => 'background:{{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'tabs_color_bcg_hover',
            [
                'label' => __('Tabs color background hover/active', 'wdk-membership'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label.active, 
                    {{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label:hover' => 'background:{{VALUE}}',
                    '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label.active:before, 
                    {{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label:hover:before' => 'border-left: 16px solid {{VALUE}};',
           
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tabs_typo',
                'selector' => '{{WRAPPER}} .wdk-membership-element .wdk-front-wrap .wdk-tabs-wrapper.wdk-tabs-wrapper-submit-listing .wdk-tabs-navs label',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'borders_sections',
            [
                    'label' => esc_html__('Borders', 'wdk-membership'),
                    'tab' => '1'
                ]
        );

        $this->add_control(
            'border_color',
            [
                    'label' => __('Border Color', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--border_color:{{VALUE}}',
                    ],
                ]
        );

        $this->add_control(
            'border_width',
            [
                    'label' => __('Border Width', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 5,
                            'step' => 1,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--border_width: {{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_control(
            'border_radius',
            [
                    'label' => __('Border Radius', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'default' => [
                        'unit' => 'px',
                        'size' => 0,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 30,
                            'step' => 1,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => '--border_radius: {{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->end_controls_section();

            $this->start_controls_section(
            'font_sections',
            [
                    'label' => esc_html__('Font', 'wdk-membership'),
                    'tab' => '1'
                ]
            );

            $this->add_control(
                'font_family',
                [
                    'label' => __( 'Font Family', 'wdk-membership' ),
                    'type' => \Elementor\Controls_Manager::FONT,
                    'selectors' => [
                        '{{WRAPPER}} .wdk-front-wrap' => 'font-family: {{VALUE}}',
                    ],
                ]
            );
       
            $this->add_control(
                'font_size_1',
                [
                        'label' => __('Font Size 1', 'wdk-membership'),
                        'description' => __('Elements like: title (selectors: h1-h6.wdk-h)', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                       
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-front-wrap' => '--font_size_1: {{SIZE}}{{UNIT}};',
                        ],
                    ]
            );
            
            $this->add_control(
                'font_size_2',
                [
                        'label' => __('Font Size 2', 'wdk-membership'),
                        'description' => __('Elements like: title in form,pagination (selectors: .postbox .postbox-header h3,
                                            .postbox .wdk_postbox-header h3, .wdk_postbox .postbox-header h3, .wdk_postbox .wdk_postbox-header h3,.tablenav-pages-navspan )', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'separator' => 'before',
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-front-wrap' => '--font_size_2: {{SIZE}}{{UNIT}};',
                        ],
                    ]
            );
            $this->add_control(
                'font_size_3',
                [
                        'label' => __('Font Size 3', 'wdk-membership'),
                        'description' => __('Elements like: buttons in header, submit buttons, labels', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'separator' => 'before',
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-front-wrap' => '--font_size_3: {{SIZE}}{{UNIT}};',
                        ],
                    ]
            );
            $this->add_control(
                'font_size_4',
                [
                        'label' => __('Font Size 4', 'wdk-membership'),
                        'description' => __('Elements like: middle buttons', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'separator' => 'before',
                        'size_units' => [ 'px' ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-front-wrap' => '--font_size_4: {{SIZE}}{{UNIT}};',
                        ],
                    ]
            );
            $this->add_control(
                'font_size_5',
                [
                        'label' => __('Font Size 5', 'wdk-membership'),
                        'description' => __('Elements like: tables, extra small buttons', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px' ],
                        'separator' => 'before',
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 50,
                                'step' => 1,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-front-wrap' => '--font_size_5: {{SIZE}}{{UNIT}};',
                        ],
                    ]
            );

        $this->end_controls_section();

            $this->start_controls_section(
            'steps_section',
            [
                    'label' => esc_html__('Steps', 'wdk-membership'),
                    'tab' => '1'
                ]
            );

                
            $WMVC = &wdk_get_instance();
            $WMVC->model('field_m'); 

            $sections_list = array('0' => esc_html__('Not Selected', 'wpdirectorykit'));
            foreach($WMVC->field_m->get_sections() as $section_id => $section_label)
            {
                $sections_list[$section_id] = '#'.$section_id.' '.$section_label;
            }

            $this->add_control(
                'section_fields_id_step_1',
                [
                    'label' => __( 'Show Fields from section on STEP 1', 'wpdirectorykit' ),
                    'description' => __( 'Move fields from section on step 1', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'label_block' => true,
                    'default' => '',
                    'options' => $sections_list,
                    
                ]
            );

            $this->add_control(
                'step_1',
                [
                    'label' => __('Step 1 Content', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => '',
                ]
            );
            
            $this->add_control(
                'step_2',
                [
                    'label' => __('Step 2 Content', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => '',
                ]
            );
            
            $this->add_control(
                'step_3',
                [
                    'label' => __('Step 3 Content', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => '',
                ]
            );

        $this->end_controls_section();

    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-quicksubmission-content');
    }
}
