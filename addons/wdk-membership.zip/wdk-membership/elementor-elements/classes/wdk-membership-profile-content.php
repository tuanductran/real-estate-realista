<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipProfileContent extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-profile-content';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Profile Details', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-menu-bar';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $Winter_MVC_WDK;
       
        $wdkmembership_user_id = wdk_get_profile_page_id();
        
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['userdata'] = get_userdata($wdkmembership_user_id);
        $this->data['user_id'] = $wdkmembership_user_id;
        $this->data['count_listings'] = 0;

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
 
        $this->data['wdk_wp_roles'] = $wp_roles->role_names;

        if($wdkmembership_user_id)
            $this->data['count_listings'] = $this->WMVC->listing_m->total(array('is_activated' => 1,'is_approved'=>1), TRUE, $wdkmembership_user_id, TRUE);

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
            echo $this->view('wdk-membership-profile-content-demo', $this->data); 
        } else {
            echo $this->view('wdk-membership-profile-content', $this->data); 
        }

    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
			'thumbnail_hide',
			[
				'label' => __( 'Thumbnail hide', 'wdk-membership' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'wdk-membership' ),
				'label_off' => __( 'Hide', 'wdk-membership' ),
				'return_value' => 'none',
				'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail' => 'display: {{VALUE}};',
                ],
			]
		);
             
        $this->add_responsive_control (
            'thumbnail_width',
            [
                'label' => esc_html__('Thumbnail side width', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 3000,
                    ],   
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'size_units' => [ 'px', 'vw', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail' => 'flex: 0 0 {{SIZE}}{{UNIT}};
                                                                                        min-width: {{SIZE}}{{UNIT}};
                                                                                        width: {{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );
        
        $this->add_responsive_control (
            'thumbnail_height',
            [
                'label' => esc_html__('Thumbnail height', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                    ],   
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],   
                ],
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'size' => '100',
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail .wdk-image' => 'height:{{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );
        
        $this->add_responsive_control (
            'thumbnail_height_max',
            [
                'label' => esc_html__('Thumbnail Max height', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                    ],   
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],   
                ],
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'size' => '100',
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail .wdk-image' => 'max-height:{{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail .wdk-image',
        );
        
        $this->generate_renders_tabs($selectors, 'thumbnail_dynamic', ['margin','border','border_radius','padding','shadow','css_filters','image_fit_control']);
 
        $this->add_responsive_control(
            'thumbnail_background',
            [
                    'label' => esc_html__( 'Background', 'wdk-membership' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail .wdk-image' => 'background: {{VALUE}};',
                    ],
            ]
        );

        $meta_fields = array(
            '' => __('Not Selected', 'wdk-membership'),
            'wdk_phone' => __('Phone', 'wdk-membership'),
            'user_email' => __('Email', 'wdk-membership'),
            'user_url' => __('Url', 'wdk-membership'),
            'display_name' => __('Display Name', 'wdk-membership'),
            'wdk_facebook' => __('Facebook', 'wdk-membership'),
            'wdk_youtube' => __('Youtube', 'wdk-membership'),
            'wdk_address' => __('Address', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_city' => __('City', 'wdk-membership'),
            'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
            'wdk_twitter' => __('Twitter', 'wdk-membership'),
            'wdk_telegram' => __('Telegram', 'wdk-membership'),
            'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
            'wdk_viber' => __('Viber', 'wdk-membership'),
            'wdk_iban' => __('IBAN', 'wdk-membership'),
            'wdk_company_name' => __('Company name', 'wdk-membership'),
            'agency_name' => __('Agency Name', 'wdk-membership'),
        );

        $repeater = new Repeater();
        $repeater->start_controls_tabs( 'meta_fields' );
        $repeater->add_control(
            'meta_field',
			[
				'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '',
                'description' => __( 'Only one field per type will be visible', 'wdk-membership' ),
				'options' =>  $meta_fields
			]
        );

        $repeater->end_controls_tabs();
        
        $this->add_control(
            'meta_title',
            [
                'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'meta_fields_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'meta_field' => 'wdk_phone',
                    ],
                    [
                        'meta_field' => 'user_email',
                    ],
                ],
                'title_field' => '{{{ meta_field }}}',
            ]
        );
        
        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'profile_cart',
                'label'=> esc_html__('Profile Card', 'wdk-membership'),
                'selector'=>'.profiles-item-profile',
                'options'=> ['typo','background_group','border','border_radius','padding','shadow'],
            ],
            [
                'key'=>'profile_cont',
                'label'=> esc_html__('Content Box', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content',
                'options'=> 'block',
            ],
            [
                'key'=>'profile_title',
                'label'=> esc_html__('Profile Name', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-header .wdk-title',
                'options'=>'full',
            ],
            [
                'key'=>'profile_subtitle',
                'label'=> esc_html__('Profile Subtitle', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-header .wdk-subtitle',
                'options'=>'full',
            ],
            [
                'key'=>'profile_text',
                'label'=> esc_html__('Profile Bio', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-text',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition'],
            ],
            [
                'key'=>'profile_meta',
                'label'=> esc_html__('Profile Meta', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-footer .wdk-list a',
                'options'=>['margin','typo','color','background','border','border_radius','padding','transition'],
            ],
            [
                'key'=>'profile_meta_icon',
                'label'=> esc_html__('Profile Meta Icon', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-footer .wdk-list a i',
                'options'=>['margin','typo','color','background','border','border_radius','padding','transition'],
            ],
            [
                'key'=>'profile_meta_share_box',
                'label'=> esc_html__('Profile Share icons group', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-footer .wdk-list-social',
                'options'=>['margin', 'padding', 'align'],
            ],
            [
                'key'=>'profile_meta_share',
                'label'=> esc_html__('Profile Share icons', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-footer .wdk-list-social a',
                'options'=>['margin', 'padding', 'background', 'color'],
            ],
            [
                'key'=>'profile_count_link',
                'label'=> esc_html__('Profile Count Link', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-content .wdk-footer .wdk-profile-link',
                'options'=>['margin','typo','color','background','border','border_radius','padding','transition'],
            ],
            [
                'key'=>'profile_opn_button',
                'label'=> esc_html__('Profile Open Button', 'wdk-membership'),
                'selector'=>'.profiles-item-profile .wdk-thumbnail .wdk-hover .wdk-profile-btn',
                'options'=>['margin','typo','color','background','border','border_radius','padding','transition'],
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if ($item ['key'] == 'profile_meta_share') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Size', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'] => 'font-size:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }

            if ($item ['key'] == 'profile_text') {
                $this->add_responsive_control(
                    $item['key'].'_text_limit',
                    [
                        'label' => esc_html__('Text Length Limit', 'wdk-membership'),
                        'type' => Controls_Manager::NUMBER,
                        'min' => 1,
                        'max' => 500,
                        'step' => 1,
                    ]
                );
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-profile-content');
    }
}
