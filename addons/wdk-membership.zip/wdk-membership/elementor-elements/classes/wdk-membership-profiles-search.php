<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipProfilesSearch extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );
   
		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }
        
        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-profiles-search';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Profile Search', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-search-bold';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        $this->enqueue_styles_scripts();
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

       
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode() || empty($wdk_listing_id)) {
            $this->data['is_edit_mode']= true;
        } else {

        }
      
        echo $this->view('wdk-membership-profiles-search', $this->data); 
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        
        $this->add_responsive_control(
            'search_scroll',
            [
                    'label' => __( 'On search scroll to', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('No scroll', 'wdk-membership'),
                        'results_profiles' => esc_html__('Results Profile', 'wdk-membership'),
                    ],
                    'default' => 'results_profiles', 
            ]
        );

        $this->add_responsive_control(
            'field_search_labels',
                [
                    'label' => esc_html__( 'Hide Labels', 'wdk-membership' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wdk-membership' ),
                    'block' => esc_html__( 'Show', 'wdk-membership' ),
                    'return_value' => 'none',
                    'default' => 'none',
                    'selectors' => [
                        '{{WRAPPER}} .wdk-membership-profile-search .wdk-form-group label' => 'display: {{VALUE}};',
                    ],
                ]
        );

        $this->add_control(
            'field_search',
            [
                'label' => __( 'Label Search', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Search', 'wdk-membership' ),
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'field_search_placeholder',
            [
                'label' => __( 'Placeholder Search', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Enter Profile Name', 'wdk-membership' ),
            ]
        );

        $this->add_control(
            'field_submit',
            [
                'label' => __( 'Text Search Button', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Search Profile', 'wdk-membership' ),
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();

    }

    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {

        $this->start_controls_section(
            'section_form',
            [
                'label' => __( 'Main', 'wdk-membership' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'form_column_direct',
            [
                    'label' => __( 'Direction', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('Default', 'wdk-membership'),
                        'row' => esc_html__('Row', 'wdk-membership'),
                        'row-reverse' => esc_html__('Row reverse', 'wdk-membership'),
                        'column' => esc_html__('Column', 'wdk-membership'),
                        'column-reverse' => esc_html__('Column reverse', 'wdk-membership'),
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-profile-search' => 'flex-direction: {{UNIT}}',
                    ],
                    'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
                'form_column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-profile-search > *' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-profile-search' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
                'form_row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-profile-search > *' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-profile-search ' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->end_controls_section();

        $items = [
            [
                'key'=>'form_group',
                'label'=> esc_html__('Form group', 'wdk-membership'),
                'selector'=>'.wdk-membership-profile-search .wdk-form-group',
                'options'=>'full',
            ],
            [
                'key'=>'style_label',
                'label'=> esc_html__('Label', 'wdk-membership'),
                'selector'=>'.wdk-membership-profile-search .wdk-form-group label)',
                'options'=>'full',
            ],
            [
                'key'=>'style_field',
                'label'=> esc_html__('Fields', 'wdk-membership'),
                'selector'=>'.wdk-membership-profile-search .wdk-form-group .wdk-control:not([type="checkbox"])',
                'selector_placeholder'=>'{{WRAPPER}} .wdk-membership-profile-search .wdk-form-group .wdk-control:not([type="checkbox"]):placeholder',
                'options'=>'full',
            ],
            [
                'key'=>'style_button',
                'label'=> esc_html__('Button', 'wdk-membership'),
                'selector'=>'.wdk-membership-profile-search .wdk-btn',
                'options'=>'full',
            ],
            [
                'key'=>'style_button_icon',
                'label'=> esc_html__('Button icon', 'wdk-membership'),
                'selector'=>'.wdk-membership-profile-search .wdk-btn i.fa-search',
                'options'=>['color','margin', 'font-size'],
                'selector_hider'=>'{{WRAPPER}} .wdk-membership-profile-search .wdk-btn i',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if(isset($item['selector_hider'])) {
                $this->add_responsive_control(
                    $item['key'].'_hide',
                        [
                            'label' => esc_html__( 'Hide Element', 'wdk-membership' ),
                            'type' => Controls_Manager::SWITCHER,
                            'none' => esc_html__( 'Hide', 'wdk-membership' ),
                            'block' => esc_html__( 'Show', 'wdk-membership' ),
                            'return_value' => 'none',
                            'default' => '',
                            'selectors' => [
                                $item['selector_hider'] => 'display: {{VALUE}};',
                            ],
                        ]
                );
            }

            if( $item ['key'] == 'style_label'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} '.$item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if ($item ['key'] == 'style_field' || $item ['key'] == 'style_button') {
                $this->add_responsive_control(
                    $item['key'].'_height',
                    [
                        'label' => esc_html__('Height', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 80,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'] => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            if(isset($item['selector_placeholder'])) {
                $this->add_control(
                    $item['key'].'_pl_header',
                    [
                        'label' => __( 'Placeholder', 'wdk-membership' ),
                        'type' => Controls_Manager::HEADING,
                    ]
                );

                $selectors = array(
                    'normal' => $item['selector_placeholder'],
                );
            
                $this->generate_renders_tabs($selectors, $item['key'].'_pl_dynamic', ['align','typo','color']);
            }

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style( 'wdk-membership-profiles-search' );
        wp_enqueue_style('wdk-notify');
        wp_enqueue_script('wdk-notify');
    }
}
