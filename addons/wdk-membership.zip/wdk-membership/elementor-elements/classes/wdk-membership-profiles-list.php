<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipProfilesList extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-profiles-list';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Profiles List', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-person';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $Winter_MVC_WDK;

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['pagination_output'] = '';

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
 
        $this->data['wdk_wp_roles'] = $wp_roles->role_names;

        $search_like_roles = "(meta_value LIKE '%wdk_agent%' OR meta_value LIKE '%wdk_agency%')";
        $search_like_roles_array = array();
        foreach ($wp_roles->role_names as $key_role => $role) {
            if(isset($this->data['settings']['enable_'.esc_attr($key_role)]) && $this->data['settings']['enable_'.esc_attr($key_role)] == 'true')
            $search_like_roles_array[] = "meta_value LIKE '%".$key_role."%'";
        }

        if(!empty($search_like_roles_array)) {
            $search_like_roles = '( '.implode(' OR ', $search_like_roles_array).' )';
        }

        $Winter_MVC_WDK->model('user_m');
        $controller = 'user';
        $columns = array('user_login','user_nicename','user_email','user_url','display_name');
        $external_columns = array('user_login','user_nicename','user_email','user_url','display_name');

        $offset = NULL;
        
        global $wpdb;
        $users_table_name = $wpdb->users;

        if($this->data['settings']['conf_pagination_enable'] == 'yes') {
            
            if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
            } else {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
            }

            if($this->data['settings']['conf_results_type'] == 'custom_users') {
                $user_ids = array();
                foreach($this->data['settings']['conf_custom_results'] as $listing) {
                    if(isset($listing['user_id']) && !empty($listing['user_id'])) {
                        if(strpos($listing['user_id'],' ') !== FALSE){
                            $user_ids [] = intval(substr($listing['user_id'],1, strpos($listing['user_id'],' ')-1));
                        }
                    }
                }

                if(!empty($user_ids))
                {
                    $this->WMVC->db->where( $users_table_name.'.ID IN(' . implode(',', $user_ids) . ')', null, false);
                    $total_items = $Winter_MVC_WDK->user_m->total(array(), NULL);
                    $this->data['users_count'] = $total_items;
                }
                
            } else {
                if(wmvc_show_data('hide_profiles_with_no_listings', $this->data['settings']) == 'yes') {
                    $total_items = $Winter_MVC_WDK->user_m->total(array(), $search_like_roles, TRUE);
                } else {
                    $total_items = $Winter_MVC_WDK->user_m->total(array(), $search_like_roles);
                }
            }

            $current_page = 1;
            if(isset($_GET['wmvc_paged_profiles']))
                $current_page = intval(wmvc_xss_clean($_GET['wmvc_paged_profiles']));

            if(empty($this->data['settings']['per_page']))
                $this->data['settings']['per_page'] = 2;

            $offset = $this->data['settings']['per_page']*($current_page-1);

            if(function_exists('wdk_wp_frontend_paginate') && $total_items > $this->data['settings']['per_page'])
                $this->data['pagination_output'] = wdk_wp_frontend_paginate($total_items, $this->data['settings']['per_page'], 'wmvc_paged_profiles');
        }

        if($this->data['settings']['conf_results_type'] == 'custom_users') {
            $user_ids = array();
            foreach($this->data['settings']['conf_custom_results'] as $listing) {
                if(isset($listing['user_id']) && !empty($listing['user_id'])) {
                    if(strpos($listing['user_id'],' ') !== FALSE){
                        $user_ids [] = intval(substr($listing['user_id'],1, strpos($listing['user_id'],' ')-1));
                    }
                }
            }

            if(!empty($user_ids))
            {
                $this->WMVC->db->where( $users_table_name.'.ID IN(' . implode(',', $user_ids) . ')', null, false);
                $this->WMVC->db->order_by('FIELD('.$users_table_name.'.ID, '. implode(',', $user_ids) . ')');

                $this->data['profiles_list'] = $Winter_MVC_WDK->user_m->get_pagination($this->data['settings']['per_page'], $offset, array(), NULL, NULL);
            }
            
        } else {
            
            if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
            } else {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
            }

            if(wmvc_show_data('hide_profiles_with_no_listings', $this->data['settings']) == 'yes') {
                $this->data['profiles_list'] = $Winter_MVC_WDK->user_m->get_pagination($this->data['settings']['per_page'], $offset, array(), NULL, $search_like_roles, FALSE, TRUE);
            } else {
                $this->data['profiles_list'] = $Winter_MVC_WDK->user_m->get_pagination($this->data['settings']['per_page'], $offset, array(), NULL, $search_like_roles);
            }
        }

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-profiles-list', $this->data); 
    }

    protected function generate_controls_conf() {

        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'roles',
            [
                'label' => __( 'Enable Roles', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
        foreach ($wp_roles->role_names as $key_role => $role) {
            $selected = '';
            if(in_array($key_role, array('wdk_agent', 'wdk_agency')))
                $selected = 'true';

            if($key_role == 'administrator' || strpos($key_role, 'wdk_') !== FALSE) {

            } else {
                continue;
            }
                
            if(in_array($key_role, array('wdk_visitor')))
                continue;

            $this->add_control(
                'enable_'.esc_attr($key_role),
                [
                    'label' => wdk_sprintf(__( 'Enable %1$s', 'wdk-membership' ), $role),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Enable', 'wdk-membership' ),
                    'label_off' => __( 'Disable', 'wdk-membership' ),
                    'return_value' => 'true',
                    'default' => $selected,
                ]
            );
        }

        
        $dbusers =  get_users( array( 'search' => '',
                                            'orderby' => 'display_name', 'order' => 'ASC', 'role__in' => [ 'administrator', 'super-admin','wdk_agent','wdk_agency']));
        $users = array('0'=>esc_html__('Not Selected', 'wdk-membership'));
            foreach($dbusers as $dbuser) {
            $users['#'.wmvc_show_data('ID', $dbuser).' '.wmvc_show_data('display_name', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->add_control(
            'conf_results_type',
            [
                'label' => __( 'Results type', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'results_listings',
                'options' => [
                    'results_listings'  => __( 'Results Users', 'wdk-membership' ),
                    'custom_users' => __( 'Specific Users Show', 'wdk-membership' ),
                ],
            ]
        );

                
        $this->add_control(
            'user_id_header',
            [
                'label' => __( 'User IDs:', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'conf_results_type',
                            'operator' => '==',
                            'value' => 'custom_users',
                        ]
                    ],
                ],
            ]
        );
        
        $repeater = new Repeater();
        $repeater->start_controls_tabs( 'listings' );

        $repeater->add_control(
            'user_id',
            [
                'label' => __( 'ID User', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '0',
                'label_block' => true,
                'options' => $users,
            ]
        );

        $repeater->end_controls_tabs();

                        
        $this->add_control(
            'conf_custom_results',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                ],
                'title_field' => '{{{ user_id }}}',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'conf_results_type',
                            'operator' => '==',
                            'value' => 'custom_users',
                        ]
                    ],
                ],
            ]
        );
        
        
        $this->add_control(
			'hide_profiles_with_no_listings',
			[
				'label' => __( 'Hide Profiles Without Listings', 'wdk-membership' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'wdk-membership' ),
				'label_off' => __( 'Show', 'wdk-membership' ),
				'return_value' => 'yes',
				'default' => '',
                'separator' => 'before',
			]
		);

        $this->add_control(
            'conf_pagination_enable',
            [
                'label' => __( 'Pagination', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'wdk-membership' ),
                'label_off' => __( 'Hide', 'wdk-membership' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'per_page',
            [
                'label' => __( 'Limit Results (Per page)', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 10,
            ]
        );


        $this->end_controls_section();
    }

    private function generate_controls_layout() {
        
        $this->start_controls_section(
            'tab_conf_main_section_settings',
            [
                'label' => esc_html__('Layout', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        
        $this->add_responsive_control(
            'row_gap_col',
            [
                    'label' => __( 'Columns', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('Default', 'wdk-membership'),
                        'auto' => esc_html__('Auto', 'wdk-membership'),
                        '100%' => '1',
                        '50%' => '2',
                        'calc(100% / 3)' => '3',
                        '25%' => '4',
                        '20%' => '5',
                        'auto_flexible' => 'auto flexible',
                    ],
                    'selectors_dictionary' => [
                        'auto' => '-webkit-flex:1 1 auto;flex:1 1 auto',
                        '100%' =>  '-webkit-flex:1 1 100%;flex:1 1 100%',
                        '50%' =>  '-webkit-flex:1 1 50%;flex:1 1 50%',
                        'calc(100% / 3)' =>  '-webkit-flex:1 1 calc(100% / 3);flex:1 1 calc(100% / 3)',
                        '25%' =>  '-webkit-flex:1 1 25%;flex:1 1 25%',
                        '20%' =>  '-webkit-flex:1 1 20%;flex:1 1 20%',
                        'auto' =>  '-webkit-flex:1 1 auto;flex:1 1 auto',
                        'auto_flexible' =>  '-webkit-flex:1 1 auto;flex:1 1 auto',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => '{{UNIT}}',
                    ],
                    'default' => '100%', 
                    'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
                'column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-row' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
                'row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row  .wdk-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-row' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        

        $this->add_control(
			'thumbnail_hide',
			[
				'label' => __( 'Thumbnail hide', 'wdk-membership' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'wdk-membership' ),
				'label_off' => __( 'Hide', 'wdk-membership' ),
				'return_value' => 'none',
				'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-list .wdk-thumbnail' => 'display: {{VALUE}};',
                ],
			]
		);
             
        $this->add_responsive_control (
            'thumbnail_width',
            [
                'label' => esc_html__('Thumbnail width', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 3000,
                    ],   
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'size_units' => [ 'px', 'vw' ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-list .wdk-thumbnail' => 'flex: 0 0 {{SIZE}}{{UNIT}};
                                                                                        min-width: {{SIZE}}{{UNIT}};
                                                                                        width: {{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );
        
        $this->add_responsive_control (
            'thumbnail_height',
            [
                'label' => esc_html__('Thumbnail height', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                    ],   
                    '%' => [
                        'min' => 0,
                        'max' => 1000,
                    ],   
                ],
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'size' => '100',
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-list .wdk-thumbnail .wdk-image' => 'height:{{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );
 
        $this->add_responsive_control (
            'thumbnail_height_max',
            [
                'label' => esc_html__('Thumbnail Max height', 'wdk-membership'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 5000,
                    ],   
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],   
                ],
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'size' => '100',
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .profiles-item-profile .wdk-thumbnail .wdk-image' => 'max-height:{{SIZE}}{{UNIT}}',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'thumbnail_hide',
                            'operator' => '==',
                            'value' => '',
                        ]
                    ],
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .profiles-item-list .wdk-thumbnail .wdk-image',
        );
        
        $this->generate_renders_tabs($selectors, 'thumbnail_dynamic', ['image_fit_control','margin','border','border_radius','padding','shadow','css_filters']);
       
        $this->add_responsive_control(
            'thumbnail_background',
            [
                    'label' => esc_html__( 'Background', 'wdk-membership' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .profiles-item-list .wdk-thumbnail .wdk-image' => 'background: {{VALUE}};',
                    ],
            ]
        );

        $this->add_control(
			'text_limit',
			[
				'label' => esc_html__( 'Limit Words', 'wdk-membership' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 150,
				'step' => 1,
                'separator' => 'after',
			]
		);

        $this->add_control(
            'per_page_hr',
            [
                    'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );

        $meta_fields = array(
            '' => __('Not Selected', 'wdk-membership'),
            'wdk_phone' => __('Phone', 'wdk-membership'),
            'user_email' => __('Email', 'wdk-membership'),
            'user_url' => __('Url', 'wdk-membership'),
            'display_name' => __('Display Name', 'wdk-membership'),
            'wdk_facebook' => __('Facebook', 'wdk-membership'),
            'wdk_youtube' => __('Youtube', 'wdk-membership'),
            'wdk_address' => __('Address', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_city' => __('City', 'wdk-membership'),
            'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
            'wdk_twitter' => __('Twitter', 'wdk-membership'),
            'wdk_telegram' => __('Telegram', 'wdk-membership'),
            'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
            'wdk_viber' => __('Viber', 'wdk-membership'),
            'wdk_iban' => __('IBAN', 'wdk-membership'),
            'wdk_company_name' => __('Company name', 'wdk-membership'),
            'agency_name' => __('Agency Name', 'wdk-membership'),
        );

        $repeater = new Repeater();
        $repeater->start_controls_tabs( 'meta_fields' );
        $repeater->add_control(
            'meta_field',
			[
				'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '',
                'description' => __( 'Only one field per type will be visible', 'wdk-membership' ),
				'options' =>  $meta_fields
			]
        );

        $repeater->end_controls_tabs();
        
        $this->add_control(
            'meta_title',
            [
                'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'meta_fields_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'meta_field' => 'wdk_phone',
                    ],
                    [
                        'meta_field' => 'user_email',
                    ],
                ],
                'title_field' => '{{{ meta_field }}}',
            ]
        );
        
        $this->end_controls_section();
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'profile_cart',
                'label'=> esc_html__('Profile Card', 'wdk-membership'),
                'selector'=>'.profiles-item-list',
                'options'=> ['typo','background_group','border','border_radius','padding','shadow'],
            ],
            [
                'key'=>'profile_cont',
                'label'=> esc_html__('Content Box', 'wdk-membership'),
                'selector'=>'.profiles-item-list .wdk-content',
                'options'=> 'block',
            ],
            [
                'key'=>'profile_title',
                'label'=> esc_html__('Profile Name', 'wdk-membership'),
                'selector'=>'.profiles-item-list .wdk-content .wdk-header .wdk-title',
                'options'=>'full',
            ],
            [
                'key'=>'profile_subtitle',
                'label'=> esc_html__('Profile Subtitle', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-content .wdk-header .wdk-title',
                'selector'=>'.profiles-item-list .wdk-content .wdk-header .wdk-subtitle',
                'options'=>'full',
            ],
            [
                'key'=>'profile_text',
                'label'=> esc_html__('Profile Bio', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-content .wdk-text',
                'selector'=>'.profiles-item-list .wdk-content .wdk-text',
                'options'=>'full',
            ],
            [
                'key'=>'profile_meta',
                'label'=> esc_html__('Profile Meta', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-content .wdk-footer .wdk-list a',
                'selector'=>'.profiles-item-list .wdk-content .wdk-footer .wdk-list a',
                'options'=>'full',
            ],
            [
                'key'=>'profile_meta_icon',
                'label'=> esc_html__('Profile Meta Icon', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-content .wdk-footer .wdk-list a i',
                'selector'=>'.profiles-item-list .wdk-content .wdk-footer .wdk-list a i',
                'options'=>'full',
            ],
            [
                'key'=>'profile_count_link',
                'label'=> esc_html__('Profile Count Link', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-content .wdk-footer .wdk-profile-link',
                'selector'=>'.profiles-item-list .wdk-content .wdk-footer .wdk-profile-link',
                'options'=>'full',
            ],
            [
                'key'=>'profile_opn_button',
                'label'=> esc_html__('Profile Open Button', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-thumbnail .wdk-hover .wdk-profile-btn',
                'selector'=>'.profiles-item-list .wdk-thumbnail .wdk-hover .wdk-profile-btn',
                'options'=>'full',
            ],
            [
                'key'=>'profile_social',
                'label'=> esc_html__('Profile Social Icons', 'wdk-membership'),
                'selector_hider'=>'{{WRAPPER}} .profiles-item-list .wdk-thumbnail .wdk-hover .wdk-list-social li a',
                'selector'=>'.profiles-item-list .wdk-thumbnail .wdk-hover .wdk-list-social li a',
                'options'=>['color','padding'],
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );
            
            if(isset($item['selector_hider'])) {
                $this->add_responsive_control(
                    $item['key'].'_hide',
                        [
                            'label' => esc_html__( 'Hide Element', 'wdk-membership' ),
                            'type' => Controls_Manager::SWITCHER,
                            'none' => esc_html__( 'Hide', 'wdk-membership' ),
                            'block' => esc_html__( 'Show', 'wdk-membership' ),
                            'return_value' => 'none',
                            'default' => '',
                            'selectors' => [
                                $item['selector_hider'] => 'display: {{VALUE}};',
                            ],
                        ]
                );
            }

            if( $item ['key'] == 'field_value'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} .wdk-listing-profile',
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }
            

            if( $item ['key'] == 'profile_social'){
                    
                $this->add_responsive_control(
                    $item['key'].'_dynamic_icon_size',
                        [
                            'label' => esc_html__('Size', 'wdk-membership'),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 3,
                                    'max' => 60,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} '.$item['selector'].' i' => 'font-size: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                );
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    
        $this->start_controls_section(
            'pagination_styles',
            [
                'label' => esc_html__('Pagination Section', 'wdk-membership'),
                'tab' => 'tab_layout',
            ]
        );
        $this->add_responsive_control(
            'pagination_styles_align',
            [
                'label' => __( 'Align', 'wdk-membership' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-right',
                    ],
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'justify-content: flex-start;',
                    'center' => 'justify-content: center;',
                    'right' => 'justify-content: flex-end;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-pagination.pagination' => '{{VALUE}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-pagination.pagination',
        );

        $this->generate_renders_tabs($selectors, 'pagination_styles_dynamic', 'block', ['align']);
        
        $this->add_control(
            'pagination_styles_head',
                [
                    'label' => esc_html__('Pagination Links', 'wdk-membership'),
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-pagination.pagination .nav-links > *',
            'hover'=>'{{WRAPPER}} .wdk-pagination.pagination .nav-links > *%1$s',
            'active'=>'{{WRAPPER}} .wdk-pagination.pagination .nav-links > *.current'
        );
        $this->generate_renders_tabs($selectors, 'pagination_styles_items_dynamic', ['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'width','height']);
        
        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-profiles-list');
    }
}
