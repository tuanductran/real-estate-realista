<?php

namespace WdkMembership\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipProfilesGrid extends WdkMembershipElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-membership')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-membership')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-profiles-grid';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Profiles Grid', 'wdk-membership');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-person';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $Winter_MVC_WDK;

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['pagination_output'] = '';

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
 
        $this->data['wdk_wp_roles'] = $wp_roles->role_names;

        $search_like_roles = "(meta_value LIKE '%wdk_agent%' OR meta_value LIKE '%wdk_agency%')";
        $search_like_roles_array = array();
        foreach ($wp_roles->role_names as $key_role => $role) {
            if(isset($this->data['settings']['enable_'.esc_attr($key_role)]) && $this->data['settings']['enable_'.esc_attr($key_role)] == 'true')
            $search_like_roles_array[] = "meta_value LIKE '%".$key_role."%'";
        }

        if(!empty($search_like_roles_array)) {
            $search_like_roles = '( '.implode(' OR ', $search_like_roles_array).' )';
        }

        $Winter_MVC_WDK->model('user_m');
        $controller = 'user';
        $columns = array('user_login','user_nicename','user_email','user_url','display_name');
        $external_columns = array('user_login','user_nicename','user_email','user_url','display_name');

        $offset = NULL;
        if($this->data['settings']['conf_pagination_enable'] == 'yes') {
            
            if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
            } else {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
            }
            
            $total_items = $Winter_MVC_WDK->user_m->total(array(), $search_like_roles);

            $current_page = 1;
            if(isset($_GET['wmvc_paged_profiles']))
                $current_page = intval(wmvc_xss_clean($_GET['wmvc_paged_profiles']));

            if(empty($this->data['settings']['per_page']))
                $this->data['settings']['per_page'] =2;

            $offset = $this->data['settings']['per_page']*($current_page-1);
            
            if(function_exists('wdk_wp_frontend_paginate'))
                $this->data['pagination_output'] = wdk_wp_frontend_paginate($total_items, $this->data['settings']['per_page'], 'wmvc_paged_profiles');
        }
        
        if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
            wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
        } else {
            wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        }

        $this->data['profiles_list'] = $Winter_MVC_WDK->user_m->get_pagination($this->data['settings']['per_page'], $offset, array(), NULL, $search_like_roles);

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-profiles-grid', $this->data); 
    }

    protected function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'roles',
            [
                'label' => __( 'Enable Roles', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
        foreach ($wp_roles->role_names as $key_role => $role) {
            $selected = '';
            if(in_array($key_role, array('wdk_agent', 'wdk_agency')))
                $selected = 'true';

            if($key_role == 'administrator' || strpos($key_role, 'wdk_') !== FALSE) {

            } else {
                continue;
            }
                
            if(in_array($key_role, array('wdk_visitor')))
                continue;

            $this->add_control(
                'enable_'.esc_attr($key_role),
                [
                    'label' => wdk_sprintf(__( 'Enable %1$s', 'wdk-membership' ), $role),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Enable', 'wdk-membership' ),
                    'label_off' => __( 'Disable', 'wdk-membership' ),
                    'return_value' => 'true',
                    'default' => $selected,
                ]
            );
        }

                    
        $this->add_control(
			'hide_profiles_with_no_listings',
			[
				'label' => __( 'Hide Profiles Without Listings', 'wdk-membership' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'wdk-membership' ),
				'label_off' => __( 'Show', 'wdk-membership' ),
				'return_value' => 'yes',
				'default' => '',
                'separator' => 'before',
			]
		);

        $this->add_control(
            'conf_pagination_enable',
            [
                'label' => __( 'Pagination', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'wdk-membership' ),
                'label_off' => __( 'Hide', 'wdk-membership' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'per_page',
            [
                'label' => __( 'Limit Results (Per page)', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 6,
            ]
        );

        $this->end_controls_section();
    }

    public function generate_avg_rating ($user_id = NULL) {
        $rating = array();
        $rating['stars_total'] = 0;
        $rating['reviewers_total'] = 0;
        global $Winter_MVC_wdk_reviews;
        if(empty($Winter_MVC_wdk_reviews)) return false;

        $Winter_MVC_wdk_reviews->model('reviews_m');

        if(!Plugin::$instance->editor->is_edit_mode()){
            $generate_avg_total = $Winter_MVC_wdk_reviews->reviews_m->generate_avg_total($user_id);
            if($generate_avg_total && is_intval(wmvc_show_data('stars_total', $generate_avg_total))) {
                $rating['stars_total'] = round(floatval(wmvc_show_data('stars_total',$generate_avg_total,0)),2);
                $rating['reviewers_total'] = wmvc_show_data('reviewers_total',$generate_avg_total);
            }
        } else {
            $rating['stars_total'] = 3.5;
            $rating['reviewers_total'] = rand(100, 250);
        }
        return $rating;
    }

    protected function generate_controls_layout() {

        $this->start_controls_section(
            'tab_conf_main_section_settings',
            [
                'label' => esc_html__('Layout', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
            'enable_carousel',
            [
                'label' => __( 'Enable Carouse', 'wpdirectorykit' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'wpdirectorykit' ),
                'label_off' => __( 'Off', 'wpdirectorykit' ),
                'return_value' => 'true',
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'row_gap_col',
            [
                    'label' => __( 'Columns', 'wdk-membership' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('Default', 'wdk-membership'),
                        'auto' => esc_html__('Auto', 'wdk-membership'),
                        '100%' => '1',
                        '50%' => '2',
                        'calc(100% / 3)' => '3',
                        '25%' => '4',
                        '20%' => '5',
                        'auto_flexible' => 'auto flexible',
                    ],
                    'selectors_dictionary' => [
                        'auto' => '-webkit-flex:1 2 auto;flex:1 2 auto',
                        '100%' =>  '-webkit-flex:1 2 100%;flex:1 2 100%',
                        '50%' =>  '-webkit-flex:1 2 50%;flex:1 2 50%',
                        'calc(100% / 3)' =>  '-webkit-flex:1 2 calc(100% / 3);flex:1 2 calc(100% / 3)',
                        '25%' =>  '-webkit-flex:1 2 25%;flex:1 2 25%',
                        '20%' =>  '-webkit-flex:1 2 20%;flex:1 2 20%',
                        'auto' =>  '-webkit-flex:1 2 auto;flex:1 2 auto',
                        'auto_flexible' =>  '-webkit-flex:1 2 auto;flex:1 2 auto',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => '{{UNIT}}',
                    ],
                    'default' => 'calc(100% / 3)', 
                    'separator' => 'before',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '!=',
                                'value' => 'true',
                            ],
                        ],
                    ],
            ]
        );

        $this->add_responsive_control(
                'column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-row' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '!=',
                                'value' => 'true',
                            ],
                        ],
                    ],
                ]
        );

        $this->add_responsive_control(
                'row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-membership'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-row  .wdk-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-row' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '!=',
                                'value' => 'true',
                            ],
                        ],
                    ],
                ]
        );

        /* Carousel Grid Config */
        if(true) {

            $this->add_control(
                'layout_carousel_is_centerMode',
                [
                    'label' => __( 'centerMode', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'On', 'wpdirectorykit' ),
                    'label_off' => __( 'Off', 'wpdirectorykit' ),
                    'return_value' => 'true',
                    'default' => '',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_control(
                'layout_carousel_is_infinite',
                [
                    'label' => __( 'Infinite', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'On', 'wpdirectorykit' ),
                    'label_off' => __( 'Off', 'wpdirectorykit' ),
                    'return_value' => 'true',
                    'default' => 'true',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_control(
                'layout_carousel_is_autoplay',
                [
                    'label' => __( 'Autoplay', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SWITCHER,
                    'label_on' => __( 'On', 'wpdirectorykit' ),
                    'label_off' => __( 'Off', 'wpdirectorykit' ),
                    'return_value' => 'true',
                    'default' => '',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_control(
                'layout_carousel_speed',
                [
                    'label' => __( 'Speed', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 0,
                    'max' => 100000,
                    'step' => 100,
                    'default' => 500,
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_control(
                'layout_carousel_animation_style',
                [
                    'label' => __( 'Animation Style', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'fade',
                    'options' => [
                        'slide'  => __( 'Slide', 'wpdirectorykit' ),
                        'fade' => __( 'Fade', 'wpdirectorykit' ),
                        'fade_in_in' => __( 'Fade in', 'wpdirectorykit' ),
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_control(
                'layout_carousel_cssease',
                [
                    'label' => __( 'cssEase', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'linear',
                    'options' => [
                        'linear'  => __( 'linear', 'wpdirectorykit' ),
                        'ease' => __( 'ease', 'wpdirectorykit' ),
                        'ease-in' => __( 'ease-in', 'wpdirectorykit' ),
                        'ease-out' => __( 'ease-out', 'wpdirectorykit' ),
                        'ease-in-out' => __( 'ease-in-out', 'wpdirectorykit' ),
                        'step-start' => __( 'step-start', 'wpdirectorykit' ),
                        'step-end' => __( 'step-end', 'wpdirectorykit' ),
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
    
            $this->add_responsive_control(
                'layout_carousel_columns',
                [
                    'label' => __( 'Count grid', 'wpdirectorykit' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'min' => 1,
                    'max' => 10,
                    'step' => 1,
                    'default' => 3,
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );

            $this->add_responsive_control(
                    'carousel_column_gap_carousel',
                    [
                        'label' => esc_html__('Slider Gap', 'wpdirectorykit'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 60,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .slick-slider.wdk_prifle_grid_slider_ini ' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
                        ],
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'enable_carousel',
                                    'operator' => '==',
                                    'value' => 'true',
                                ]
                            ],
                        ],
                    ]
            );

            $this->add_responsive_control (
                    'carousel_column_gap',
                    [
                        'label' => esc_html__('Columns Gap', 'wpdirectorykit'),
                        'type' => Controls_Manager::SLIDER,
                        'default' => [
                            'size' => 10,
                        ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 60,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .slick-slider.wdk_prifle_grid_slider_ini .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};',
                            '{{WRAPPER}} .slick-slider.wdk_prifle_grid_slider_ini' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                        ],
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'enable_carousel',
                                    'operator' => '==',
                                    'value' => 'true',
                                ]
                            ],
                        ],
                    ]
            );

            $this->add_responsive_control(
                    'carousel_column_gap_top',
                    [
                        'label' => esc_html__('Columns Gap Top', 'wpdirectorykit'),
                        'type' => Controls_Manager::SLIDER,
                        'default' => [
                            'size' => 0,
                        ],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 60,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk_prifle_grid_slider_box' => 'padding-top: {{SIZE}}{{UNIT}};',
                        ],
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'enable_carousel',
                                    'operator' => '==',
                                    'value' => 'true',
                                ]
                            ],
                        ],
                    ]
            );

            $this->add_responsive_control(
                'carousel_column_gap_bottom',
                [
                    'label' => esc_html__('Columns Gap Bottom', 'wpdirectorykit'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk_prifle_grid_slider_box' => 'padding-bottom: {{SIZE}}{{UNIT}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'enable_carousel',
                                'operator' => '==',
                                'value' => 'true',
                            ]
                        ],
                    ],
                ]
            );
        }



        $meta_fields = array(
            '' => __('Not Selected', 'wdk-membership'),
            'wdk_phone' => __('Phone', 'wdk-membership'),
            'user_email' => __('Email', 'wdk-membership'),
            'user_url' => __('Url', 'wdk-membership'),
            'display_name' => __('Display Name', 'wdk-membership'),
            'description' => __('Bio', 'wdk-membership'),
            'wdk_facebook' => __('Facebook', 'wdk-membership'),
            'wdk_youtube' => __('Youtube', 'wdk-membership'),
            'wdk_address' => __('Address', 'wdk-membership'),
            'wdk_country' => __('Country', 'wdk-membership'),
            'wdk_city' => __('City', 'wdk-membership'),
            'wdk_position_title' => __('Position Title', 'wdk-membership'),
            'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
            'wdk_twitter' => __('Twitter', 'wdk-membership'),
            'wdk_telegram' => __('Telegram', 'wdk-membership'),
            'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
            'wdk_viber' => __('Viber', 'wdk-membership'),
            'wdk_iban' => __('IBAN', 'wdk-membership'),
            'wdk_company_name' => __('Company name', 'wdk-membership'),
            'reviews' => __('Show Reviews Rating', 'wdk-membership'),
            'agency_name' => __('Agency Name', 'wdk-membership'),
        );

        $repeater = new Repeater();
        $repeater->start_controls_tabs( 'meta_fields' );
        $repeater->add_control(
            'meta_field',
			[
				'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SELECT,
				'default' => '',
                'description' => __( 'Only one field per type will be visible', 'wdk-membership' ),
				'options' =>  $meta_fields
			]
        );

        $repeater->end_controls_tabs();
        
        $this->add_control(
            'meta_title',
            [
                'label' => __( 'Meta Fields', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'meta_fields_list',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'meta_field' => 'wdk_phone',
                    ],
                    [
                        'meta_field' => 'user_email',
                    ],
                ],
                'title_field' => '{{{ meta_field }}}',
            ]
        );
        
        $this->end_controls_section();


        /* carousel */

        $this->start_controls_section(
            'styles_carousel_arrows_section',
            [
                'label' => esc_html__('Carousel Arrows', 'wpdirectorykit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'enable_carousel',
                            'operator' => '==',
                            'value' => 'true',
                        ]
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_hide',
            [
                    'label' => esc_html__( 'Hide Element', 'wpdirectorykit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'none' => esc_html__( 'Hide', 'wpdirectorykit' ),
                    'block' => esc_html__( 'Show', 'wpdirectorykit' ),
                    'return_value' => 'none',
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows' => 'display: {{VALUE}};',
                    ],
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_position',
            [
                'label' => __( 'Position', 'wpdirectorykit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'wdk_slider_arrows_bottom',
                'options' => [
                    'wdk_slider_arrows_bottom'  => __( 'Bottom', 'wpdirectorykit' ),
                    'wdk_slider_arrows_middle' => __( 'Center', 'wpdirectorykit' ),
                    'wdk_slider_arrows_top' => __( 'Top', 'wpdirectorykit' ),
                ],
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_align',
            [
                'label' => __( 'Align', 'wpdirectorykit' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                            'title' => esc_html__( 'Justified', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'justify-content: flex-start;',
                    'center' => 'justify-content: center;',
                    'right' => 'justify-content: flex-end;',
                    'justify' => 'justify-content: space-between;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows' => '{{VALUE}};',
                ],
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'styles_carousel_arrows_position',
                            'operator' => '!=',
                            'value' => 'wdk_slider_arrows_middle',
                        ]
                    ],
                ],
            ]
        );
        
        $this->add_responsive_control(
            'styles_carousel_arrows_icon_left_h',
            [
                'label' => esc_html__('Arrow left', 'wpdirectorykit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_s_m_left_margin',
            [
                    'label' => esc_html__( 'Margin', 'wpdirectorykit' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'allowed_dimensions' => 'horizontal',
                    'selectors' => [
                        '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows .wdk_lr_slider_arrow.wdk-slider-prev' => 'margin-right:{{RIGHT}}{{UNIT}}; margin-left:{{LEFT}}{{UNIT}};',
                    ],
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_icon_left',
            [
                'label' => esc_html__('Icon', 'wpdirectorykit'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-angle-left',
                    'library' => 'solid',
                ],
            ]
        );
                            
        $this->add_responsive_control(
            'styles_carousel_arrows_icon_right_h',
            [
                'label' => esc_html__('Arrow right', 'wpdirectorykit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_arrows_s_m_right_margin',
            [
                    'label' => esc_html__( 'Margin', 'wpdirectorykit' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'allowed_dimensions' => 'horizontal',
                    'selectors' => [
                        '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows .wdk_lr_slider_arrow.wdk-slider-next' => 'margin-right:{{RIGHT}}{{UNIT}}; margin-left:{{LEFT}}{{UNIT}};',
                    ],
            ]
        );
     
        $this->add_responsive_control(
            'styles_carousel_arrows_icon_right',
            [
                'label' => esc_html__('Icon', 'wpdirectorykit'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-angle-right',
                    'library' => 'solid',
                ],
            ]
        );
        
        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows .wdk_lr_slider_arrow',
            'hover'=>'{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows .wdk_lr_slider_arrow%1$s'
        );
        $this->generate_renders_tabs($selectors, 'styles_carousel_arrows_dynamic', ['margin','color','background','border','border_radius','padding','shadow','transition','font-size','hover_animation']);
        
        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk_prifle_grid_slider_box .wdk_slider_arrows .wdk_lr_slider_arrow'
        );
        $this->generate_renders_tabs($selectors, 'styles_carousel_arrows_addit_dynamic', ['height', 'width']);

        $this->end_controls_section();

        $this->start_controls_section(
            'styles_carousel_dots_section',
            [
                'label' => esc_html__('Carousel Dots', 'wpdirectorykit'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'enable_carousel',
                            'operator' => '==',
                            'value' => 'true',
                        ]
                    ],
                ],
            ]
        );

        $this->add_responsive_control(
                'styles_carousel_dots_hide',
                [
                        'label' => esc_html__( 'Hide Element', 'wpdirectorykit' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wpdirectorykit' ),
                        'block' => esc_html__( 'Show', 'wpdirectorykit' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .wdk_prifle_grid_slider_box .slick-dots' => 'display: {{VALUE}} !important;',
                        ],
                ]
        );

        $this->add_responsive_control(
            'styles_carousel_dots_position_style',
            [
                'label' => __( 'Position Style', 'wpdirectorykit' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'wdk_slider_dots_out',
                'options' => [
                    'wdk_slider_dots_out' => __( 'Out', 'wpdirectorykit' ),
                    'wdk_slider_dots_in' => __( 'In', 'wpdirectorykit' ),
                ],
            ]
        );

        $this->add_responsive_control(
            'styles_carousel_dots_align',
            [
                'label' => __( 'Position', 'wpdirectorykit' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                            'title' => esc_html__( 'Justified', 'wpdirectorykit' ),
                            'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'justify-content: flex-start;',
                    'center' => 'justify-content: center;',
                    'right' => 'justify-content: flex-end;',
                    'justify' => 'justify-content: space-between;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk_prifle_grid_slider_box .slick-dots' => '{{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'styles_carousel_dots_icon',
            [
                'label' => esc_html__('Icon', 'wpdirectorykit'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-circle',
                    'library' => 'solid',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk_prifle_grid_slider_box .slick-dots li .wdk_lr_dot',
            'hover'=>'{{WRAPPER}} .wdk_prifle_grid_slider_box .slick-dots li .wdk_lr_dot%1$s',
            'active'=>'{{WRAPPER}} .wdk_prifle_grid_slider_box .slick-dots li.slick-active .wdk_lr_dot'
        );

        $this->generate_renders_tabs($selectors, 'styles_carousel_dots_dynamic', ['margin','color','background','border','border_radius','padding','shadow','transition','font-size','hover_animation']);

        $this->end_controls_section();
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'card',
                'label'=> esc_html__('Card', 'wdk-membership'),
                'selector'=>'.profiles-item-grid',
                'options'=> 'block',
            ],
            [
                'key'=>'profile_thumbnail',
                'label'=> esc_html__('Thumbnail Box', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-thumbnail',
                'options'=> 'block',
            ],
            [
                'key'=>'profile_opn_button',
                'label'=> esc_html__('Profile Open Button', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-thumbnail .wdk-hover .wdk-profile-btn',
                'options'=>'full',
            ],
            [
                'key'=>'profile_social',
                'label'=> esc_html__('Profile Social Icons', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-thumbnail .wdk-hover .wdk-list-social li a',
                'options'=>['color','padding'],
            ],
            [
                'key'=>'profile_title',
                'label'=> esc_html__('Profile Name', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-title',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'align'],
            ],
            [
                'key'=>'profile_subtitle',
                'label'=> esc_html__('Profile Subtitle', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-subtitle',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'align'],
            ],
            [
                'key'=>'profile_text',
                'label'=> esc_html__('Profile Bio', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-text',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'align'],
            ],
            [
                'key'=>'profile_meta_list_item',
                'label'=> esc_html__('Profile Meta', 'wdk-membership'),
                'selector'=>'.profiles-item-grid .wdk-meta .wdk-list .meta-item',
                'options'=>['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'align'],
            ],
            [
                'key'=>'profile_btn_view',
                'label'=> esc_html__('Button View', 'wdk-membership'),
                'selector_hide'=>'.profiles-item-grid .wdk-button-group',
                'selector'=>'.profiles-item-grid .wdk-button-group .wdk-btn',
                'options'=>'full',
            ]
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );
            
            
            if(!empty($item['selector_hide'])) {
                $this->add_responsive_control(
                    $item['key'].'_hide',
                    [
                        'label' => esc_html__( 'Hide Element', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector_hide'] => 'display: {{VALUE}};',
                        ],
                    ]
                );
            } else {
                $this->add_responsive_control(
                    $item['key'].'_hide',
                    [
                        'label' => esc_html__( 'Hide Element', 'wdk-membership' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-membership' ),
                        'block' => esc_html__( 'Show', 'wdk-membership' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'] => 'display: {{VALUE}};',
                        ],
                    ]
                );
            }

            if( $item ['key'] == 'field_value'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} .wdk-listing-profile',
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            if(in_array($item['key'], array('profile_text','profile_subtitle','profile_title','profile_btn_view','profile_meta_list_item','profile_thumbnail'))){
                $this->add_responsive_control(
                    $item['key'].'_order',
                    [
                        'label' => esc_html__('Order', 'wdk-membership'),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'min' => 1,
                        'max' => 10,
                        'step' => 1,
                        'selectors' => [
                            '{{WRAPPER}} '.$item['selector'] => 'order: {{VALUE}};',
                        ],
                    ]
                );
            }

            if($item['key'] == 'profile_text')
                $this->add_responsive_control(
                    'profile_text_limit',
                    [
                        'label' => esc_html__('Limit Words', 'wdk-membership'),
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'min' => 5,
                        'max' => 100,
                        'step' => 1,
                        'default' => 14,
                    ]
                );


            if( $item ['key'] == 'profile_btn_view'){
                $this->add_control(
                    'profile_btn_view_box_header',
                    [
                        'label' => __( 'Container', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'after',
                    ]
                );

                $this->add_responsive_control(
                    'profile_btn_view_box_button_align',
                        [
                            'label' => esc_html__('Alignment', 'elementinvader-addons-for-elementor'),
                            'type' => Controls_Manager::CHOOSE,
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Left', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'end' => [
                                    'title' => esc_html__('Right', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'stretch' => [
                                    'title' => esc_html__('Justified', 'elementinvader-addons-for-elementor'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'render_type' => 'ui',
                            'default' => 'center',
                            'prefix_class' => 'elementor%s-button-align-',
                            'selectors_dictionary' => [
                                'start' => 'text-align:left',
                                'center' => 'text-align:center',
                                'end' => 'text-align:right',
                                'stretch' => 'width: 100%',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .profiles-item-grid .wdk-button-group' => '{{VALUE}};',
                            ],
                        ]
                );

                $this->add_control(
                    'profile_btn_view_btn_text',
                    [
                        'label' => __( 'Button Text', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __( 'View', 'wdk-membership' ),
                        'separator' => 'after',
                    ]
                );

                $selectors = array(
                    'normal' => '{{WRAPPER}} .profiles-item-grid .wdk-button-group',
                );
                $this->generate_renders_tabs($selectors, 'profile_btn_view_box_dynamic', ['padding','margin']);


            }


            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);


            if( $item ['key'] == 'profile_thumbnail'){
                $this->add_responsive_control (
                    'thumbnail_height',
                    [
                        'label' => esc_html__('Thumbnail height', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 5000,
                            ],   
                            '%' => [
                                'min' => 0,
                                'max' => 1000,
                            ],   
                        ],
                        'size_units' => [ 'px', '%' ],
                        'selectors' => [
                            '{{WRAPPER}} .profiles-item-grid .wdk-thumbnail .wdk-image' => 'height:{{SIZE}}{{UNIT}}',
                        ],
                    ]
                );

                $this->add_control (
                    'thumbnail_size',
                    [
                        'label' => esc_html__('Thumbnail Size', 'wdk-membership'),
                        'description' => esc_html__('Image Size', 'wdk-membership'),
                        'type' => Controls_Manager::SLIDER,
                        'range' => [
                            'px' => [
                                'min' => 150,
                                'max' => 1500,
                            ],   
                        ],
                        'size_units' => [ 'px' ],
                        'separator' => 'after',
                    ]
                );
    
                $this->add_control(
                        'thumbnail_des',
                        [
                                'label' => esc_html__( 'Fit', 'textdomain' ),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'options' => [
                                        '' => esc_html__( 'Default', 'textdomain' ),
                                        'fill' => esc_html__( 'Fill', 'textdomain' ),
                                        'contain'  => esc_html__( 'Contain', 'textdomain' ),
                                        'cover' => esc_html__( 'Cover', 'textdomain' ),
                                        'none' => esc_html__( 'None', 'textdomain' ),
                                        'scale-down' => esc_html__( 'Scale down', 'textdomain' ),
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .profiles-item-grid .wdk-thumbnail .wdk-image' => 'object-fit: {{VALUE}};',
                                ],
                                'default' => 'contain', 
                        ]
                );
                $this->add_control(
                        'thumbnail_des_fit_control_position',
                        [
                                'label' => esc_html__( 'Fit Position', 'textdomain' ),
                                'type' => \Elementor\Controls_Manager::SELECT,
                                'options' => [
                                        '' => esc_html__( 'Default', 'textdomain' ),
                                        'top' => esc_html__( 'Top', 'textdomain' ),
                                        'bottom'  => esc_html__( 'Bottom', 'textdomain' ),
                                        'left' => esc_html__( 'Left', 'textdomain' ),
                                        'right' => esc_html__( 'Right', 'textdomain' ),
                                        'center' => esc_html__( 'Center', 'textdomain' ),
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .profiles-item-grid .wdk-thumbnail .wdk-image' => 'object-position: {{VALUE}};',
                                ],
                        ]
                );

                $selectors = array(
                    'normal' => '{{WRAPPER}} .profiles-item-grid .wdk-thumbnail .wdk-image',
                );
                //$this->generate_renders_tabs($selectors, 'profile_thumbnail_img_dynamic', 'full');
            }


            if( $item ['key'] == 'profile_social'){
                    
                $this->add_responsive_control(
                    $item['key'].'_dynamic_icon_size',
                        [
                            'label' => esc_html__('Size', 'wdk-membership'),
                            'type' => Controls_Manager::SLIDER,
                            'range' => [
                                'px' => [
                                    'min' => 3,
                                    'max' => 60,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} '.$item['selector'].' i' => 'font-size: {{SIZE}}{{UNIT}};',
                            ],
                        ]
                );
            }

            if( $item ['key'] == 'profile_meta_list_item'){
                $this->add_control(
                    'profile_meta_list_item_link_header',
                    [
                        'label' => __( 'Profile Meta', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $selectors = array(
                    'normal' => '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item a',
                    'hover'=>'{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item a%1$s'
                );
                $this->generate_renders_tabs($selectors, 'profile_meta_list_item_link_dynamic', 'full',  ['align']);

                $this->add_control(
                    'profile_meta_icon_header',
                    [
                        'label' => __( 'Profile Meta Icon', 'wdk-membership' ),
                        'type' => \Elementor\Controls_Manager::HEADING,
                        'separator' => 'before',
                    ]
                );

                $selectors = array(
                    'normal' => '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item a i',
                    'hover'=>'{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item a i%1$s'
                );
                $this->generate_renders_tabs($selectors, 'profile_meta_icon_dynamic', 'full',  ['align']);

            }


            $this->end_controls_section();
            /* END special for some elements */
        }

        $this->start_controls_section(
            'pagination_styles',
            [
                'label' => esc_html__('Pagination Section', 'wdk-membership'),
                'tab' => 'tab_layout'
            ]
        );
        $this->add_responsive_control(
            'pagination_styles_align',
            [
                'label' => __( 'Align', 'wdk-membership' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wdk-membership' ),
                            'icon' => 'eicon-text-align-right',
                    ],
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'justify-content: flex-start;',
                    'center' => 'justify-content: center;',
                    'right' => 'justify-content: flex-end;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-pagination.pagination' => '{{VALUE}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-pagination.pagination',
        );

        $this->generate_renders_tabs($selectors, 'pagination_styles_dynamic', 'block', ['align']);
        
        $this->add_control(
            'pagination_styles_head',
                [
                    'label' => esc_html__('Pagination Links', 'wdk-membership'),
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-pagination.pagination .nav-links > *',
            'hover'=>'{{WRAPPER}} .wdk-pagination.pagination .nav-links > *%1$s',
            'active'=>'{{WRAPPER}} .wdk-pagination.pagination .nav-links > *.current'
        );
        $this->generate_renders_tabs($selectors, 'pagination_styles_items_dynamic', ['margin','align','typo','color','background','border','border_radius','padding','shadow','transition', 'width','height']);
        
        $this->end_controls_section();

        /* reviews styles */
        $this->start_controls_section(
            'reviews_section',
            [
                'label' => __( 'Reviews', 'wdk-membership' ),
                'tab' => 'tab_layout'
            ]
        );

        /* color active */ 
        $this->add_control(
            'reviews_icon_color_active',
            [
                    'label' => __('Active', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item.meta-itme-reviews .active' => 'color:{{VALUE}}',
                    ],
                ]
        );

        /* color halfactive */ 
        $this->add_control(
            'reviews_icon_color_halfactive',
            [
                    'label' => __('Half active', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item.meta-itme-reviews .half-active' => 'color:{{VALUE}}',
                    ],
                ]
        );

        /* color deactive */ 
        $this->add_control(
            'reviews_icon_color_deactive',
            [
                    'label' => __('Deactive', 'wdk-membership'),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '#a3a3a3',
                    'selectors' => [
                        '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item.meta-itme-reviews .innactive' => 'color:{{VALUE}}',
                    ],
                ]
        );

        /* icon active */
        $this->add_responsive_control(
            'reviews_icon_active',
            [
                'label' => esc_html__('Icon Active', 'wdk-membership'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'far fa-star',
                    'library' => 'solid',
                ],
            ]
        );

        /* icon half active */
        $this->add_responsive_control(
            'reviews_icon_halfactive',
            [
                'label' => esc_html__('Icon Half Active', 'wdk-membership'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fas fa-star-half-alt',
                    'library' => 'solid',
                ],
            ]
        );

        /* icon deactive */
        $this->add_responsive_control(
            'reviews_icon_deactive',
            [
                'label' => esc_html__('Icon Deactive', 'wdk-membership'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'far fa-star',
                    'library' => 'solid',
                ],
            ]
        );

        /* icon size */
        $this->add_responsive_control(
            'reviews_icon_size',
                [
                        'label' => esc_html__( 'Font Size', 'wdk-membership' ),
                        'type' => Controls_Manager::SLIDER,
                        'size_units' => [ 'px', 'em', '%' ],
                        'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 150,
                                ],
                            ],
                        'default' => [
                            'unit' => 'px',
                            'size' => 14,
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .profiles-item-grid .wdk-meta .wdk-list .meta-item.meta-itme-reviews' => 'font-size: {{SIZE}}{{UNIT}};',
                        ],
                ]
        );

        $this->end_controls_section();
        /* END special for some elements */
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-membership-profiles-grid');
    }
}
