<?php
/**
 * The template for Element Profiles Search Form.
 * This is the template that elementor element form, search profiles
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<?php

$obj_id = get_queried_object_id();
$results_page = get_permalink( $obj_id );

if(get_option('wdk_membership_profile_search_page')) {
    $results_page = get_permalink(get_option('wdk_membership_profile_search_page'));
}

?>

<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <nav class="wdk-membership-profile-search">
        <form action="<?php echo esc_url($results_page);?>" data-scrollto="<?php echo esc_attr(wmvc_show_data('search_scroll', $settings));?>" class="wdk-profile-search">
            <?php
            $array_filters = array('profile_search');
            foreach ($_GET as $key => $value):
                if(!in_array($key, $_GET)):?>
                    <input type="hidden" name="<?php echo esc_attr($key);?>" value="<?php echo esc_attr($value);?>">
                <?php endif;?>
            <?php endforeach;?>

            <div class="wdk-form-group wdk-form-group-field">
                <label for="<?php echo esc_html($id_element);?>_profile"><?php echo esc_html(wmvc_show_data('field_search',$settings));?></label>
                <input type="text" name="profile_search" value="<?php echo esc_attr(wmvc_show_data('profile_search', $_GET,''));?>" id="<?php echo esc_html($id_element);?>_profile" placeholder="<?php echo esc_html(wmvc_show_data('field_search_placeholder',$settings));?>" class="wdk-control">
            </div>
            <div class="wdk-form-group">
                <button type="submit" class="wdk-btn wdk-click-load-animation"><i class="fa fa-search"></i>&nbsp;<?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
            </div>
        </form>
    </nav>
</div>

