<?php
/**
 * The template for Element Profiles List results.
 * This is the template that elementor element profiles results, list
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-membership-user-details">
        <?php if($field_key == 'avatar'):?>
            <a href="<?php echo esc_url($url);?>"><img src="<?php echo esc_url($field_value);?>" class='wdk-avatar' alt="<?php echo esc_html__('Avatar','wdk-membership');?>"></a>
        <?php elseif($field_key == 'display_name'):?>
            <a href="<?php echo esc_url($url);?>"><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(filter_var($field_value, FILTER_VALIDATE_EMAIL) !== FALSE):?>
            <a href="mailto:<?php echo esc_attr($field_value);?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['icon_user_email'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'youtube') !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_youtube'], [ 'aria-hidden' => 'true' ] ); ?>
                <span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'facebook') !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_facebook'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'linkedin') !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_linkedin'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'twitter') !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_twitter'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'telegram') !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_telegram'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'whatsapp') !== FALSE):?>
            <a href="//wa.me/<?php echo esc_attr(wdk_filter_phone($field_value));?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_whatsapp'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'viber') !== FALSE):?>
            <a href="viber://chat?number=<?php echo esc_attr(wdk_filter_phone($field_value));?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_viber'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(filter_var($field_value, FILTER_VALIDATE_URL) !== FALSE):?>
            <a href="<?php echo esc_url($field_value);?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_link'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php elseif(strpos($field_key,'phone') !== FALSE || wdk_is_phone($field_value)):?>
            <a href="tel:<?php echo esc_attr(wdk_filter_phone($field_value));?>"><?php \Elementor\Icons_Manager::render_icon( $settings['icon_wdk_phone'], [ 'aria-hidden' => 'true' ] ); ?><span class="text"><?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix);?></span></a>
        <?php else:?>
            <?php echo esc_html($field_prefix).esc_html($field_value).esc_html($field_suffix); ?>
        <?php endif;?>
    </div>
</div>

