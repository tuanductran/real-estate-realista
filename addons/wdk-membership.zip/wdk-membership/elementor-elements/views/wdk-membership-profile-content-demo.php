<?php
/**
 * The template for Element Profile Content of User, static demo data.
 * This is the template that elementor element content, profile, avatar, meta, contact
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element); ?>">
    <div class="wdk-membership-profile-content" id='results_profile'>
        <div class="wdk-row">
            <div class="wdk-col-12">
                <div class="profiles-item-profile">
                    <div class="wdk-thumbnail">
                        <img src="<?php echo esc_url(wdk_placeholder_image_src()); ?>" alt="<?php echo esc_html__('Debra Moran', 'wdk-membership'); ?>" class="wdk-image">
                        <a href="#" class="thumbnail_link"></a>
                    </div>
                    <div class="wdk-content">
                        <div class="wdk-header">
                            <h3 class="wdk-title"><a href="#" title="<?php echo esc_html__('Debra Moran', 'wdk-membership'); ?>"><?php echo esc_html__('Debra Moran', 'wdk-membership'); ?></a></h3>
                            <span class="wdk-subtitle"><?php echo esc_html__('Debra Moran', 'wdk-membership'); ?></span>
                        </div>

                        <?php if(!empty(wmvc_show_data('profile_text_text_limit', $settings))):?>
                            <div class="wdk-text"><?php echo esc_html(wmvc_character_limiter(esc_html__('Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet maurs. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odi non mauris vitae erat consequat Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit.', 'wdk-membership'), wmvc_show_data('profile_text_text_limit', $settings)));?></div>
                        <?php else:?>
                            <div class="wdk-text"><?php echo esc_html(esc_html__('Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet maurs. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odi non mauris vitae erat consequat Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit.', 'wdk-membership'));?></div>
                        <?php endif;?>
                        
                        <div class="wdk-footer">
                            <div class="wdk-side">
                                <ul class="wdk-list">
                                    <?php
                                        $used_fields = array();
                                        if(!empty(wmvc_show_data('meta_fields_list', $settings)))
                                        foreach (wmvc_show_data('meta_fields_list', $settings) as $meta):?>
                                            <?php
                                                if(isset($used_fields [$meta['meta_field']])) continue;
                                                $used_fields [$meta['meta_field']] = true;
                                            ?>
                                          
                                            <?php if(filter_var($meta['meta_field'], FILTER_VALIDATE_EMAIL) !== FALSE || strpos($meta['meta_field'],'email') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="mailto:agent1@wpdirectorykit.com"><i class="far fa-envelope"></i>agent1@wpdirectorykit.com</a></li>
                                            <?php elseif(strpos($meta['meta_field'],'youtube') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-youtube"></i><?php echo esc_html__('link youtube','wdk-membership');?></a></li>
                                            <?php elseif(strpos($meta['meta_field'],'facebook') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fab fa-facebook-f"></i><?php echo esc_html__('link facebook','wdk-membership');?></a></li>
                                            <?php elseif(strpos($meta['meta_field'],'linkedin') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-linkedin"></i><?php echo esc_html__('link linkedin','wdk-membership');?></a></li>
                                            <?php elseif(strpos($meta['meta_field'],'twitter') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-twitter"></i><?php echo esc_html__('link twitter','wdk-membership');?></a></li>
                                            <?php elseif(strpos($meta['meta_field'],'telegram') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-telegram"></i><?php echo esc_html__('link telegram','wdk-membership');?></a></li>
                                            <?php elseif(strpos($meta['meta_field'],'whatsapp') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-whatsapp"></i><?php echo esc_html__('link whatsapp','wdk-membership');?> </a></li>
                                            <?php elseif(strpos($meta['meta_field'],'viber') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="viber://chat?number=#"><i class="fab fa-viber"></i>(917) 367-2058</a></li>
                                            <?php elseif(filter_var($meta['meta_field'], FILTER_VALIDATE_URL) !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="#"><i class="fa fa-anchor"></i>(917) 367-2058</a></li>
                                            <?php elseif(strpos($meta['meta_field'],'phone') !== FALSE):?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="tel:9173672058"><i class="far fa-phone"></i>(917) 367-2058</a></li></li>
                                            <?php else:?>
                                                <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><?php echo esc_html__('meta ','wdk-membership');?> <?php echo esc_html($meta['meta_field']);?></li>
                                            <?php endif;?>
                                    <?php endforeach;?>
                                </ul>
                                <ul class="wdk-list-social">
                                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-telegram"></i></a></li>
                                </ul>
                            </div>
                            <div class="wdk-side text-right">
                                <a href="#" class="wdk-profile-link">
                                    5 Listings                           
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>