<?php
/**
 * The template for Element Dash Menu.
 * This is the template that elementor element links, dash menu
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <nav class="wdk-membership-dash-breadcrumb">    
        <?php if($is_edit_mode):?>
            <a href="#" class="wdk-breadcrumb-item"><?php echo esc_html__('Dash','wdk-membership');?></a>
            <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <a href="#" class="wdk-breadcrumb-item"><?php echo esc_html__('Listings','wdk-membership');?></a>
            <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
            <a href="#" class="wdk-breadcrumb-item"><?php echo esc_html__('Edit','wdk-membership');?></a>
        <?php else:?>
            <?php foreach ($breadcrumb_items as $link => $title):?>
                <a href="<?php echo esc_url($link);?>" class="wdk-breadcrumb-item"><?php echo esc_html($title);?></a>
                <?php if(next($breadcrumb_items)):?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php endif;?>
            <?php endforeach;?>
        <?php endif;?>
    </nav> 
</div>

