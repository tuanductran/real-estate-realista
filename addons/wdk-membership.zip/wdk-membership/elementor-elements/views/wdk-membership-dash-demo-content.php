<?php
/**
 * The template for Element Dash Content Demo data.
 * This is the template that elementor element content, profile, listings, table, form, search
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element " id="wdk_el_<?php echo esc_html($id_element); ?>">
    <div class="wdk-membership-content">
        <div class="wdk-front-wrap">
            <h1 class="wdk-h"><?php echo esc_html__('Listings Management','wdk-membership');?> <a href="#" class="button button-primary" title="<?php echo esc_attr__('Add Listing','wdk-membership');?>" id="add_listing_button"><?php echo esc_html__('Add Listing','wdk-membership');?></a></h1>
            <form method="GET" action="#" class="wdk-from-inline wdk-from-label-inline" novalidate="novalidate">
                <div class="tablenav top">
                    <div class="tablenav-main">
                        <div class="actions">
                            <input type="hidden" name="page_id" value="1749">
                            <input type="hidden" name="dash_page" value="listings">
                            <div class="wdk-from-group">
                                <label class="screen-reader-text" for="location_id"><?php echo esc_html__('Filter by location','wdk-membership');?></label>
                                <select name="location_id">
                                    <option value=""><?php echo esc_html__('Location','wdk-membership');?></option>
                                    <option value="1">|-<?php echo esc_html__('Austria','wdk-membership');?></option>
                                    <option value="2">&nbsp;&nbsp;|-<?php echo esc_html__('Graz','wdk-membership');?></option>
                                </select>                    
                            </div>
                            <div class="wdk-from-group">
                                <label class="screen-reader-text" for="category_id"><?php echo esc_html__('Filter by category','wdk-membership');?></label>
                                <select name="category_id">
                                    <option value=""><?php echo esc_html__('Category','wdk-membership');?></option>
                                    <option value="1">|-<?php echo esc_html__('House','wdk-membership');?></option>
                                    <option value="2">|-<?php echo esc_html__('Apartment','wdk-membership');?></option>
                                    <option value="3">|-<?php echo esc_html__('Agriculture','wdk-membership');?></option>
                                    <option value="4">|-<?php echo esc_html__('Commercial','wdk-membership');?></option>
                                </select>                   
                            </div>
                            <div class="wdk-from-group">
                                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword','wdk-membership');?></label>
                                <input type="text" name="search" id="search" class="postform left" value="" placeholder="<?php echo esc_html__('Filter by keyword','wdk-membership');?>">
                            </div>
                            <div class="wdk-from-group">
                                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By','wdk-membership');?></label>
                                <select name="order_by">
                                    <option value=""><?php echo esc_html__('Order by','wdk-membership');?></option>
                                    <option value="ID DESC"><?php echo esc_html__('ID DESC','wdk-membership');?></option>
                                    <option value="ID ASC"><?php echo esc_html__('ID ASC','wdk-membership');?></option>
                                    <option value="post_title ASC"><?php echo esc_html__('Post Title ASC','wdk-membership');?></option>
                                    <option value="post_title DESC"><?php echo esc_html__('Post Title DESC','wdk-membership');?></option>
                                </select>                    
                            </div>
                            <div class="wdk-from-group">
                                <input type="submit" name="filter_action" id="post-query-submit" class="wdk-btn wdk-btn-primary" value="<?php echo esc_html__('Filter','wdk-membership');?>">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <form method="GET" action="#">
                <table class="wdk-table responsive">
                    <thead>
                        <tr>
                            <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo esc_html__('Select All','wdk-membership');?></label><input id="cb-select-all-1" type="checkbox"></td>
                            <th style="width:50px;">#ID</th>
                            <th><?php echo esc_html__('Title','wdk-membership');?></th>
                            <th><?php echo esc_html__('Category','wdk-membership');?></th>
                            <th><?php echo esc_html__('Image','wdk-membership');?></th>
                            <th><?php echo esc_html__('Date','wdk-membership');?></th>
                            <th class="actions_column"><?php echo esc_html__('Actions','wdk-membership');?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th data-label="<?php echo esc_html__('Checkbox','wdk-membership');?>" scope="row" class="check-column hide-resonsive">
                                <input id="cb-select-1731" type="checkbox" name="post[]" value="1731">
                            </th>
                            <td data-label="id">
                                1731                       
                             </td>
                            <td data-label="<?php echo esc_html__('Title','wdk-membership');?>" class="title column-title has-row-actions column-primary" data-colname="<?php echo esc_html__('Title','wdk-membership');?>">
                                <strong>
                                    <a class="row-title" href="#" target="blank"><?php echo esc_html__('FavoIcy Apartmentrites','wdk-membership');?></a>
                                </strong>
                            </td>
                            <td data-label="<?php echo esc_html__('Categery','wdk-membership');?>">
                                |-<?php echo esc_html__('House','wdk-membership');?>
                            </td>
                            <td data-label="Images">
                                <a class="img-link" href="#" target="blank">
                                    <img src="#" alt="thumb" style="height:70px;width:110px;object-fit:cover;text-align: center;">                            
                                </a>
                            </td>
                            <td data-label="<?php echo esc_html__('Date','wdk-membership');?>">
                                <?php echo esc_html__('November 19, 2021 4:00 pm','wdk-membership');?>
                            </td>
                            <td data-label="<?php echo esc_html__('Actions','wdk-membership');?>" class="actions_column">
                                <a href="#"><span class="dashicons dashicons-edit"></span></a>
                                <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="#"><span class="dashicons dashicons-no"></span></a>
                            </td>
                        </tr>
                        <tr>
                            <th data-label="<?php echo esc_html__('Checkbox','wdk-membership');?>" scope="row" class="check-column hide-resonsive">
                                <input id="cb-select-1728" type="checkbox" name="post[]" value="1728">
                            </th>
                            <td data-label="id">
                                1728                        
                            </td>
                            <td data-label="<?php echo esc_html__('Title','wdk-membership');?>" class="title column-title has-row-actions column-primary" data-colname="<?php echo esc_html__('Title','wdk-membership');?>">
                                <strong>
                                    <a class="row-title" href="#" target="blank"><?php echo esc_html__('SeaLine Apartment','wdk-membership');?></a>
                                </strong>
                            </td>
                            <td data-label="<?php echo esc_html__('Categery','wdk-membership');?>">
                                |-<?php echo esc_html__('Apartment','wdk-membership');?>                        
                            </td>
                            <td data-label="Images">
                                <a class="img-link" href="#" target="blank">
                                    <img src="#" alt="thumb" style="height:70px;width:110px;object-fit:cover;text-align: center;">  
                                </a>
                            </td>
                            <td data-label="<?php echo esc_html__('Date','wdk-membership');?>">
                                <?php echo esc_html__('November 19, 2021 4:00 pm ','wdk-membership');?>                       
                            </td>
                            <td data-label="<?php echo esc_html__('Actions','wdk-membership');?>" class="actions_column">
                                <a href="#"><span class="dashicons dashicons-edit"></span></a>
                                <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="#"><span class="dashicons dashicons-no"></span></a>
                            </td>
                        </tr>
                        <tr>
                            <th data-label="<?php echo esc_html__('Checkbox','wdk-membership');?>" scope="row" class="check-column hide-resonsive">
                                <input id="cb-select-1725" type="checkbox" name="post[]" value="1725">
                            </th>
                            <td data-label="id">
                                1725                        
                            </td>
                            <td data-label="<?php echo esc_html__('Title','wdk-membership');?>" class="title column-title has-row-actions column-primary" data-colname="<?php echo esc_html__('Title','wdk-membership');?>">
                                <strong>
                                    <a class="row-title" href="#" target="blank"><?php echo esc_html__('Meadow View','wdk-membership');?></a>
                                </strong>
                            </td>
                            <td data-label="<?php echo esc_html__('Categery','wdk-membership');?>">
                                |-<?php echo esc_html__('Favorites','wdk-membership');?>Apartment                        
                            </td>
                            <td data-label="Images">
                                <a class="img-link" href="#" target="blank">
                                    <img src="#" alt="thumb" style="height:70px;width:110px;object-fit:cover;text-align: center;">                            
                                </a>
                            </td>
                            <td data-label="<?php echo esc_html__('Date','wdk-membership');?>">
                                <?php echo esc_html__('November 19, 2021 4:00 pm  ','wdk-membership');?>                      
                            </td>
                            <td data-label="<?php echo esc_html__('Actions','wdk-membership');?>" class="actions_column">
                                <a href="#"><span class="dashicons dashicons-edit"></span></a>
                                <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-membership');?>"  href="#"><span class="dashicons dashicons-no"></span></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="tablenav bottom">
                    <div class="tablenav-main">
                        <div class="alignleft actions bulkactions">
                            <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo esc_html__('Select bulk action','wdk-membership');?></label>
                            <select name="action" id="bulk-action-selector-bottom">
                                <option value="-1"><?php echo esc_html__('Bulk actions','wdk-membership');?></option>
                                <option value="delete" class="hide-if-no-js"><?php echo esc_html__('Delete','wdk-membership');?></option>
                                <option value="deactivate" class="hide-if-no-js"><?php echo esc_html__('Deactivate','wdk-membership');?></option>
                                <option value="activate" class="hide-if-no-js"><?php echo esc_html__('Activate','wdk-membership');?></option>
                            </select>
                            <input type="hidden" name="page" value="wdk">
                            <input type="submit" id="table_action" class="wdk-btn wdk-btn-primary" name="table_action" value="<?php echo esc_html__('Apply','wdk-membership');?>">
                        </div>
                    </div>
                    <div class="tablenav-sidebar">
                    <div class="tablenav-pages"><span class="displaying-num">15 <?php echo esc_html__('items','wdk-membership');?></span><span class="pagination-links"><a class="first-page button" href="/wordpress/code-wpdirectorykit/?page_id=1749&amp;dash_page=listings"><span class="screen-reader-text">First page</span><span aria-hidden="true">«</span></a><span class="tablenav-pages-navspan button disabled" aria-hidden="true">‹</span><span class="screen-reader-text">Current Page</span><span id="table-paging" class="paging-input"><span class="tablenav-paging-text">1 of <span class="total-pages">3</span></span></span><a class="next-page button" href="/wordpress/code-wpdirectorykit/?page_id=1749&amp;dash_page=listings&amp;paged=2"><span class="screen-reader-text">Next page</span><span aria-hidden="true">›</span></a><a class="last-page button" href="/wordpress/code-wpdirectorykit/?page_id=1749&amp;dash_page=listings&amp;paged=3"><span class="screen-reader-text">Last page</span><span aria-hidden="true">»</span></a></span></div>            </div>
                </div>
            </form>
        </div>
    </div>
</div>



