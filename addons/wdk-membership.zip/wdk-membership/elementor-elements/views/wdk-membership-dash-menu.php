<?php
/**
 * The template for Element Dash Menu.
 * This is the template that elementor element links, dash menu
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <nav class="wdk-membership-menu">
        <?php if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')): ?>
            <?php if($settings['add_listing_disable'] != 'yes' && $settings['add_listing_disable'] != 'none'):?>
            <a href="<?php echo wdk_dash_url("dash_page=listings&function=edit"); ?>" class="wdk-membership-add-btn wdk-addlisting <?php echo (!isset($_GET['id'])) ? esc_attr(wdk_dash_menu_active(array('listings'), 'active','edit')) : '';?>">
                <?php if(wmvc_show_data('link_icon_position', $settings) == 'left') :?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php endif;?>
                <?php echo esc_html(wmvc_show_data('link_text', $settings));?>
                <?php if(wmvc_show_data('link_icon_position', $settings) == 'right') :?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <?php endif;?>
            </a>
            <?php endif;?>
            
            <?php if($settings['manager_listings_disable'] != 'yes' && $settings['manager_listings_disable'] != 'none'):?>
            <div class="wdkm-menu-item wdk-listings">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=listings'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active(array('listings'), 'active', null, (!isset($_GET['id'])) ? array(['function'=>'edit']) : null));?>"><span class="dashicons dashicons-location"></span><?php echo esc_html__('Listings','wdk-membership');?></a>
            </div>
            <?php endif;?>
        <?php endif;?>

        <?php do_action('wdk-membership/elementor-elements/dash_menu', $settings); ?>

        <?php if($settings['savesearch_disable'] != 'yes' && $settings['savesearch_disable'] != 'none'):?>
            <?php if(function_exists('run_wdk_save_search')): ?>
            <div class="wdkm-menu-item wdk-savesearch">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=save-search'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('save-search'));?>"><span class="dashicons dashicons-code-standards"></span><?php echo esc_html__('Saved Searches','wdk-membership');?></a>
            </div>
            <?php endif;?>
        <?php endif;?>

        <?php if($settings['messages_disable'] != 'yes' && $settings['messages_disable'] != 'none'):?>
            <div class="wdkm-menu-item wdk-messages">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=messages'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('messages'));?>"><span class="dashicons dashicons-email"></span><?php echo esc_html__('Messages','wdk-membership');?></a>
            </div>
        <?php endif;?>

        <?php if($settings['bookings_disable'] != 'yes' && $settings['bookings_disable'] != 'none'):?>
            <?php if(function_exists('run_wdk_bookings')): ?>
                <div class="wdkm-menu-item wdk-bookings">
                    <?php if((current_user_can('edit_own_listings') || wmvc_user_in_role('administrator'))): ?>
                        <a href="<?php echo esc_url(wdk_dash_url('dash_page=booking-reservations'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active(array('bookings_calendar_ical_import','booking-myreservations','booking-reservations','booking-reservations','booking-prices','booking-calendars')));?>"><span class="dashicons dashicons-calendar-alt"></span><?php echo esc_html__('Booking','wdk-membership');?></a>
                    <?php else:?>
                        <a href="<?php echo esc_url(wdk_dash_url('dash_page=booking-myreservations'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active(array('bookings_calendar_ical_import','booking-myreservations','booking-reservations','booking-reservations','booking-prices','booking-calendars')));?>"><span class="dashicons dashicons-calendar-alt"></span><?php echo esc_html__('Booking','wdk-membership');?></a>
                    <?php endif;?>
                </div>
            <?php endif;?>
        <?php endif;?>
        
        <?php if($settings['membership_disable'] != 'yes' && $settings['membership_disable'] != 'none'):?>
            <?php if(wdk_get_option('wdk_membership_is_enable_subscriptions') && (
                (current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')) || (!wdk_get_option('wdk_membership_none_user_editable_hide') && $has_subscription_private_listings))): ?>
                <div class="wdkm-menu-item wdk-membership">
                    <a href="<?php echo esc_url(wdk_dash_url('dash_page=membership'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('membership'));?>"><span class="dashicons dashicons-groups"></span><?php echo esc_html__('Membership','wdk-membership');?></a>
                </div>
            <?php endif;?>
        <?php endif;?>

        <?php if($settings['favorites_disable'] != 'yes' && $settings['favorites_disable'] != 'none'):?>
            <?php if(function_exists('run_wdk_favorites')): ?>
            <div class="wdkm-menu-item wdk-favorites">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=favorites'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('favorites'));?>"><span class="dashicons dashicons-heart"></span><?php echo esc_html__('Favorites','wdk-membership');?></a>
            </div>
            <?php endif;?>
        <?php endif;?>

        <?php if($settings['reviews_disable'] != 'yes' && $settings['reviews_disable'] != 'none'):?>
            <?php if(function_exists('run_wdk_reviews')): ?>
            <div class="wdkm-menu-item wdk-reviews">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=reviews'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('reviews'));?>"><span class="dashicons dashicons-star-half"></span><?php echo esc_html__('Reviews','wdk-membership');?></a>
            </div>
            <?php endif;?>
        <?php endif;?>

        <?php if($settings['payout_disable'] != 'yes' && $settings['payout_disable'] != 'none' && get_option('wdk_bookings_enable_woocommerce_payments') == 1 && class_exists( 'woocommerce' ) && (current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')) ):?>
            <div class="wdkm-menu-item wdk-payout">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=payout'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('payout'));?>"><span class="dashicons dashicons-money-alt"></span><?php echo esc_html__('Payout','wdk-membership');?></a>
            </div>
        <?php endif;?>

        <?php if($settings['profile_disable'] != 'yes' && $settings['profile_disable'] != 'none'):?>
            <div class="wdkm-menu-item wdk-profile">
                <a href="<?php echo esc_url(wdk_dash_url('dash_page=profile'));?>" class="wdkm-btn <?php echo esc_attr(wdk_dash_menu_active('profile'));?>"><span class="dashicons dashicons-admin-users"></span><?php echo esc_html__('Profile','wdk-membership');?></a>
            </div>
        <?php endif;?>

        <?php if($settings['wooorder_disable'] != 'yes' && $settings['wooorder_disable'] != 'none'):?>
            <?php if(class_exists( 'WooCommerce' ) && get_option('woocommerce_myaccount_page_id') && (
                    $has_subscription || function_exists('run_wdk_payments') || wdk_get_option('wdk_bookings_enable_woocommerce_payments') || wdk_get_option('wdk_membership_is_enable_subscriptions'))): ?>
            <div class="wdkm-menu-item wdk-wooorder">
                <a href="<?php echo esc_url( wc_get_account_endpoint_url( get_option( 'woocommerce_myaccount_orders_endpoint', 'orders' ) ) ); ?>" class="wdkm-btn"><span class="dashicons dashicons-cart"></span><?php echo esc_html__('Orders','wdk-membership');?></a>
            </div>
            <?php endif;?>
        <?php endif;?>

        <?php if($settings['logout_disable'] != 'yes' && $settings['logout_disable'] != 'none'):?>
            <div class="wdkm-menu-item wdk-logout">
                <a href="<?php echo esc_url(wp_logout_url(get_home_url()));?>" class="wdkm-btn"><span class="dashicons dashicons-exit"></span><?php echo esc_html__('Logout','wdk-membership');?></a>
            </div>
        <?php endif;?>
    </nav>
</div>

