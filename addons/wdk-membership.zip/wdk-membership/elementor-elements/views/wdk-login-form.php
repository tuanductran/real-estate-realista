<?php
/**
 * The template for Element Login Form.
 * This is the template that elementor element form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-login-form">
    <?php if(is_user_logged_in() && !$is_edit_mode):?>
        <div class="wdk-front-wrap">
            <h3 class="wdk-h"><?php echo esc_html__('Hi','wdk-membership');?> <?php echo esc_html(wp_get_current_user()->display_name);?>,</h3>
            <span class="wdk-h">
                <?php 
                    $wdk_link_dash = get_admin_url() . "admin.php?page=wdk";

                    if(is_user_logged_in() && get_option('wdk_membership_dash_page') && get_post_status(get_option('wdk_membership_dash_page')) == 'publish') {
                        $wdk_link_dash = wdk_dash_url();
                    }

                    printf(
                        esc_html__( 'You are already logged in, you can open dashboard %1$s here %2$s', 'wdk-membership' ),
                        '<a href="'.$wdk_link_dash . '">',
                        '</a>'
                    );
                ?>
            </span>
        </div>
    <?php else:?>
        <form action="" class="wdk-login">
            <div class="config" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></div>
            <input type="hidden" name="element_id" value="<?php echo $this->get_id_int();?>"/>
            <input type="hidden" name="wdk_id" value="<?php echo esc_html($this->get_id());?>"/>
            <input type="hidden" name="wdk_type" value="<?php echo esc_html($this->get_name());?>"/>
            <input type="hidden" name="redirect_to" value="<?php echo esc_attr(wmvc_show_data('redirect_to',$_GET));?>"/>
            <?php if(wmvc_show_data('custom_message',$_GET, false)):?>
                <p class="<?php echo (wmvc_show_data('custom_message_class', $_GET, false)) ? esc_attr(wmvc_show_data('custom_message_class', $_GET)) : 'wdk_alert wdk_alert-info';?>">
                    <?php echo wp_kses_post(str_replace(__('contact us', 'wdk-membership'),'<a href="mailto:@'.wdk_get_option('admin_email').'">'.__('contact us', 'wdk-membership').'</a>', urldecode(wmvc_show_data('custom_message',$_GET))));?>
                </p>
            <?php endif;?>
            <div class="alert_box"></div>
            <div class="wdk-form-group">
                <label for="<?php echo esc_html($id_element);?>_username"><?php echo esc_html(wmvc_show_data('field_login',$settings));?></label>
                <input type="text" name="username" id="<?php echo esc_html($id_element);?>_username" placeholder="<?php echo esc_html(wmvc_show_data('field_login_placeholder',$settings));?>" class="wdk-control">
            </div>
            <div class="wdk-form-group">
                <label for="<?php echo esc_html($id_element);?>_password"><?php echo esc_html(wmvc_show_data('field_password',$settings));?></label>
                <div class="wdk-eye-field">
                    <input type="password" name="password" id="<?php echo esc_html($id_element);?>_password" placeholder="<?php echo esc_html(wmvc_show_data('field_password_placeholder',$settings));?>" class="wdk-control">
                    
                    <?php if(wmvc_show_data('disable_eye_on_password',$settings) !='yes'): ?>
                        <span class="wdk-toggle"><span class="dashicons dashicons-visibility"></span></span>
                    <?php endif;?>
                </div>
            </div>
            <div class="wdk-form-group actions">
                <label for="<?php echo esc_html($id_element);?>_remember" class="remember_btn"><input type="checkbox" name="remember" id="<?php echo esc_html($id_element);?>_remember" value="1" class="wdk-control"><?php echo esc_html(wmvc_show_data('field_remember',$settings));?></label>
                <?php if(class_exists( 'WooCommerce' )):?>
                    <a href="<?php echo esc_url(wc_lostpassword_url()); ?>" class="forg_btn"><?php echo esc_html(wmvc_show_data('field_forgot',$settings));?></a>
                <?php else:?>
                    <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" class="forg_btn"><?php echo esc_html(wmvc_show_data('field_forgot',$settings));?></a>
                <?php endif;?>
            </div>
            <?php if(get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key')):?>
                <div class="wdk-form-group">
                    <?php wdk_recaptcha_field(); ?>
                </div>
            <?php endif;?>
            <div class="wdk-form-group">
                <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
            </div>
        </form>
    <?php endif;?>
    </div>
</div>

