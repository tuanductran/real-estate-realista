<?php
/**
 * The template for Element Profile Content of user.
 * This is the template that elementor element content, profile, avatar, meta, contact
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-membership-profile-content" id='results_profile'>
        <?php if(!empty($userdata)):?>
            <div class="wdk-row">
                <div class="wdk-col-12">
                    <div class="profiles-item-profile">
                        <div class="wdk-thumbnail">
                            <img onerror="this.src = '<?php echo esc_url(wdk_placeholder_image_src());?>';" src="<?php echo esc_url(get_avatar_url( $user_id, array("size"=>350)));?>" alt="<?php echo esc_attr(wmvc_show_data('display_name', $userdata));?>" class='wdk-image jsplaceholder'>
                        </div>
                        <div class="wdk-content">
                            <div class="wdk-header">
                                <h3 class="wdk-title"><?php echo esc_html(wmvc_show_data('display_name', $userdata));?>
                                    <?php if(shortcode_exists('wdk-review-avg')):?>
                                        <?php echo do_shortcode('[wdk-review-avg]');?>
                                    <?php endif;?>
                                </h3>
                                <span class="wdk-subtitle">
                                    <?php if(wmvc_show_data('wdk_position_title', $userdata, false, TRUE, TRUE)):?>
                                        <?php echo esc_html(wmvc_show_data('wdk_position_title', $userdata, false, TRUE, TRUE));?>
                                    <?php else:?>
                                        <?php 
                                            if( !empty( $userdata->roles ) ){
                                                foreach( $userdata->roles as $role ){
                                                    if(isset($wdk_wp_roles[$role])) {
                                                        echo esc_html($wdk_wp_roles[$role]);
                                                    } else {
                                                        echo esc_html($role);
                                                    }
                                                }
                                            }
                                        ?>
                                    <?php endif;?>
                                </span>
                            </div>

                            <?php if(!empty(wmvc_show_data('profile_text_text_limit', $settings))):?>
                                <div class="wdk-text"><?php echo esc_html(wmvc_character_limiter(wmvc_show_data('description', $userdata), wmvc_show_data('profile_text_text_limit', $settings)));?></div>
                            <?php else:?>
                                <div class="wdk-text"><?php echo esc_html(wmvc_show_data('description', $userdata));?></div>
                            <?php endif;?>
                            
                            <div class="wdk-footer">
                                <div class="wdk-side">
                                    <ul class="wdk-list">
                                        <?php
                                        $used_fields = array();
                                        if(!empty(wmvc_show_data('meta_fields_list', $settings)))
                                            foreach (wmvc_show_data('meta_fields_list', $settings) as $meta):?>
                                                <?php
                                                    if(isset($used_fields [$meta['meta_field']])) continue;
                                                    $used_fields [$meta['meta_field']] = true;
                                                ?>
                                                <?php
                                                    $value = wmvc_show_data($meta['meta_field'], $userdata);
                                                    if(empty($value)) continue;
                                                ?>
                                                <?php if(filter_var($value, FILTER_VALIDATE_EMAIL) !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="mailto:<?php echo esc_attr($value);?>"><i class="far fa-envelope"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'youtube') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-youtube"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'facebook') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fab fa-facebook-f"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'linkedin') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-linkedin"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'twitter') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-twitter"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'telegram') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-telegram"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'whatsapp') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="//wa.me/<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="fa fa-whatsapp"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'viber') !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="viber://chat?number=<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="fab fa-viber"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(filter_var($value, FILTER_VALIDATE_URL) !== FALSE):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-anchor"></i><?php echo esc_html($value);?></a></li>
                                                <?php elseif(strpos($meta['meta_field'],'phone') !== FALSE || wdk_is_phone($value)):?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="tel:<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="far fa-phone"></i><?php echo esc_html($value);?></a></li>
                                                <?php else:?>
                                                    <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><?php echo esc_html($value);?></li>
                                                <?php endif;?>
                                        <?php endforeach;?>
                                    </ul>

                                    <ul  class="wdk-list-social">
                                        <?php if( wmvc_show_data('wdk_facebook', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_facebook', $userdata,'#'));?>"><i class="fab fa-facebook-f"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_linkedin', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_linkedin', $userdata,'#'));?>"><i class="fa fa-linkedin"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_twitter', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_twitter', $userdata,'#'));?>"><i class="fa fa-twitter"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_facebook', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_facebook', $userdata,'#'));?>"><i class="fa fa-telegram"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_whatsapp', $userdata, false)):?>
                                            <li><a href="//wa.me/<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_viber', $userdata,'#')));?>"><i class="fa fa-whatsapp"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_viber', $userdata, false)):?>
                                            <li><a href="viber://chat?number=<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_viber', $userdata,'#')));?>"><i class="fab fa-viber"></i></a></li>
                                        <?php endif;?>
                                    </ul>
                                </div>
                                <div class="wdk-side text-right"><span class="wdk-profile-link">
                                <?php
                                    echo esc_html(wdk_sprintf(_nx(
                                            '%1$s Listing',
                                            '%1$s Listings',
                                            $count_listings,
                                            'profile listings count',
                                            'wdk-membership'
                                    ), $count_listings));
                                ?>
                            </span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else:?>
            <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Profile not found', 'wdk-membership');?></p>
        <?php endif;?>
    </div>
</div>

