<?php
/**
 * The template for Element Listing Packages.
 * This is the template that elementor element subscriptions items
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-payments-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-membership-subscriptions">
        <?php if(wmvc_show_data('custom_message',$_GET, false)):?>
            <p class="<?php echo esc_attr(wmvc_show_data('custom_message_class',$_GET, 'wdk_alert wdk_alert-info'));?>"><?php echo esc_html(urldecode(wmvc_show_data('custom_message',$_GET)));?></p>
        <?php endif;?>

        <?php if(!wdk_get_option('wdk_membership_is_enable_subscriptions')): ?>
            <p class="wdk_alert wdk_alert-danger" style="margin: 0;"><?php echo esc_html__('Membership subscriptions disabled', 'wdk-membership');?></p>
        <?php else:?>
            
                    
            <?php if(is_user_logged_in()):?>
                <?php if(!empty($user_have_active) && $listings_limit):?>
                    <div style="margin-bottom: 20px;" class="wdk_alert wdk_alert-danger" role="alert">
                        <?php if(wdk_get_option('wdk_membership_multiple_subscriptions_enabled')):?>
                            <?php echo esc_html__('Your membership(s) subscription reaches max listings number limitation, please', 'wdk-membership'); ?> 
                            <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                                <?php echo esc_html__('purchase one more or contact us','wdk-membership'); ?>
                            </a>
                        <?php else: ?>
                                <?php echo esc_html__('You reached subscription limit listings','wdk-membership'); ?>
                        <?php endif;?>  
                    </div>

                    <?php if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled')):?>
                    <div style="margin-bottom: 20px;" class="wdk_alert wdk_alert-danger" role="alert">
                        <?php echo esc_html__('If you want to change your membership subscription, please', 'wdk-membership'); ?> 
                        <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                            <?php echo esc_html__('contact us','wdk-membership'); ?>
                        </a>
                    </div>
                    <?php endif;?>
                <?php endif;?>
                
                <?php if(!empty($user_subscriptions)):?>
                    <?php foreach($user_subscriptions as $user_subscription): ?>
                        <?php if($user_subscription->date_expire < date('Y-m-d H:i:s')):?>
                                <div style="margin-bottom: 20px;" class="wdk_alert wdk_alert-danger" role="alert">
                                    <?php echo wdk_sprintf(esc_html__('You active subscription %1$s expired on %2$s','wdk-membership'), 
                                                                    wdk_show_data('subscription_name',$user_subscription, false, TRUE, TRUE),
                                                                    wdk_get_date( wdk_show_data('date_expire',$user_subscription, false, TRUE, TRUE), false)
                                                                    ); ?>
                                </div>
                            <?php else:?>
                                <div style="margin-bottom: 20px;" class="wdk_alert wdk_alert-info" role="alert">
                                    <?php echo wdk_sprintf(esc_html__('You active subscription %1$s, will expire on %2$s','wdk-membership'), 
                                                                    wdk_show_data('subscription_name',$user_subscription, false, TRUE, TRUE),
                                                                    wdk_get_date( wdk_show_data('date_expire',$user_subscription, false, TRUE, TRUE), false)
                                                                    ); ?>
                                </div>
                            <?php endif;?>
                    <?php endforeach;?>
                <?php endif;?>
            <?php endif;?>
            <br>
            <?php if(!empty($results)):?>
                <div class="wdk-row">
                    <?php foreach($results as $item):?>
                    <?php
                        $currency = '';
                        $price = wdk_show_data('price',$item, '', TRUE, TRUE);
                        if ( wdk_show_data('woocommerce_product_id',$item, false, TRUE, TRUE) && function_exists( 'wc_get_product' ) ) {
                            $product = wc_get_product(wdk_show_data('woocommerce_product_id',$item, false, TRUE, TRUE));
                            $currency = get_woocommerce_currency_symbol();
                            $price = $product->get_price();
                        }
                    ?>
                    <div class="wdk-col">
                        <div class="wdk-pac subscription_<?php echo esc_attr(wdk_show_data('idsubscription', $item, '-', TRUE, TRUE));?> <?php if(isset($listings_custom[wdk_show_data('idsubscription', $item, '-', TRUE, TRUE)]) && wdk_show_data('is_auto_featured',$listings_custom[wdk_show_data('idsubscription',$item, '-', TRUE, TRUE)], false, TRUE, TRUE)):?> featured <?php endif;?>">
                            <div class="top">
                                <h2 class="title">
                                    <?php echo esc_html(wdk_show_data('subscription_name',$item, '', TRUE, TRUE));?>

                                    <?php if(isset($user_subscriptions[$item->idsubscription])):?>
                                        <?php if(!empty($user_subscriptions[$item->idsubscription]->date_expire) && $user_subscriptions[$item->idsubscription]->date_expire < date('Y-m-d H:i:s')):?>
                                            <span class="wdk_label wdk_label-danger"><?php echo esc_html__('expired', 'wdk-membership'); ?></span>
                                        <?php elseif(!empty($user_subscriptions[$item->idsubscription]->date_expire)):?>
                                            <span class="wdk_label wdk_label-success"><?php echo esc_html__('active', 'wdk-membership'); ?></span>
                                        <?php endif;?>
                                    <?php endif;?>

                                    <?php if(!empty($item->date_to) && strtotime($item->date_to) < strtotime('+7 days', time()) && strtotime($item->date_to) > time()):?>
                                        <span class="wdk_label wdk_label-info"><?php echo esc_html__('Last date', 'wdk-membership').' '. esc_html(wdk_get_date($item->date_to, FALSE)); ?></span>
                                    <?php endif;?>
                                </h4>
                            </div>
                            <div class="header">
                                <p><?php echo esc_html__('Listing', 'wdk-membership'); ?></p>
                                <div class="pricing-value">
                                    <span class="price"><span class="before"><?php echo esc_html($currency);?></span><?php echo esc_html(wdk_filter_decimal($price));?><span class="after"></span></span>

                                    <?php if(!empty($item->days_limit)):?>
                                    <span class="expired">/
                                        <?php
                                            echo esc_html(wdk_sprintf(_nx(
                                                    '%1$s Day',
                                                    '%1$s Days',
                                                    intval($item->days_limit),
                                                    'days count',
                                                    'wdk-membership'
                                            ), intval($item->days_limit)));
                                        ?>
                                    </span>
                                    <?php endif;?>
                                </div>
                            </div>
                            <ul class="list-items">
                                <?php 
                                    $roles = '';
                                    foreach(explode(',',wdk_show_data('user_types', $item, '', TRUE, TRUE)) as $user_type){
                                        if(empty($user_type)) continue;
                                        if(isset($this->WMVC_Membership->subscription_m->user_types_list[$user_type])){
                                            $roles .= esc_html($this->WMVC_Membership->subscription_m->user_types_list[$user_type]).', ';
                                        } else {
                                            $roles .= esc_html($user_type).', ';
                                        }
                                    }
                                    $roles = substr($roles,0,-2);
                                ?>
                                <?php if(!empty($roles)):?>
                                <li class="item item-user_types">
                                    <span class="dashicons dashicons-yes enable"></span>
                                    <?php 
                                        if(!empty($roles)) {
                                            echo esc_html__('Allow for user types', 'wdk-membership').': '.$roles;
                                        } else {
                                            echo esc_html__('Allow for any user', 'wdk-membership');
                                        }
                                    ?>
                                </li>
                                <?php endif; ?>
                                <li class="item item-days_limit days_limit_value_<?php echo esc_attr(wdk_show_data('days_limit',$item, '0', TRUE, TRUE));?>">
                                    <?php if(wdk_show_data('days_limit',$item, '', TRUE, TRUE)): ?>
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>
                                    <?php echo esc_html(wdk_show_data('days_limit', $item, '', TRUE, TRUE));?>
                                    <?php echo esc_html__('Days', 'wdk-membership'); ?>
                                </li>
                                <?php if(is_user_logged_in()):?>
                                <li class="item item-listings_limit listings_limit_value_<?php echo esc_attr(wdk_show_data('listings_limit',$item, '0', TRUE, TRUE));?>">
                                    <?php if(wdk_show_data('listings_limit',$item, '', TRUE, TRUE)): ?>
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>

                                    <?php if(wdk_show_data('listings_limit',$item, '', TRUE, TRUE) == '-1'): ?>
                                        <?php echo esc_html__('Unlimited Listings', 'wdk-membership'); ?>
                                    <?php else: ?>
                                            <?php echo wmvc_show_data('listings_counter', $item, 0); ?> / 
                                        <?php echo esc_html(wdk_show_data('listings_limit', $item, esc_html__('No', 'wdk-membership'), TRUE, TRUE));?> 
                                        <?php echo esc_html__('Listings Allowed', 'wdk-membership'); ?>
                                    <?php endif; ?>
                                </li>
                                <?php else:?>
                                    <li class="item item-listings_limit listings_limit_value_<?php echo esc_attr(wdk_show_data('listings_limit',$item, '0', TRUE, TRUE));?>">
                                        <?php if(wdk_show_data('listings_limit',$item, '', TRUE, TRUE)): ?>
                                            <span class="dashicons dashicons-yes enable"></span>
                                        <?php else: ?>
                                            <span class="dashicons dashicons-no-alt disable"></span>
                                        <?php endif; ?>
                                        
                                        <?php if(wdk_show_data('listings_limit',$item, '', TRUE, TRUE) == '-1'): ?>
                                            <?php echo esc_html__('Unlimited Listings', 'wdk-membership'); ?>
                                        <?php else: ?>
                                            <?php echo esc_html(wdk_show_data('listings_limit', $item, esc_html__('No', 'wdk-membership'), TRUE, TRUE));?> 
                                            <?php echo esc_html__('Listings Allowed', 'wdk-membership'); ?>
                                        <?php endif; ?>
                                    </li>
                                <?php endif; ?>
                                <li class="item item-images_limit images_limit_value_<?php echo esc_attr(wdk_show_data('images_limit',$item, '0', TRUE, TRUE));?>">
                                    <?php if(wdk_show_data('images_limit',$item, '', TRUE, TRUE)): ?>
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>

                                    <?php if(wdk_show_data('images_limit',$item, '', TRUE, TRUE) == '-1'): ?>
                                        <?php echo esc_html__('Unlimited Images', 'wdk-membership'); ?>
                                    <?php else: ?>
                                        <?php echo esc_html(wdk_show_data('images_limit', $item, esc_html__('No', 'wdk-membership'), TRUE, TRUE));?> 
                                        <?php echo esc_html__('Images Allowed', 'wdk-membership'); ?>
                                    <?php endif; ?>
                                </li>
                                <li class="item item-featured_rank rank_value_<?php echo esc_attr(wdk_show_data('featured_rank',$item, '0', TRUE, TRUE));?>">
                                    <?php if(wdk_show_data('featured_rank',$item, '', TRUE, TRUE)): ?> 
                                        <span class="dashicons dashicons-yes enable"></span>
                                        <?php echo esc_html__('Featured rank level', 'wdk-membership'); ?>: 
                                        <?php echo esc_html(wdk_show_data('featured_rank', $item, '', TRUE, TRUE));?>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                        <?php echo esc_html__('Featured rank level', 'wdk-membership'); ?>
                                    <?php endif; ?>
                                </li>
                                <li class="item item-location_title location_title_value_<?php echo esc_attr(wdk_show_data('location_id',$item, '0', TRUE, TRUE));?>">
                                    <span class="dashicons dashicons-yes enable"></span>
                                    <?php if(wdk_show_data('location_title',$item, '', TRUE, TRUE)): ?> 
                                        <?php echo esc_html__('Locations', 'wdk-membership'); ?>: 
                                        <?php echo esc_html((wdk_show_data('location_title',$item, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                    <?php else: ?>
                                        <?php echo esc_html((wdk_show_data('location_title',$item, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                        <?php echo esc_html__('Location', 'wdk-membership'); ?>
                                    <?php endif; ?>
                                </li>
                                <li class="item item-category_title category_title_value_<?php echo esc_attr(wdk_show_data('category_id',$item, '0', TRUE, TRUE));?>">
                                    <span class="dashicons dashicons-yes enable"></span>
                                    <?php if(wdk_show_data('category_title',$item, '', TRUE, TRUE)): ?> 
                                        <?php echo esc_html__('Categories', 'wdk-membership'); ?>: 
                                        <?php echo esc_html((wdk_show_data('category_title',$item, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                    <?php else: ?>
                                        <?php echo esc_html((wdk_show_data('category_title',$item, esc_html__('Any', 'wdk-membership'), TRUE, TRUE))) ?> 
                                        <?php echo esc_html__('Category', 'wdk-membership'); ?>
                                    <?php endif; ?>
                                </li>
                                <li class="item item-is_auto_featured">
                                    <?php if(wdk_show_data('is_auto_featured',$item, '', TRUE, TRUE)): ?>
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>
                                    <?php echo esc_html__('Auto Featured', 'wdk-membership'); ?>
                                </li>
                                <li class="item item-is_auto_approved">
                                    <?php if(wdk_show_data('is_auto_approved',$item, '', TRUE, TRUE)): ?> 
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>
                                    <?php echo esc_html__('Auto Approved', 'wdk-membership'); ?>
                                </li>
                                <?php if(wdk_get_option('wdk_membership_subscriptions_view_listing_enabled')):?>
                                <li class="item item-is_view_private_listings">
                                    <?php if(wdk_show_data('is_view_private_listings',$item, '', TRUE, TRUE)): ?> 
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>
                                    <?php echo esc_html__('View Listing Details', 'wdk-membership'); ?>
                                </li>
                                <?php endif;?>
                                <?php if(wdk_get_option('wdk_bookings_disable_bookings_by_default')):?>
                                <li class="item item-is_booked_enabled">
                                    <?php if(wdk_show_data('is_booked_enabled',$item, '', TRUE, TRUE)): ?> 
                                        <span class="dashicons dashicons-yes enable"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-no-alt disable"></span>
                                    <?php endif; ?>
                                    <?php echo esc_html__('Allow Booking', 'wdk-membership'); ?>
                                </li>
                                <?php endif;?>
                            </ul>
                            <div class="wdk-pac-footer">
                            <?php if(is_user_logged_in()): ?>
                                <?php if(function_exists('wc_get_cart_url') && !empty($item->woocommerce_product_id)): ?>
                                    <?php if(isset($user_subscriptions[$item->idsubscription])):?>
                                        <?php if(!empty($item->date_expire) && (empty($price) || $price == '0.00')):?>
                                            <a target="_blank" href="#" class="btn btn-outline-secondary disabled"><?php echo esc_html__('Free possible activate only once', 'wdk-membership'); ?></a>
                                        <?php else:?>
                                            <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($item->woocommerce_product_id)); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Extend', 'wdk-membership'); ?></a>
                                        <?php endif;?>
                                    <?php elseif(!empty($user_have_active) && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled') 
                                        && current($user_subscriptions)->price != '0.00' && !empty(current($user_subscriptions)->price)
                                        ):?>
                                        <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($item->woocommerce_product_id)); ?>" class="btn btn-outline-secondary disabled"><?php echo esc_html__('Other subscription currently active', 'wdk-membership'); ?></a>
                                    <?php elseif(empty($price) || $price == '0.00'):?>
                                        <a href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'wdk_membership_activate_subscription=1&id='.wdk_show_data('idsubscription', $item, '-', TRUE, TRUE).'&redirect_to='.wdk_server_current_url())); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Select Subscription', 'wdk-membership'); ?></a>
                                    <?php else:?>
                                        <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($item->woocommerce_product_id)); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Buy', 'wdk-membership'); ?></a>
                                    <?php endif;?>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(function_exists('wc_get_cart_url') && !empty($item->woocommerce_product_id)): ?>
                                    <a target="_blank" href="<?php echo wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($item->woocommerce_product_id)); ?>" class="btn btn-outline-secondary"><?php echo esc_html__('Buy', 'wdk-membership'); ?></a>
                                <?php else:?>

                                <?php endif;?>
                            <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    
                    <?php endforeach;?>
                </div>

                <?php if(wdk_get_option('wdk_membership_is_subscription_required') && !empty($user_have_active) && $listings_limit):?>
                <?php else:?>
                    <?php if(!wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && !empty($user_have_active) 
                                                                            && (!empty($user_subscriptions) && (!wmvc_show_data('price', $user_subscriptions[key($user_subscriptions)], false, TRUE, TRUE)
                                                                                                                || wmvc_show_data('price', $user_subscriptions[key($user_subscriptions)], false, TRUE, TRUE) != '0.00'
                                                                                                                )
                                                                                                                )):?>
                        <div style="margin-bottom: 20px;" class="wdk_alert wdk_alert-info" role="alert">
                            <?php echo esc_html__('If you want to change your membership subscription, please', 'wdk-membership'); ?> 
                            <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email'));?>?subject=<?php echo esc_attr__('Change membership', 'wdk-membership');?>">
                                <?php echo esc_html__('contact us','wdk-membership'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php else:?>
                <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Results not found', 'wdk-membership');?></p>
            <?php endif;?>
        <?php endif;?>
    </div>
</div>