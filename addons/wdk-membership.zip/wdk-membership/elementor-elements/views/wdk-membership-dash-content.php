<?php
/**
 * The template for Element Dash Content.
 * This is the template that elementor element content, profile, listings, table, form, search
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <nav class="wdk-membership-content">
        <?php wdk_membership_view_dash();?>
    </nav>
</div>

