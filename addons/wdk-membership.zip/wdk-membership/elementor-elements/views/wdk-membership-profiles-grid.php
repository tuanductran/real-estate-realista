<?php
/**
 * The template for Element Profiles List results.
 * This is the template that elementor element profiles results, list
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-membership-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-membership-profiles-grid" id='results_profile'>
        <?php if(count($profiles_list)>0):?>
            <?php if(isset($settings['enable_carousel']) && $settings['enable_carousel'] == 'true'):?>
                <div class="wdk_prifle_grid_slider_box <?php echo esc_attr($settings['layout_carousel_animation_style']).'_animation';?> <?php echo join(' ', [$settings['styles_carousel_dots_position_style'], $settings['styles_carousel_arrows_position']]);?>">
                <div class="wdk_prifle_grid_slider_body">
                <div class="wdk_prifle_grid_slider_ini">
            <?php else:?>
                <div class="wdk-row">
            <?php endif;?>
            
                <?php foreach($profiles_list as $profile_id => $value):?>
                <?php 
                    $userdata = get_userdata(wmvc_show_data('ID', $value));
                    $profile_url = wdk_generate_profile_permalink($userdata);
                    $count_listings = wmvc_show_data('listings_counter', $value, 0);
                    
                    if(wmvc_show_data('agency_listings_counter', $value, 0)) {
                        $count_listings += intval(wmvc_show_data('agency_listings_counter', $value, 0));
                    }
                ?>
                <div class="wdk-col">
                    <div class="profiles-item-grid profile_id_<?php echo esc_attr(wmvc_show_data('ID', $value));?>">
                        <div class="wdk-thumbnail-box">
                            <div class="wdk-thumbnail">
                                <img onerror="this.src = '<?php echo esc_url(wdk_placeholder_image_src());?>';" src="<?php echo esc_url(get_avatar_url( wmvc_show_data('ID', $value), array("size"=>((isset($settings['thumbnail_size']) && !empty($settings['thumbnail_size']['size']) ) ? $settings['thumbnail_size']['size'] : 450))));?>" alt="<?php echo esc_attr(wmvc_show_data('display_name', $userdata));?>" class='jsplaceholder wdk-image'>
                                <a href="<?php echo esc_url( $profile_url);?>" class="thumbnail_link"></a>
                                <div class="wdk-hover">
                                    <ul  class="wdk-list-social">
                                        <?php if( wmvc_show_data('wdk_facebook', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_facebook', $userdata,'#'));?>"><i class="fab fa-facebook-f"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_linkedin', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_linkedin', $userdata,'#'));?>"><i class="fa fa-linkedin"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_twitter', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_twitter', $userdata,'#'));?>"><i class="fa fa-twitter"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_facebook', $userdata, false)):?>
                                            <li><a href="<?php echo esc_url(wmvc_show_data('wdk_facebook', $userdata,'#'));?>"><i class="fa fa-telegram"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_whatsapp', $userdata, false)):?>
                                            <li><a href="//wa.me/<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_viber', $userdata,'#')));?>"><i class="fa fa-whatsapp"></i></a></li>
                                        <?php endif;?>

                                        <?php if( wmvc_show_data('wdk_viber', $userdata, false)):?>
                                            <li><a href="viber://chat?number=<?php echo esc_attr(wdk_filter_phone(wmvc_show_data('wdk_viber', $userdata,'#')));?>"><i class="fab fa-viber"></i></a></li>
                                        <?php endif;?>
                                    </ul>
                                    <a href="<?php echo esc_url( $profile_url);?>" class="wdk-profile-btn" title="<?php echo esc_attr(wmvc_show_data('display_name', $userdata));?>"><?php echo esc_html__('View My Profile','wdk-membership');?></a>
                                </div>
                            </div>
                        </div>
                        <h3 class="wdk-title"><a href="<?php echo esc_url( $profile_url);?>" title="<?php echo esc_attr(wmvc_show_data('display_name', $userdata));?>"><?php echo esc_html(wmvc_show_data('display_name', $userdata));?></a></h3>
                        <div class="wdk-subtitle">
                            <?php if(wmvc_show_data('wdk_position_title', $userdata, false, TRUE, TRUE)):?>
                                <?php echo esc_html(wmvc_show_data('wdk_position_title', $userdata, false, TRUE, TRUE));?>
                            <?php else:?>
                                <?php 
                                    if( !empty( $userdata->roles ) ){
                                        foreach( $userdata->roles as $role ){
                                            if(isset($wdk_wp_roles[$role])) {
                                                echo esc_html($wdk_wp_roles[$role]);
                                            } else {
                                                echo esc_html($role);
                                            }
                                        }
                                    }
                                ?>
                            <?php endif;?>
                        </div>
                        <div class="wdk-meta">
                            <ul class="wdk-list">
                                <?php
                                $used_fields = array();
                                if(!empty(wmvc_show_data('meta_fields_list', $settings)))
                                    foreach (wmvc_show_data('meta_fields_list', $settings) as $meta):?>
                                        <?php
                                            if(isset($used_fields [$meta['meta_field']])) continue;
                                            $used_fields [$meta['meta_field']] = true;
                                        ?>
                                        <?php if($meta['meta_field'] == 'reviews'):?>
                                            <li class="meta-item meta-itme-reviews">
                                            <?php if(function_exists('run_wdk_reviews')):?>
                                                <?php
                                                    $stars_total = $this->generate_avg_rating(wmvc_show_data('ID', $userdata))['stars_total'];
                                                ?>
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <?php if ($i <= $stars_total): ?>
                                                        <?php \Elementor\Icons_Manager::render_icon( $settings['reviews_icon_active'], [ 'aria-hidden' => 'true','class'=>'active' ] ); ?>
                                                    <?php elseif( abs($stars_total - $i) < 1): ?>
                                                        <?php \Elementor\Icons_Manager::render_icon( $settings['reviews_icon_halfactive'], [ 'aria-hidden' => 'true','class'=>'half-active' ] ); ?>
                                                    <?php else: ?>
                                                        <?php \Elementor\Icons_Manager::render_icon( $settings['reviews_icon_deactive'], [ 'aria-hidden' => 'true','class'=>'innactive' ] ); ?>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            <?php else: ?>
                                                <span class="wdk_alert wdk_alert-info"><?php echo esc_html__('WDK Reviews Addon missing', 'wdk-membership');?></span>
                                            <?php endif; ?>
                                            </li>
                                        <?php continue;endif;?>

                                        <?php
                                            $value = wmvc_show_data($meta['meta_field'], $userdata);
                                            if(empty($value)) continue;
                                        ?>

                                        <?php if(filter_var($value, FILTER_VALIDATE_EMAIL) !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="mailto:<?php echo esc_attr($value);?>"><i class="far fa-envelope"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'youtube') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-youtube"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'facebook') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fab fa-facebook-f"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'linkedin') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-linkedin"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'twitter') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-twitter"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'telegram') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-telegram"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'whatsapp') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="//wa.me/<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="fa fa-whatsapp"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'viber') !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="viber://chat?number=<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="fab fa-viber"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(filter_var($value, FILTER_VALIDATE_URL) !== FALSE):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="<?php echo esc_url($value);?>"><i class="fa fa-anchor"></i><?php echo esc_html($value);?></a></li>
                                        <?php elseif(strpos($meta['meta_field'],'phone') !== FALSE || wdk_is_phone($value)):?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><a href="tel:<?php echo esc_attr(wdk_filter_phone($value));?>"><i class="far fa-phone"></i><?php echo esc_html($value);?></a></li>
                                        <?php else:?>
                                            <li class="meta-item <?php echo esc_html($meta['meta_field']);?>"><?php echo esc_html($value);?></li>
                                        <?php endif;?>
                                <?php endforeach;?>
                                <li class="meta-item">
                                    <a href="mailto:<?php echo esc_attr($profile_url);?>#listings">
                                        <?php
                                            echo esc_html(wdk_sprintf(_nx(
                                                    '%1$s Listing',
                                                    '%1$s Listings',
                                                    $count_listings,
                                                    'profile listings count',
                                                    'wdk-membership'
                                            ), $count_listings));
                                        ?>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="wdk-text">
                            <?php
                            echo esc_html(wp_strip_all_tags(html_entity_decode(wp_trim_words(htmlentities(wpautop(wmvc_show_data('description', $userdata))), $settings['profile_text_limit'], '...'))));
                            ?>
                        </div>
                        
                        <div class="wdk-button-group">
                            <a href="<?php echo esc_url( $profile_url);?>#listings" class="wdk-btn">
                                <?php echo esc_html(wmvc_show_data('profile_btn_view_btn_text', $settings));?>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach;?>

            <?php if(isset($settings['enable_carousel']) && $settings['enable_carousel'] == 'true'):?>
            </div>
                <div class="wdk_slider_arrows">
                    <a class="wdk-slider-prev wdk_lr_slider_arrow">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['styles_carousel_arrows_icon_left'], [ 'aria-hidden' => 'true' ] ); ?>
                    </a>
                    <a class="wdk-slider-next wdk_lr_slider_arrow">
                        <?php \Elementor\Icons_Manager::render_icon( $settings['styles_carousel_arrows_icon_right'], [ 'aria-hidden' => 'true' ] ); ?>
                    </a>
                </div>
            </div>
            </div>
            <?php else:?>
                </div>
            <?php endif;?>
        <?php else:?>
            <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Profiles not found', 'wdk-membership');?></p>
        <?php endif;?>
        <?php echo wmvc_xss_clean($pagination_output); ?>
    </div>

    <?php if(isset($settings['enable_carousel']) && $settings['enable_carousel'] == 'true'):?>
    <script>
        jQuery(document).ready(function($){
            var el = $('#wdk_el_<?php echo esc_html($id_element);?> .wdk_prifle_grid_slider_ini').slick({
                dots: true,
                arrows: true,
                <?php if(!empty(wmvc_show_data('layout_carousel_is_centerMode', $settings))):?>
                centerMode: <?php echo wmvc_show_data('layout_carousel_is_centerMode', $settings, 'true');?>,
                <?php endif;?>
                slidesToShow: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns', $settings, '3')))) ? wmvc_show_data('layout_carousel_columns', $settings, '3') : 3;?>,
                slidesToScroll: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns', $settings, '3')))) ? wmvc_show_data('layout_carousel_columns', $settings, '3') : 3;?>,
                <?php if(!empty(wmvc_show_data('layout_carousel_is_infinite', $settings))):?>
                infinite: <?php echo wmvc_show_data('layout_carousel_is_infinite', $settings, 'true');?>,
                <?php endif;?>
                <?php if(!empty(wmvc_show_data('layout_carousel_is_autoplay', $settings))):?>
                autoplay: <?php echo wmvc_show_data('layout_carousel_is_autoplay', $settings, 'false');?>,
                <?php endif;?>
                <?php if(wmvc_show_data('layout_carousel_columns', $settings, 1) == 1 &&  in_array($settings['layout_carousel_animation_style'], ['fade','fade_in_in'])):?>
                fade: true,
                <?php endif;?>
                nextArrow: $('#wdk_el_<?php echo esc_html($id_element);?> .wdk_slider_arrows .wdk-slider-next'),
                prevArrow: $('#wdk_el_<?php echo esc_html($id_element);?> .wdk_slider_arrows .wdk-slider-prev'),
                customPaging: function(slider, i) {
                    // this example would render "tabs" with titles
                    return '<span class="wdk_lr_dot"><?php \Elementor\Icons_Manager::render_icon( $settings['styles_carousel_dots_icon'], [ 'aria-hidden' => 'true' ] ); ?></span>';
                },
                responsive: [
                    {
                        breakpoint: 991,
                        settings: {
                            slidesToShow: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns_tablet', $settings, '2')))) ? wmvc_show_data('layout_carousel_columns_tablet', $settings, '2') : 2;?>,
                            slidesToScroll: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns_tablet', $settings, '2')))) ? wmvc_show_data('layout_carousel_columns_tablet', $settings, '2') : 2;?>,
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns_mobile', $settings, '1')))) ? wmvc_show_data('layout_carousel_columns_mobile', $settings, '1') : 1;?>,
                            slidesToScroll: <?php echo (!empty(trim(wmvc_show_data('layout_carousel_columns_mobile', $settings, '1')))) ? wmvc_show_data('layout_carousel_columns_mobile', $settings, '1') : 1;?>,
                        }
                    },
                ]
            })
        })
    </script>
    <?php endif;?>
</div>
