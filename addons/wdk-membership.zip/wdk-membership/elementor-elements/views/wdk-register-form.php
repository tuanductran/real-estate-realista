<?php
/**
 * The template for Element Register Form.
 * This is the template that elementor element form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-register-form">
    <?php if(is_user_logged_in() && !$is_edit_mode):?>
        <div class="wdk-front-wrap">
            <h3 class="wdk-h"><?php echo esc_html__('Hi','wdk-membership');?> <?php echo esc_html(wp_get_current_user()->display_name);?>,</h3>
            <span class="wdk-h">
                <?php 
                    $wdk_link_dash = get_admin_url() . "admin.php?page=wdk";

                    if(is_user_logged_in() && get_option('wdk_membership_dash_page') && get_post_status(get_option('wdk_membership_dash_page')) == 'publish') {
                        $wdk_link_dash = wdk_dash_url();
                    }

                    printf(
                        esc_html__( 'You are already logged in, you can open dashboard %1$s here %2$s', 'wdk-membership' ),
                        '<a href="'.$wdk_link_dash . '">',
                        '</a>'
                    );
                ?>
            </span>
        </div>
    <?php elseif(get_option('wdk_membership_disable_registration')):?>
        <?php if(!get_option('wdk_membership_disable_registration_custom_message')):?>
            <p class="wdk_alert wdk_alert-danger" style="margin:0"><?php echo esc_html('New user registration disabled', 'wdk-membership');?></p>
        <?php else:?>
            <p class="wdk_alert wdk_alert-danger" style="margin:0"><?php echo esc_html(get_option('wdk_membership_disable_registration_custom_message'));?></p>
        <?php endif;?>
    <?php else:?>
        <form action="" class="wdk-register">
            <div class="config" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>"></div>
            <input type="hidden" name="element_id" value="<?php echo $this->get_id_int();?>"/>
            <input type="hidden" name="wdk_id" value="<?php echo esc_html($this->get_id());?>"/>
            <input type="hidden" name="wdk_type" value="<?php echo esc_html($this->get_name());?>"/>
            <?php if(wmvc_show_data('custom_message',$_GET, false)):?>
                <p class="<?php echo esc_attr(wmvc_show_data('custom_message_class',$_GET, 'wdk_alert wdk_alert-info'));?>"><?php echo esc_html(urldecode(wmvc_show_data('custom_message',$_GET)));?></p>
            <?php endif;?>
            <div class="alert_box"></div>
            <?php if(get_option('wdk_membership_register_show_user_select')):?>
            <?php
                global $wdk_membership_user_types;

                $roles = array('' => __('Select Role', 'wdk-membership'));
                if(isset($wdk_membership_user_types))
                foreach($wdk_membership_user_types as $role_key => $role_name) {
                    if(get_option('wdk_membership_user_type_'.$role_key.'_enable'))
                        $roles [$role_key] = $role_name;
                }

                $default_role = '';
                if(get_option('wdk_membership_register_type')){
                    $default_role = get_option('wdk_membership_register_type');
                }

                if(isset($_GET['user_role'])) {
                    $default_role = sanitize_text_field($_GET['user_role']);
                }

            ?>
            <div class="wdk-form-group field_user_role">
                <label for="<?php echo esc_html($id_element);?>_email"><?php echo esc_html__('User Role', 'wdk-membership');?></label>
                <select name="user_role" id="<?php echo esc_attr($id_element);?>_user_role" class="wdk-control">
                    <?php foreach ($roles as $role_key => $role_name) :?>
                        <?php if($role_key == 'administrator') continue;?>
                        <option value="<?php echo esc_attr($role_key);?>" <?php if($role_key == $default_role):?> selected="selected" <?php endif;?>><?php echo esc_html__($role_name, 'wdk-membership');?></option>
                    <?php endforeach;?>               
                </select>
            </div>
            <?php endif;?>
            <div class="wdk-form-group field_email">
                <label for="<?php echo esc_html($id_element);?>_email"><?php echo esc_html(wmvc_show_data('field_email',$settings));?>*</label>
                <input type="email" name="email" id="<?php echo esc_attr($id_element);?>_email" placeholder="<?php echo esc_html(wmvc_show_data('field_email_placeholder',$settings));?>*" class="wdk-control">
            </div>
            <?php if(false):?>
            <div class="wdk-form-group field_username">
                <label for="<?php echo esc_html($id_element);?>_username"><?php echo esc_html(wmvc_show_data('field_username',$settings));?></label>
                <input type="text" name="username" id="<?php echo esc_attr($id_element);?>_username" placeholder="<?php echo esc_html(wmvc_show_data('field_username_placeholder',$settings));?>" class="wdk-control">
            </div>
            <?php endif;?>
            <div class="wdk-form-group field_password">
                <label for="<?php echo esc_html($id_element);?>_password"><?php echo esc_html(wmvc_show_data('field_password',$settings));?>*</label>
                <div class="wdk-eye-field">
                    <input type="password" name="password" id="<?php echo esc_attr($id_element);?>_password" placeholder="<?php echo esc_html(wmvc_show_data('field_password_placeholder',$settings));?>*" class="wdk-control">
                    <?php if(wmvc_show_data('disable_eye_on_password',$settings) !='yes'): ?>
                        <span class="wdk-toggle"><span class="dashicons dashicons-visibility"></span></span>
                    <?php endif;?>
                </div>
            </div>
            <div class="wdk-form-group field_repassword">
                <label for="<?php echo esc_html($id_element);?>_repassword"><?php echo esc_html(wmvc_show_data('field_repassword',$settings));?>*</label>
               
                <div class="wdk-eye-field">
                    <input type="password" name="repassword" id="<?php echo esc_attr($id_element);?>_repassword" placeholder="<?php echo esc_html(wmvc_show_data('field_repassword_placeholder',$settings));?>*" class="wdk-control">
                    <?php if(wmvc_show_data('disable_eye_on_password',$settings) !='yes'): ?>
                        <span class="wdk-toggle"><span class="dashicons dashicons-visibility"></span></span>
                    <?php endif;?>
                </div>
            </div>

            <?php
            $used_fields = array();
            if(!empty(wmvc_show_data('additional_fields_list', $settings)))
                foreach (wmvc_show_data('additional_fields_list', $settings) as $field):?>
                    <?php
                   
                        if($is_edit_mode && isset($used_fields [$field['field_id']])) {
                            ?>
                            <div class="wdk-form-group field_exists">
                                <p class="wdk_alert wdk_alert-danger"><?php echo esc_html__('Field Id already exists', 'wdk-membership').' #'. esc_html($field['field_id']);?></p>
                            </div>
                            <?php
                            continue;
                        } elseif(isset($used_fields [$field['field_id']])) {
                            continue;
                        }

                        $used_fields [$field['field_id']] = true;
                    ?>
                    <?php if($field['field_id'] == 'wdk_accept_terms'):?>
                        <div class="wdk-form-group field_<?php echo esc_html($field['field_id']);?> checkbox">
                            <input type="checkbox" <?php if($field['is_required'] == 'yes'):?> required="required" <?php endif;?> name="<?php echo esc_html($field['field_id']);?>" id="<?php echo esc_attr($field['field_id']);?>" placeholder="<?php echo esc_html($field['field_placeholder']);?>" class="wdk-control">
                            <label for="<?php echo esc_html($field['field_id']);?>">
                                <?php if(!empty($field['link']['url'])):?>
                                    <?php echo esc_html($field['field_label']);?>
                                    <a href="<?php echo esc_url( $field['link']['url'] ); ?>" <?php if(!empty($field['link']['is_external'])):?> target="_blank" <?php endif;?>>
                                        <?php echo esc_html($field['field_label_text']);?></a>
                                        
                                    <?php if($field['is_required'] == 'yes'):?>*<?php endif;?>
                                <?php else:?>
                                    <?php echo esc_html($field['field_label']);?> <?php echo esc_html($field['field_label_text']);?><?php if($field['is_required'] == 'yes'):?>*<?php endif;?>
                                <?php endif;?>
                            </label>
                        </div>
                    <?php else:?>
                        <div class="wdk-form-group field_<?php echo esc_html($field['field_id']);?>">
                            <label for="<?php echo esc_html($field['field_id']);?>"><?php echo esc_html($field['field_label']);?><?php if($field['is_required'] == 'yes'):?>*<?php endif;?></label>
                            <input type="text" <?php if($field['is_required'] == 'yes'):?> required="required" <?php endif;?> name="<?php echo esc_html($field['field_id']);?>" id="<?php echo esc_attr($field['field_id']);?>" placeholder="<?php echo esc_html($field['field_placeholder']);?>" class="wdk-control">
                        </div>
                    <?php endif;?>
            <?php endforeach;?>

            <?php if(get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key')):?>
                <div class="wdk-form-group field_recaptcha">
                    <?php wdk_recaptcha_field(); ?>
                </div>
            <?php endif;?>
            
            <div class="wdk-form-group field_submit">
                <button type="submit" class="wdk-btn wdk-click-load-animation"><?php echo esc_html(wmvc_show_data('field_submit',$settings));?>&nbsp;<i class="fa fa-spinner fa-spin fa-ajax-indicator" style="display: none;"></i>&nbsp;</button>
            </div>
        </form>
    <?php endif;?>
    </div>
</div>

