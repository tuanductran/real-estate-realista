<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       listing-themes.com
 * @since      1.0.0
 *
 * @package    Wpdirectorykit
 * @subpackage Wpdirectorykit/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wpdirectorykit
 * @subpackage Wpdirectorykit/admin
 * @author     listing-themes.com <dev@listing-themes.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_membership_elementor {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * The name of Elementor Category.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $elementor_category_name = 'wdk-membership-elementor';
    
	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name='wdk-membership', $version='1.0' ) {
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpdirectorykit_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpdirectorykit_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		wp_enqueue_style( 'font-awesome' );
		wp_enqueue_style( 'wdk-membership-elementor-main', plugin_dir_url( __FILE__ ) . 'assets/css/wdk-membership-main.css', array(), $this->version, 'all' );
	}
	
	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpdirectorykit_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpdirectorykit_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script( 'wdk-membership-elementor-main', plugin_dir_url( __FILE__ ) . 'assets/js/wdk-membership-main.js', array(), $this->version, true );
    }

	/**
	 * Load class/script files
	 *
	 * @since    1.0.0
	 */
	public function loader() {
        
    }

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-elementor-base.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-dash-menu.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-dash-content.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-profiles-grid.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-user-details.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-profiles-list.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-profiles-search.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-profile-content.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-profile-listings.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-login-form.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-register-form.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-subscriptions.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-listing-altagents.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-dash-breadcrumb.php';
        require_once plugin_dir_path( __FILE__ ) . 'classes/wdk-membership-quicksubmission-content.php';


		do_action('wdk-membership/elementor-elements/includes');
    }
   
	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {

        $dash_page_id = get_option('wdk_membership_dash_page');
        $profile_page_id = get_option('wdk_membership_profile_preview_page');
        $quicksumbission_page_id = get_option('wdk_membership_quicksumbission_page');
        if(!empty($quicksumbission_page_id))
        {
			if(isset($_GET['post']) && $_GET['post'] == $quicksumbission_page_id)
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipQuickSubmissionContent');

				do_action('wdk-membership/elementor-elements/register_widget/quick_submission', $this);
            } 
            else if(isset($_GET['post']))
            {

            }
            else
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipQuickSubmissionContent');
			
				do_action('wdk-membership/elementor-elements/register_widget/quick_submission', $this);
            }

        }

        if(!empty($dash_page_id))
        {
            if(isset($_GET['post']) && $_GET['post'] == $dash_page_id)
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipBreadcrumb');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipMenu');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipContent');

				do_action('wdk-membership/elementor-elements/register_widget/dash', $this);
            } 
            else if(isset($_GET['post']))
            {

            }
            else
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipBreadcrumb');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipMenu');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipContent');
			
				do_action('wdk-membership/elementor-elements/register_widget/dash', $this);
            }

        }

        if(!empty($profile_page_id))
        {
            if(isset($_GET['post']) && $_GET['post'] == $profile_page_id)
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileContent');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfilesList');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileListings');

				do_action('wdk-membership/elementor-elements/register_widget/profile', $this);
            } 
            else if(isset($_GET['post']))
            {

            }
            else
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileContent');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfileListings');
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfilesList');
			
				do_action('wdk-membership/elementor-elements/register_widget/profile', $this);
            }

        }

		$listing_page_id = get_option('wdk_listing_page');
        if(!empty($listing_page_id))
        {
            if(isset($_GET['post']) && $_GET['post'] == $listing_page_id)
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipListingAltAgents');

				do_action('wdk-membership/elementor-elements/register_widget/listing', $this);
            } 
            else if(isset($_GET['post']))
            {

            }
            else
            {
				$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipListingAltAgents');
			
				do_action('wdk-membership/elementor-elements/register_widget/listing', $this);
            }

        }
		
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkUserDetails');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipLoginForm');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipRegisterForm');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfilesGrid');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfilesList');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipProfilesSearch');
		$this->add_widget('WdkMembership\Elementor\Widgets\WdkMembershipSubscriptions');
	
		do_action('wdk-membership/elementor-elements/register_widget', $this);
    }
        
    public function add_widget($class = ''){
        if(class_exists($class))
        {
            $object = new $class();
            \Elementor\Plugin::instance()->widgets_manager->register( $object );
        };
    }

    /**
     * Register Widget
     *
     * @since 1.0.0
     *
     * @access private
     */
    private function register_modules() {
        
    }       

	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
		$this->register_modules();
	}

	/**
	 * Add elementor category
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */  
    function load_category( $elements_manager ) {
        $elements_manager->add_category(
            $this->elementor_category_name,
            [
                'title' => esc_html__( 'Wdk Membership', 'wdk-membership' ),
                'icon' => 'fa fa-plug',
            ]
        );
    }


    /**
     * Start Elementor Addon
     */
    public function run() { 

		add_action( 'wp_enqueue_scripts',[ $this, 'enqueue_styles' ]);
		add_action( 'wp_enqueue_scripts',[ $this, 'enqueue_scripts' ]);

        add_action( 'elementor/elements/categories_registered', [ $this, 'load_category' ] );
        add_action( 'elementor/widgets/register', [ $this, 'on_widgets_registered' ] );

		do_action('wdk-membership/elementor-elements/run');

        /* load module */
        $this->loader();
		//wmvc_dump($meta);
    }
}

/* Init lib after elementor loaded */
add_action( 'wpdirectorykit/elementor-elements/init', function() {
	$wdk_elementor = new Wdk_membership_elementor();
	$wdk_elementor->run();
	do_action('wdk-membership/elementor-elements/init');
});

add_action('wdk-membership/elementor-elements/register_widget/profile', function(){
	add_action('eli/includes', function(){
		require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/class-contact-form.php';
	});
	
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/class-wdk-membership-map.php';
	$object = new WdkMembership\Elementor\Extensions\WdkMembershipProfileMap();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );
	
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-agency-profiles-list.php';
	$object = new WdkMembership\Elementor\Extensions\WdkMembershipAgencyProfilesList();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );
	
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-agency-profiles-grid.php';
	$object = new WdkMembership\Elementor\Extensions\WdkMembershipAgencyProfilesGrid();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );

	add_action('eli/register_widget', function(){
		$object = new WdkMembership\Elementor\Extensions\WdkMembershipContactFormExt();
		\Elementor\Plugin::instance()->widgets_manager->register( $object );
	});
});

add_action('wdk-membership/elementor-elements/register_widget/listing', function(){
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-listing-agency.php';
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-listing-agency-avatar.php';
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-listing-agency-field.php';
	require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/wdk-membership-listing-agency-listings.php';
	
	$object = new WdkMembership\Elementor\Extensions\WdkMembershipListinAgency();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );

	$object = new WdkMembership\Elementor\Extensions\WdkMembershipListingAgencyAvatar();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );

	$object = new WdkMembership\Elementor\Extensions\WdkMembershipListinAgencyField();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );

	$object = new WdkMembership\Elementor\Extensions\WdkMembershipListinAgencyListings();
	\Elementor\Plugin::instance()->widgets_manager->register( $object );
});

require_once WDK_MEMBERSHIP_PATH . '/elementor-extensions/class-ajax-handler.php';
$object = new WdkMembership\Elementor\Extensions\AjaxHandler();
