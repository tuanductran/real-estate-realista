<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter('the_content', 'wdkmembership_content',1,10);  

function wdkmembership_content( $content )
{
    global $wp_query;

    if(get_option('wdk_membership_dash_page') && isset($wp_query->post) && get_option('wdk_membership_dash_page') == $wp_query->post->ID)
    if(is_user_logged_in())
    { 
        /* success */
    } else {

        $content = '<div style="margin: 35px auto;max-width:768px"><p class="wdk_alert wdk_alert-danger">'.esc_html__('Please Login', 'wdk-membership').'';
        
        if(get_option('wdk_membership_login_page')){
            wp_redirect((wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')),'redirect_to='.urlencode(wdk_current_url()).'&custom_message='.urlencode(esc_html__('Login for open dash page', 'wdk-membership')))));
            //$content .= ', <a href="'.esc_url((wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')),'redirect_to='.urlencode(wdk_current_url())))).'">'.esc_html__('Open Login page', 'wdk-membership').'</a>';
        } else {
            wp_redirect(wp_login_url(wdk_current_url()));
           //$content .= ', <a href="'.esc_url(wp_login_url(wdk_current_url())).'">'.esc_html__('Open Login page', 'wdk-membership').'</a>';
        }

        $content .= '</p></div>';
    }

    return $content;

}

add_filter('the_content', 'wdkmembership_profile_content');  

function wdkmembership_profile_content( $content )
{
    global $wp_query;
    if(get_option('wdk_membership_profile_preview_page') && isset($wp_query->post)  && get_option('wdk_membership_profile_preview_page') == $wp_query->post->ID)
    {
        $wdkmembershiplisting_page_id = get_option('wdk_membership_profile_preview_page');
        if(!empty($wdkmembershiplisting_page_id) && get_post_status($wdkmembershiplisting_page_id) =='publish')
        {

        } else {
            $content = '<div style="margin: 35px auto;max-width:768px"><p class="wdk_alert wdk_alert-danger">'.esc_html__('Missing Profile Page', 'wdk-membership').', <a href="'.get_admin_url().'admin.php?page=wdk-membership&function=import_demo">'.esc_html__('Import demo Page', 'wdk-membership').'</a></p></div>';
        }

    }
    return $content;
}

add_action('admin_bar_menu', 'wdkmembership_toolbar_items', 100);
function wdkmembership_toolbar_items($admin_bar){
    global $wp_query;
    if(isset($wp_query->post))
    if ($wp_query->post->post_type == 'wdk-listing') {
        $admin_bar->add_menu(array(
            'id'    => 'edit',
            'title' => __('Edit Profile', 'wdk-membership'),
            'href'  => admin_url('admin.php?page=wdk_listing&id='.$wp_query->post->ID),
        ));
    }
}

/* disable admin bar by option */
add_action('after_setup_theme', 'wdk_remove_admin_bar');
function wdk_remove_admin_bar() {
    if(get_option('wdk_membership_adminbar_disabled'))
        if (!wmvc_user_in_role('administrator') && !is_admin()) {
            show_admin_bar(false);
        }
}

function wdk_membership_admin_default_page( $url) {
    if( !wmvc_user_in_role('administrator') && get_option('wdk_membership_is_always_dash_redirect') 
    && function_exists('wdk_dash_url') && get_option('wdk_membership_dash_page')){
        $url = get_permalink(get_option('wdk_membership_dash_page'));
    }
    return $url;
}

add_filter('login_redirect', 'wdk_membership_admin_default_page', 10, 3 );

/* filters page title */


if(!function_exists('wdk_membership_override_page_title')) {
    add_filter('document_title_parts', 'wdk_membership_override_page_title', 10);
    function wdk_membership_override_page_title($title) {

        if(isset($_GET['dash_page'])) {
            $title['title'] = implode(' - ', wdk_membership_generate_page_title_tags());
        }

        return $title; 
    }
}

/* fixed woocomerce 7.8 compatibilty for upload images on frotnend */
add_filter('woocommerce_disable_admin_bar', function(){
    if(wmvc_user_in_role('wdk_agent') || wmvc_user_in_role('wdk_owner') || wmvc_user_in_role('wdk_agency'))
        return false;

    return true;
});


add_action('template_redirect', function ()
{
    if(get_option('wdk_membership_login_required_listing_results') && get_option('wdk_membership_login_page') && get_option('wdk_results_page')) {
        global $wp_query;

        if(isset($wp_query->post) && get_option('wdk_results_page') == $wp_query->post->ID)
        if(is_user_logged_in())
        { 
            /* success */
        } else {
            wp_redirect(wdk_login_url(wdk_current_url(), esc_html__('Please log in for access to the open results listings page.', 'wdk-membership')));
        }
    }
}, 1, 10);  

?>