<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $wdk_membership_user_fields_list, $wdk_membership_user_fields;

/* will be deprecated */
$wdk_membership_user_fields_list = array(
    'wdk_slug' => __('Profile slug', 'wdk-membership'),
    'wdk_address' => __('Address', 'wdk-membership'),
    'wdk_country' => __('Country', 'wdk-membership'),
    'wdk_city' => __('City', 'wdk-membership'),
    'wdk_company_name' => __('Company name', 'wdk-membership'),
    'agency_name' => __('Agency Name', 'wdk-membership'),
    'wdk_position_title' => __('Position Title', 'wdk-membership'),
    'wdk_facebook' => __('Facebook', 'wdk-membership'),
    'wdk_youtube' => __('Youtube', 'wdk-membership'),
    'wdk_linkedin' => __('Linkedin', 'wdk-membership'),
    'wdk_twitter' => __('Twitter', 'wdk-membership'),
    'wdk_instagram' => __('Instagram', 'wdk-membership'),
    'wdk_telegram' => __('Telegram', 'wdk-membership'),
    'wdk_whatsapp' => __('WhatsApp', 'wdk-membership'),
    'wdk_viber' => __('Viber', 'wdk-membership'),
    'wdk_iban' => __('IBAN', 'wdk-membership'),
    'wdk_payment_instructions' => __('Payment Instructions', 'wdk-membership'),
);

$wdk_membership_user_fields = array(
    'wdk_slug' => array(
        'field_name' => __('Profile slug', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_address' => array(
        'field_name' => __('Address', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_country' => array(
        'field_name' => __('Country', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_city' => array(
        'field_name' => __('City', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_company_name' => array(
        'field_name' => __('Company name', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'agency_name' => array(
        'field_name' => __('Agency Name', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_position_title' => array(
        'field_name' => __('Position Title', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_facebook' => array(
        'field_name' => __('Facebook', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_youtube' => array(
        'field_name' => __('Youtube', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_linkedin' => array(
        'field_name' => __('Linkedin', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_twitter' => array(
        'field_name' => __('Twitter', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_instagram' => array(
        'field_name' => __('Instagram', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_telegram' => array(
        'field_name' => __('Telegram', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_whatsapp' => array(
        'field_name' => __('WhatsApp', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_viber' => array(
        'field_name' => __('Viber', 'wdk-membership'),
        'field_hint' => '',
        'field_type' => 'INPUTBOX'
    ),
    'wdk_iban' => array(
        'field_name' => __('IBAN', 'wdk-membership'),
        'field_hint' => __("IBAN will be used for Payouts or similar cases",'wdk-membership'),
        'field_type' => 'INPUTBOX'
    ),
    'wdk_payment_instructions' => array(
        'field_name' => __('Payment Instructions', 'wdk-membership'),
        'field_hint' => __("Please enter specific bank information and payment instructions here",'wdk-membership'),
        'field_type' => 'TEXTAREA'
    )
);


add_action( 'show_user_profile', function($user) use ($wdk_membership_user_fields) {wdk_membership_extra_user_profile_fields($user,$wdk_membership_user_fields);} );
add_action( 'edit_user_profile', function($user) use ($wdk_membership_user_fields) {wdk_membership_extra_user_profile_fields($user,$wdk_membership_user_fields);} );

function wdk_membership_extra_user_profile_fields( $user,$wdk_membership_user_fields ) {
    if(wdk_get_option('wdk_membership_is_enable_subscriptions') && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
        wp_enqueue_script( 'jquery-ui-datepicker' );
        wp_enqueue_style('jquery-ui');

        $subscriptions_drops = array();
        $user_subscription_id = '';
        $user_subscription_date_expire = '';
        $user_id = wmvc_show_data('ID', $user);

        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        $Winter_MVC_wdk_membership->model('subscription_m');

        $user_subscription = $Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id), TRUE);
        if(wmvc_show_data('subscription_id', $user_subscription, false, TRUE, TRUE))
            $user_subscription_id = wmvc_show_data('subscription_id', $user_subscription, '', TRUE, TRUE);

        if(wmvc_show_data('date_expire', $user_subscription, false, TRUE, TRUE))
            $user_subscription_date_expire = wmvc_show_data('date_expire', $user_subscription, false, TRUE, TRUE);

        $subscriptions = $Winter_MVC_wdk_membership->subscription_m->get_pagination(NULL, FALSE, array('is_activated'=>1));
        if (count($subscriptions) > 0) {
            foreach($subscriptions as $subscription) {
                $subscriptions_drops[wdk_show_data('idsubscription',$subscription,'', TRUE, TRUE)] = wdk_show_data('idsubscription', $subscription,'', TRUE, TRUE)
                                                                                            .', '.wdk_show_data('subscription_name', $subscription,'', TRUE, TRUE)
                                                                                            .', '.wdk_show_data('location_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE).' '. esc_html__('Location', 'wdk-membership')
                                                                                            .', '.wdk_show_data('category_title',$subscription, esc_html__('Any', 'wdk-membership'), TRUE, TRUE).' '. esc_html__('Category', 'wdk-membership');
            }
        }

    }

    $wdk_membership_user_fields = apply_filters( 'wdk_membership_user_edit_fields', $wdk_membership_user_fields);
    ?>
    <div class="wdk_postbox" style="display: block;">
        <div class="wdk_postbox-header">
            <h3><?php _e("WDK Membership Info", "wdk-membership"); ?></h3>
        </div>
        <div class="wdk_inside">
            <table class="form-table">
                <?php foreach($wdk_membership_user_fields as $field_id => $field_name) :?>
                <?php if(!get_option('wdk_membership_custom_field_'.$field_id.'_enable')) continue;?>
                <tr>
                    <th><label for="user_field_<?php echo esc_html($field_id);?>"><?php echo esc_html__($field_name['field_name'], 'wdk-membership'); ?></label></th>
                    <td>
                        <?php if($field_name['field_type'] == "INPUTBOX"):?>
                            <input type="text" name="<?php echo esc_html($field_id);?>" id="user_field_<?php echo esc_html($field_id);?>" value="<?php echo esc_attr( get_the_author_meta( $field_id, $user->ID ) ); ?>" class="regular-text" /><br />
                        <?php elseif($field_name['field_type'] == "TEXTAREA"):?>
                            <textarea name="<?php echo esc_html($field_id);?>"  id="user_field_<?php echo esc_html($field_id);?>"  rows="6" class="regular-text"><?php echo esc_attr( get_the_author_meta( $field_id, $user->ID ) ); ?></textarea><br />
                        <?php endif;?>

                        

                        <?php if(!empty($field_name['field_hint'])):?>
                            <span class="description"><?php echo wp_kses_post($field_name['field_hint']); ?>.</span>
                        <?php else:?>
                            <span class="description"><?php _e("Please enter your",'wdk-membership'); ?> <?php echo esc_html__($field_name['field_name'], 'wdk-membership'); ?>.</span>
                        <?php endif;?>

                    </td>
                </tr>
                <?php endforeach;?>
                <?php if(!is_page(get_option('wdk_membership_dash_page')) && wdk_get_option('wdk_membership_is_enable_subscriptions') && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled')): ?>
                    <?php if(wmvc_user_in_role('administrator')):?>
                        <tr>
                            <th><label for="user_field_subscription_id"><?php echo esc_html__('Membership Subscription','wdk-membership'); ?></label></th>
                            <td>
                                <?php
                                    echo wmvc_select_option('subscription_id', $subscriptions_drops, $user_subscription_id, "id='subscriptions'", __('Not Selected', 'wdk-membership'));
                                ?>
                                <br>
                                <span class="description"><?php echo esc_html__("User Membership Subscription",'wdk-membership'); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="user_field_date_expire"><?php echo esc_html__('Membership Subscription Date Expire','wdk-membership'); ?></label></th>
                            <td>
                                <input type="text" name="user_field_date_expire" id="user_field_date_expire" value="<?php echo esc_html($user_subscription_date_expire);?>" class="regular-text wdk-fielddate" /><br />
                                <span class="description"><?php echo esc_html__("User Membership Subscription Date Expire",'wdk-membership'); ?></span>
                            </td>
                        </tr>
                    <?php else:?>
                        <tr>
                            <th><label for="user_field_subscription_id"><?php echo esc_html__('Membership Subscription'); ?></label></th>
                            <td>
                                <?php
                                    echo wmvc_select_option('subscription_id', $subscriptions_drops, $user_subscription_id, "id='subscriptions' disabled='disabled' readonly='readonly'", __('Not Selected', 'wdk-membership'));
                                ?>
                                <br>
                                <span class="description"><?php echo esc_html__("User Membership Subscription",'wdk-membership'); ?></span>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="user_field_date_expire"><?php echo esc_html__('Membership Subscription Date Expire','wdk-membership'); ?></label></th>
                            <td>
                                <input readonly='readonly' type="text" name="user_field_date_expire" id="user_field_date_expire" value="<?php echo esc_html($user_subscription_date_expire);?>" class="regular-text wdk-fielddate" /><br />
                                <span class="description"><?php echo esc_html__("User Membership Subscription Date Expire",'wdk-membership'); ?></span>
                            </td>
                        </tr>
                    <?php endif;?>
                <?php endif;?> 
                <?php if(!is_page(get_option('wdk_membership_dash_page')) && wdk_get_option('wdk_membership_is_enable_subscriptions') && wdk_get_option('wdk_membership_multiple_subscriptions_enabled') && wmvc_user_in_role('administrator')): ?>
                    <tr>
                        <th><label for="user_field_date_expire"><?php echo esc_html__('Membership Subscription','wdk-membership'); ?></label></th>
                        <td>
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-membership-subscriptions-users&user_id=".esc_attr( wmvc_show_data('ID', $user));?>"><?php echo esc_html__('Open Membership User Subscriptions List','wdk-membership'); ?></a>
                        </td>
                    </tr>
                <?php endif;?>
            </table>
        </div>
    </div>
    <?php
    
    global $Winter_MVC_wdk_membership;
    $user_id = wmvc_show_data('ID', $user);
    $Winter_MVC_wdk_membership->model('agency_agent_m');
    $agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agency_id'=>$user_id), FALSE);
    $agency_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agent_id'=>$user_id), FALSE);

    ?>
    <?php if(wmvc_user_in_role('wdk_agency') || wmvc_user_in_role('wdk_agent')):?>
    <div class="wdk_postbox" style="display: block;">
        <div class="wdk_postbox-header">
            <h3><?php _e("WDK Agency Info", "wdk-membership"); ?></h3>
        </div>
        <div class="wdk_inside">
            <table class="form-table">
                <?php if(wmvc_user_in_role('wdk_agency')):?>
                <tr>
                    <th><label for="user_agency_agent_email"><?php echo esc_html__('Agent email','wdk-membership'); ?></label></th>
                    <td>
                        <div class="wdk_agent_invite">
                        <input type="text" name="user_agency_agent_email" id="user_agency_agent_email" value="<?php echo esc_html($user_subscription_date_expire);?>" class="regular-text" />
                        <button type="button" name="filter_action" id="user_agency_agent_email-submit" class="wdk-click-load-animation wdk-btn wdk-btn-primary wdk-btn-slim" data-wpnonce="<?php echo wp_create_nonce('wdk_agency_agent_submit');?>">
                            <span class="hidden-onloading"><?php echo esc_html__('Invite agent','wdk-membership') ?></span>
                            <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                        </button>

                        <div>
                        <br />
                        <span class="description"><?php echo esc_html__("Enter agent email and invite them to become your agency registered agent",'wdk-membership'); ?></span>
                    </td>
                </tr>
                <?php if(count($agent_list) > 0): ?>
                <tr>
                    <th><label for="user_agency_agents"><?php echo esc_html__('Assigned Agents','wdk-membership'); ?></label></th>
                    <td>
                        <table class="agency_agents">
                            <tr>
                                <th><?php echo esc_html__('Agent','wdk-membership'); ?></th>
                                <th><?php echo esc_html__('Status','wdk-membership'); ?></th>
                                <th><?php echo esc_html__('Actions','wdk-membership'); ?></th>
                            </tr>
                            <?php if(count($agent_list) == 0): ?>
                            <tr>
                                <td colspan="5">
                                    <span class="label label-info"><?php echo esc_html__('Agents not found','wdk-membership') ?></span>
                                </td>
                            </tr>
                            <?php endif;?>
                            <?php foreach($agent_list as $agent): ?>
                            <tr>
                                <td><div class="agent_name"><?php echo wdk_get_user_field($agent->agent_id, 'user_email'); ?></div></td>
                                <td><div class="agent_status"><span class="label label-info"><?php echo esc_html($agent->status); ?></span></div></td>
                                <td>
                                <button type="button" name="filter_action" class="agency_agent_email-remove wdk-click-load-animation wdk-btn wdk-btn-primary wdk-btn-slim" data-wpnonce="<?php echo wp_create_nonce('wdk_agency_agent_remove');?>">
                                    <span class="hidden-onloading"><?php echo esc_html__('Remove','wdk-membership') ?></span>
                                    <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                                    <span class="wdk-hidden question"><?php echo esc_html__('You really want to remove this agent?','wdk-membership') ?></span>
                                </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </td>
                </tr>
                <?php endif;?>
                <?php endif;?>
                <?php if(wmvc_user_in_role('wdk_agent')):?>
                    <tr>
                    <th><label for="user_agency_agents"><?php echo esc_html__('Agencies related','wdk-membership'); ?></label></th>
                    <td>
                        <table class="agency_agents">
                            <tr>
                                <th><?php echo esc_html__('Agency','wdk-membership'); ?></th>
                                <th><?php echo esc_html__('Status','wdk-membership'); ?></th>
                                <th><?php echo esc_html__('Actions','wdk-membership'); ?></th>
                            </tr>
                            <?php if(count($agency_list) == 0): ?>
                            <tr>
                                <td colspan="5">
                                    <span class="label label-info"><?php echo esc_html__('Agencies not found','wdk-membership') ?></span>
                                </td>
                            </tr>
                            <?php endif;?>
                            <?php foreach($agency_list as $agency): ?>
                            <tr>
                                <td><div class="agency_name"><?php echo wdk_get_user_field($agency->agency_id, 'user_email'); ?></div></td>
                                <td><div class="agent_status"><span class="label label-info"><?php echo esc_html($agency->status); ?></span></div></td>
                                <td>
                                <button type="button" name="filter_action" class="agent_agency_email-remove wdk-click-load-animation wdk-btn wdk-btn-primary wdk-btn-slim" data-wpnonce="<?php echo wp_create_nonce('wdk_agent_agency_remove');?>">
                                    <span class="hidden-onloading"><?php echo esc_html__('Remove','wdk-membership') ?></span>
                                    <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                                    <span class="wdk-hidden question"><?php echo esc_html__('You really want to be removed from agency?','wdk-membership') ?></span>
                                </button>
                                <?php if($agency->status != 'CONFIRMED'): ?>
                                <button type="button" name="filter_action" class="agent_agency_email-approve wdk-click-load-animation wdk-btn wdk-btn-primary wdk-btn-slim" data-wpnonce="<?php echo wp_create_nonce('wdk_agent_agency_approve');?>">
                                    <span class="hidden-onloading"><?php echo esc_html__('Approve','wdk-membership') ?></span>
                                    <span class="wdk-ajax-indicator wdk-infinity-load dashicons dashicons-update-alt wdk-hidden">
                                </button>
                                <?php endif;?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </td>
                </tr>
                <?php endif;?>
            </table>
        </div>
    </div>
    <?php endif;?>

    <?php 
}

add_action( 'personal_options_update', function($user) use ($wdk_membership_user_fields) {
    wdk_membership_save_extra_user_profile_fields($user,$wdk_membership_user_fields);} );
add_action( 'edit_user_profile_update', function($user) use ($wdk_membership_user_fields) {
    wdk_membership_save_extra_user_profile_fields($user,$wdk_membership_user_fields);} );

function wdk_membership_save_extra_user_profile_fields( $user,$wdk_membership_user_fields ) {
    $user_id = wmvc_show_data('ID', $user);
    if ( empty( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'update-user_' . $user_id ) ) {
        return;
    }
    
    if ( !current_user_can( 'edit_user', $user_id ) ) { 
        return false; 
    }

    foreach ($wdk_membership_user_fields as  $field_id => $field_name) {
        if(isset($_POST[$field_id])) {
            if($field_id == 'wdk_slug') {

                $wdk_slug = sanitize_text_field($_POST['wdk_slug']);

                // Check for validation errors
                $errors = new WP_Error();
                validate_wdk_slug_field($errors, true, get_userdata($user_id));
        
                // If no errors, update the phone field
                if (empty($errors->errors)) {
                    update_user_meta($user_id, 'wdk_slug', $wdk_slug);
                }

                continue;
            }

            update_user_meta( $user_id, $field_id, wmvc_xss_clean($_POST[$field_id]) );
        }
    }

    if(isset($_POST['subscription_id']) && wmvc_user_in_role('administrator') && wdk_get_option('wdk_membership_is_enable_subscriptions') && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->model('subscription_user_m');
        $Winter_MVC_wdk_membership->model('subscription_m');

        $user_subscription = $Winter_MVC_wdk_membership->subscription_user_m->get_by(array('user_id'=>$user_id), TRUE);

        $update_data = array();
        /* if subscription exists and not changed */
        if($user_subscription && wmvc_show_data('subscription_id', $user_subscription, false, TRUE, TRUE) == $_POST['subscription_id']) {
            //from now
            $update_data['date_expire'] = wdk_normalize_date_db(sanitize_text_field($_POST['user_field_date_expire']));

            $Winter_MVC_wdk_membership->subscription_user_m->insert($update_data, wmvc_show_data('idsubscription_user', $user_subscription, false, TRUE, TRUE));
        } elseif(intval($_POST['subscription_id'])) {
            /* remove old */
            $Winter_MVC_wdk_membership->db->where(array('user_id'=>$user_id));
            $Winter_MVC_wdk_membership->db->delete($Winter_MVC_wdk_membership->subscription_user_m->_table_name);

            $subscription = $Winter_MVC_wdk_membership->subscription_m->get(intval($_POST['subscription_id']), TRUE);
            $update_data['subscription_id'] = $subscription->idsubscription;
            $update_data['user_id'] = $user_id;

            if(isset($_POST['user_field_date_expire']) && !empty($_POST['user_field_date_expire'])) {
                $update_data['date_expire'] = wdk_normalize_date_db(sanitize_text_field($_POST['user_field_date_expire']));
            } else {
                $update_data['date_expire'] = date('Y-m-d H:i:s', 
                    strtotime('+'.$subscription->days_limit.' days', current_time('timestamp')));
            }

            $update_data['status'] = 'ACTIVE';
            $Winter_MVC_wdk_membership->subscription_user_m->insert($update_data);
        }
        /* expire date set more if already exists package */

    }
}

// Validate the entered phone number
function validate_wdk_slug_field($errors, $update, $user) {
    if (isset($_POST['wdk_slug']) && !empty($_POST['wdk_slug'])) {
        $profile_slug = sanitize_text_field($_POST['wdk_slug']);

        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT user_id FROM $wpdb->usermeta
            WHERE meta_key = %s AND meta_value = %s AND user_id != %s LIMIT 1",
            'wdk_slug',
            $profile_slug,
            wmvc_show_data('ID', $user),
        );
        $check_in_meta = $wpdb->get_results($query);

        $query = $wpdb->prepare(
            "SELECT ID FROM $wpdb->users
            WHERE user_login = %s AND ID != %s LIMIT 1",
            $profile_slug,
            wmvc_show_data('ID', $user),
        );
        $check_in_users = $wpdb->get_results($query);
        // Add your own validation logic here
        if (!empty($profile_slug) && !empty($check_in_meta) || !empty($check_in_users)) {
            $errors->add('invalid_wdk_slug', sprintf(__('Please enter unique profile slug, profile with slug or username %1$s already exists', 'wdk-membership'), $profile_slug));
        }

        if (!empty($profile_slug) && !preg_match("/^[a-z0-9-_]+\$/", $profile_slug)) {
            $errors->add('invalid_wdk_slug', sprintf(__('Profile slug allowed only a-z 0-9 - _', 'wdk-membership'), $profile_slug));
        }  

    }
}
add_action('user_profile_update_errors', 'validate_wdk_slug_field', 10, 3);

