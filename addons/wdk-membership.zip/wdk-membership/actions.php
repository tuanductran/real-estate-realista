<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'wpdirectorykit/install/api', 'wdk_membership_install'); 

if(!function_exists('wdk_membership_install')) {
    function wdk_membership_install () {
        global $Winter_MVC_wdk_membership;
        $Winter_MVC_wdk_membership->load_controller('wdk-membership', 'api_import');
    }
} 


/* export calendar */


if(!function_exists('wdk_export_icl_calendar')) {
add_action('init', 'wdk_export_icl_calendar');
    function wdk_export_icl_calendar(){
        if(isset($_GET['function']) &&  $_GET['function'] =='wdk_export_icl_calendar' && isset($_GET['calendar_id'])) {
            @ob_clean();
            global $Winter_MVC_wdk_bookings;
            $calendar_id = sanitize_text_field($_GET['calendar_id']);
            $Winter_MVC_wdk_bookings->model('reservation_m');
            $Winter_MVC_wdk_bookings->model('calendar_m');

            if(!$Winter_MVC_wdk_bookings->calendar_m->check_deletable($calendar_id))   exit(__('Permission denied', 'wdk-membership'));

            $reservations = $Winter_MVC_wdk_bookings->reservation_m->get_pagination(NULL, NULL, array('calendar_id'=>$calendar_id, 'is_approved' =>1));

            $print_data = [];
            $print_data [] = 'BEGIN:VCALENDAR';
            $print_data [] = 'VERSION:2.0';
            $print_data [] = 'PRODID:-//'.get_bloginfo("name").'//EN';
            $print_data [] = 'X-WR-CALNAME:'.get_bloginfo("name").'';
            $print_data [] = 'X-WR-CALDESC:Public '.get_bloginfo("name").' Reservations Provided by '.site_url();
            $print_data [] = 'X-PUBLISHED-TTL:PT1H';
            $print_data [] = 'REFRESH-INTERVAL;VALUE=DURATION:P1H';
            $print_data [] = 'NAME:'.get_bloginfo("name").'';
            $print_data [] = 'CALSCALE:GREGORIAN';
            $print_data [] = 'METHOD:PUBLISH';
            
            foreach ($reservations as $key => $reservation) {
                    $print_data [] = 'BEGIN:VEVENT';
                    $print_data [] = 'DTEND;VALUE=DATE:'. date('YmdTHis', strtotime(wmvc_show_data('date_to', $reservation)));
                    $print_data [] = 'DTSTART;VALUE=DATE:'.date('YmdTHis', strtotime(wmvc_show_data('date_from', $reservation)));
                    $print_data [] = 'URL;VALUE=URI:' . admin_url('admin.php?page=wdk-bookings-add&id='.wmvc_show_data('idreservation', $reservation));
                    $print_data [] = 'UID:reservation_' .wmvc_show_data('idreservation', $reservation);
                    $print_data [] = 'SUMMARY:'.get_bloginfo("name").' Reservation Id '.wmvc_show_data('idreservation', $reservation); 
                    $print_data [] = 'DESCRIPTION:<strong>Price</strong> '.wmvc_show_data('price', $reservation).wdk_booking_currency_symbol().'\n'.wmvc_show_data('notes', $reservation) ;
                    $print_data [] = 'END:VEVENT';
                
            }
            
            $print_data [] = 'END:VCALENDAR';

            $print_data = preg_replace('/^[ \t]*[\r\n]+/m', '', implode(PHP_EOL, ($print_data)));


            header('Content-type: text/calendar; charset=utf-8');
            header("Content-Length:".strlen($print_data));
            header("Content-Disposition: attachment; filename=export_icl_calendar".$calendar_id.".ics");
            
            echo $print_data;
            
            exit();
        }
    }
}

/* export calendar */


if(!function_exists('wdk_export_payout')) {
    add_action('init', 'wdk_export_payout');
        function wdk_export_payout(){
            if(isset($_GET['function']) &&  $_GET['function'] =='wdk_export_payout') {
                @ob_clean();

                global $Winter_MVC_wdk_bookings;
                global $Winter_MVC_WDK;
                $Winter_MVC_wdk_bookings->model('reservation_m');
                $Winter_MVC_wdk_bookings->model('reportdata_m');
                $Winter_MVC_wdk_bookings->model('report_m');
        
                $current_user_id = get_current_user_id();
        
                $owner = get_user_by('id', $current_user_id);      

                /* end filters */
        
                $controller = 'reportdata';
                $columns = array('email_sender', 'message');
                $external_columns = array('email_sender', 'message');
        
                $per_page = NULL;
                $offset = NULL;
        
                wdk_booking_prepare_search_query_GET($columns, $controller.'_m', $external_columns);   
                $results = $Winter_MVC_wdk_bookings->reportdata_m->get_pagination($per_page, $offset, array('owner_email' => $owner->user_email), NULL, 'report_id');
        
                $skip_cols = array();
        
                foreach($results as $key=>$report)
                {
                    $user = get_user_by( 'email', $report->owner_email );
                                    
                    $results[$key]->IBAN = wmvc_show_data('wdk_iban', $user , '-'); 
                    $results[$key]->Payout = esc_html((100-$report->fee_percentage)/100*$report->total_price_net_sum);
                }
        
                $csv_list = wdk_booking_prepare_export($results, $skip_cols);
                
                header('Content-Type: application/csv');
                header("Content-Length:".strlen($csv_list));
                header("Content-Disposition: attachment; filename=payout_user_".$current_user_id.'_'.date('Y-m-d-H-i-s', time()+get_option('gmt_offset')*60*60).".csv");
        
                echo $csv_list;
                exit();
            }
        }
    }


remove_action( 'woocommerce_order_details_after_order_table', 'woocommerce_order_again_button' );

// When payment is completed or status completed, then auto activate order/subscription
add_action( 'woocommerce_payment_complete', function($order_id){
    wdk_membership_after_payment( $order_id, 'ACTIVE' );
} );

// When payment is completed or status completed, then auto activate order/subscription
// if enabled sometimes trigerring 2x payment so will be extended 2 times

add_action( 'woocommerce_order_status_completed', 'wdk_membership_woocommerce_order_status_completed', 10, 1 );

function wdk_membership_woocommerce_order_status_completed( $order_id ) {
    wdk_membership_after_payment( $order_id, 'ACTIVE', 'completed' );
}

/*
add_action( 'woocommerce_order_status_changed', 'wdk_membership_woocommerce_order_status_completed', 99, 4 );
function wdk_membership_woocommerce_order_status_completed(  $order_id, $old_status, $new_status, $order ) {
    if( $new_status == "completed" ) {
        wdk_membership_after_payment( $order_id, 'ACTIVE' );
    }
}
*/

//add_action( 'woocommerce_after_register_post_type', 'wdk_payment_woocommerce_cron' );

add_action( 'init', 'wdk_membership_disable_subscriptions_cron' , 10, 1 ); 
function wdk_membership_disable_subscriptions_cron()
{
    //wdk_membership_after_payment(3596);
    if ( ! wp_next_scheduled( 'wdk_membership_disable_subscriptions' ) ) {
        wp_schedule_event( time(), 'daily', 'wdk_membership_disable_subscriptions' );
    }

}

function wdk_membership_after_payment( $order_id, $status = NULL, $event='payment' )
{
    static $called_count = array();

    if(isset($called_count[$order_id]))
    {
        return; // disable multiple calls on payment if autocompleted
    }
    else
    {
        $called_count[$order_id] = 1;
    }

    $order = wc_get_order( $order_id );

    $user_id = $order->get_user_id();
    $items = $order->get_items();

    global $Winter_MVC_wdk_membership;
    global $Winter_MVC_WDK;

    $Winter_MVC_WDK->model('listing_m');

    $Winter_MVC_wdk_membership->model('subscription_m');
    $Winter_MVC_wdk_membership->model('subscription_user_m');

    /* create user if guest */
    if(empty($user_id)) {
        $username = $order->get_billing_email();
        $email_address = $order->get_billing_email();
        $password = wp_generate_password();

        $user_id = wp_create_user( $username, $password, $email_address );

        if(is_intval($user_id)){
            // Set the nickname
            wp_update_user(
                array(
                    'ID'          =>    $user_id,
                    'nickname'    =>    $username
                )
            );

            $available_acc_types = 'wdk_visitor';
            if(get_option('wdk_membership_register_type')){
                $available_acc_types = get_option('wdk_membership_register_type');
            }
            if(get_option('wdk_membership_register_show_user_select') && isset($data_fields['user_role']) && !empty($data_fields['user_role'])){
                $available_acc_types =  sanitize_text_field($data_fields['user_role']);
            }

            $user = new WP_User( $user_id );
            $user->set_role($available_acc_types);

            $display_name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
            wp_update_user( array ('ID' => $user_id, 'display_name' => esc_html( $display_name ) ) );

            $userdata = get_userdata($user_id);

            $subject = __('New user on our website!', 'wdk-membership');
            $data_message = array();
            $data_message['login'] = $username;
            $data_message['password'] = $password;
            $data_message['user'] = $userdata;
            $data_message['data'] = '';

            update_user_meta( $user_id, 'first_name', $order->get_billing_first_name());
            update_user_meta( $user_id, 'last_name', $order->get_billing_last_name());
            update_user_meta( $user_id, 'last', $order->get_billing_last_name());

            $ret = wdk_mail($email_address, $subject, $data_message, 'new_user_auto_created');
            
        } elseif($user = get_user_by( 'email', $order->get_billing_email())) {
            $user_id = $user->ID;
        } else {
            return false;
        }
    }
    
    foreach ( $items as $item ) {
        
        $product_id = (int) $item['product_id'];
        $subscription_user_id = NULL;

        $product = wc_get_product( $product_id ); 
        //$price = $product->get_price(); - $product can be NULL here if removed and generate errors!

        $price = $item['subtotal'];

        // fetch subscription based on product_id
        $subscription = $Winter_MVC_wdk_membership->subscription_m->get_by(array( 'woocommerce_product_id' => $product_id, 'is_activated' => 1 ), TRUE);
        
        if(empty($subscription))continue;
        
        $subscription_user = $Winter_MVC_wdk_membership->subscription_user_m->get_by(array( 'user_id' => $user_id,'subscription_id' => $subscription->idsubscription), TRUE);

        if($subscription_user) {
            $subscription_user_id = $subscription_user->idsubscription_user;
            
            // skip activating if already same status and completed status changed on order
            // trouble, not possible to extend in such case
            /*
            if($event == 'completed')
            {
                if($subscription_user->status == $status)
                {
                    continue;
                }
            }*/
        }

        /* unlimit days */
        if(empty($subscription->days_limit)) {
            $subscription->days_limit = 365 * 10;
        }

        $update_data = array();
        
        $update_data['subscription_id'] = $subscription->idsubscription;
        $update_data['user_id'] = $user_id;
        $update_data['date_last_paid'] = date('Y-m-d H:i:s');
        $update_data['status'] = $status;
        $update_data['price_paid'] = $price;


        /* if single subscriptions and not extend remove old */
        if(empty($subscription_user_id) && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
            /* remove old */
            //$Winter_MVC_wdk_membership->db->where(array('user_id'=>$user_id));
            //$Winter_MVC_wdk_membership->db->delete($Winter_MVC_wdk_membership->subscription_user_m->_table_name);

            $Winter_MVC_WDK->db->query('UPDATE '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.' SET status = "DEPRECATED" WHERE user_id = "'.esc_sql($user_id).'"');
        }

        /* expire date set more if already exists package */
        if($subscription_user_id && strtotime($subscription_user->date_expire) > time())
        {
            //from now
            $update_data['date_expire'] = date('Y-m-d H:i:s', 
                                                    strtotime('+'.$subscription->days_limit.' days', strtotime($subscription_user->date_expire)));
        }
        else
        {
            //from previous date_subscription_expire
            $update_data['date_expire'] = date('Y-m-d H:i:s', 
                                                    strtotime('+'.$subscription->days_limit.' days', current_time('timestamp')));
        }

        // update subscription_user
        $Winter_MVC_wdk_membership->subscription_user_m->insert($update_data, $subscription_user_id);
        /* extend listings */

        /* message */
        $data_message = array();
        $data_message['user'] = get_userdata( wmvc_show_data('user_id', $update_data) );
        $data_message['subscription'] = $subscription;
        $data_message['subscription_user'] = $update_data;
        
        $ret = wdk_mail(wdk_show_data('user_email', $data_message['user']),
                                sprintf(__('Membership Subscription %1$s Confirmation','wdk-membership'), wdk_show_data('subscription_name', $subscription)),
                                $data_message, 'membership_purchased');

        if($status == "ACTIVE") {
    
    
        }
    }


    //exit('END wdk_after_payment');
}


add_action( 'wdk_membership_disable_subscriptions', 'wdk_membership_disable_subscriptions_sync', 10, 2 );

function wdk_membership_disable_subscriptions_sync($print = TRUE)
{

    // check if some listing date_subscription_expired and if so, deapprove listing
    global $Winter_MVC_WDK;
    global $Winter_MVC_wdk_membership;
    $Winter_MVC_wdk_membership->model('subscription_user_m');
    $Winter_MVC_wdk_membership->model('subscription_m');
    $Winter_MVC_WDK->model('listing_m');

    $Winter_MVC_WDK->db->select($Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.*,'.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.woocommerce_product_id');
    $Winter_MVC_wdk_membership->db->join($Winter_MVC_wdk_membership->subscription_m->_table_name.' ON '.$Winter_MVC_wdk_membership->subscription_m->_table_name.'.idsubscription = '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.'.subscription_id', TRUE, 'left');
    $user_subscriptions = $Winter_MVC_wdk_membership->subscription_user_m->get_by(array('date_expire < \''.current_time('mysql').'\'' => NULL));
    
    //echo $Winter_MVC_WDK->db->last_query();
 
    if($print)
        echo esc_html__('CRON START', 'wdk-membership').'<br />';

    if($print)
        echo esc_html__('Expired Subscriptions found', 'wdk-membership').': '.count($user_subscriptions).'<br />';

    $messages_count = 0;
    foreach($user_subscriptions as $user_subscription)
    {
        $listings = $Winter_MVC_WDK->listing_m->get_pagination(NULL, NULL, array('subscription_id'=>$user_subscription->subscription_id,'is_approved'=>1), TRUE, $user_subscription->user_id);
       
        $listings_ids = '';
        $listings_count = 0;
        foreach ($listings as $listing) {
            $listings_count++;
            if(!empty($listings_ids)) {
                $listings_ids .= ',';
            }

            $listings_ids .= $listing->post_id;
        }

        if(!empty($listings_ids)) {

            /* deapproved listings */
            $Winter_MVC_WDK->db->query('UPDATE '.$Winter_MVC_WDK->listing_m->_table_name.' SET is_approved = NULL WHERE subscription_id = "'.esc_sql($user_subscription->subscription_id).'" AND post_id in ('.$listings_ids.')');
        
            $user_info = get_userdata($user_subscription->user_id);

            if(wdk_show_data('user_email', $user_info)) {
                            
                $subject = esc_html__('Expired Subscription', 'wdk-membership');
                $subject .= ' #'.$user_subscription->subscription_id;

                if($print)
                    echo '<br /><br />'.esc_html__('Sending Email', 'wdk-membership').'<br />';

                if($print) {
                    echo esc_html__('Subscription id', 'wdk-membership').': '.$user_subscription->subscription_id .'<br />';
                    echo esc_html__('User', 'wdk-membership').': #'.$user_subscription->user_id.', '.$user_info->display_name.' '.$user_info->user_email.'<br />';
                    echo esc_html__('Subject', 'wdk-membership').': '.$subject.'<br />';
                    $data_message = array();
                    $data_message['user'] = $user_info;
                    $data_message['listings'] = $listings;
                    $data_message['subject']= $subject;
                    $data_message['subscription_link'] = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($user_subscription->woocommerce_product_id));

                    $Winter_MVC_WDK->view('email/membership_expired_listing_cron', $data_message, TRUE);
                }

                /* message */
                $data_message = array();
                $data_message['user'] = $user_info;
                $data_message['listings'] = $listings;
                $data_message['subscription_link'] = wdk_url_suffix(wc_get_cart_url(), 'add-to-cart='.esc_attr($user_subscription->woocommerce_product_id));
            
                $ret = wdk_mail(wdk_show_data('user_email', $user_info), __('Listing Expired by', 'wdk-membership').' '.get_bloginfo('name'), $data_message, 'membership_expired_listing_cron');

                // Save info about notified user
                $update_data = array('date_notify'=>current_time('mysql'), 'status' => 'EXPIRED');

                if($ret === TRUE)
                {
                    echo '<br />'.esc_html__('Sending Message SUCCESSFULLY', 'wdk-membership').'<br />';
                    $Winter_MVC_wdk_membership->subscription_user_m->insert($update_data, $user_subscription->idsubscription_user);
                }
                else
                {
                    echo '<br /><b style="color:red;">'.esc_html__('Sending Message FAILED', 'wdk-membership').'</b><br />';
                }

                $messages_count++;
            }
        }

        /* remove old user subscription (happens when on single subscription user add new) */
        if($user_subscription->status == 'DEPRECATED') {
            $Winter_MVC_wdk_membership->subscription_user_m->delete($user_subscription->subscription_id);
        }

    }
        
    if($print)
        echo '<br /><br />'.esc_html__('Total Expired Listings Emails sent', 'wdk-membership').': '.$messages_count.'<br />';

    if($print)
        echo esc_html__('CRON END', 'wdk-membership').'<br />';

    exit('END wdk_disable_subscriptions_sync');
}

function wdk_subscriptions_sync_cron_manual()
{
    if(isset($_GET['wdk_subscriptions_sync_cron'])) {
        wdk_membership_disable_subscriptions_sync(TRUE);
        exit();
    }
}

add_action( 'init', 'wdk_subscriptions_sync_cron_manual', 10, 2 );

//add Listings page to Woo My Account 
add_filter ( 'woocommerce_account_menu_items', 'wdk_membership_myaccount_one_more_link' );
function wdk_membership_myaccount_one_more_link( $menu_links ){
    $new = array( 'wdklistings' => esc_html__('Listings', 'wdk-membership') );
    $menu_links = array_slice( $menu_links, 0, 1, true ) 
                + $new 
                + array_slice( $menu_links, 1, NULL, true );

    return $menu_links;
}

add_filter( 'woocommerce_get_endpoint_url', 'wdk_membership_myaccount_hook_endpoint', 10, 4 );
function wdk_membership_myaccount_hook_endpoint( $url, $endpoint, $value, $permalink ){
    if( $endpoint === 'wdklistings' ) {
        if(current_user_can('edit_own_listings') || wmvc_user_in_role('administrator')) {
            // ok, here is the place for your custom URL, it could be external
            $url = wdk_dash_url('dash_page=listings');
        } else {
            $url = wdk_dash_url('');
        }

    }
    return $url;
}

require_once WDK_MEMBERSHIP_PATH . 'extensions/wdk-email-confirmation.php';
new \WdkMembership\Extensions\WdkEmailConfirmation();

if (isset($_GET['wdk_confirm_agency']))
{
    add_action('template_redirect', 'wdk_membership_confirm_agency');
}

function wdk_membership_confirm_agency() {
    $custom_message = '';
    $custom_message_class = '';
    $redirect_link = get_permalink(get_option('wdk_membership_login_page'));

    if(is_user_logged_in()) {
        $redirect_link = wdk_dash_url('');
    }

    // check if exists
    global $Winter_MVC_WDK;
    $Winter_MVC_WDK->load_helper('listing');
    global $Winter_MVC_wdk_membership;
    $Winter_MVC_wdk_membership->model('agency_agent_m');

    $wdk_confirm_code = sanitize_text_field(strip_tags(trim($_GET['wdk_confirm_agency'])));
    $agent_id = get_current_user_id();

    $splited = explode('-', $wdk_confirm_code);

    if(count($splited) != 2)
    {
        $custom_message_class = 'wdk_alert wdk_alert-danger';
        $custom_message =  __('Wrong confirmation code', 'wdk-membership');
        wp_redirect(trim(wdk_url_suffix($redirect_link, 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
        exit;
    }

    $insert_id = $splited[0];
    $agency_agent_list = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('idagency_agent'=>$insert_id, 'agent_id'=>$agent_id, '(SUBSTR(MD5(CONCAT(idagency_agent,agent_id,"'.NONCE_SALT.'")),1,5) = "'.$splited[1].'")'=>NULL), FALSE);
    
    if(count($agency_agent_list) == 0)
    {
        $custom_message_class = 'wdk_alert wdk_alert-danger';
        $custom_message =  __('Confirmation code expired or wrong', 'wdk-membership');
        wp_redirect(trim(wdk_url_suffix($redirect_link, 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
        exit;
    }

    $agency_id = $agency_agent_list[0]->agency_id;
    $agency_email = wdk_get_user_field ($agency_id, 'user_email');
    //https://localhost/wordpress/code-wpdirectorykit/?page_id=5289&wdk_confirm_agency=5-1e8d2
    // Confirm
    if($agency_agent_list[0]->date_confirmed != NULL) {
        $custom_message_class = 'wdk_alert wdk_alert-info';
        $custom_message =  __('Already confirmed', 'wdk-membership');
        wp_redirect(trim(wdk_url_suffix($redirect_link, 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
        exit;
    }

    $Winter_MVC_wdk_membership->agency_agent_m->update(array('date_confirmed' => wp_date('Y-m-d H:i:s'), 'status' => 'CONFIRMED'), $insert_id);

    //echo $Winter_MVC_wdk_membership->db->last_query();

    // Send confirmation email
    $subject = __('Agent confirmed your invitation', 'wdk-membership').' '.wdk_get_user_field ($agent_id, 'display_name');
    $data_message = array();
    $data_message['agent'] = wdk_get_user_field ($agent_id, 'display_name');
    $ret =  wdk_mail( $agency_email, $subject, $data_message, 'default');

    $_GET['success_message'] = esc_html__('Your invitation confirmed', 'wdk-membership');

    $custom_message_class = 'wdk_alert wdk_alert-success';
    $custom_message =  __('Your invitation confirmed', 'wdk-membership');
    wp_redirect(trim(wdk_url_suffix($redirect_link, 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
    exit;
}

function wdk_booking_prepare_export($data, $skip_cols)
{
    $counter=0;
    $print_data = '';

    foreach($data as $key_log=>$row_log)
    {
        // print only keys if first row
        if($counter==0)
        {
            //Define CSV format for Excel
            $print_data.="sep=;\r\n";

            foreach($row_log as $key=>$val)
            {
                if(!is_string($key) || in_array($key, $skip_cols))continue;

                $print_data.='"'.$key.'";';    
            }
            $print_data.="\r\n";
        }

        foreach($row_log as $key=>$val)
        {
            if(!is_string($key) || in_array($key, $skip_cols))continue;

            if(is_string($val))
            {
                $val_prepared = strip_tags(htmlspecialchars($val));
                $val_prepared = '"'.$val_prepared.'"';

                $print_data.=$val_prepared.';';
            }
            else
            {
                $print_data.=';';
            }
        }
        $print_data.="\r\n";

        $counter++;
    }

    $print_data.= "\r\n";

    return $print_data;
}

add_action('wpdirectorykit/listing/saved', 'wdk_membership_agency_udpate_listings_count_agency');
add_action('wpdirectorykit/listing/removed', 'wdk_membership_agency_udpate_listings_count');
add_action('wpdirectorykit/listing/bulk_removed', 'wdk_membership_agency_udpate_listings_count');
add_action('wpdirectorykit/listing/updated', 'wdk_membership_agency_udpate_listings_count');

add_action('wdk-membership/listing/saved', 'wdk_membership_agency_udpate_listings_count_agency');
add_action('wdk-membership/listing/removed', 'wdk_membership_agency_udpate_listings_count');
add_action('wdk-membership/listing/updated', 'wdk_membership_agency_udpate_listings_count');

function wdk_membership_agency_udpate_listings_count_agency($post_id = NULL, $old_listing_date = NULL) {
    global $Winter_MVC_WDK, $Winter_MVC_wdk_membership;
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('user_m');
    $Winter_MVC_wdk_membership->model('agency_agent_m');
    if(!empty($post_id)) {
        $listing_data = $Winter_MVC_WDK->listing_m->get($post_id, TRUE);

        if($listing_data && wmvc_show_data('user_id_editor', $listing_data, false)) {
            $user_id = wmvc_show_data('user_id_editor', $listing_data);
            $agent_agency = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agent_id' => $user_id, 'status' => 'CONFIRMED'), TRUE);
            if($agent_agency) {

                $alt_agents_table = $Winter_MVC_WDK->db->prefix.'wdk_listings_users';
                
                $Winter_MVC_WDK->db->select('ID,user_login,user_nicename,user_email,display_name,user_status,user_url, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor) AS listings_counter');
                
                $Winter_MVC_WDK->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON ('.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor = '.$Winter_MVC_WDK->user_m->_table_name.'.ID AND ('.$Winter_MVC_WDK->listing_m->_table_name.'.is_activated = 1 AND '.$Winter_MVC_WDK->listing_m->_table_name.'.is_approved = 1))', TRUE, 'LEFT');
               // $Winter_MVC_WDK->db->join($alt_agents_table.' ON '.$alt_agents_table.'.user_id = '.$Winter_MVC_WDK->user_m->_table_name.'.ID', TRUE, 'LEFT');
        
                $Winter_MVC_WDK->db->group_by('ID');
                $user = $Winter_MVC_WDK->user_m->get($user_id, TRUE);

                if($user) {
                    $Winter_MVC_wdk_membership->agency_agent_m->update(array('listings_count' => wmvc_show_data('listings_counter', $user, 0)), wmvc_show_data('idagency_agent', $agent_agency, 0));
                }
            }   
        }
    }
}

function wdk_membership_agency_udpate_listings_count() {
    global $Winter_MVC_WDK, $Winter_MVC_wdk_membership;
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->model('user_m');
    $Winter_MVC_wdk_membership->model('agency_agent_m');

    $agent_agency = $Winter_MVC_wdk_membership->agency_agent_m->get_pagination(NULL,0, array(), NULL, FALSE);
    if($agent_agency) {
        foreach ($agent_agency as $key => $agency_agent) {
            $user_id = wmvc_show_data('agent_id', $agency_agent);
            $Winter_MVC_WDK->db->select('ID,user_login,user_nicename,user_email,display_name,user_status,user_url, COUNT('.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor) AS listings_counter');
            $Winter_MVC_WDK->db->join($Winter_MVC_WDK->listing_m->_table_name.' ON ('.$Winter_MVC_WDK->listing_m->_table_name.'.user_id_editor = '.$Winter_MVC_WDK->user_m->_table_name.'.ID AND ('.$Winter_MVC_WDK->listing_m->_table_name.'.is_activated = 1 AND '.$Winter_MVC_WDK->listing_m->_table_name.'.is_approved = 1))', TRUE, 'LEFT');
            $Winter_MVC_WDK->db->group_by('ID');
            $user = $Winter_MVC_WDK->user_m->get($user_id, TRUE);
            if($user) {
                $Winter_MVC_wdk_membership->agency_agent_m->update(array('listings_count' => wmvc_show_data('listings_counter', $user, 0)), wmvc_show_data('idagency_agent', $agency_agent, 0));
            }
        }
    }   
}


function wdk_payments_disable_packages_sync_manual()
{
    if(get_current_user_id() && isset($_GET['wdk_membership_activate_subscription'])) {
       
            global $Winter_MVC_wdk_membership;
            global $Winter_MVC_WDK;
        
            $Winter_MVC_WDK->model('listing_m');
        
            $Winter_MVC_wdk_membership->model('subscription_m');
            $Winter_MVC_wdk_membership->model('subscription_user_m');
            
            $idsubscription = (int) $_GET['id'];
            $subscription_user_id = NULL;
            $user_id = get_current_user_id();
    
            // fetch subscription based on product_id
            $subscription = $Winter_MVC_wdk_membership->subscription_m->get_by(array( 'idsubscription' => $idsubscription, 'is_activated' => 1 ), TRUE);
            
            if(empty($subscription)) exit('Not found');
            
            $subscription_user = $Winter_MVC_wdk_membership->subscription_user_m->get_by(array( 'user_id' => $user_id,'subscription_id' => $subscription->idsubscription), TRUE);
    
            if($subscription_user) {
                $subscription_user_id = $subscription_user->idsubscription_user;

                $custom_message_class = 'wdk_alert wdk_alert-danger';
                $custom_message =  __('Subscription already activated', 'wdk-membership');
                
                if(isset($_GET['redirect_to'])) {
                    wp_redirect(trim(wdk_url_suffix(sanitize_text_field($_GET['redirect_to']), 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
                }
                exit();
            }

            /* unlimit days */
            if(empty($subscription->days_limit)) {
                $subscription->days_limit = 365 * 10;
            }
    
            $update_data = array();
            
            $update_data['subscription_id'] = $subscription->idsubscription;
            $update_data['user_id'] = $user_id;
            $update_data['date_last_paid'] = date('Y-m-d H:i:s');
            $update_data['status'] = 'ACTIVE';
            $update_data['price_paid'] = 0;
    
    
            /* if single subscriptions and not extend remove old */
            if(empty($subscription_user_id) && !wdk_get_option('wdk_membership_multiple_subscriptions_enabled')) {
                $Winter_MVC_WDK->db->query('UPDATE '.$Winter_MVC_wdk_membership->subscription_user_m->_table_name.' SET status = "DEPRECATED" WHERE user_id = "'.esc_sql($user_id).'"');
            }
    
            /* expire date set more if already exists package */
            if($subscription_user_id && strtotime($subscription_user->date_expire) > time())
            {
                //from now
                $update_data['date_expire'] = date('Y-m-d H:i:s', 
                                                        strtotime('+'.$subscription->days_limit.' days', strtotime($subscription_user->date_expire)));
            }
            else
            {
                //from previous date_subscription_expire
                $update_data['date_expire'] = date('Y-m-d H:i:s', 
                                                        strtotime('+'.$subscription->days_limit.' days', current_time('timestamp')));
            }
    
            // update subscription_user
            $insert_id = $Winter_MVC_wdk_membership->subscription_user_m->insert($update_data, $subscription_user_id);
            /* extend listings */
    
            /* message */
            $data_message = array();
            $data_message['user'] = get_userdata( wmvc_show_data('user_id', $update_data) );
            $data_message['subscription'] = $subscription;
            $data_message['subscription_user'] = $update_data;
            
            $ret = wdk_mail(wdk_show_data('user_email', $data_message['user']),
                                    sprintf(__('Membership Subscription %1$s Confirmation','wdk-membership'), wdk_show_data('subscription_name', $subscription)),
                                    $data_message, 'membership_purchased');


            $custom_message_class = 'wdk_alert wdk_alert-success';
            $custom_message =  __('Subscription is activated', 'wdk-membership');
            
            if(isset($_GET['redirect_to'])) {
                wp_redirect(trim(wdk_url_suffix(sanitize_text_field($_GET['redirect_to']), 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
            }
    
        exit('success');
    }
}

add_action( 'init', 'wdk_payments_disable_packages_sync_manual', 10, 2 );
?>