<span class="wdk-favorites-shortcode wdk-favorites-actions">
    <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-add-favorites-action <?php echo (esc_attr($favorite_added))?'wdk-hidden':''; ?>"  data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
        <i class="fa fa-heart-o"></i>
    </a>
    <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-remove-favorites-action <?php echo (!esc_attr($favorite_added))?'wdk-hidden':''; ?>" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
        <i class="fa fa-heart"></i>
    </a>
    <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
</span>

