<?php

namespace WdkMembership\Extensions;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class WdkEmailConfirmation
{
    /**
     * data array
     *
     * @var array
     */
    protected $data = array();

    public function __construct($data = array(), $args = null)
    {

        if(get_option('wdk_membership_enable_varification_mail')){
            add_action('wdk-membership/extension/registration/user_created', array($this, 'add_activation_key'));
            add_action('template_redirect', array($this, 'activation_user'));
            add_filter('wp_authenticate_user', array($this, 'user_email_activation_required'), 10, 3 );



            /* admin actions */
            add_filter('user_row_actions', array($this, 'user_verification_row'), 10, 2);

            add_filter('admin_action_wdk_approve_resendmessage',  array($this, 'admin_action_wdk_approve_resendmessage'));
            add_filter('admin_action_wdk_approve',  array($this, 'admin_action_wdk_approve'));
            add_filter('admin_action_wdk_unapprove',  array($this, 'admin_action_wdk_unapprove'));
        }
    }

    public function add_activation_key($user_id = NULL)
    {
        if (empty($user_id))
            return false;

        $userdata = get_userdata($user_id);

        // create md5 code to verify later
        $code = md5(wdk_show_data('user_email', $userdata, '', TRUE, TRUE) . time());

        update_user_meta($user_id, 'wdk_is_not_activated', 1);
        update_user_meta($user_id, 'wdk_activation_code', $code);
        $string = array('id' => $user_id, 'code' => $code);

        $url_activate = trim(wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')), 'wdk_act_user=' . base64_encode(serialize($string))), '&');

        // Email the admin

        $subject = __('Please confirm your email', 'wdk-membership');

        $data_message = array();
        $data_message['user_client'] = $userdata;

        $data_message['data'] = __('Please click', 'wdk-membership');
        $data_message['data'] .= ' <a href="' . esc_url($url_activate) . '">' . __('here', 'wdk-membership') . '</a> ';
        $data_message['data'] .= __('to confirm your email address and activate account on website', 'wdk-membership');
        $data_message['data'] .= ' <a href="' . esc_url(get_home_url()) . '">' . get_home_url() . '</a> ';

        $ret = wdk_mail(wdk_show_data('user_email', $userdata, '', TRUE, TRUE), $subject, $data_message, 'wdk_membership_confirm_email_user_request');

        if ($ret) {
            add_filter('wdk-membership/extension/registration/filter_output', function ($filter_output) {
                if ($filter_output['success']) {
                    $filter_output['message'] = '<p class="wdk_alert wdk_alert-info">' . esc_html__('New account created, please check your email and click on activation link', 'wdk-membership') . '</p>';
                    return $filter_output;
                }
            });
        } else {
            add_filter('wdk-membership/extension/registration/filter_output', function ($filter_output) {
                if ($filter_output['success']) {
                    $filter_output['message'] = '<p class="wdk_alert wdk_alert-info">' . esc_html__('Message not sent, please contact with admin', 'wdk-membership') . ' ' . get_option('admin_email') . '</p>';
                    return $filter_output;
                }
            });
        }
    }


    /**
     * Check for an activation key and if one exists,
     * validate and log in user.
     */

    public function activation_user ()
    {
        // Check for activation key.
        if (isset($_GET['wdk_act_user'])) {
            
            $custom_message = '';
            $custom_message_class = '';

            $wdk_act_user_code = sanitize_text_field(strip_tags(trim($_GET['wdk_act_user'])));
            $wdk_act_user_code = unserialize(base64_decode($wdk_act_user_code));
            $user_info = get_userdata($wdk_act_user_code['id']);

            if (!$user_info) {
                $custom_message_class = 'wdk_alert wdk_alert-danger';
                $custom_message = __('User is not found', 'wdk-membership');
            } elseif ($wdk_act_user_code['code'] == get_user_meta($wdk_act_user_code['id'], 'wdk_activation_code', true)) {

                update_user_meta($wdk_act_user_code['id'], 'wdk_is_not_activated', 0);

                $custom_message = esc_html__('Your e-mail is confirmed, please log in now.', 'wdk-membership');

                /* message */
                // Send email to client
                $userdata = get_userdata(intval($wdk_act_user_code['id']));

                $subject = sprintf(__('Welcome to the %1$s!', 'wdk-membership'), get_bloginfo("name"));

                $data_message = array();
                $data_message['user_client'] = $userdata;

                $data_message['data'] = __('Your email is activated please use your credential for login', 'wdk-membership');

                $ret = wdk_mail(wdk_show_data('user_email', $userdata, '', TRUE, TRUE), $subject, $data_message, 'wdk_membership_confirm_email_user_request');

                /* true */
            } else {
                $custom_message_class = 'wdk_alert wdk_alert-danger';
                $custom_message =  __('User is not activated, please check your email and click on activation link or contact us', 'wdk-membership');
            }
            
            wp_redirect(trim(wdk_url_suffix(get_permalink(get_option('wdk_membership_login_page')), 'custom_message=' . $custom_message . '&custom_message_class=' . $custom_message_class), '&'));
            exit;
        }
    }


    function user_verification_row($actions, $user_object)
    {

        $wdk_is_not_activated = get_user_meta($user_object->ID, 'wdk_is_not_activated', true);

        $url_redirect = '//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

        if (get_current_user_id() !== $user_object->ID && current_user_can('edit_user', $user_object->ID)) {
            // phpcs:ignore WordPress.CSRF.NonceVerification.NoNonceVerification
            $site_id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
            $url     = 'site-users-network' === get_current_screen()->id ? add_query_arg(array('id' => $site_id), 'site-users.php') : 'users.php';

            if ($wdk_is_not_activated) {
                $url_resend = wp_nonce_url(add_query_arg(array(
                    'action' => 'wdk_approve_resendmessage',
                    'user'   => $user_object->ID,
                    'redirect_to'   => $url_redirect,
                ), $url), 'wdk_approve-message');

                $url = wp_nonce_url(add_query_arg(array(
                    'action' => 'wdk_approve',
                    'user'   => $user_object->ID,
                    'redirect_to'   => $url_redirect,
                ), $url), 'wdk_approve-users');

                $actions['wdk_approve'] = sprintf('<a class="wdk_submitapprove" href="%1$s">%2$s</a>', esc_url($url), esc_html__('Approve', 'wdk-membership'));
                $actions['wdk_send_rejection'] = "<a class='send_verification_email' href='" . esc_url($url_resend) . "'>" . __('Send Verification Email') . "</a>";
            } else {
                $url = wp_nonce_url(add_query_arg(array(
                    'action' => 'wdk_unapprove',
                    'user'   => $user_object->ID,
                    'redirect_to'   => $url_redirect,
                ), $url), 'wdk_unapprove-users');

                $actions['wdk_unapprove'] = sprintf('<a class="submitunapprove" href="%1$s">%2$s</a>', esc_url($url), esc_html__('Unapprove', 'wdk-membership'));
            }
        }

        return $actions;
    }

    function admin_action_wdk_approve()
    {
        $id = (int) $_GET['user'];

        $redirect_to = '//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($_GET['redirect_to']))
            $redirect_to = sanitize_text_field(strip_tags(trim($_GET['redirect_to'])));

        update_user_meta($id, 'wdk_is_not_activated', 0);
        wp_redirect($redirect_to);
    }

    function admin_action_wdk_unapprove()
    {
        $id = (int) $_GET['user'];

        $redirect_to = '//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($_GET['redirect_to']))
            $redirect_to = sanitize_text_field(strip_tags(trim($_GET['redirect_to'])));

        update_user_meta($id, 'wdk_is_not_activated', 1);
        wp_redirect($redirect_to);
    }

    function admin_action_wdk_approve_resendmessage()
    {
        $user_id = (int) $_GET['user'];

        $redirect_to = '//' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        if (isset($_GET['redirect_to']))
            $redirect_to = sanitize_text_field(strip_tags(trim($_GET['redirect_to'])));;


        $this->add_activation_key($user_id);

        wp_redirect($redirect_to);
    }

    function user_email_activation_required($user, $password)
    {
        $wdk_is_not_activated = get_user_meta( $user->ID, 'wdk_is_not_activated', true ); 
        if($wdk_is_not_activated) {
            $message = esc_html__('Mail is not activated, please check your mail', 'wdk_win');
            $errors = new \WP_Error();
            $errors->add('title_error', $message);
            return $errors;
        }
        return $user;
    }
    
}
