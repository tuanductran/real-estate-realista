<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Membership
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Membership
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-membership.html
 * Description:       Login, Registration, Frontend Dashboard, Search for Agent, and every Agent have own page with their Listings and Details.
 * Version:           1.0.4
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-membership
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_MEMBERSHIP_VERSION', '1.0.4' );
define( 'WDK_MEMBERSHIP_NAME', 'wdk-membership' );
define( 'WDK_MEMBERSHIP_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_MEMBERSHIP_URL', plugin_dir_url( __FILE__ ) );

// [WGumroad]
require_once plugin_dir_path( __FILE__  ) . 'vendor/WGumroad/init.php';

global $WGumroad;

$WGumroad->activate_plugin(array(
    'plugin_name' => 'WDK Membership',
    'plugin_slug' => 'wdk-membership',
    'plugin_path' => plugin_dir_path( __FILE__ ),
    'plugin_version' => WDK_MEMBERSHIP_VERSION,
    'gumroad_product_permalink' => 'wp-directory-membership',
    'gumroad_subscription_permalink' => 'wp-directory-kit-addons',
    'product_website_link' => 'https://swit.gumroad.com/l/wp-directory-membership',
    'grace_period_days' => 30,
    'support_email' => 'support@wpdirectorykit.com',
    'license_uses_limit' => 2
));

if(!$WGumroad->is_plugin_active('wdk-membership'))
    return;
// [/WGumroad]

require plugin_dir_path( __FILE__ ) . 'functions.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-membership-activator.php
 */
function activate_wdk_membership() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-membership-activator.php';
	Wdk_Membership_Activator::activate();
}
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-membership-deactivator.php
 */
function deactivate_wdk_membership() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-membership-deactivator.php';
	Wdk_Membership_Deactivator::deactivate();
}
register_activation_hook( __FILE__, 'activate_wdk_membership' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_membership' );
/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-membership.php';
if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    run_wdk_membership();
}