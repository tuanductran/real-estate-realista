<?php

namespace WdkMembership\Elementor\Extensions;
        

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipListinAgencyListings extends \Wdk\Elementor\Widgets\WdkListingAgentsListings {
    public $field_types = array();

    public function __construct($data = array(), $args = null) {
        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-listing-agency-listings';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Listing Agency Listings', 'wdk-membership');
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        $this->enqueue_styles_scripts();
        $this->add_page_settings_css();

        $this->WMVC = &wdk_get_instance();
        $this->WMVC->model('listingfield_m');
        $this->WMVC->model('listing_m');
        $this->WMVC->load_helper('listing');

        global $Winter_MVC_wdk_membership, $wdk_listing_id;

        $Winter_MVC_wdk_membership->model('agency_agent_m');

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['listings_count'] = 0;
        $this->data['results'] = array();
        $this->data['pagination_output'] = '';

        $columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by','is_featured', 'address');
        $external_columns = array('location_id', 'category_id', 'post_title');
        $custom_parameters = array();

        $this->data['custom_order'] =  array();
        if ($this->data['settings']['custom_order_list']) {
            foreach ($this->data['settings']['custom_order_list'] as $item) {
                if (empty($item['title']) || empty($item['key'])) {
                    continue;
                }
                $this->data['custom_order'][] = array('title'=>$item['title'],'key'=>$item['key']);
            }
        }
        
        $controller = 'listing';
        $offset = NULL;
        
        if (isset($wdk_listing_id)) {
            foreach($this->data['settings']['similar_by_fields'] as $similar_field) {

                if(empty($similar_field['field'])) continue;

                if ($similar_field['field_skip_if_empty'] == 'true' && empty(wdk_field_value(str_replace('field','',$similar_field['field']), $wdk_listing_id))) {
                    continue;
                }

                if($similar_field['field'] == 'is_featured') {
                    if (!empty(wdk_field_value(str_replace('field','',$similar_field['field']), $wdk_listing_id))) {
                        $custom_parameters[$similar_field['field']] = 'on';
                    } else {
                        $custom_parameters[$similar_field['field']] = 'off';
                    }
                } else {    
                    $custom_parameters[$similar_field['field']] = wdk_field_value(str_replace('field','',$similar_field['field']), $wdk_listing_id);
                }
            }
        }

        if(wmvc_show_data('featured_query', $this->data['settings']) == 'only_featured') {
            $custom_parameters['is_featured'] = 'on';
        }

        if(wmvc_show_data('featured_query', $this->data['settings']) == 'only_unfeatured') {
            $custom_parameters['is_featured'] = 'off';
        }

        $_GET['order_by'] = $this->data['settings']['conf_order_by'].' '.$this->data['settings']['conf_order'];

        /* if detected custom field for order */
        if(!empty($this->data['settings']['conf_order_by_custom'])) {
            $_GET['order_by'] = $this->data['settings']['conf_order_by_custom'].' '.$this->data['settings']['conf_order'];
        }
            
        $user_id = NULL;

        if(!Plugin::$instance->editor->is_edit_mode()){
            if(wdk_field_value ('user_id_editor', $wdk_listing_id)) {
                $agent_id = wdk_field_value ('user_id_editor', $wdk_listing_id);
                $agent_agency = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agent_id' => $agent_id, 'status' => 'CONFIRMED'), TRUE);
                if($agent_agency) {
                    $user_id = wmvc_show_data('agency_id', $agent_agency, 0);
                }   
            }
        } 


        
        if(Plugin::$instance->editor->is_edit_mode()) {
            $this->WMVC->db->limit(3);
        }

        /* filter same listing */
        wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, TRUE);
        if (isset($wdk_listing_id)) {
            global $wpdb;
            $this->WMVC->db->where($wpdb->prefix.'wdk_listings.post_id != '.$wdk_listing_id) ;
        }
        $this->data['results'] = $this->WMVC->listing_m->get_pagination($this->data['settings']['per_page'], $offset, array('is_activated' => 1,'is_approved'=>1), TRUE, $user_id, TRUE);

        if(!empty($this->data['results']) && $this->data['listings_count'] == 0)
            $this->data['listings_count'] = wmvc_count($this->data['results']);

        $this->data['settings']['content_button_icon'] = $this->generate_icon($this->data['settings']['content_button_icon']);

        $this->data['is_edit_mode'] = false;          
        if(Plugin::$instance->editor->is_edit_mode())
            $this->data['is_edit_mode'] = true;

        if(isset($_GET['wmvc_view_type']) && $this->data['settings']['get_filters_enable'] == 'yes') {
            if(wmvc_xss_clean($_GET['wmvc_view_type']) == 'grid')
                $this->data['settings']['layout_type'] = 'grid';
            if(wmvc_xss_clean($_GET['wmvc_view_type']) == 'list')
                $this->data['settings']['layout_type'] = 'list';
        }

        echo $this->view('wdk-listing-agents-listings', $this->data); 
    }

}

/* remove */
add_action(
    'elementor/element/before_section_end',
    function($section, $section_id, $args) {
        if( $section->get_name() == 'wdk-membership-listing-agency-listings'/* && $section_id == 'section_style'*/ ) 
        {
            $section->remove_control('user_editor_disabled');
            $section->remove_control('alternative_agents_disabled');
            $section->remove_control('row_gap_col');
            $section->remove_control('column_gap');
            $section->remove_control('row_gap');
        }
    }, 10, 3
);
