<?php
namespace WdkMembership\Elementor\Extensions;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class AjaxHandler {
    /**
     * data array
     *
     * @var array
     */
    protected $data = array();
    protected $WMVC = NULL;

    public function __construct($data = array(), $args = null) {
        add_action( 'eli/ajax-handler/before', array( $this, 'before' ) );
        remove_all_actions( 'eli/ajax-handler/after');
        add_action( 'eli/ajax-handler/after', array( $this, 'after' ) );
        add_filter( 'eli/ajax-handler/filter_from_data', array( $this, 'filter_from_data' ) );
    }

    public function filter_from_data ($form_data = array()) {
        if(isset($_POST['profile_id'])) {
            $userdata = get_userdata((int)$_POST['profile_id']);
            $form_data['settings']['mail_data_to_email'] = wmvc_show_data('user_email', $userdata);
            $form_data['settings']['disable_mail_send'] = 1;
        }

        return $form_data;
    }

    public function after ($form_data = array()) {
        $this->WMVC = &wdk_get_instance();
        $this->WMVC->model('messages_m');
        
        $email = '';
        $message = '';
        $post_id = '';
        foreach ($_POST as $key => $value) {
            if(stripos($key,'mail') !== FALSE || filter_var($value, FILTER_VALIDATE_EMAIL))
                $email = sanitize_email($value);
            if(stripos($key,'message') !== FALSE)
                $message = sanitize_text_field($value);
            if(stripos($key,'listing_id') !== FALSE)
                $post_id = sanitize_text_field($value);
        }

        /* message data */

        if(isset($_POST['profile_id'])){
            $data_insert = array(
                'post_id' => ($post_id),
                'email_sender' =>  ($email),
                'user_id_receiver' =>  ( $_POST['profile_id']),
                'message' =>  ($message),
                'json_object' => json_encode($_POST)
            );

            $insert_idmessage = $this->WMVC->messages_m->insert($data_insert, NULL);

            $message_data = array();
            foreach($_POST as $key => $value){
                if($key=='element_id') continue;
                if(in_array($key, array('eli_page_id','eli_id', 'eli_type','ID','filter','action','send_action_type','profile_id'))) continue;

                if(filter_var($value, FILTER_VALIDATE_URL ) || strpos( $value, 'http' ) !== FALSE) {
                    $message_data[$key] = '<a href="'.esc_url($value).'">'.wp_kses_post($value).'</a>';
                } else {
                    $message_data[$key] = wp_kses_post($value);
                }
            }

            $user_data_profile = get_userdata($_POST['profile_id']);
       
            if(empty($user_data_profile)) {
                $user_data_profile = array(
                    'display_name' => __('Administrator', 'wdk-bookings'),
                    'user_email' => get_bloginfo('admin_email'),
                );
            }

            if(!empty($email)) {

                /* message */
                $data_message = array();
                $data_message['message'] = $message_data;
                $data_message['data'] = __('We received message from you, we will answer as soon as possible', 'wdk-membership');
                $data_message['user_profile'] = $user_data_profile;

                $ret = wdk_mail($email, __('Your message sent on', 'wdk-membership').' '.html_entity_decode(get_bloginfo('name')), $data_message, 'membership_contact_visitor', '', array(), wdk_show_data('user_email', $user_data_profile, '' , TRUE, TRUE));
            }
            
            /* message */
            $data_message = array();
            $data_message['message'] = $message_data;
            $data_message['user_profile'] = $user_data_profile;


            if($user_data_profile)
                $data_message['data'] = __('New Message', 'wdk-membership');

            if(wdk_get_option('wdk_membership_dash_page')) {
                $data_message['data'] .= ' <a href="'.wdk_dash_url('dash_page=messages&function=view&id=' . $insert_idmessage).'">'.__('Open', 'wdk-membership').'</a>';
            } else if(wmvc_is_user_in_role( $user_data_profile,  'administator' )) {
                $data_message['data'] .= ' <a href="'.admin_url('admin.php?page=wdk_messages&function=edit&id='.$insert_idmessage).'">'.__('Open', 'wdk-membership').'</a>';
            }

            $ret = wdk_mail(wdk_show_data('user_email', $user_data_profile, '' , TRUE, TRUE), __('New Message from', 'wdk-membership').' '.html_entity_decode(get_bloginfo('name')), $data_message, 'membership_contact_owner', '', array(), $email);

            if( $ret) {
                add_filter( 'eli/ajax-handler/filter_output', function($filter_output) {
                    $filter_output['message'] = '<div class="elementinvader_addons_for_elementor_alert elementinvader_addons_for_elementor_alert-success" role="alert">'.esc_html__('Message sent', 'wdk-membership').'</div>';
                    $filter_output['success'] = true;
                    return $filter_output;
                } );
            }
            else
            {
                add_filter( 'eli/ajax-handler/filter_output', function($filter_output) {
                    $filter_output['message'] = '<div class="elementinvader_addons_for_elementor_alert elementinvader_addons_for_elementor_alert-danger" role="alert">'.esc_html__('Server can\'t send emails, please use SMTP mail configuration.', 'wdk-membership').'</div>';
                    $filter_output['no_clear_from'] = true;
                    return $filter_output;
                } );
            }
        }
    }

    public function before ($form_data = array()) {
    }
	
}
