<?php

namespace WdkMembership\Elementor\Extensions;
        

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipAgencyProfilesGrid extends \WdkMembership\Elementor\Widgets\WdkMembershipProfilesGrid {
    public $field_types = array();

    public function __construct($data = array(), $args = null) {
        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-agency-profiles-grid';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Agency Profiles Grid', 'wdk-membership');
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        $this->enqueue_styles_scripts();
        $this->add_page_settings_css();

        $this->WMVC = &wdk_get_instance();
        $this->WMVC->model('listingfield_m');
        $this->WMVC->model('listing_m');
        $this->WMVC->load_helper('listing');
        $this->WMVC_Membership->model('agency_agent_m');

        $wdkmembership_user_id = wdk_get_profile_page_id();

        $userinfo = wdk_get_user_data($wdkmembership_user_id);

        if(!Plugin::$instance->editor->is_edit_mode())
            if(!$userinfo || !wmvc_is_user_in_role( $userinfo['userdata'], 'wdk_agency')) {
                return false;
            }   

        global $Winter_MVC_WDK;

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['pagination_output'] = '';

        global $wp_roles;
        if ( ! isset( $wp_roles ) ) {
            $wp_roles = new \WP_Roles();
        }
 
        $this->data['wdk_wp_roles'] = $wp_roles->role_names;

        $Winter_MVC_WDK->model('user_m');
        $controller = 'user';
        $columns = array('user_login','user_nicename','user_email','user_url','display_name');
        $external_columns = array('user_login','user_nicename','user_email','user_url','display_name');
        $offset = NULL;
        
        global $wpdb;
   

        if($this->data['settings']['conf_pagination_enable'] == 'yes') {
            
            if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
            } else {
                wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
            }

            if(wmvc_show_data('hide_profiles_with_no_listings', $this->data['settings']) == 'yes') {
                $total_items = $this->WMVC_Membership->agency_agent_m->total_agents($wdkmembership_user_id, array(), TRUE);
            } else {
                $total_items = $this->WMVC_Membership->agency_agent_m->total_agents($wdkmembership_user_id, array());
            }

            $current_page = 1;
            if(isset($_GET['wmvc_paged_profiles']))
                $current_page = intval(wmvc_xss_clean($_GET['wmvc_paged_profiles']));

            if(empty($this->data['settings']['per_page']))
                $this->data['settings']['per_page'] = 2;

            $offset = $this->data['settings']['per_page']*($current_page-1);

            if(function_exists('wdk_wp_frontend_paginate') && $total_items > $this->data['settings']['per_page'])
                $this->data['pagination_output'] = wdk_wp_frontend_paginate($total_items, $this->data['settings']['per_page'], 'wmvc_paged_profiles');
        }
        
        if(wmvc_show_data('hide_profiles_with_no_listings', $settings) == 'yes') {
            wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns, array('is_activated' => 1,'is_approved'=>1));
        } else {
            wdk_users_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        }

        if(wmvc_show_data('hide_profiles_with_no_listings', $this->data['settings']) == 'yes') {
            $this->data['profiles_list'] = $this->WMVC_Membership->agency_agent_m->get_pagination_agents($wdkmembership_user_id, $this->data['settings']['per_page'], $offset, array(), NULL, FALSE, TRUE);
        } else {
            $this->data['profiles_list'] = $this->WMVC_Membership->agency_agent_m->get_pagination_agents($wdkmembership_user_id, $this->data['settings']['per_page'], $offset, array(), NULL);
        }
        
        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-membership-profiles-grid', $this->data); 
    }

    protected function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-membership'),
                'tab' => '1',
            ]
        );

        $this->add_control(
			'hide_profiles_with_no_listings',
			[
				'label' => __( 'Hide Profiles Without Listings', 'wdk-membership' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'wdk-membership' ),
				'label_off' => __( 'Show', 'wdk-membership' ),
				'return_value' => 'yes',
				'default' => '',
                'separator' => 'before',
			]
		);

        $this->add_control(
            'conf_pagination_enable',
            [
                'label' => __( 'Pagination', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'wdk-membership' ),
                'label_off' => __( 'Hide', 'wdk-membership' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'per_page',
            [
                'label' => __( 'Limit Results (Per page)', 'wdk-membership' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 50,
                'step' => 1,
                'default' => 6,
            ]
        );

        $this->end_controls_section();
    }
}

/* remove */
add_action(
    'elementor/element/before_section_end',
    function($section, $section_id, $args) {
        if( $section->get_name() == 'wdk-membership-class-contact-form'/* && $section_id == 'section_style'*/ ) 
        {
            $section->remove_control('mail_data_to_email');
        }
    }, 10, 3
);
