<?php

namespace WdkMembership\Elementor\Extensions;
        

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkMembershipListinAgency extends \Wdk\Elementor\Widgets\WdkListinAgent {
    public $field_types = array();

    public function __construct($data = array(), $args = null) {
        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-membership-listing-agency';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Listing Agency', 'wdk-membership');
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        $this->enqueue_styles_scripts();
        $this->add_page_settings_css();

        $this->WMVC = &wdk_get_instance();
        $this->WMVC->model('listingfield_m');
        $this->WMVC->model('listing_m');
        $this->WMVC->load_helper('listing');

        global $Winter_MVC_wdk_membership, $wdk_listing_id;

        $Winter_MVC_wdk_membership->model('agency_agent_m');
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        $this->data['userdata'] = false;
        $this->data['user_id'] = false;
        $this->data['settings']['listing_agency_disabled'] = 'no';
        $this->data['settings']['user_editor_disabled'] = 'yes';
        $this->data['settings']['alternative_agents_disabled'] = 'yes';

        $this->WMVC->model('listing_m');
        $user = NULL;
        if(wdk_field_value ('user_id_editor', $wdk_listing_id)) {
            
            $agent_id = wdk_field_value ('user_id_editor', $wdk_listing_id);
            $agent_agency = $Winter_MVC_wdk_membership->agency_agent_m->get_by(array('agent_id' => $agent_id, 'status' => 'CONFIRMED'), TRUE);
            if($agent_agency) {
                $user = wdk_get_user_data( wmvc_show_data('agency_id', $agent_agency, 0));

                if($user){
                    $this->data['userdata'] = $user['userdata'];
                }
            }   
        }

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()) {
            $this->data['is_edit_mode']= true;
            echo $this->view('wdk-listing-agent-demo', $this->data); 
        } else {
            echo $this->view('wdk-listing-agent', $this->data); 
        }
    }

}

/* remove */
add_action(
    'elementor/element/before_section_end',
    function($section, $section_id, $args) {
        if( $section->get_name() == 'wdk-membership-listing-agency'/* && $section_id == 'section_style'*/ ) 
        {
            $section->remove_control('user_editor_disabled');
            $section->remove_control('listing_agency_disabled');
            $section->remove_control('alternative_agents_disabled');
            $section->remove_control('row_gap_col');
            $section->remove_control('column_gap');
            $section->remove_control('row_gap');
        }
    }, 10, 3
);
