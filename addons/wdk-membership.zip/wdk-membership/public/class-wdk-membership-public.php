<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Membership
 * @subpackage Wdk_Membership/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wdk_Membership
 * @subpackage Wdk_Membership/public
 * @author     wpdirectorykit.com <info@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Wdk_Membership_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Membership_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Membership_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_style( 'wdk-membership-user-details', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-user-details.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-register-form', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-register-form.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-login-form', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-login-form.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-booking-field-calendar', plugin_dir_url( __FILE__ ) . 'css/wdk-booking-field-calendar.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-profiles-search', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-profiles-search.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-profile-content', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-profile-content.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-profiles-grid', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-profiles-grid.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-profiles-list', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-profiles-list.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-dash-content', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-dash-content.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-dash-menu', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-dash-menu.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-dash-breadcrumb', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-dash-breadcrumb.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-subscriptions', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-subscriptions.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-membership-listing-altagents', WDK_MEMBERSHIP_URL. 'elementor-elements/assets/css/widgets/wdk-membership-listing-altagents.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wdk-membership-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_Membership_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_Membership_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_register_script( 'wdk-booking-field-calendar', plugin_dir_url( __FILE__ ) . 'js/wdk-booking-field-calendar.js', array( 'jquery' ), $this->version, false );
		wp_register_script( 'wdk-booking-field-calendar-price', plugin_dir_url( __FILE__ ) . 'js/wdk-booking-field-calendar-price.js', array( 'jquery' ), $this->version, false );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wdk-membership-public.js', array( 'jquery' ), $this->version, false );

	}

	public function ajax_public()
	{
		global $Winter_MVC_wdk_membership;

		$page = '';
		$function = '';

		if(isset($_POST['page']))$page = wmvc_xss_clean($_POST['page']);
		if(isset($_POST['function']))$function = wmvc_xss_clean($_POST['function']);

		/* protect access only to ajax controller */
		if($page == 'wdk_membership_frontendajax') {
			$page = 'wdk-membership-frontendajax';
		} 

		if($page != 'wdk-membership-frontendajax') {
			exit(esc_html__('Access denied','wdk-membership'));
		} 

		$Winter_MVC_wdk_membership = new MVC_Loader(plugin_dir_path( __FILE__ ).'../');
		$Winter_MVC_wdk_membership->load_helper('basic');
		$Winter_MVC_wdk_membership->load_controller($page, $function, array());
	}

}
