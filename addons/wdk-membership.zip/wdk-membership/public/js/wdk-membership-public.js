(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 jQuery(document).ready(function($) {
		 $('.event-ajax-indicator').on('click submit', function () {
			if ($(this).find('.wdk-ajax-indicator').length) {
				$(this).find('.wdk-ajax-indicator').removeClass('hidden')
												   .removeClass('wdk-hidden');
				$(this).find('.hidden-onloading').addClass('wdk-hidden');
			}
			else {
				$(this).parent().find('.wdk-ajax-indicator').removeClass('hidden');
			}
		 });

         $('button.agency_agent_email-remove').on('click submit', function () {

            if (!confirm($(this).find('span.question').html())) {
                return false;
            }

            var data = {
                "action": 'wdk_membership_public_action',
                "page": 'wdk-membership-frontendajax',
                "function": 'agency_agent_remove',
                "_wpnonce": $(this).attr('data-wpnonce'),
                "agent_email": $(this).parent().parent().find('div.agent_name').html()
              };

            var button_invite = $(this);

            $(this).find('.wdk-ajax-indicator').removeClass('hidden')
                .removeClass('wdk-hidden');
            $(this).find('.hidden-onloading').addClass('wdk-hidden');

            jQuery.ajax({
                url : script_parameters.ajax_url,
                type : "POST",
                data: data,
                success: function (data) {
                    button_invite.find('.wdk-ajax-indicator').addClass('hidden').addClass('wdk-hidden');
                    button_invite.find('.hidden-onloading').removeClass('wdk-hidden');

                    if(data.success)
                    {
                        button_invite.parent().parent().remove();
                    }

                    alert(data.message);
                },
                error: function (err) {
                    console.log(err);
                }
            });
		 });

         $('button.agent_agency_email-remove').on('click submit', function () {

            if (!confirm($(this).find('span.question').html())) {
                return false;
            }

            var data = {
                "action": 'wdk_membership_public_action',
                "page": 'wdk-membership-frontendajax',
                "function": 'agent_agency_remove',
                "_wpnonce": $(this).attr('data-wpnonce'),
                "agency_email": $(this).parent().parent().find('div.agency_name').html()
              };

            var button_invite = $(this);

            $(this).find('.wdk-ajax-indicator').removeClass('hidden')
                .removeClass('wdk-hidden');
            $(this).find('.hidden-onloading').addClass('wdk-hidden');

            jQuery.ajax({
                url : script_parameters.ajax_url,
                type : "POST",
                data: data,
                success: function (data) {
                    button_invite.find('.wdk-ajax-indicator').addClass('hidden').addClass('wdk-hidden');
                    button_invite.find('.hidden-onloading').removeClass('wdk-hidden');

                    if(data.success)
                    {
                        button_invite.parent().parent().remove();
                    }

                    alert(data.message);
                },
                error: function (err) {
                    console.log(err);
                }
            });
		 });

         $('button.agent_agency_email-approve').on('click submit', function () {

            var data = {
                "action": 'wdk_membership_public_action',
                "page": 'wdk-membership-frontendajax',
                "function": 'agent_agency_approve',
                "_wpnonce": $(this).attr('data-wpnonce'),
                "agency_email": $(this).parent().parent().find('div.agency_name').html()
              };

            var button_invite = $(this);

            $(this).find('.wdk-ajax-indicator').removeClass('hidden')
                .removeClass('wdk-hidden');
            $(this).find('.hidden-onloading').addClass('wdk-hidden');

            jQuery.ajax({
                url : script_parameters.ajax_url,
                type : "POST",
                data: data,
                success: function (data) {
                    button_invite.find('.wdk-ajax-indicator').addClass('hidden').addClass('wdk-hidden');
                    button_invite.find('.hidden-onloading').removeClass('wdk-hidden');

                    alert(data.message);

                    location.reload();
                },
                error: function (err) {
                    console.log(err);
                }
            });
		 });

		 $('button#user_agency_agent_email-submit').on('click submit', function () {

            var data = {
                "action": 'wdk_membership_public_action',
                "page": 'wdk-membership-frontendajax',
                "function": 'agency_agent_submit',
                "_wpnonce": $(this).attr('data-wpnonce'),
                "agent_email": $('input#user_agency_agent_email').val()
              };

            var button_invite = $(this);

            $(this).find('.wdk-ajax-indicator').removeClass('hidden')
                .removeClass('wdk-hidden');
            $(this).find('.hidden-onloading').addClass('wdk-hidden');

            jQuery.ajax({
                url : script_parameters.ajax_url,
                type : "POST",
                data: data,
                success: function (data) {
                    button_invite.find('.wdk-ajax-indicator').addClass('hidden').addClass('wdk-hidden');
                    button_invite.find('.hidden-onloading').removeClass('wdk-hidden');
                    alert(data.message);
                },
                error: function (err) {
                    console.log(err);
                }
            });
        })
		 
        const wdk_start_search = (form) => {
            var url,scrollTo, data = {};
            url = form.attr('action').replace(/#results/, '');
            if (url.indexOf('?') == -1) {
                url += '?';
            } else {
                url += '&';
            }
            var str_parameters = "";
            $.each(form.serializeArray(), function (i, k) {
                if (k.value != '') {
                    if (str_parameters != "") {
                        str_parameters += "&";
                    }
                    str_parameters += k.name + "=" + encodeURIComponent(k.value); 
                }
            });
            if ($('.wdk-agent-search[data-scrollto]').length)
                scrollTo = '#'+$('.wdk-agent-search[data-scrollto]').attr('data-scrollto');
                
            return url+str_parameters+scrollTo;
        }

        /* set current page for search results if exists results widget and enabled in setttings*/
        if($('form.wdk-agent-search').length && $('.wdk-listings-results').length && $("form.wdk-agent-search").attr('data-current-link') != '') {
            $('form.wdk-agent-search').attr('action', $("form.wdk-agent-search").attr('data-current-link'));
        }

        $("form.wdk-agent-search").on('submit', function (e) {
            e.preventDefault();
            var url = wdk_start_search($(this));
            if (window.location.href == url) {
                window.location.reload();
            } else {
                window.location.href = url;
            }
            return false;
        });

        $("form.wdk-agent-search .wdk-search-start").on('click', function (e) {
            e.preventDefault();
            var url = wdk_start_search($(this).closest('form'));
            if (window.location.href == url) {
                window.location.reload(url);
            } else {
                window.location.href = url;
            }
            return false;
        })

        $("form.wdk-agent-search .wdk-search-start").on('click', function (e) {
            e.preventDefault();
            var url = wdk_start_search($(this).closest('form'));
            if (window.location.href == url) {
                window.location.reload(url);
            } else {
                window.location.href = url;
            }
            return false;
        })

        wdk_membership_register_form();
        wdk_membership_login_form();

        jQuery( document ).on( 'elementor/popup/show', () => {
            wdk_membership_register_form();
            wdk_membership_login_form();
        } );

        $('.profiles-item-list .wdk-thumbnail .thumbnail_link').on('keydown', function(e){
            var keyCode = e.keyCode || e.which; 
            if (!e.shiftKey && keyCode == 9) {
                $(this).closest('.wdk-thumbnail').addClass('wdk-profile-card-active');
            }
            if (e.shiftKey && keyCode == 9) {
                $(this).closest('.wdk-thumbnail').removeClass('wdk-profile-card-active');
            }
        })

        $('.profiles-item-list .wdk-thumbnail .wdk-hover a.wdk-profile-btn').on('keydown', function(e){
            var keyCode = e.keyCode || e.which; 
            if (!e.shiftKey && keyCode == 9) {
                $(this).closest('.wdk-thumbnail').removeClass('wdk-profile-card-active');
            }
        })

        $('.profiles-item-list .wdk-thumbnail .wdk-hover a.wdk-profile-btn').focusin(function() {
            $(this).closest('.wdk-thumbnail').addClass('wdk-profile-card-active');
        });
    })
})( jQuery );

const wdk_membership_login_form = () => {
        /* login send */
        var $ = jQuery;
        $('.wdk-login-form .wdk-login').off().on('submit', function(e){
            e.preventDefault();
            var this_form = $(this);
            var $config = this_form.find('.config');
            var conf_link = $config.attr('data-url') || 0;
            var load_indicator = this_form.find('.fa-ajax-indicator');
            var box_alert = this_form.find('.alert_box').html('');
            load_indicator.css('display', 'inline-block');
            
            var data = this_form.serializeArray();
            data.push({ name: 'action', value: "wdk_membership_public_action" });
            data.push({ name: 'page', value: "wdk_membership_frontendajax" });
            data.push({ name: 'function', value: "login" });

            if(!this_form[0].checkValidity())
                load_indicator.css('display', 'none');

            $.post(conf_link, data, 
                function(data){
                if(data.message)
                    box_alert.html(data.message)
                    
                if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                    
                if(data.success)
                {
                    if(data.redirect) {
                        location.href = data.redirect;
                    } else {
                        location.reload();
                    }
                    this_form.find('input:not([type="checkbox"]):not([name="element_id"]):not([type="radio"]):not([type="hidden"]),textarea').val('');
                } else {
                    if(typeof grecaptcha != 'undefined') {
                        if(jQuery("div.g-recaptcha").length > 0) {
                            grecaptcha.reset();
                        } else {
                            //There's no container, there should be no captcha
                        }
                    }
                }
            }).always(function(data) {
                load_indicator.css('display', 'none');
            });

            return false;
        });
        /* end login send */
};


const wdk_membership_register_form = () => {
    var $ = jQuery;
        /* register send */
        $('.wdk-register-form .wdk-register').off().on('submit', function(e){
            e.preventDefault();
            var this_form = $(this);
            var $config = this_form.find('.config');
            var conf_link = $config.attr('data-url') || 0;
            var load_indicator = this_form.find('.fa-ajax-indicator');
            var box_alert = this_form.find('.alert_box').html('');
            load_indicator.css('display', 'inline-block');

            var data = this_form.serializeArray();
            data.push({ name: 'action', value: "wdk_membership_public_action" });
            data.push({ name: 'page', value: "wdk_membership_frontendajax" });
            data.push({ name: 'function', value: "register" });
            
            if(!this_form[0].checkValidity())
                load_indicator.css('display', 'none');

            $.post(conf_link, data, 
                function(data){
                if(data.message)
                    box_alert.html(data.message)
                    
                if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                    
                if(data.success)
                {
                    if(data.redirect) {
                        location.href = data.redirect;
                    } else {
                    }
                    this_form.find('input:not([type="checkbox"]):not([name="element_id"]):not([type="radio"]):not([type="hidden"]),textarea').val('');
                } else {
                    if(typeof grecaptcha != 'undefined') {
                        if(jQuery("div.g-recaptcha").length > 0) {
                            grecaptcha.reset();
                        } else {
                            //There's no container, there should be no captcha
                        }
                    }
                }
            }).always(function(data) {
                load_indicator.css('display', 'none');
            });

            return false;
        });
        /* end register send */
};