(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 const wdk_booking_calendar = () => {
		var class_active = 'active';
		var class_resevation_end = 'reservation-end';
		var class_resevation_start = 'reservation-start';
		var list_days = $('.wdk-field-calendar table tbody td[data-order]');

		$('.wdk-field-calendar table td a,.wdk-field-calendar').off();
		$('.wdk-field-calendar table td.bg-available a').on('click', function (e) {
			e.preventDefault();
			$('.wdk-field-calendar table td a').removeClass([class_active, class_resevation_end, class_resevation_start]);

			var self, order_from, order_to, date_from;
			self = $(this);
			self.addClass([class_active,class_resevation_start]);
			
			order_from = self.parent().attr('data-order');
			date_from = self.attr('title');
			
			$('.wdk-field-calendar:hover').on('mouseover', function (e) {
			
				var related = e.target ? e.target : "unknown";
				if ($(related).is("a"))
					related = $(related).parent();
				
				if ($(related).hasClass('bg-available')) {
					order_to = parseInt($(related).attr('data-order'));
					if (order_to > order_from) {
						$('.wdk-field-calendar table td a').removeClass(class_active);
						while (order_to >= order_from) {
							$(list_days[order_to]).find('a').addClass(class_active);
							order_to--;
						}
					}
				}

				/* finish */
				$('.wdk-field-calendar table td.bg-available a').off().on('click', function (e) {
					e.preventDefault();
					$('.wdk-field-calendar:hover').off();
					$(this).addClass(class_resevation_end);
					order_to = $(this).parent().attr('data-order');
					var error = false;
					while (order_to >= order_from) {
						if ($(list_days[order_to]).hasClass('bg-booked') && !$(list_days[order_to]).hasClass('bg-available')) {
							error = true;
							break;
						}
						order_to--;
					}

					if (error) {
						$('.wdk-field-calendar table td a').removeClass(class_active);
						wdk_log_notify($('.wdk-field-calendar .js_message_error_date').text(), 'error');
					} else {
						$('#date_from').val(date_from);

						$('#date_from_mask').datepicker("setDate", new Date(date_from) );
						$('#date_to_mask').datepicker("setDate", new Date($(this).attr('title')));

						$('#date_to').val($(this).attr('title'));
						
						$([document.documentElement, document.body]).animate({
							scrollTop: (jQuery("#date_from_mask").length) ? $("#date_from_mask").offset().top - 100 : $("#date_from").offset().top - 100
						}, 500, function () {
							if ($('.elementinvader_addons_for_elementor_f input[name="Name"]').length) {
								//$('.elementinvader_addons_for_elementor_f input[name="Name"]').focus();
							} else {
								//$('#date_from').focus();
							}
						});
					}

					wdk_booking_calendar();
				});
			});
		});

		
		$('.wdk-field-calendar .wdk-btn-pag').off().on('click', function (e) {
			e.preventDefault();
			var btn = $(this);
			var parent = btn.closest('.wdk-field-calendar');

			if (btn.hasClass('next')) {
				parent.find('.wdk-field-calendar-addinition[style*="none"]').first().slideDown('slow', function(){
					btn.parent().find('.pre').removeClass('noactive')
					if(!parent.find('.wdk-field-calendar-addinition[style*="none"]').length) {
						btn.parent().find('.next').addClass('noactive')
					} 
				});
			} else {
				parent.find('.wdk-field-calendar-addinition:not([style*="none"])').last().slideUp('slow', function(){
					btn.parent().find('.next').removeClass('noactive')
					if(!parent.find('.wdk-field-calendar-addinition:not([style*="none"])').length) {
						btn.parent().find('.pre').addClass('noactive')
					} 
				});
			}
		});

		$('#date_from, #date_to').on('input', function(){
			var dateStart,dateEnd,order_from,order_to;
			dateStart = $('#date_from').val();
			dateEnd = $('#date_to').val();
			dateStart = dateStart.split(' ')[0];
			dateEnd = dateEnd.split(' ')[0];

			$('.wdk-field-calendar table td a').removeClass([class_active, class_resevation_end, class_resevation_start]);

			order_from = +($('.wdk-field-calendar table td a[title="'+dateStart+'"]').parent().data('order'));
			order_to = +($('.wdk-field-calendar table td a[title="'+dateEnd+'"]').parent().data('order'));


			if (order_to > order_from) {
				$('.wdk-field-calendar table td a').removeClass(class_active);
				while (order_to >= order_from) {
					$(list_days[order_to]).find('a').addClass(class_active);
					order_to--;
				}
			}
			
			$('.wdk-field-calendar table td a[title="'+dateStart+'"]').addClass(class_resevation_start);
			$('.wdk-field-calendar table td a[title="'+dateEnd+'"]').addClass(class_resevation_end);
		});
	};
	wdk_booking_calendar();

    // [START] Changed post_id //  
    jQuery('input[name="post_id"]').change(function (e) {
        e.preventDefault();
        let self = jQuery(this);
        let self_parent = jQuery('.wdk-field-calendar');
		let post_id = jQuery(this).val()
		let current_reservation_id = jQuery('#current_reservation_id').val() || '';
        let ajax_url = jQuery('.data-ajax').attr('data-ajax')

        var data = { post_id: post_id,current_reservation_id: current_reservation_id};
        jQuery.extend( data, {
            "action": 'wdk_bookings_public_action',
            "page": 'wdk_bookings_frontendajax',
            "function": 'availabledates',
        });
        
        self_parent.addClass('loading');
        jQuery.post(ajax_url, data, 
			function (data) {
				if(data.success == true)
				{
					self_parent.removeClass('hidden');
					//reset
					self_parent.find('td').removeClass('bg-booked booked_current bg-available').addClass('bg-not-selected').find('a').removeClass('active');
					jQuery.each(data.output, function (i, v) { 
						var cell = self_parent.find('[title="' + i + '"]');
						if (cell && cell.length) {
							if(v.indexOf ('booked_current') !== -1 ) {
								cell.parent().addClass("bg-booked booked_current").removeClass('bg-not-selected');
							} else if(v.indexOf ('booked') !== -1) {
								cell.parent().addClass("bg-booked").removeClass('bg-not-selected');
							} else {
								cell.parent().addClass("bg-available").removeClass('bg-not-selected');
							}

							if(v.indexOf ('book_current_bookd') !== -1){
								cell.parent().addClass("reservation-booked-booked_current")
							}else if(v.indexOf ('book_book_current') !== -1){
								cell.parent().addClass("reservation-booked_current-booked")
							}else if(v.indexOf ('reservation_start') !== -1 && v.indexOf ('reservation_end') == -1){
								cell.parent().addClass("bg-available reservation-start")
							}else if(v.indexOf ('reservation_end') !== -1 && v.indexOf ('reservation_start') == -1){
								cell.parent().addClass("bg-available reservation-end")
							}
						}
					});
					
					/* time hide/show */
					if(typeof data.is_hours_enable !='undefined') {
						if(data.is_hours_enable == true) {
							$('.datetime_time_mask').show();
						} else {
							$('.datetime_time_mask').hide();
						}
					}

				} else {
					/* calendar */
					self_parent.removeClass('hidden');
                }
        }).always(function(){
			self_parent.removeClass('loading');
			wdk_booking_calendar();
        });
        return false;
    });
    // [END] Changed post_id //  

})( jQuery );
