(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 const wdk_booking_calendar = () => {
		var class_active = 'active';
		var list_days = $('.wdk-field-calendar table tbody td[data-order]');

		$('.wdk-field-calendar table td a,.wdk-field-calendar').off();
		$('.wdk-field-calendar table td.bg-available a').on('click', function (e) {
			e.preventDefault();
			var self, order_from, order_to, date_from;
			self = $(this);
			self.addClass(class_active);
			order_from = self.parent().attr('data-order');
			date_from = self.attr('title');
			$('.wdk-field-calendar table td a').removeClass(class_active);
			
			$('.wdk-field-calendar:hover').on('mouseover', function (e) {
			
				var related = e.target ? e.target : "unknown";
				if ($(related).is("a"))
					related = $(related).parent();
				
				if ($(related).hasClass('bg-available')) {
					order_to = parseInt($(related).attr('data-order'));
					if (order_to > order_from) {
						$('.wdk-field-calendar table td a').removeClass(class_active);
						while (order_to >= order_from) {
							$(list_days[order_to]).find('a').addClass(class_active);
							order_to--;
						}
					}
				}

				/* finish */
				$('.wdk-field-calendar table td.bg-available a').off().on('click', function (e) {
					e.preventDefault();
					$('.wdk-field-calendar:hover').off();
				
					order_to = $(this).parent().attr('data-order');
					var error = false;
					while (order_to >= order_from) {
						if ($(list_days[order_to]).hasClass('bg-booked')) {
							error = true;
							break;
						}
						order_to--;
					}

					if (error) {
						$('.wdk-field-calendar table td a').removeClass(class_active);
						wdk_log_notify($('.wdk-field-calendar .js_message_error_date').text(), 'error');
					} else {
						$('#date_from').val(date_from);
						$('#date_to').val($(this).attr('title'));

						$('#date_from_mask').datepicker("setDate", new Date(date_from) );
						$('#date_to_mask').datepicker("setDate", new Date($(this).attr('title')));

						$([document.documentElement, document.body]).animate({
							scrollTop: (jQuery("#date_from_mask").length) ? $("#date_from_mask").offset().top - 100 : $("#date_from").offset().top - 100
						}, 500, function () {
							if ($('.elementinvader_addons_for_elementor_f input[name="Name"]').length) {
								//$('.elementinvader_addons_for_elementor_f input[name="Name"]').focus();
							} else {
								//$('#date_from').focus();
							}
						});
					}

					wdk_booking_calendar();
				});
			});

		});

		$('.wdk-field-calendar .wdk-btn-pag').off().on('click', function (e) {
			e.preventDefault();
			var btn = $(this);
			var parent = btn.closest('.wdk-field-calendar');

			if (btn.hasClass('next')) {
				parent.find('.wdk-field-calendar-addinition[style*="none"]').first().slideDown('slow', function(){
					btn.parent().find('.pre').removeClass('noactive')
					if(!parent.find('.wdk-field-calendar-addinition[style*="none"]').length) {
						btn.parent().find('.next').addClass('noactive')
					} 
				});
			} else {
				parent.find('.wdk-field-calendar-addinition:not([style*="none"])').last().slideUp('slow', function(){
					btn.parent().find('.next').removeClass('noactive')
					if(!parent.find('.wdk-field-calendar-addinition:not([style*="none"])').length) {
						btn.parent().find('.pre').addClass('noactive')
					} 
				});
			}
		});

		
		$('#date_from, #date_to').on('input', function(){
			var dateStart,dateEnd,order_from,order_to;
			dateStart = $('#date_from').val();
			dateEnd = $('#date_to').val();
			dateStart = dateStart.split(' ')[0];
			dateEnd = dateEnd.split(' ')[0];

			order_from = +($('.wdk-field-calendar table td a[title="'+dateStart+'"]').parent().data('order'));
			order_to = +($('.wdk-field-calendar table td a[title="'+dateEnd+'"]').parent().data('order'));

			if (order_to > order_from) {
				$('.wdk-field-calendar table td a').removeClass(class_active);
				while (order_to >= order_from) {
					$(list_days[order_to]).find('a').addClass(class_active);
					order_to--;
				}
			}
		});

	};
	wdk_booking_calendar();


    // [START] Changed post_id //  
    jQuery('input[name="post_id"]').change(function (e) {
        e.preventDefault();
        let self = jQuery(this);
        let self_parent = jQuery('.wdk-field-calendar');
		let self_parent_table = jQuery('.prices-table');
		let post_id = jQuery(this).val()
		let current_price_id = jQuery('#current_price_id').val() || '';
        let ajax_url = jQuery('.data-ajax').attr('data-ajax')

		var data = { 
			post_id: post_id,
			current_price_id: current_price_id
		};

        jQuery.extend( data, {
            "action": 'wdk_bookings_public_action',
            "page": 'wdk_bookings_frontendajax',
            "function": 'availablerates',
        });
        
        self_parent.addClass('loading');

        jQuery.post(ajax_url, data, 
            function(data){
                /*
			    if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                */
				if(data.success == true)
				{
					/* calendar */
					self_parent.removeClass('hidden');
					//reset
					self_parent.find('td:not(.ignore)').removeClass('bg-booked bg-not-selected').addClass('bg-available').find('a').removeClass('active').removeAttr('href');
					jQuery.each(data.output.prices_dates, function (i, v) { 
						var cell = self_parent.find('[title="' + i + '"]');
						if (cell && cell.length) {
							if(current_price_id == v) {
								cell.parent().addClass("bg-available").removeClass('bg-not-selected bg-booked').find('a').addClass('active');
							} else {
								cell.parent().addClass("bg-booked").removeClass('bg-not-selected bg-available');
							}
						}
					});
					/* end calendar */

					/* time hide/show */
					if(typeof data.output.is_hours_enable !='undefined') {
						if(data.output.is_hours_enable == true) {
							$('.datetime_time_mask').show();
						} else {
							$('.datetime_time_mask').hide();
						}
					}

                } else {
					/* calendar */
					self_parent.removeClass('hidden');
					//reset
					self_parent.find('td:not(.ignore)').removeClass('bg-booked bg-not-selected').addClass('bg-available').find('a').removeClass('active');
                }
			}).always(function () {
				self_parent.removeClass('loading');
				wdk_booking_calendar();
			});
        return false;
    });

    // [END] Changed post_id //  
	const wdk_booking_filter_var = (value, _default = '') => {
		if(typeof value =='undefined' || value == "null" || value == null) {
			return _default;
		} else {
			return value;
		}
	};
})( jQuery );
