=== Plugin Name ===
Contributors: listingthemes
Donate link: https://wpdirectorykit.com/donate/
Tags: directory,currency,conversion,indexes
Requires at least: 5.2
Tested up to: 6.6
Requires PHP: 5.6
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Directory Kit - Multy Currency

== Description ==

Automatically import and sync wanted currencies available in API and auto conver on Homepage Based on Switcher selection. 

<h3>How this works:</h3>

You will be able to put dropdown currency selection element in elementor

And in admin dashboard manage currencies

When user select currency on frontend all prices will be auto converted for them 

<h3>Features:</h3>

<ul>
    <li>Manage Currencies</li>
    <li>Import sync with exchangeratesapi.io</li>
    <li>Import sync with mindicador.cl</li>
    <li>Elementor Element to show all currencies indexes list</li>
    <li>Elementor Element to change currency on website</li>
    <li>Automatic currency conversion on results</li>
</ul>

<h3>Required to use it:</h3>

<ul>
    <li>WP Directory Kit</li>
</ul>


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `wdk-currency-conversion.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does it support any API? =

No, support only API-s listed above i ndescription

== Screenshots ==

1. Currencies list element
2. Currencies management
3. Import Currencies

== Changelog ==

= 1.0.2 =
* Support for multiple API-s, mindicador.cl
* Currencies list Elementor element
* Inversed indexes support

= 1.0 =
* Init version
