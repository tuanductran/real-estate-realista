<?php

/**
 * Fired during plugin deactivation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Currency_Conversion
 * @subpackage Wdk_Currency_Conversion/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wdk_Currency_Conversion
 * @subpackage Wdk_Currency_Conversion/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Currency_Conversion_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
