<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Currency_Conversion
 * @subpackage Wdk_Currency_Conversion/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Currency_Conversion
 * @subpackage Wdk_Currency_Conversion/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Currency_Conversion_Activator {

    public static $db_version = 1.1;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

        $prefix = 'wdk_currency_';

	}

    public static function plugins_loaded()
    {
		if ( get_site_option( 'wdk_currency_db_version' ) === false ||
		     get_site_option( 'wdk_currency_db_version' ) < self::$db_version ) {
			self::install();
		}
    }

    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0
        if(get_site_option( 'wdk_currency_db_version' ) === false)
        {
            // Main table for currency calendar

            $table_name = $wpdb->prefix . 'wdk_currency';

            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                    `idcurrency` int(11) NOT NULL AUTO_INCREMENT,
                    `date` datetime DEFAULT NULL,
                    `conversion_index` decimal(20,8) DEFAULT NULL,
                    `currency_code` varchar(20) DEFAULT NULL,
                    `currency_symbol` varchar(20) DEFAULT NULL,
                    `is_activated` tinyint(1) DEFAULT NULL,
                    `is_default` tinyint(1) DEFAULT NULL,
                PRIMARY KEY  (idcurrency)
            ) $charset_collate COMMENT='Currency conversion table';";
        
            dbDelta( $sql );

            /* install demo content */
            if(true){
                // Save currency_m
                $data = array();
                $data['conversion_index'] = '1.00000000';
                $data['currency_code'] = 'EUR';
                $data['currency_symbol'] = '€';
                $data['is_activated'] = 1;
                $wpdb->insert( $table_name, $data);

                $data = array();
                $data['conversion_index'] = '1.13000000';
                $data['currency_code'] = 'USD';
                $data['currency_symbol'] = '$';
                $data['is_activated'] = 1;
                $data['is_default'] = 1;
                $wpdb->insert( $table_name, $data);
        
                /* settings */
                update_option('wdk_currency_conversion_fields', '6,7');
            }

            self::$db_version = 1.0;
        }

        if ( get_site_option( 'wdk_currency_db_version' ) < '1.1' ) {
                                
            $table_name = $wpdb->prefix . 'wdk_currency';
            $sql = "ALTER TABLE `$table_name`  ADD `is_inversed_index` INT(1) DEFAULT NULL";
            $wpdb->query($sql);

            self::$db_version = 1.1;
            /* udpate option with db version */ 
        }
    
        update_option( 'wdk_currency_db_version', self::$db_version );
    }

}
