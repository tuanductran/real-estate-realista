<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/* Get currency from GET link */

if(isset($_GET['wdk_currency'])) {
    $currency_code = trim(sanitize_text_field($_GET['wdk_currency']));
    global $Winter_MVC_wdk_currency;
    $Winter_MVC_wdk_currency->model('currency_m');
    $currency = $Winter_MVC_wdk_currency->currency_m->get_currencies($currency_code, TRUE);

    if($currency) {
        setcookie( 'wdk_currency', wmvc_show_data('currency_code',$currency));
        
        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
        if(is_plugin_active('litespeed-cache/litespeed-cache.php')) {
            do_action( 'litespeed_purge_all' );
        }
        
        $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . '://' . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        wp_redirect(trim(str_replace('wdk_currency='.$currency_code,'',$current_url), '?'));
        exit();
    }
}
 
add_action( 'wpdirectorykit/install/api', 'wdk_currencies_install'); 

if(!function_exists('wdk_currencies_install')) {
    function wdk_currencies_install () {
        global $Winter_MVC_wdk_currency;
        $Winter_MVC_wdk_currency->model('currency_m');
        if($Winter_MVC_wdk_currency->currency_m->get()){
            //$this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Currency already imported', 'wdk-currency-conversion').'</div>';
            return false;
        }

        if(!function_exists('run_wdk_currency_conversion')){
            //$this->data['import_log'] .= '<div class="alert alert-danger" role="alert">'.esc_html__('Addon WDK Currency Conversion missing', 'wdk-currency-conversion').'</div>';
            return false;
        }
        
        /* remove data */
        $Winter_MVC_wdk_currency->db->delete($Winter_MVC_wdk_currency->currency_m->_table_name);
        /* end remove data */

        /* reset autoincrement */
        $Winter_MVC_wdk_currency->db->query('TRUNCATE TABLE `'.$Winter_MVC_wdk_currency->currency_m->_table_name.'`');

        // Save currency_m
        $data = array();
        $data['conversion_index'] = '1.00000000';
        $data['currency_code'] = 'EUR';
        $data['currency_symbol'] = '€';
        $data['is_activated'] = 1;
        $insert_id = $Winter_MVC_wdk_currency->currency_m->insert($data, NULL);

        $data = array();
        $data['conversion_index'] = '1.13000000';
        $data['currency_code'] = 'USD';
        $data['currency_symbol'] = '$';
        $data['is_activated'] = 1;
        $data['is_default'] = 1;
        $insert_id = $Winter_MVC_wdk_currency->currency_m->insert($data, NULL);

        /* settings */
        update_option('wdk_currency_conversion_fields', '6,7');

        //$this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.esc_html__('Currency imported').'</div>';
        return true;
    }
}

?>