<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'wpdirectorykit/listing/field/value', 'wdk_currencies_filter_price', 10, 3 ); 
add_filter( 'wpdirectorykit/listing/field/prefix', 'wdk_currencies_filter_symbol_prefix', 10, 2 ); 
add_filter( 'wpdirectorykit/listing/field/suffix', 'wdk_currencies_filter_symbol_suffix', 10, 2 ); 

/* every time convert value */
add_filter( 'wdk-currency-conversion/convert/price', 'wdk_currencies_convert_value', 10, 2 ); 
add_filter( 'wdk-currency-conversion/convert/symbol', 'wdk_currencies_convert_symbol', 10, 2 ); 
add_filter( 'wdk-currency-conversion/convert/symbol_prefix', 'wdk_currencies_convert_symbol_prefix', 10, 2 ); 
add_filter( 'wdk-currency-conversion/convert/symbol_suffix', 'wdk_currencies_convert_symbol_suffix', 10, 2 ); 

add_filter( 'wdk-currency-conversion/convert/default_value', 'wdk_currencies_filter_default_price', 10, 2 ); 
add_filter( 'wdk-currency-conversion/convert/default_prefix', 'wdk_currencies_filter_default_symbol_prefix', 10, 2 ); 
add_filter( 'wdk-currency-conversion/convert/default_suffix', 'wdk_currencies_filter_default_symbol_suffix', 10, 2 ); 

if(!function_exists('wdk_currencies_filter_price')) {
    function wdk_currencies_filter_price ($field_value = '', $field_id = NULL, $number_format = TRUE) {

        if(empty($field_id))
            return $field_value;

        if(wdk_currencies_is_price_field($field_id)){
            if (!wdk_currencies_is_default_price()) {
                return wdk_currencies_price_convert($field_value, $number_format);
            } else {
                $field_value = filter_var($field_value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $field_value = (float)str_replace(array(","," ",'&nbsp;'), "", $field_value);
                return ($number_format) ? number_format_i18n($field_value) : $field_value;
            }
        }

        return $field_value;
    }
}

if(!function_exists('wdk_currencies_filter_symbol_prefix')) {
    function wdk_currencies_filter_symbol_prefix ($value = '', $field_id = NULL) {
        if(empty($field_id))
            return $value;
        
        if(wdk_currencies_is_price_field($field_id) && !wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() == '$') {
                return wdk_currencies_symbol_convert($value);
            } else {
                return '';
            }
        }

        return $value;
        
    }
}

if(!function_exists('wdk_currencies_filter_symbol_suffix')) {
    function wdk_currencies_filter_symbol_suffix ($value = '', $field_id = NULL) {
        if(empty($field_id))
            return $value;

        if(wdk_currencies_is_price_field($field_id) && !wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() != '$') {
                return wdk_currencies_symbol_convert($value);
            } else {
                return '';
            }
        }

        return $value;
    }
}


if(!function_exists('wdk_currencies_convert_symbol')) {
    function wdk_currencies_convert_symbol ($value = '') {
        if(!wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() != '$') {
                return wdk_currencies_symbol_convert($value);
            } else {
                return '';
            }
        }
        return $value;
    }
}

if(!function_exists('wdk_currencies_convert_symbol_prefix')) {
    function wdk_currencies_convert_symbol_prefix ($value = '') {
        if(!wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() == '$') {
                return wdk_currencies_symbol_convert($value);
            } else {
                return '';
            }
        }
        return $value;
    }
}

if(!function_exists('wdk_currencies_convert_symbol_suffix')) {
    function wdk_currencies_convert_symbol_suffix ($value = '') {
        if(!wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() != '$') {
                return wdk_currencies_symbol_convert($value);
            } else {
                return '';
            }
        }
        return $value;
    }
}

if(!function_exists('wdk_currencies_convert_value')) {
    function wdk_currencies_convert_value ($price = '') {
        if (!wdk_currencies_is_default_price()) {
            return wdk_currencies_price_convert($price);
        } else {
            $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $price = (float)str_replace(array(","," ",'&nbsp;'), "", $price);
            return number_format_i18n($price);
        }

        return $price;
    }
}

/* convert to default */
if(!function_exists('wdk_currencies_filter_default_price')) {
    function wdk_currencies_filter_default_price ($field_value = '', $field_id = NULL) {
        if(empty($field_id))
            return $field_value;

        if(wdk_currencies_is_price_field($field_id)){
            if (!wdk_currencies_is_default_price()) {
                return wdk_currencies_price_default_convert($field_value);
            } else {
                $field_value = filter_var($field_value, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
                $field_value = (float)str_replace(array(","," ",'&nbsp;'), "", $field_value);
                return $field_value;
            }
        }

        return $field_value;
    }
}

if(!function_exists('wdk_currencies_filter_default_symbol_prefix')) {
    function wdk_currencies_filter_default_symbol_prefix ($value = '', $field_id = NULL) {
        if(empty($field_id))
            return $value;
        
        if(wdk_currencies_is_price_field($field_id) && !wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() == '$') {
                return wdk_currencies_symbol_default_convert($value);
            } else {
                return '';
            }
        }

        return $value;
    }
}

if(!function_exists('wdk_currencies_filter_default_symbol_suffix')) {
    function wdk_currencies_filter_default_symbol_suffix ($value = '', $field_id = NULL) {
        if(empty($field_id))
            return $value;

        if(wdk_currencies_is_price_field($field_id) && !wdk_currencies_is_default_price()){
            if(wdk_currencies_symbol_convert() != '$') {
                return wdk_currencies_symbol_default_convert($value);
            } else {
                return '';
            }
        }

        return $value;
    }
}