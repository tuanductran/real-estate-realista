<?php

namespace WdkСurrencyСonversion\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkСurrenciesList extends WdkСurrencyСonversionElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-currency-conversion')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-currency-conversion')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-currency-conversion')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-currencies-list';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Сurrencies List', 'wdk-currency-conversion');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-bullet-list';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->WMVC_СurrencyСonversion->model('currency_m');

        $currency_code = NULL;
        $is_activated = 1;
        if(!empty($this->data['settings']['selected_currency']))
        {
            $currency_code = $this->data['settings']['selected_currency'];
            $is_activated = 0;
        }

        $this->data['currencies'] = $this->WMVC_СurrencyСonversion->currency_m->get_currencies($currency_code, FALSE, $is_activated);

        if($this->data['settings']['hide_currency_symbol'] == 'yes' && $this->data['settings']['hide_currency_code'] == 'yes') {
            $this->data['settings']['hide_currency_symbol'] = $this->data['settings']['hide_currency_code'] = 'no';
        }

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        } else {
            if(empty( $this->data['currencies'])) return false;
        }

        echo $this->view('wdk-currencies-list', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-currency-conversion'),
                'tab' => '1',
            ]
        );

        $this->add_control (
			'hide_currency_code',
			[
				'label' => __( 'Hide Currency Code', 'wdk-currency-conversion' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'wdk-currency-conversion' ),
				'label_off' => __( 'Show', 'wdk-currency-conversion' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

        $this->add_control (
			'hide_currency_symbol',
			[
				'label' => __( 'Hide Currency Symbol', 'wdk-currency-conversion' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Hide', 'wdk-currency-conversion' ),
				'label_off' => __( 'Show', 'wdk-currency-conversion' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);

        $currency_list = array('' => esc_html__('Show all active', 'wpdirectorykit'));

        $this->WMVC_СurrencyСonversion->model('currency_m');

        $currencies = $this->WMVC_СurrencyСonversion->currency_m->get_currencies(NULL, FALSE, 0);

        foreach($currencies as $currency)
        {
            $currency_list[$currency->currency_code] = $currency->currency_code.' '.$currency->currency_symbol;
        }

        $this->add_control (
			'selected_currency',
			[
				'label' => __( 'Show only currency', 'wdk-currency-conversion' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $currency_list,
				'default' => '',
			]
		);

        $this->end_controls_section();

    }


    private function generate_controls_layout() {
    }


    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'currency_code',
                'label'=> esc_html__('Currency Code', 'wpdirectorykit'),
                'selector'=>'.wdk-currencies-code',
                'options'=>'full',
            ],
            [
                'key'=>'currency_symbol',
                'label'=> esc_html__('Currencies Symbol', 'wpdirectorykit'),
                'selector'=>'.wdk-currencies-symbol',
                'options'=>'full',
            ],
            [
                'key'=>'currency_value',
                'label'=> esc_html__('Currencies Value', 'wpdirectorykit'),
                'selector'=>'.wdk-currencies-value',
                'options'=>'full',
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
                'hover'=>'{{WRAPPER}} '.$item['selector'].'%1$s'
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'],  ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-currencies-list');
    }
}
