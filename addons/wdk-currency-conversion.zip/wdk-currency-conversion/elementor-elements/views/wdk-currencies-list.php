<?php
/**
 * The template for Element Currency Picker.
 * This is the template that elementor element dropdown
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-currencies-list-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <ul class="wdk-currencies-list">
        <?php if(count($currencies) == 0): ?>
        <li class="currencies-not-found"><?php echo esc_html__('Currencies not found', 'wdk-currency-conversion'); ?></li>
        <?php endif; ?>
        <?php foreach($currencies as $currency): ?>
        <li class="currency-data"><?php if($settings['hide_currency_code'] != 'yes')echo '<span class="wdk-currencies-code">'.$currency->currency_code.'</span>'; ?> <?php if($settings['hide_currency_symbol'] != 'yes')echo '<span class="wdk-currencies-symbol">'.$currency->currency_symbol.'</span>'; ?> <?php echo '<span class="wdk-currencies-value">'.number_format($currency->conversion_index, 2).'</span>'; ?></li>
        <?php endforeach; ?>
    </ul>
</div>