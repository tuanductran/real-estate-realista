<?php
/**
 * The template for Element Currency Picker.
 * This is the template that elementor element dropdown
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-currency-conversion-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-currency-picker">
        <div class="wdk-currency-dropdown">
            <button class="wdk-currency-btn-toogle" type="button">
                <?php if(wdk_currencies_get_current_currency()):?>
                    <?php $current_currency = wdk_currencies_get_current_currency();?>
                    <?php if($settings['hide_currency_code'] != 'yes'):?>
                        <?php echo esc_html(wmvc_show_data('currency_code', $current_currency));?>
                    <?php endif;?>
                    <?php if(wmvc_show_data('currency_symbol', $current_currency, false) && $settings['hide_currency_symbol'] != 'yes'):?>
                        <?php if($settings['hide_currency_code'] != 'yes'):?>(<?php endif;?><?php echo wmvc_show_data('currency_symbol', $current_currency);?><?php if($settings['hide_currency_code'] != 'yes'):?>)<?php endif;?>
                    <?php endif;?>

                <?php else:?>
                    <?php $current_currency = wdk_currencies_get_default_currency();?>
                    <?php if($settings['hide_currency_code'] != 'yes'):?>
                        <?php echo esc_html(wmvc_show_data('currency_code', $current_currency));?>
                    <?php endif;?>
                    <?php if(wmvc_show_data('currency_symbol', $current_currency, false) && $settings['hide_currency_symbol'] != 'yes'):?>
                        <?php if($settings['hide_currency_code'] != 'yes'):?>(<?php endif;?><?php echo wmvc_show_data('currency_symbol', $current_currency);?><?php if($settings['hide_currency_code'] != 'yes'):?>)<?php endif;?>
                    <?php endif;?>
                <?php endif;?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['select_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </button>
            <div class="wdk-currency-dropdown-menu">
                <?php foreach($currencies as $currency):?>
                    <a class="item" href="<?php echo esc_url(wdk_url_suffix(wdk_current_url(), 'wdk_currency='. wmvc_show_data('currency_code', $currency)));?>">
                        <?php if($settings['hide_currency_code'] != 'yes'):?>
                            <?php echo esc_html(wmvc_show_data('currency_code', $currency));?>
                        <?php endif;?>

                        <?php if(wmvc_show_data('currency_symbol', $currency, false) && $settings['hide_currency_symbol'] != 'yes'):?>
                            <?php if($settings['hide_currency_code'] != 'yes'):?>(<?php endif;?><?php echo wmvc_show_data('currency_symbol', $currency);?><?php if($settings['hide_currency_code'] != 'yes'):?>)<?php endif;?>
                        <?php endif;?>
                    </a>
                <?php endforeach;?>
            </div>
        </div>
    </div>
</div>