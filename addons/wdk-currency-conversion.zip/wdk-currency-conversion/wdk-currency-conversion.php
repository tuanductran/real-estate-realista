<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_Currency_Conversion
 *
 * @wordpress-plugin
 * Plugin Name:       WDK Currency Conversion
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-multy-currency.html
 * Description:       Automatically import and sync wanted currencies available in API and auto conver on Homepage Based on Switcher selection.
 * Version:           1.0.4
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-currency-conversion
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_CURRENCY_CONVERSION_VERSION', '1.0.4' );
define( 'WDK_CURRENCY_CONVERSION_NAME', 'wdk-currency-conversion' );
define( 'WDK_CURRENCY_CONVERSION_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_CURRENCY_CONVERSION_URL', plugin_dir_url( __FILE__ ) );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-currency-conversion-activator.php
 */
function activate_wdk_currency_conversion() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-currency-conversion-activator.php';
	Wdk_Currency_Conversion_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-currency-conversion-deactivator.php
 */
function deactivate_wdk_currency_conversion() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-currency-conversion-deactivator.php';
	Wdk_Currency_Conversion_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_currency_conversion' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_currency_conversion' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-currency-conversion.php';

if(file_exists(dirname(__FILE__) . '/premium_functions.php') && !defined('WDK_FS_DISABLE'))
{
    require_once dirname(__FILE__) . '/premium_functions.php';
}
else
{
    run_wdk_currency_conversion();
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wdk_currency_conversion() {

	$plugin = new Wdk_Currency_Conversion();
	$plugin->run();

}

add_action( 'wdk_currencies_cron_exchangeratesapi', 'wdk_currencies_cron_exchangeratesapi_sync', 10, 2 );

//wdk_currencies_cron_exchangeratesapi_sync();
function wdk_currencies_cron_exchangeratesapi_sync()
{
    $data = array(
        'exchangeratesapi_api_key'      => get_option('exchangeratesapi_api_key'),
        'exchangeratesapi_cron_enabled' => get_option('exchangeratesapi_cron_enabled'),
        'exchangeratesapi_used'         => get_option('exchangeratesapi_used'),
    );

    if($data['exchangeratesapi_cron_enabled'] != '1')return;
    
    if($data['exchangeratesapi_used'] == 'exchangeratesapi.io')
    {
        if(empty($data['exchangeratesapi_api_key']))return;

        // old key
        // $results = wp_remote_request('http://api.exchangeratesapi.io/v1/latest?access_key='.$data['exchangeratesapi_api_key'], array() );

        $params = array('apikey' => $data['exchangeratesapi_api_key']);

        $results = wp_remote_request('https://api.apilayer.com/exchangerates_data/latest', array('headers' => $params)  );

        $json_object = json_decode($results['body']);

        if(!is_null($json_object))
        {
            if(isset($json_object->message))
            {
                // Error
            }
            else
            {
                global $wpdb;

                foreach((array) $json_object->rates as $currency_code=>$conversion_index)
                {

                    $data_update = array(
                        'conversion_index' => $conversion_index,
                        'date' => date("Y-m-d h:i:s")
                    );

                    $where = array(
                        'currency_code' => $currency_code,
                    );

                    $updated = $wpdb->update( $wpdb->prefix.'wdk_currency', $data_update, $where );
    
                    if ( false === $updated ) {
                        // There was an error.
                    } else {
                        // No error. You can check updated to see how many rows were changed.
                    }

                }
            }
        }
    }
    else if($data['exchangeratesapi_used'] == 'mindicador.cl')
    {
        $params = array();

        $results = wp_remote_request('https://mindicador.cl/api', array('headers' => $params)  );

        $json_array = (array) json_decode($results['body']);

        if(!is_null($json_array))
        {
            if(!isset($json_array['fecha']))
            {
                // Error
            }
            else
            {
                global $wpdb;

                foreach($json_array as $currency_code=>$currency_object)
                {
                    if(is_object($currency_object) && isset($currency_object->codigo))
                    {
                        $data_update = array(
                            'conversion_index' => $currency_object->valor,
                            'date' => date("Y-m-d h:i:s")
                        );

                        $where = array(
                            'currency_code' => $currency_object->codigo,
                        );

                        $updated = $wpdb->update( $wpdb->prefix.'wdk_currency', $data_update, $where );
    
                        if ( false === $updated ) {
                            // There was an error.
                        } else {
                            // No error. You can check updated to see how many rows were changed.
                        }
                    }
                }
            }
        }
    }
}