<?php
/**
 * The template for Settings Page.
 *
 * This is the template that edit settings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">

    <h1 class="wp-heading-inline"><?php echo __('Settings Currency Conversion','wdk-currency-conversion'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
            <div class="postbox hidden">
                <div class="postbox-header">
                    <h3><?php echo __('Main info','wdk-currency-conversion'); ?></h3>
                </div>
                <div class="inside">
                    <?php 
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-currency-conversion'));
                    ?>

                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr class="hidden">
                                <th scope="row"><label for="wdk_currency_conversion_fields"><?php echo __('Search Form Json/Structure','wdk-currency-conversion'); ?></label></th>
                                <td>
                                    <textarea readonly="readonly" name="wdk_currency_conversion_fields" type="text" id="wdk_currency_conversion_fields" class="regular-text"><?php echo esc_textarea(wmvc_show_data('wdk_currency_conversion_fields', $db_data, '')); ?></textarea>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="postbox" style="display: block;">
                <div class="postbox-header"><h3><?php echo __('Drag & Drop Builder','wdk-currency-conversion'); ?></h3>
            </div>
            <div class="inside">
                <?php 
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-currency-conversion'));
                ?>
                <p class="alert alert-info"><?php echo __('Drag fields from left side to right side, right side enable conversion for defined fields.','wdk-currency-conversion'); ?></p>
                <div class="wdk-builder-container">
                    <div class="wdk-builder-elements-column">
                        <div class="wdk-builder-elements-box">
                            <h3 class="sec-title"><?php echo __('Available numeric fields','wdk-currency-conversion'); ?></h3>
                            <div id="wdk-drag" class="wdk-builder-elements wdk-drop section_fields">
                            <?php foreach($fields as $key => $field): 
                                    if(in_array($field->idfield,$used_fields))continue; // skip if field is used

                                    if(in_array($field->idfield, array('search','loc','cat','address','post_title','more','booking_date')) !== FALSE)continue; // skip if field is used
                                ?>
                                <?php if($field->field_type=='SECTION'):?>
                                    </div>
                                    </div>
                                    <div class="wdk-builder-elements-box">
                                        <h3 class="sec-title"><?php echo esc_html($field->field_label); ?></h3>
                                        <div id="wdk-drag" class="wdk-builder-elements wdk-drop section_fields" data-name="<?php echo esc_html($field->field_label); ?>">
                                <?php continue; endif;?>
                                
                                <div id="fid_<?php echo esc_attr($field->idfield); ?>" class="widget ui-draggable" rel="<?php echo esc_attr($field->idfield); ?>">
                                    <div class="widget-top">
                                        <div class="widget-title ui-draggable-handle"><h3>#<?php echo esc_html($field->idfield); ?> [<?php echo esc_html($field->field_type); ?>] <?php echo esc_html($field->field_label); ?><span class="in-widget-title"></span></h3></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="drop-container" style='padding-top: 6px;'>
                        <div class="wdk-builder-elements-box">
                            <h3 class="sec-title"><?php echo __('Fields for currency conversion','wdk-currency-conversion'); ?></h3>
                        </div>
                        <?php
                            $WMVC = &wdk_get_instance();
                            $WMVC->model('field_m');
                        ?>
                        <div id="wdk-drop" class="wdk-builder-selected wdk-drop" style="margin-top: 15px;">
                        <?php if(is_array($used_fields))
                                foreach($used_fields as $used_field): 
                                    $field = $WMVC->field_m->get_fields_data($used_field);
                            ?>
                            <div id="fid_<?php echo esc_attr(wmvc_show_data('idfield', $field)); ?>" class="widget ui-draggable" rel="<?php echo esc_attr(wmvc_show_data('idfield', $field)); ?>">
                                <div class="widget-top">
                                    <div class="widget-title ui-draggable-handle"><h3>#<?php echo esc_html(wmvc_show_data('idfield', $field)); ?> [<?php echo esc_html(wmvc_show_data('field_type', $field)); ?>] <?php echo esc_html(wmvc_show_data('field_label', $field)); ?><span class="in-widget-title"></span></h3></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    </div>
                    <br style="clear:both;" />
                </div>

            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-currency-conversion'); ?>">
            </div>
            </div>
        </form>
    </div>

</div>

<?php
wp_enqueue_script( 'jquery-ui-core', false, array('jquery') );
wp_enqueue_script( 'jquery-ui-sortable', false, array('jquery') );
?>

<script>
// Generate table
jQuery(document).ready(function($) {

    $( "#wdk-drag, #wdk-drop" ).sortable({
        connectWith: ".wdk-drop",
        placeholder: "ui-sortable-placeholder widget-placeholder",
        update: function(event, ui) {
            save_data();
        }
    }).disableSelection();

    $('button.widget-action').on('click', function(){
        if($(this).attr("aria-expanded") == 'true')
        {
            $(this).attr("aria-expanded", 'false');
            $(this).parent().parent().parent().find('.widget-inside').hide();
        }
        else
        {
            $(this).attr("aria-expanded", 'true');
            $(this).parent().parent().parent().find('.widget-inside').show();
        }
    });

    $('.wdk-builder-container').find('input,select').on('input', save_data);


    function save_data()
    {
        var data_fields_list = '';

        $('#wdk-drop .widget.ui-draggable').each(function( index ) {
            if(data_fields_list !='')
                data_fields_list +=',';

            data_fields_list += $( this ).attr('rel');
        });

        $('#wdk_currency_conversion_fields').val(data_fields_list);
    }
});

</script>
<?php $this->view('general/footer', $data); ?>