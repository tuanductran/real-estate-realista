<?php
/**
 * The template for Edit Currencies
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo __('Currencies Management','wdk-currency-conversion'); ?></h1>
    <br /><br />

    <div class="wdk-body">
        <div class="postbox" style="display: block;">
            <div class="postbox-header">
                <h3><?php echo __('Add/Edit Currency','wdk-currency-conversion'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                        $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-currency-conversion'));
                    ?>

                    <?php echo wdk_generate_fields($fields, $db_data); ?> 

                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo __('Save Changes','wdk-currency-conversion'); ?>">
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>