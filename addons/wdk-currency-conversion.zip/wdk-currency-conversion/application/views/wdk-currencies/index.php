<?php
/**
 * The template for Currencies Management.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo __('Currencies Management', 'wdk-currency-conversion'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies-add"; ?>" class="button button-primary" id="add_currency_button"><?php echo __('Add Currency', 'wdk-currency-conversion'); ?></a></h1>

    
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-currencies" />

                <label class="screen-reader-text" for="search"><?php echo __('Filter by keyword', 'wdk-currency-conversion'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo __('Filter by keyword', 'wdk-currency-conversion'); ?>" />

                <label class="screen-reader-text" for="order_by"><?php echo __('Order By', 'wdk-currency-conversion'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-currency-conversion')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo __('Filter', 'wdk-currency-conversion'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <table class="wp-list-table widefat fixed striped table-view-list pages">
            <thead>
                <tr>
                    <td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1"><?php echo __('Select All', 'wdk-currency-conversion'); ?></label><input id="cb-select-all-1" type="checkbox"></td>
                    <th style="width:50px;"><?php echo __('#ID', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Currency Code', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Symbol', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Conversion Index', 'wdk-currency-conversion'); ?></th>
                    <th class="actions_column"><?php echo __('Actions', 'wdk-currency-conversion'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($currencies) == 0) : ?>
                    <tr class="no-items">
                        <td class="colspanchange" colspan="6"><?php echo __('No Currencies Found.', 'wdk-currency-conversion'); ?></td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($currencies as $currency) : ?>
                    <tr>
                        <th scope="row" class="check-column">
                            <input id="cb-select-<?php echo wmvc_show_data('idcurrency', $currency, '-'); ?>" type="checkbox" name="post[]" value="<?php echo wmvc_show_data('idcurrency', $currency, '-'); ?>">
                            <div class="locked-indicator">
                                <span class="locked-indicator-icon" aria-hidden="true"></span>
                                <span class="screen-reader-text"><?php echo __('Is Locked', 'wdk-currency-conversion'); ?></span>
                            </div>
                        </th>
                        <td>
                            <?php echo wmvc_show_data('idcurrency', $currency, '-'); ?>
                        </td>
                        <td class="title column-title has-row-actions column-primary page-title" data-colname="Title">
                            <strong>
                                <a class="row-title" href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies-add&id=" . wmvc_show_data('idcurrency', $currency, '-'); ?>"><?php echo wmvc_show_data('currency_code', $currency, '-'); ?></a>
                                <?php if(!wmvc_show_data('is_activated', $currency, 0)): ?>
                                <span class="label label-danger"><?php echo __('Not Activated', 'wdk-currency-conversion'); ?></span>
                                <?php endif; ?>
                                <?php if(wmvc_show_data('is_default', $currency, 0)): ?>
                                <span class="label label-info"><?php echo __('Default', 'wdk-currency-conversion'); ?></span>
                                <?php endif; ?>
                            </strong>
                            <div class="row-actions">
                                <span class="edit"><a href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies-add&id=" . wmvc_show_data('idcurrency', $currency, '-'); ?>"><?php echo __('Edit', 'wdk-currency-conversion'); ?></a> | </span>
                                <span class="trash "><a href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idcurrency', $currency, '-'); ?>" class="submitdelete question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-currency-conversion');?>" ><?php echo __('Delete', 'wdk-currency-conversion'); ?></a></span>
                            </div>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('currency_symbol', $currency, '-'); ?>
                        </td>
                        <td>
                            <?php echo wmvc_show_data('conversion_index', $currency, '-'); ?>
                        </td>
                        <td class="actions_column">
                            <a href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies-add&id=" . wmvc_show_data('idcurrency', $currency, '-'); ?>"><span class="dashicons dashicons-edit"></span></a>
                            <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-currency-conversion');?>"  href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies&function=delete&paged=".esc_attr($paged)."&id=" . wmvc_show_data('idcurrency', $currency, '-'); ?>"><span class="dashicons dashicons-no"></span></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>    
            <tfoot>
                <tr>
                    <td class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-2"><?php echo __('Select All', 'wdk-currency-conversion'); ?></label><input id="cb-select-all-2" type="checkbox"></td>
                    <th style="width:50px;"><?php echo __('#ID', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Currency Code', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Symbol', 'wdk-currency-conversion'); ?></th>
                    <th><?php echo __('Conversion Index', 'wdk-currency-conversion'); ?></th>
                    <th class="actions_column"><?php echo __('Actions', 'wdk-currency-conversion'); ?></th>
                </tr>
            </tfoot>
        </table>
        <div class="tablenav bottom">
            <div class="alignleft actions bulkactions">
                <label for="bulk-action-selector-bottom" class="screen-reader-text"><?php echo __('Select bulk action', 'wdk-currency-conversion'); ?></label>
                <select name="action" id="bulk-action-selector-bottom">
                    <option value="-1"><?php echo __('Bulk actions', 'wdk-currency-conversion'); ?></option>
                    <option value="delete" class="hide-if-no-js"><?php echo __('Delete', 'wdk-currency-conversion'); ?></option>
                    <option value="deactivate" class="hide-if-no-js"><?php echo __('Deactivate', 'wdk-currency-conversion'); ?></option>
                    <option value="activate" class="hide-if-no-js"><?php echo __('Activate', 'wdk-currency-conversion'); ?></option>
                </select>
                <input type="hidden" name="page" value="wdk-currencies" />
                <input type="submit" id="table_action" class="button action" name="table_action" value="<?php echo esc_attr__('Apply', 'wdk-currency-conversion'); ?>">
            </div>

            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>

    <div class="tablenav bottom">
    <div class="tablenav-pages">
        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-currencies&function=import_exchangeratesapi"; ?>" class="button" id="exchangeratesapi_button"><?php echo __('External API Import/Sync', 'wdk-currency-conversion'); ?></a>
    </div>
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {

        $('.question_sure').on('click', function() {
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!', 'wdk-currency-conversion')); ?>");
        });

    });
</script>

<?php $this->view('general/footer', $data); ?>