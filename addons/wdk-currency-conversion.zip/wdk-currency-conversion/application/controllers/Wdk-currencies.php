<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_currencies_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('currency_m');

        /* [Table Actions Bulk Form] */

        $table_action = $this->input->post_get('table_action');
        $action = $this->input->post_get('action');
        $posts_selected = $this->input->post_get('post');

        if(!empty($table_action))
        {
            switch ($action) {
                case 'delete':
                    $this->bulk_delete($posts_selected);
                  break;
                case 'deactivate':
                    $this->bulk_deactivate($posts_selected);
                  break;
                case 'activate':
                    $this->bulk_activate($posts_selected);
                  break;
                default:
              } 
        }

        /* [Search Form] */

        $controller = 'currency';
        $columns = array('idcurrency', 'search', 'order_by', 'currency_code');
        $external_columns = array();

        $this->data['order_by']   = array('idcurrency DESC' => __('ID', 'wdk-currency-conversion').' DESC', 
                                          'idcurrency ASC' => __('ID', 'wdk-currency-conversion').' ASC',  );

        $rules = array(
                array(
                    'field' => 'search',
                    'label' => __('Search tag', 'wdk-currency-conversion'),
                    'rules' => ''
                ),
                array(
                    'field' => 'order_by',
                    'label' => __('Order By', 'wdk-currency-conversion'),
                    'rules' => ''
                ),
        );

        $this->data['db_data'] = $this->currency_m->prepare_data($this->input->get(), $rules);

        /* [/Search Form] */

        wdk_currencies_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->currency_m->total();

        //exit($this->db->last_query());

        $current_page = 1;

        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);

        $this->data['paged'] = $current_page;

        $per_page = 20;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_currencies_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['currencies'] = $this->currency_m->get_pagination($per_page, $offset);

        // Load view
        $this->load->view('wdk-currencies/index', $this->data);
    }

    public function delete()
    {
        $post_id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');

        $this->load->model('currency_m');

        $this->currency_m->delete($post_id);

        wp_redirect(admin_url("admin.php?page=wdk-currencies&paged=$paged"));
    }

    public function bulk_delete($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('currency_m');
    
            $this->currency_m->delete($post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-currencies"));
    }

    public function bulk_deactivate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('currency_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('currency_m', $post_id);
            $this->currency_m->insert(array('is_activated'=>NULL), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-currencies"));
    }

    public function bulk_activate($posts_selected)
    {
        foreach($posts_selected as $key=>$post_id)
        {
            $this->load->model('currency_m');
            if(function_exists('wdk_access_check'))
                wdk_access_check('currency_m', $post_id);
            $this->currency_m->insert(array('is_activated'=>1), $post_id);
        }

        wp_redirect(admin_url("admin.php?page=wdk-currencies"));
    }

    public function import_exchangeratesapi()
    {
        $this->load->model('currency_m');

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = array(
            array(
                'field' => 'exchangeratesapi_used',
                'field_label' => __('External API', 'wdk-currency-conversion'),              
                'values' => array(
                    '-' => esc_html__('Api not selected', 'wdk-currency-conversion'),
                    'exchangeratesapi.io' => esc_html__('exchangeratesapi.io', 'wdk-currency-conversion'),
                    'mindicador.cl' => esc_html__('mindicador.cl', 'wdk-currency-conversion'),
                ),
                'hint' => __('Select wanted API from supported above', 'wdk-currency-conversion'),
                'field_type' => 'DROPDOWN', 
                'rules' => ''
            ),
            array(
                'field' => 'exchangeratesapi_api_key',
                'field_label' => __('API Key', 'wdk-currency-conversion'),
                'hint' => __('You can get api key from related api like exchangeratesapi.io, mindicador.cl right now don\t need key so leave empty in such case', 'wdk-currency-conversion'),
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'exchangeratesapi_cron_enabled',
                'field_label' => __('Enable auto sync once per day', 'wdk-currency-conversion'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->data['fields'] as $key=>$field)
        {
            $this->data['fields'][$key]['label'] = $field['field_label'];
        }

        if($this->input->post('exchangeratesapi_used') == 'exchangeratesapi.io')
        {
            $this->data['fields'][1]['rules'] = 'required';
        }

        $this->data['db_data']['exchangeratesapi_used'] = get_option('exchangeratesapi_used');
        $this->data['db_data']['exchangeratesapi_api_key'] = get_option('exchangeratesapi_api_key');
        $this->data['db_data']['exchangeratesapi_cron_enabled'] = get_option('exchangeratesapi_cron_enabled');

        //exit($this->db->last_query());

        //$this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-currency-conversion'));
        //$this->form->add_error_message('reservation_date_exists', __('Date already in use for this Listing/Post', 'wdk-currency-conversion'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->currency_m->prepare_data($this->input->post(), $this->data['fields']);
            update_option('exchangeratesapi_used', sanitize_text_field($data['exchangeratesapi_used']));
            update_option('exchangeratesapi_api_key', sanitize_text_field($data['exchangeratesapi_api_key']));
            update_option('exchangeratesapi_cron_enabled', sanitize_text_field($data['exchangeratesapi_cron_enabled']));

            //old key
            //$results = wp_remote_request('http://api.exchangeratesapi.io/v1/latest?access_key='.$data['exchangeratesapi_api_key'], array() );

            if($data['exchangeratesapi_used'] == 'exchangeratesapi.io')
            {
                $params = array('apikey' => $data['exchangeratesapi_api_key']);

                $results = wp_remote_request('https://api.apilayer.com/exchangerates_data/latest', array('headers' => $params)  );
                
    
                $json_object = json_decode($results['body']);
    
                //dump($json_object);
    
                if(!is_null($json_object))
                {
                    if(isset($json_object->message))
                    {
                        $this->form->add_manual_error_message($json_object->message);
                    }
                    else
                    {
                        foreach((array) $json_object->rates as $currency_code=>$conversion_index)
                        {
                            $currency = $this->currency_m->get_by(array('currency_code' => $currency_code), TRUE);
    
                            $newid = NULL;
                            if(isset($currency->idcurrency))
                                $newid = $currency->idcurrency;
    
                            $data_insert = array(
                                'conversion_index' => $conversion_index,
                                'currency_code' => $currency_code
                            );
    
                            $this->currency_m->insert($data_insert, $newid);
                        }
    
                        if($data['exchangeratesapi_cron_enabled'] == '1')
                        {
                            if ( ! wp_next_scheduled( 'wdk_currencies_cron_exchangeratesapi' ) ) {
                                wp_schedule_event( time(), 'daily', 'wdk_currencies_cron_exchangeratesapi' );
                            }
                        }
                        else
                        {
                            wp_clear_scheduled_hook( 'wdk_currencies_cron_exchangeratesapi' );
                        }
    
                    }
                }
            }
            else if($data['exchangeratesapi_used'] == 'mindicador.cl')
            {
                $params = array();

                $results = wp_remote_request('https://mindicador.cl/api', array('headers' => $params)  );
    
                $json_array = (array) json_decode($results['body']);
    
                if(!is_null($json_array))
                {
                    if(!isset($json_array['fecha']))
                    {
                        $this->form->add_manual_error_message('Troubles with fetching api, try to open: https://mindicador.cl/api');
                    }
                    else
                    {
                        foreach($json_array as $currency_code=>$currency_object)
                        {
                            if(is_object($currency_object) && isset($currency_object->codigo))
                            {
                                $currency = $this->currency_m->get_by(array('currency_code' => $currency_object->codigo), TRUE);
    
                                $newid = NULL;
                                if(isset($currency->idcurrency))
                                    $newid = $currency->idcurrency;
        
                                $data_insert = array(
                                    'conversion_index' => $currency_object->valor,
                                    'currency_code' => $currency_object->codigo,
                                    'is_inversed_index' => 1,
                                    //'currency_symbol' => $currency_object->nombre
                                );
        
                                $this->currency_m->insert($data_insert, $newid);
                            }
                        }
    
                        if($data['exchangeratesapi_cron_enabled'] == '1')
                        {
                            if ( ! wp_next_scheduled( 'wdk_currencies_cron_exchangeratesapi' ) ) {
                                wp_schedule_event( time(), 'daily', 'wdk_currencies_cron_exchangeratesapi' );
                            }
                        }
                        else
                        {
                            wp_clear_scheduled_hook( 'wdk_currencies_cron_exchangeratesapi' );
                        }
    
                    }
                }
            }


            //wmvc_dump($results);



            /*
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-currencies&function=import_exchangeratesapi&is_updated=true"));
                exit;
            }*/
                
        }

        // Load view
        $this->load->view('wdk-currencies/import_exchangeratesapi', $this->data);
    }

}



