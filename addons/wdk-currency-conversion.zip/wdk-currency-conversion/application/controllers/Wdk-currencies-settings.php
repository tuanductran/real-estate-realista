<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_currencies_settings extends Winter_MVC_Controller {
    
	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('field_m');

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['db_data']['wdk_currency_conversion_fields'] = '';

        $Winter_MVC_WDK->db->where(array('field_type'=> 'NUMBER'));
        $this->data['fields'] = $Winter_MVC_WDK->field_m->get();

        $rules = array(
                array(
                    'field' => 'wdk_currency_conversion_fields',
                    'label' => __('Fields List', 'wdk-currency-conversion'),
                    'rules' => ''
                ),
        );

        if($this->form->run($rules))
        {
            // Save procedure for basic data
            $data = $this->input->post();

            $insert_id = update_option('wdk_currency_conversion_fields', sanitize_text_field($data['wdk_currency_conversion_fields']));

            //exit($this->db->last_error().$insert_id);

            // redirect
            
            if($insert_id)
            {
                wp_redirect(admin_url("admin.php?page=wdk-currencies-settings&is_updated=true"));
                exit;
            }
        }

        // generate/decode used fields
        $this->data['used_fields'] = array();
        
        if( get_option('wdk_currency_conversion_fields')) {
            $this->data['db_data']['wdk_currency_conversion_fields'] = get_option('wdk_currency_conversion_fields');
            $this->data['used_fields'] = explode(',',  get_option('wdk_currency_conversion_fields'));
        }

        $this->load->view('wdk-currencies-settings/index', $this->data);
    }
    
}