<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_currencies_add extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('currency_m');


        $id = $this->input->post_get('id');
        if(function_exists('wdk_access_check'))
            wdk_access_check('currency_m', $id);
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->currency_m->fields_list;

        //exit($this->db->last_query());

        //$this->form->add_error_message('post_exists', __('Listing/Post ID related doesn\'t exists', 'wdk-currency-conversion'));
        //$this->form->add_error_message('reservation_date_exists', __('Date already in use for this Listing/Post', 'wdk-currency-conversion'));

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->currency_m->prepare_data($this->input->post(), $this->data['fields']);

            // default reconfigcurrency_symbol
            if($data['is_default'] == '1')
            {
                $this->currency_m->update_where(array('is_default' => NULL), 'is_default', '1');
                
                global $Winter_MVC_WDK;
                $Winter_MVC_WDK->model('field_m');
        
                $fields = $Winter_MVC_WDK->field_m->get();
                foreach ($fields as $field) {
                    if(wdk_currencies_is_price_field($field->idfield)){
                        $Winter_MVC_WDK->field_m->insert(array('suffix'=>$data['currency_symbol'], 'prefix'=>''), $field->idfield);
                    }
                }

            }

            $insert_id = $this->currency_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-currencies-add&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->currency_m->get($id, TRUE);
        }

        // Load view
        $this->load->view('wdk-currencies-add/index', $this->data);
    }


}
