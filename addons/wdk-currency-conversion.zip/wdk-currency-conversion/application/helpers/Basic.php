<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
function wdk_currencies_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_currencies;
    $WMVC = &$Winter_MVC_wdk_currencies;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {
                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_booking_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

if(!function_exists('wdk_currencies_get_current_currency')) {
    function wdk_currencies_get_current_currency() {
        static $currency = NULL;

        if($currency) {
            return $currency;
        }

        if(isset($_COOKIE['wdk_currency'])) {
            $currency_code = trim(sanitize_text_field($_COOKIE['wdk_currency']));
            global $Winter_MVC_wdk_currency;
            $Winter_MVC_wdk_currency->model('currency_m');
            $currency = $Winter_MVC_wdk_currency->currency_m->get_currencies($currency_code, TRUE);
        
            if($currency) {
                return $currency;
            }
        }

        return false;
    }
}

if(!function_exists('wdk_currencies_get_default_currency')) {
    function wdk_currencies_get_default_currency() {
        static $currency = NULL;

        if($currency) {
            return $currency;
        }

        global $Winter_MVC_wdk_currency;
        $Winter_MVC_wdk_currency->model('currency_m');
        $currency = $Winter_MVC_wdk_currency->currency_m->get_default_currency();
    
        if($currency) {
            return $currency;
        }

        return false;
    }
}

if(!function_exists('wdk_currencies_price_convert')) {
    function wdk_currencies_price_convert($price = '', $number_format = TRUE) {
        
        static $current_currency;
        static $default_currency;

        if(empty($current_currency))
            $current_currency = wdk_currencies_get_current_currency();

        if(empty($default_currency))
            $default_currency = wdk_currencies_get_default_currency();
        
        if($current_currency && $default_currency && wmvc_show_data('is_default',$current_currency) != 1) {
            $current_currency_index = wmvc_show_data('conversion_index',$current_currency);
            $default_currency_index = wmvc_show_data('conversion_index',$default_currency);
            $is_inversed_index = wmvc_show_data('is_inversed_index', $current_currency);

            $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $price = (float)str_replace(array(","," ",'&nbsp;'), "", $price);

            if($is_inversed_index == 1)
            {
                $price = ($default_currency_index)/($current_currency_index)*($price);
            }
            else
            {
                $price = ($current_currency_index)/($default_currency_index)*($price);
            }

			$price = ($number_format) ? number_format_i18n($price,2) : $price;
        }
        return $price;
    }
}

if(!function_exists('wdk_currencies_symbol_convert')) {
    function wdk_currencies_symbol_convert($symbol = '') {
        $current_currency = wdk_currencies_get_current_currency();
        $default_currency = wdk_currencies_get_default_currency();
        
        if($current_currency) {
            $current_currency_symbol = wmvc_show_data('currency_symbol', $current_currency);
            if(empty($current_currency_symbol)) {
                $current_currency_symbol = wmvc_show_data('currency_code', $current_currency);
            }
            return $current_currency_symbol;
        }

        return $symbol;
    }
}

if(!function_exists('wdk_currencies_is_default_price')) {
    function wdk_currencies_is_default_price() {
        $current_currency = wdk_currencies_get_current_currency();

        if(!$current_currency || wmvc_show_data('is_default', $current_currency))
            return true;

        return false;
    }
}

if(!function_exists('wdk_currencies_is_price_field')) {
    function wdk_currencies_is_price_field($field_id = '') {
        static $prices_fields = NULL;
        
        if(is_null($prices_fields)) {
            if(get_option('wdk_currency_conversion_fields')) {
                foreach (explode(',',get_option('wdk_currency_conversion_fields')) as $key => $f_field_id) {
                    $prices_fields[$f_field_id] = true;
                }
            } else {
                $price_fields_list = wdk_resultitem_fields_section(5, 1);
                $prices_fields = array();
                foreach($price_fields_list as $field) {
                    $prices_fields[wmvc_show_data('field_id', $field)] = true;
                }
            }

            if(empty($prices_fields)) $prices_fields ='none';
        } 
        if(!empty($prices_fields) && $prices_fields !='none') {
            if(isset($prices_fields[$field_id])) return true;
        }
        return false;
    }
}

if(!function_exists('wdk_currencies_price_default_convert')) {
    function wdk_currencies_price_default_convert($price = '') {
        
        $current_currency = wdk_currencies_get_current_currency();
        $default_currency = wdk_currencies_get_default_currency();
        
        if($current_currency && $default_currency && wmvc_show_data('is_default',$current_currency) != 1) {
            $current_currency_index = wmvc_show_data('conversion_index',$current_currency);
            $default_currency_index = wmvc_show_data('conversion_index',$default_currency);
            $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $price = (float)str_replace(array(","," ",'&nbsp;'), "", $price);
            $price = number_format_i18n((($price)/($current_currency_index))*($default_currency_index), 2);
        }
        return $price;
    }
}

if(!function_exists('wdk_currencies_symbol_default_convert')) {
    function wdk_currencies_symbol_default_convert($symbol = '') {
        $current_currency = wdk_currencies_get_current_currency();
        $default_currency = wdk_currencies_get_default_currency();
        
        if($current_currency) {
            $current_currency_symbol = wmvc_show_data('currency_symbol', $default_currency);
            if(empty($current_currency_symbol)) {
                $current_currency_symbol = wmvc_show_data('currency_code', $default_currency);
            }
            return $current_currency_symbol;
        }

        return $symbol;
    }
}

?>