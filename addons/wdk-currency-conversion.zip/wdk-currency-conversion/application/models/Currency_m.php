<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Currency_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_currency';
	public $_order_by = 'is_activated DESC, currency_code';
    public $_primary_key = 'idcurrency';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        $this->fields_list = array(
            array(
                'field' => 'currency_code',
                'field_label' => __('Currency Code', 'wdk-currency-conversion'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'required'
            ),
            array(
                'field' => 'currency_symbol',
                'field_label' => __('Currency Symbol', 'wdk-currency-conversion'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'conversion_index',
                'field_label' => __('Conversion Index', 'wdk-currency-conversion'),
                'hint' => __('Based on Index we can calculate value in any currency with basic math, Example: if HRK = 1 USD, then HRK index = 7 and USD index = 1 (case then USD is default)', 'wdk-currency-conversion'),
                'field_type' => 'INPUTBOX', 
                'rules' => 'required|numeric'
            ),
            array(
                'field' => 'is_activated',
                'field_label' => __('Is Activated', 'wdk-currency-conversion'),
                'hint' => __('If you don\'t want to show it on website, then don\'t activate it', 'wdk-currency-conversion'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_inversed_index',
                'field_label' => __('Is Inversed Index', 'wdk-currency-conversion'),
                'hint' => __('Sometimes indexes are inversed, this is usualy on very small valued currencies like CLP', 'wdk-currency-conversion'), 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
            array(
                'field' => 'is_default',
                'field_label' => __('Is Default', 'wdk-currency-conversion'),
                'hint' => __('Please also change suffix on listing price field for this to work properly', 'wdk-currency-conversion'),
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }

	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array())
    {
        $post_table = $this->db->prefix.'posts';
        
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }

    public function get_currencies ($currency_code = NULL, $single = FALSE, $is_activated=1)
    {
        $where = array();

        if($is_activated == 1)
        {
            $where['is_activated'] = 1;
        }

        if($currency_code){
            $where['currency_code'] = $currency_code;
        }

        $this->db->where($where);

        $return = parent::get(null, $single);
        return $return;
    }
        
    public function get_default_currency ()
    {
        $this->db->where(array('is_activated' => 1,'is_default' => 1));

        $return = parent::get(null, TRUE);
        return $return;
    }
    
    public function check_deletable($id)
    {
        if(wmvc_user_in_role('administrator')) return true;

        return false;
    }
   
    public function delete($id) {

        if(!$this->check_deletable($id)) return false;

        parent::delete($id);

        return true;
    }

    public function update_where($data, $where_column, $where_value)
    {
        $this->db->update($this->_table_name, $data, $where_value, $where_column);
    }

}
?>