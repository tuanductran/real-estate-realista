<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Save_search_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_save_search';
	public $_order_by = 'idsave_search DESC';
    public $_primary_key = 'idsave_search';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    public $statuses_list = array();
    
	public function __construct(){
        parent::__construct();

        $this->fields_list = array(
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'USERS_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'parameters',
                'field_label' => __('Search Criteria', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'SAVE_SEARCH_QUERY', 
                'rules' => 'required'
            ),
            array(
                'field' => 'date',
                'field_label' => __('Date', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'date_notify',
                'field_label' => __('Last Date Notify', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_enable_email_notify',
                'field_label' => __('Email Alerts Enabled', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }


        $this->fields_list_dash = array(
            array(
                'field' => 'user_id',
                'field_label' => __('User', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'USERS_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'parameters',
                'field_label' => __('Search Criteria', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'SAVE_SEARCH_QUERY_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'date',
                'field_label' => __('Date', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'date_notify',
                'field_label' => __('Last Date Notify', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'DATE_READONLY', 
                'rules' => ''
            ),
            array(
                'field' => 'is_enable_email_notify',
                'field_label' => __('Email Alerts Enabled', 'wdk-save-search'),
                'hint' => '', 
                'field_type' => 'CHECKBOX', 
                'rules' => ''
            ),
        );

        foreach($this->fields_list_dash as $key=>$field)
        {
            $this->fields_list_dash[$key]['label'] = $field['field_label'];
        }
	}
  
    public function get($id = NULL, $single = FALSE)
    {
        return parent::get($id, $single);
    }
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE)
    {
        global $wpdb;

        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);

        $wp_usermeta_table = $wpdb->users;
        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.user_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));
        
        $this->db->order_by($this->_order_by);

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }

    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = TRUE)
    {
        global $wpdb;

        $this->db->from($this->_table_name);
        $this->db->where($where);

        $wp_usermeta_table = $wpdb->users;
        $this->db->select($this->_table_name.'.*, '.$wp_usermeta_table.'.display_name,'.$wp_usermeta_table.'.user_nicename, '.$wp_usermeta_table.'.user_login');
        $this->db->join($wp_usermeta_table.' ON '.$this->_table_name.'.user_id = '.$wp_usermeta_table.'.ID', NULL, 'LEFT');

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $query = $this->get(NULL, FALSE, $user_check);

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
                                        
        if(empty($user_id))
            $user_id = get_current_user_id();

        $item = $this->get($id, TRUE);
        if(isset($item->user_id) && $item->user_id == $user_id)
            return true;

        return false;
    }
    
     /* [END] For dynamic data table */
    
    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        /* remove */
        parent::delete($id);

        return true;
    }
  
    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $item = $this->get($item_id, TRUE);
        if(isset($item->user_id) && $item->user_id == $user_id)
            return true;
            
        return false;
    }
    
    public function check_if_exists($user_id, $parameters)
    {
        $this->db->from($this->_table_name);
        $this->db->where(array('user_id'=> $user_id, 
                               'parameters'=> $parameters));
        $query = $this->db->get();

        if (!empty($query))
            return true;

        return false;
    }
}
?>