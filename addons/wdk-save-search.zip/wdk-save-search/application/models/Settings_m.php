<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;


	public function __construct(){
        parent::__construct();

        $this->fields_list = array( 
            array(
                'field' => 'wdk_save_search_show_on_searchform', 
                'field_label' => __('Show on Search Form', 'wdk-save-search'), 
                'hint' => __('Please select for show in main search form', 'wdk-save-search'), 
                'field_type' => 'CHECKBOX', 
                'rules' => '', 
            ),
            array(
                'field' => 'wdk_save_search_alert_subject', 
                'field_label' => __('Alert Email Subject', 'wdk-save-search'), 
                'hint' => __('Please set custom alert Email Subject', 'wdk-save-search'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),

        );
	}
}
?>