<?php
/**
 * The template for Edit Save Search.
 *
 * This is the template that edit form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Save Search Management','wdk-save-search'); ?></h1>
    <?php if(!get_option('wdk_results_page')):?>
        <div class="alert alert-info" role="alert"><?php echo esc_html__('Not defined results page, please follow Directory kit -> Settings and set results page','wdk-save-search'); ?></div>
    <?php endif;?>
        <div class="wdk-body">
            <div class="postbox" style="display: block;">
                <div class="postbox-header"><h3><?php echo esc_html__('Edit Saved Search','wdk-save-search'); ?></h3>
            </div>
            <div class="inside">
                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
                    <?php 
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-save-search'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?> 
                    
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-save-search'); ?>">
                    <?php if(get_option('wdk_results_page')):?>
                    <a href="<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')), wmvc_show_data('parameters', $db_data, '-')); ?>" target="_blank" class="button button-default"><?php echo esc_html__('Show search','wdk-save-search'); ?></a>
                    <?php endif;?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $this->view('general/footer', $data); ?>