<?php
/**
 * The template for Settings.
 *
 * This is the template that edit form settings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('WDK Save Search Settings', 'wdk-save-search'); ?></h1>
    <br /><br />
    <div class="wdk-body">
    <div class="row fields_list">
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('General Settings', 'wdk-save-search'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-save-search'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>   

                    <div class="wdk-field-edit">
                        <a target="_blank" href="<?php echo esc_url(wdk_url_suffix(get_home_url(),'wdk_save_search_alert_cron=1')); ?>" class="button button-primary"><?php echo esc_html__('Run cronjob for email alerts manually','wdk-save-search'); ?></a> 
                    </div>
                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', 'wdk-save-search'); ?>">
        </form>
    </div>
</div>

<?php //$this->view('general/footer', $data); ?>