<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_save_search_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('save_search_m');


        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->data['post_types'] = array();

        $this->data['order_by']   = array(  'idreportabuse DESC' => __('ID', 'wdk-save-search').' DESC', 
                                            'idreportabuse ASC' => __('ID', 'wdk-save-search').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-save-search').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-save-search').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-save-search'),
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'label' => __('User', 'wdk-save-search'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->save_search_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'save_search';
        $columns = array('parameters', 'user_id','user_nicename','user_login');
        $external_columns = array('parameters', 'date','user_nicename','user_login');

        wdk_save_search_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->save_search_m->total( array(), FALSE);

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_save_search_prepare_search_query_GET($columns, $controller.'_m', $external_columns);

        $this->data['results'] = $this->save_search_m->get_pagination($per_page, $offset, array(), NULL, FALSE);
        
        // Load view
        $this->load->view('wdk_save_search/index', $this->data);
    }

	public function edit()
	{
        $this->load->model('save_search_m');

        $id = $this->input->post_get('id'); 
        if(function_exists('wdk_access_check'))
            wdk_access_check('save_search_m', $id);

        $this->data['db_data'] = NULL; 
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->save_search_m->fields_list;

        //exit($this->db->last_query());

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->save_search_m->prepare_data($this->input->post(), $this->data['fields']);
            unset($data['date_notify'],$data['date'],$data['user_id']);
            $insert_id = $this->save_search_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-save-search-add&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
            $this->data['db_data'] = $this->save_search_m->get($id, TRUE);
        }

        // Load view
        $this->load->view('wdk_save_search/edit', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('save_search_m');
        
        $this->save_search_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-save-search&paged=$paged"));
    }
    
}
