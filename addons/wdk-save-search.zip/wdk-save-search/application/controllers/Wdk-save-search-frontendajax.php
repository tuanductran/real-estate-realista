<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_save_search_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function save($output="", $atts=array(), $instance=NULL)
    {
		$this->load->load_helper('listing');
		$this->load->model('save_search_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

		$parameters = sanitize_text_field($_POST['parameters']);
        $user_id = get_current_user_id();
		if(empty($user_id))
        {
            $data['popup_text_error'] = __('Please login to use Save Search', 'wdk-save-search');
        } 

		if(empty($parameters))
        {
            $data['popup_text_error'] = __('Please define some search criteria', 'wdk-save-search');
        } 

		if(empty($data['popup_text_error'])) {
		
			if($this->save_search_m->check_if_exists($user_id, $parameters))
			{
				$data['popup_text_error'] = __('Search with this parameters already exists!', 'wdk-save-search');
				$data['success'] = true;
			}
			// Save favorites to database
			else
			{
				$data_save = array();
				$data_save['user_id'] = $user_id;
				$data_save['parameters'] = $parameters;
				$data_save['date'] = date('Y-m-d H:i:s');
				$data_save['date_notify'] = date('Y-m-d H:i:s');
				$data_save['is_enable_email_notify'] = 1;
				
				$insert_id = $this->save_search_m->insert($data_save, NULL);
				$data['popup_text_success'] = __('Search parameters saved!!', 'wdk-save-search');
				$data['success'] = true;
			}
		}

        
		$this->output($data);
    }


     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
