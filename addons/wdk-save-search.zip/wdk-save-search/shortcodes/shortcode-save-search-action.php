<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-save-search-action], show action add/remove save-search
*
* Layout path : 
* get_template_directory().'/wdk-save-search/shortcodes/views/shortcode-save-search-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-save-search-action.php'
*/

add_shortcode('wdk-save-search-action', 'wdk_save_search_action');
function wdk_save_search_action($atts, $content){
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'post_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;
    
    if(!wmvc_show_data('post_id', $data, false)){
        global $wdk_listing_id;
        if(isset($wdk_listing_id)){
            $data['post_id'] = $wdk_listing_id;
            $data['post_type'] = 'wdk-listing';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $data['post_id'] = $post_object_id;

            $data['post_type'] = get_post_type();
        }
    }

    /* Favorite module */
    $report_abuse_added=false;
    global $Winter_MVC_wdk_save_search; 
    if(get_current_user_id() != 0 && isset($Winter_MVC_wdk_save_search) && wmvc_show_data('post_id', $data, false))
    {
        $Winter_MVC_wdk_save_search->model('save_search_m');
        $report_abuse_added = $Winter_MVC_wdk_save_search->save_search_m->check_if_exists(get_current_user_id(), 
                                                                wmvc_show_data('post_id', $data));
        if($report_abuse_added>0)$report_abuse_added = true;
    }
    
    $data ['save-search_added'] = $report_abuse_added;
    /* End Favorite module */
    
    return wdk_save_search_shortcodes_view('shortcode-save-search-action', $data);
}

?>