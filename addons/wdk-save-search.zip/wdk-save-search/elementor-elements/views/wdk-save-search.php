<?php
/**
 * The template for Element Save Search Button.
 * This is the template that elementor element button search save
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div class="wdk-save-search-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-save-search" id="wdk_save_search">
        <a href="#" class="wdk-save-search-button" data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
            <?php if(wmvc_show_data('link_icon_position', $settings) == 'left') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['link_icon'], [ 'aria-hidden' => 'true', 'class'=>'left' ] ); ?>
                <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator left"></i>
            <?php endif;?>
            <?php echo esc_html(wmvc_show_data('link_text', $settings));?>
            <?php if(wmvc_show_data('link_icon_position', $settings) == 'right') :?>
                <?php \Elementor\Icons_Manager::render_icon( $settings['link_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
            <?php endif;?>
        </a>
    </div> 
</div>