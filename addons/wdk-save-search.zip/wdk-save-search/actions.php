<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

wdk_save_search_cron();
function wdk_save_search_cron()
{
    if ( ! wp_next_scheduled( 'wdk_save_search_schedule' ) ) {
        wp_schedule_event( time(), 'daily', 'wdk_save_search_schedule' );
    }

}

add_action( 'wdk_save_search_schedule', 'wdk_save_search_schedule_alert', 10, 2 );
function wdk_save_search_schedule_alert($print = FALSE)
{
    global $Winter_MVC_wdk_save_search;
    global $Winter_MVC_WDK;
    $Winter_MVC_wdk_save_search = new MVC_Loader(WDK_SAVE_SEARCH_PATH);

    $Winter_MVC_wdk_save_search->model('save_search_m');
    $Winter_MVC_WDK->model('listing_m');
    $Winter_MVC_WDK->load_helper('listing');
    
    $Winter_MVC_wdk_save_search->db->select($Winter_MVC_wdk_save_search->save_search_m->_table_name.'.*');
    $Winter_MVC_wdk_save_search->db->from($Winter_MVC_wdk_save_search->save_search_m->_table_name);
    $Winter_MVC_wdk_save_search->db->where('is_enable_email_notify','1');
    $Winter_MVC_wdk_save_search->db->get();
    $save_search = $Winter_MVC_wdk_save_search->db->results();

    $controller = 'listing'; 
    $columns = array('ID', 'location_id', 'category_id', 'post_title', 'post_date', 'search', 'order_by','is_featured', 'address');
    $external_columns = array('location_id', 'category_id', 'post_title');

    if($print)
        echo esc_html__('CRON START', 'wdk-save-search').'<br />';

    if($print)
        echo esc_html__('Saved Search find', 'wdk-save-search').': '.count($save_search).'<br />';

    $messages_count = 0;
    foreach($save_search as $search)
    {
        if(!empty($search->parameters) && !empty($search->user_id)) {
            $custom_parameters = array();
            $qr_string = trim($search->parameters);
            $string_par = array();
            parse_str($qr_string, $string_par);
            $custom_parameters = array_map('trim', $string_par);
            if(empty($search->date_notify))
                $search->date_notify = $search->date;

            wdk_prepare_search_query_GET($columns, $controller.'_m', $external_columns, $custom_parameters, true);
            $Winter_MVC_WDK->db->where(array( '(post_date > \''.esc_sql($search->date_notify).'\')' => NULL));
            $results = $Winter_MVC_WDK->listing_m->get_pagination(NULL, NULL, array('is_activated' => 1,'is_approved'=>1));
            
            $subject = esc_html__('New/Updated Listings by saved search', 'wdk-save-search');
            if(get_option('wdk_save_search_alert_subject'))
                $subject = get_option('wdk_save_search_alert_subject');

            $subject .= ' #'.$search->idsave_search;
            
            if($results) {
                if($print)
                    echo '<br /><br />'.esc_html__('Sending Email Alert', 'wdk-save-search').'<br />';

                $user_info = get_userdata($search->user_id);
                $link = wdk_url_suffix(get_permalink(get_option('wdk_results_page')), trim($search->parameters,'='));
                $link_edit = '';

                if(function_exists('wdk_dash_url') && get_option('wdk_membership_dash_page'))
                    $link_edit = wdk_dash_url("dash_page=save-search&function=edit&id=" . $search->idsave_search);

                if($print) {
                    echo esc_html__('Last date notify', 'wdk-save-search').': '.$search->date_notify.'<br />';
                    echo esc_html__('User', 'wdk-save-search').': #'.$search->user_id.', '.$user_info->display_name.' '.$user_info->user_email.'<br />';
                    echo esc_html__('Subject', 'wdk-save-search').': '.$subject.'<br />';
                    $data_message = array();
                    $data_message['user'] = $user_info;
                    $data_message['search_link_results']= $link;
                    $data_message['search_link_edit']= $link_edit;
                    $data_message['results']= $results;
                    $data_message['subject']= $subject;
                    $Winter_MVC_WDK->view('email/save_search_new_listings', $data_message, TRUE);
                }

                $data_message = array();
                $data_message['user'] = $user_info;
                $data_message['search_link_results']= $link;
                $data_message['search_link_edit']= $link_edit;
                $data_message['results']= $results;

                $ret = wdk_mail(wdk_show_data('user_email', $user_info ), $subject, $data_message, 'save_search_new_listings');

                // Save info about notified user
                $update_data = array('date_notify'=>current_time('mysql'));
                if($ret === TRUE)
                {
                    $Winter_MVC_wdk_save_search->save_search_m->insert($update_data, $search->idsave_search);
                    echo esc_html__('Sending Message SUCCESSFULLY', 'wdk-save-search').'<br />';
                }
                else
                {
                    echo '<b style="color:red;">'.esc_html__('Sending Message FAILED', 'wdk-save-search').'</b><br />';
                }

                $messages_count++;
            }
    
        }

    }
        
    if($print)
        echo '<br /><br />'.esc_html__('Total Email Alerts sent', 'wdk-save-search').': '.$messages_count.'<br />';

    if($print)
        echo esc_html__('CRON END', 'wdk-save-search').'<br />';

    exit('END wdk_save_search_alert');
}


function wdk_save_search_cron_manual()
{
    if(isset($_GET['wdk_save_search_alert_cron'])) {
        wdk_save_search_schedule_alert(TRUE);
        exit();
    }
}

add_action( 'init', 'wdk_save_search_cron_manual', 10, 2 );


add_action('wdk-membership/dash/homepage/widgets', function() {
    global $Winter_MVC_wdk_save_search;
    $Winter_MVC_wdk_save_search->model('save_search_m');
    $total_items = $Winter_MVC_wdk_save_search->save_search_m->total( array(), TRUE);

    if(function_exists('wdk_dash_url')) {
    ?>
    <div class="wdk-col-12 wdk-col-md-3 wdk-membership-dash-widget_savesearch"> 
        <a href="<?php echo esc_url(wdk_dash_url('dash_page=save-search'));?>" class="wdk-membership-dash-widget">
            <span class="wdk-content">
                <span class="icon"><span class="dashicons dashicons-code-standards"></span></span>
            </span>
            <span class="wdk-side">
                <span class="title"><?php echo esc_html__('Searches','wdk-save-search');?></span>
                <span class="wdk-count"><?php echo esc_html($total_items);?></span>
            </span>
        </a>
    </div>
    <?php
    }
});