(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */


	/* save search */
	jQuery(document).ready(function ($) {
		$('.wdk-save-search-button').on('click', function (e) {
			e.preventDefault();
			var this_form = $(this);
			var conf_link = this_form.attr('data-url') || 0;
			var load_indicator = this_form.find('.fa-ajax-indicator');
        
			var data = [];
			data.push({ name: 'action', value: "wdk_save_search_public_action" });
			data.push({ name: 'page', value: "wdk-save-search-frontendajax" });
			data.push({ name: 'function', value: "save" });

			var parameters = wdk_start_search($('.wdk-search-form'));
			data.push({ name: 'parameters', value: parameters });

			this_form.addClass('loading');
			$.post(conf_link, data,
				function (data) {
					if (data.popup_text_success)
						wdk_log_notify(data.popup_text_success);
				
					if (data.popup_text_error)
						wdk_log_notify(data.popup_text_error, 'error');
				
					if (data.success) {
			
					} else {
				
					}
				}).always(function (data) {
					this_form.removeClass('loading');
				});

			return false;
		});
	
		const wdk_start_search = (form) => {
			var url, data = {};
			url = form.attr('action').replace(/#results/, '');
			if (url.indexOf('?') == -1) {
				url += '?';
			} else {
				url += '&';
			}
			var str_parameters = "";
			$.each(form.serializeArray(), function (i, k) {
				if (k.value != '') {
					if (str_parameters != "") {
						str_parameters += "&";
					}
					if( k.name == 'wdk_search_additional_opened') return;
					if( $.trim(k.value) == '') return;

					str_parameters += k.name + "=" + encodeURIComponent(k.value);
				}
			});
			
			return str_parameters;
		}
		/* end save search */
	})
})(jQuery);