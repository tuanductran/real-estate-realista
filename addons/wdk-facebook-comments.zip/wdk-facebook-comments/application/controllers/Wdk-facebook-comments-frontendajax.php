<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_facebook_comments_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function report_abuse_send($output="", $atts=array(), $instance=NULL)
    {

		$this->load->load_helper('listing');
		$this->load->model('report_abuse_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();
		global $Winter_MVC_wdk_facebook_comments;

		$Winter_MVC_wdk_facebook_comments->input = new \MVC_Input();
		$Winter_MVC_wdk_facebook_comments->form = new \MVC_Form();
		
		$Winter_MVC_wdk_facebook_comments->model('report_abuse_m');
		/* save review */

		$fields_list = $Winter_MVC_wdk_facebook_comments->report_abuse_m->fields_list;
		if(
			(get_option('wdk_facebook_comments_recaptcha_site_key') && get_option('wdk_facebook_comments_recaptcha_secret_key'))
			|| (get_option('wdk_recaptcha_site_key') && get_option('wdk_recaptcha_secret_key'))
		) {
			$fields_list [] = array (
				'field' => 'g-recaptcha-response',
				'field_label' => __('Recaptcha', 'wdk-facebook-comments'),
				'hint' => '', 
				'field_type' => 'INPUTBOX', 
				'rules' => 'required|wdk_facebook_comments_valid_recaptcha',
			);
		}

		$Winter_MVC_wdk_facebook_comments->form->add_error_message('wdk_valid_recaptcha', __('Recaptcha is wrong', 'wdk-facebook-comments'));

		if($Winter_MVC_wdk_facebook_comments->form->run($fields_list))
		{

			// Save procedure for basic data
			$data_r = $Winter_MVC_wdk_facebook_comments->report_abuse_m->prepare_data($Winter_MVC_wdk_facebook_comments->input->post(), $fields_list);
			$data_r['date'] = date('Y-m-d H:i:s');

			if(isset($data_r['g-recaptcha-response'])) {
				unset($data_r['g-recaptcha-response']);
			}

			if(get_current_user_id())
				$data_r['user_id'] = get_current_user_id();
			// Save standard wp post

			$insert_id = $Winter_MVC_wdk_facebook_comments->report_abuse_m->insert($data_r);

			// Save procedure for basic data
		  
			/* message data */
			$data_message = array();
			$data_message['user'] = get_userdata( wmvc_show_data('user_id', $data_r) );
			$data_message['data'] = $data_r; /* report data */
			$data_message['data']['post_link'] = get_permalink(intval($_POST['post_id']));
			$data_message['report_abuse_id'] = $insert_id;

			$ret =  wdk_mail( get_bloginfo('admin_email'), __('New Report', 'wdk-facebook-comments'), $data_message, 'new_report');

			$data['success'] = true;

			$data['popup_text_success'] = __('Report sent', 'wdk-facebook-comments');

		} else {
			ob_start();
			$Winter_MVC_wdk_facebook_comments->form->messages();
			$data['message'] = ob_get_contents();
			ob_end_clean();
			
			$this->data['validation_messages'] = true;
		}

		$this->output($data);
    }

     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
