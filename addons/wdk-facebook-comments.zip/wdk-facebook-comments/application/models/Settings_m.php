<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Settings_m extends Winter_MVC_Model {

	public $_table_name = 'options';
	public $_order_by = 'option_id';
    public $_primary_key = 'option_id';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $fields_list = NULL;


	public function __construct(){
        parent::__construct();

        $this->fields_list = array( 
            array(
                'field' => 'wdk_facebook_comments_app_id', 
                'field_label' => __('Facebook App ID', 'wdk-facebook-comments'), 
                'hint' => __('Facebook App ID missing, you can create one here:', 'wdk-facebook-comments').' '.__('https://developers.facebook.com', 'wdk-facebook-comments'), 
                'field_type' => 'INPUTBOX', 
                'rules' => '', 
            ),
        );
	}
}
?>