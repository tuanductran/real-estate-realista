<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-facebook-comments-action], show action add/remove report-abuse
*
* Layout path : 
* get_template_directory().'/wdk-facebook-comments/shortcodes/views/shortcode-report-abuse-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-report-abuse-action.php'
*/

add_shortcode('wdk-facebook-comments-action', 'wdk_facebook_comments_action');
function wdk_facebook_comments_action($atts, $content){
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'post_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;
    
    if(!wmvc_show_data('post_id', $data, false)){
        global $wdk_listing_id;
        if(isset($wdk_listing_id)){
            $data['post_id'] = $wdk_listing_id;
            $data['post_type'] = 'wdk-listing';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $data['post_id'] = $post_object_id;

            $data['post_type'] = get_post_type();
        }
    }

    /* Favorite module */
    $report_abuse_added=false;
    global $Winter_MVC_wdk_facebook_comments; 
    if(get_current_user_id() != 0 && isset($Winter_MVC_wdk_facebook_comments) && wmvc_show_data('post_id', $data, false))
    {
        $Winter_MVC_wdk_facebook_comments->model('report_abuse_m');
        $report_abuse_added = $Winter_MVC_wdk_facebook_comments->report_abuse_m->check_if_exists(get_current_user_id(), 
                                                                wmvc_show_data('post_id', $data));
        if($report_abuse_added>0)$report_abuse_added = true;
    }
    
    $data ['report-abuse_added'] = $report_abuse_added;
    /* End Favorite module */
    
    return wdk_facebook_comments_shortcodes_view('shortcode-facebook-comments-action', $data);
}

?>