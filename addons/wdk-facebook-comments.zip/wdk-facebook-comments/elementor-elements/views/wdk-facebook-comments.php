<?php
/**
 * The template for Element Facebook Comments.
 * This is the template that elementor element facebook comment form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-facebook-comments-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-facebook-comments" id="wdk_facebook_comments">
        <div id="fb-root"></div> 
        <?php
            $current_url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            $current_url = str_replace('/www.', '/',  $current_url);
        ?>

        <div 
            class="fb-comments" 
            <?php /* test link */ if(false):?>
                data-href="https://developers.facebook.com/docs/plugins/comments#configurator"
            <?php endif;?>
            data-href="<?php echo esc_url($current_url);?>"
            data-colorscheme="<?php echo esc_attr(wdk_show_data('colorscheme',$settings,'', TRUE,TRUE));?>"
            data-lazy="<?php echo esc_attr(wdk_show_data('lazy',$settings,'', TRUE,TRUE));?>"
            data-mobile="<?php echo esc_attr(wdk_show_data('mobile',$settings,'', TRUE,TRUE));?>"
            data-numposts="<?php echo esc_attr(wdk_show_data('numposts',$settings,'4', TRUE,TRUE));?>"
            data-order-by="<?php echo esc_attr(wdk_show_data('order-by',$settings,'', TRUE,TRUE));?>"
            data-width="100%"
            >
        </div>

        <div class="text-note"><?php echo esc_html($settings['text_note']);?></div>
   
    </div> 
</div>

