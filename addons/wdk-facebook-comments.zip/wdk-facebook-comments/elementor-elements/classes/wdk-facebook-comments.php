<?php

namespace WdkFacebook_Сomments\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkFacebookСomments extends WdkFacebook_СommentsElementorBase {

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab (
            'tab_conf',
            esc_html__('Settings', 'wdk-facebook-comments')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_layout',
            esc_html__('Layout', 'wdk-facebook-comments')
        );

        \Elementor\Controls_Manager::add_tab (
            'tab_content',
            esc_html__('Main', 'wdk-facebook-comments')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);
    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-facebook-comments';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Facebook Comments', 'wdk-facebook-comments');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-facebook-comments';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-facebook-comments', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-facebook-comments'),
                'tab' => '1',
            ]
        );
        $this->add_control(
			'important_note',
			[
				'label' => esc_html__( 'Important Note', 'wdk-facebook-comments' ),
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw' => '<br>'.__( 'Comments Facebook Plugin is visible only if you are logged in to Facebook and you have tracking enabled in browser', 'wdk-facebook-comments' ),
				'content_classes' => 'your-class',
			]
		);
        if (!get_option('wdk_facebook_comments_app_id')) {
            $this->add_control(
                'important_note2',
                [
                'label' => esc_html__('Important Note', 'wdk-facebook-comments'),
                'type' => \Elementor\Controls_Manager::RAW_HTML,
                'raw' => '<br>'.sprintf(__('Facebook App ID missing, you can create one here: %1$s https://developers.facebook.com %2$s', 'wdk-facebook-comments'), '<a href="https://developers.facebook.com" target="_blank">', '</a>'),
                'content_classes' => 'your-class',
            ]
            );
        }

        $this->add_control(
            'text_note',
            [
                'label' => __( 'Text Note', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __( 'Comments Facebook Plugin is visible only if you are logged in to Facebook and you have tracking enabled in browser', 'wdk-facebook-comments' ),
            ]
        );

        $this->add_control(
            'colorscheme',
            [
                'label' => __( 'Colorscheme', 'wdk-facebook-comments' ),
                'description' => __( 'The color scheme used by the comments plugin. Can be "light" or "dark".', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'light',
                'options' => [
                    'light' => esc_html__('Light', 'wdk-facebook-comments'),
                    'dark' => esc_html__('Dark', 'wdk-facebook-comments'),
                ],
            ]
        );

        $this->add_control(
            'lazy',
            [
                'label' => __( 'Lazy load', 'wdk-facebook-comments' ),
                'description' => __( 'Means use the browser\'s lazy-loading mechanism', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'wdk-facebook-comments' ),
                'label_off' => __( 'Off', 'wdk-facebook-comments' ),
                'return_value' => 'true',
                'default' => 'false',
            ]
        );
        
        $this->add_control(
            'mobile',
            [
                'label' => __( 'Mobile', 'wdk-facebook-comments' ),
                'description' => __( 'Specifies whether to show the mobile-optimized version or not.', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'On', 'wdk-facebook-comments' ),
                'label_off' => __( 'Off', 'wdk-facebook-comments' ),
                'return_value' => 'true',
                'default' => 'false',
            ]
        );

        $this->add_control(
            'numposts',
            [
                'label' => __( 'Num Posts', 'wdk-facebook-comments' ),
                'description' => __( 'The number of comments to show by default. The minimum value is 1.', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 15,
                'step' => 1,
            ]
        );

        $this->add_control(
            'order-by',
            [
                'label' => __( 'Order By', 'wdk-facebook-comments' ),
                'description' => __( 'The order to use when displaying comments. Can be "reverse_time" or "time". The different order types are explained in the', 'wdk-facebook-comments' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'reverse-time',
                'options' => [
                    'reverse-time' => esc_html__('Reverse time', 'wdk-facebook-comments'),
                    'time' => esc_html__('Time', 'wdk-facebook-comments'),
                ],
            ]
        );

        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {
        $items = [
            [
                'key'=>'note_text_style',
                'label'=> esc_html__('Note Text Label', 'wdk-facebook-comments'),
                'selector'=>'.text-note',
                'options'=>'full',
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            $this->add_responsive_control(
                $item['key'].'_hide',
                    [
                            'label' => esc_html__( 'Hide Element', 'wdk-facebook-comments' ),
                            'type' => Controls_Manager::SWITCHER,
                            'none' => esc_html__( 'Hide', 'wdk-facebook-comments' ),
                            'block' => esc_html__( 'Show', 'wdk-facebook-comments' ),
                            'return_value' => 'none',
                            'default' => '',
                            'selectors' => [
                                '{{WRAPPER}} '.$item['selector'] => 'display: {{VALUE}};',
                            ],
                    ]
            );

            if( $item ['key'] == 'note_text_style'){
                $selectors = array(
                    'normal' => '{{WRAPPER}} '.$item['selector'],
                );
                $this->generate_renders_tabs($selectors, $item['key'].'_dynamic_align', ['align']);
            }

            $selectors = array(
                'normal' => '{{WRAPPER}} '.$item['selector'],
            );
            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options'], ['align']);

            $this->end_controls_section();
            /* END special for some elements */
        }
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-facebook-comments');
        wp_enqueue_script('facebook-sdk');
    }
}
