<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_SvgMap
 * @subpackage Wdk_SvgMap/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wdk_SvgMap
 * @subpackage Wdk_SvgMap/public
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */
class Wdk_SvgMap_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_SvgMap_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_SvgMap_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_register_style( 'wdk-geo-map-lib', plugin_dir_url( __FILE__ ) . 'css/wdk-geo-map-lib.css', array(), $this->version, 'all' );
		wp_register_style( 'wdk-svg-map', WDK_SVG_MAP_URL. 'elementor-elements/assets/css/widgets/wdk-svg-map.css', array(), $this->version, 'all' );
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wdk-svg-map-public.css', array(), $this->version, 'all' );
		
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wdk_SvgMap_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wdk_SvgMap_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		
		$params = array(
			'ajax_url' => admin_url( 'admin-ajax.php' )
		);

		if(function_exists('wdk_get_option')) {
			$params['wdk_get_submaps_enable'] = wdk_get_option( 'wdk_get_submaps_enable' );
		}

		wp_register_script( 'wdk-geo-map-lib', plugin_dir_url( __FILE__ ) . 'js/wdk-geo-map-lib.js', array( 'jquery' ), $this->version, false );
		wp_localize_script( 'wdk-geo-map-lib', 'wdk_geo_map_script_parameters', $params);
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wdk-svg-map-public.js', array( 'jquery' ), $this->version, false );

	}

	public function ajax_public()
	{
		global $Winter_MVC_wdk_svg_map;

		$page = '';
		$function = '';

		if(isset($_POST['page']))$page = wmvc_xss_clean($_POST['page']);
		if(isset($_POST['function']))$function = wmvc_xss_clean($_POST['function']);

		/* protect access only to ajax controller */
		if($page == 'wdk_svg_map_frontendajax') {
			$page = 'wdk-svg-map-frontendajax';
		} 

		if($page != 'wdk-svg-map-frontendajax') {
			exit(esc_html__('Access denied','wdk-svg-map'));
		} 

		$Winter_MVC_wdk_svg_map = new MVC_Loader(plugin_dir_path( __FILE__ ).'../');
		$Winter_MVC_wdk_svg_map->load_helper('basic');
		$Winter_MVC_wdk_svg_map->load_controller($page, $function, array());
	}


}
