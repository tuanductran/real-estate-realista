<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              wpdirectorykit.com
 * @since             1.0.0
 * @package           Wdk_SvgMap
 *
 * @wordpress-plugin
 * Plugin Name:       WDK SVG Maps
 * Plugin URI:        https://wpdirectorykit.com/plugins/wp-directory-svg-map.html
 * Description:       Enable Multiple SVG Maps in Elementor, Import Locations, Submaps locations support, quick search based on map
 * Version:           1.0.2
 * Requires PHP:      5.6
 * Author:            wpdirectorykit.com
 * Author URI:        https://wpdirectorykit.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wdk-svg-map
 * Domain Path:       /languages
 * 
 *  @fs_premium_only /premium_functions.php
 * 
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WDK_SVG_MAP_VERSION', '1.0.2' );
define( 'WDK_SVG_MAP_NAME', 'wdk-svg-map' );
define( 'WDK_SVG_MAP_PATH', plugin_dir_path( __FILE__ ) );
define( 'WDK_SVG_MAP_URL', plugin_dir_url( __FILE__ ) );
define( 'WDK_SVG_MAP_PACS_URL', WDK_SVG_MAP_URL.'public/svg_maps/' );
define( 'WDK_SVG_MAP_PACS_PATH', WDK_SVG_MAP_PATH.'public/svg_maps/' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wdk-svg-map-activator.php
 */
function activate_wdk_svg_map() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-svg-map-activator.php';
	Wdk_SvgMap_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wdk-svg-map-deactivator.php
 */
function deactivate_wdk_svg_map() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wdk-svg-map-deactivator.php';
	Wdk_SvgMap_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wdk_svg_map' );
register_deactivation_hook( __FILE__, 'deactivate_wdk_svg_map' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */

require plugin_dir_path( __FILE__ ) . 'includes/class-wdk-svg-map.php';


run_wdk_svg_map();

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wdk_svg_map() {

	$plugin = new Wdk_SvgMap();
	$plugin->run();

}

