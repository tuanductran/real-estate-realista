<?php

namespace WdkSvgMap\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkSvgMap extends WdkSvgMapElementorBase {

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-svg-map')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-svg-map')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-svg-map')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-svg-map';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Svg Map', 'wdk-svg-map');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-globe';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }


    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();

        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }
        // @codingStandardsIgnoreEnd

        $maps_data_json = $wp_filesystem->get_contents(WDK_SVG_MAP_PATH.'resourse/maps-list-db.json');
        $maps_data = json_decode($maps_data_json, JSON_OBJECT_AS_ARRAY);

        /* translate */
        $this->data['select_list'] = array();
        foreach ($maps_data as $location_key => $location) {
            $this->data['select_list'][str_replace('.svg', '', $location_key)] = esc_html__($location, 'wdk-svg-map');
        }

        $this->data['selected_maps'] = array();
        $this->data['svg_file_names'] = array();
        foreach ($this->data['settings']['section_locations_multi_maps'] as $map) {
            if(!empty($map['map'])) {
                $this->data['svg_file_names'][] = $map['map'];
                $this->data['selected_maps'][] = '"'.wmvc_show_data($map['map'], $this->data['select_list'], $map['map']).'"' ;
            }
        }

        /* get locations ids for root maps */
        $this->data['root_locations_id'] = array();
        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->db->where( $Winter_MVC_WDK->location_m->_table_name.'.location_title IN(' . implode(',', $this->data['selected_maps']) . ')', null);
        $location_related_root = $Winter_MVC_WDK->location_m->get();

        foreach ($location_related_root as $location) {
            $this->data['root_locations_id'][$location->location_title] = $location->idlocation;
        }

        echo $this->view('wdk-svg-map', $this->data);
    }

    private function generate_controls_conf() {
    }

    private function generate_controls_layout() {

        /* TAB_STYLE */ 
        $this->start_controls_section(
            'section_form_style',
            [
                'label' => __( 'Main', 'wdk-svg-map' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }
        // @codingStandardsIgnoreEnd

        $maps_data_json = $wp_filesystem->get_contents(WDK_SVG_MAP_PATH.'resourse/maps-list-db.json');
        $maps_data = json_decode($maps_data_json, JSON_OBJECT_AS_ARRAY);

        /* translate */
        $select_list = array();
        $select_list[''] = esc_html__('Not Selected', 'wdk-svg-map');
        foreach ($maps_data as $location_key => $location) {
            $select_list[str_replace('.svg', '', $location_key)] = esc_html__($location, 'wdk-svg-map');
        }

        $this->add_responsive_control(
                'column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-svg-map'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-svg-map-element .wdk-row .wdk-col' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-svg-map-element .wdk-row' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
                'row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-svg-map'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-svg-map-element .wdk-row .wdk-col' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-svg-map-element .wdk-row' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'search_in_hide',
                [
                        'label' => esc_html__( 'Hide Search in All', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .map-list .item_search_in' => 'display: {{VALUE}};',
                        ],
                        'separator' => 'before',
                ] 
        );    

        $this->end_controls_section();

        /* TAB_STYLE */ 
        $this->start_controls_section(
            'section_locations_list',
            [
                'label' => __( 'Location List', 'wdk-svg-map' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'list_location_hide',
                [
                        'label' => esc_html__( 'List Locations Hide', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .wdk-svg-map-element .wdk-row .wdk-col:first-child' => 'display: {{VALUE}};',
                        ],
                        'separator' => 'before',
                ] 
        );
        
        $this->add_responsive_control(
            'section_locations_list_position',
            [
                'label' => __( 'Position', 'wdk-svg-map' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wdk-svg-map' ),
                            'icon' => 'eicon-h-align-left',
                    ],
                    'top' => [
                            'title' => esc_html__( 'Top', 'wdk-svg-map' ),
                            'icon' => 'eicon-v-align-top',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wdk-svg-map' ),
                            'icon' => 'eicon-h-align-right',
                    ],
                    'bottom' => [
                            'title' => esc_html__( 'Bottom', 'wdk-svg-map' ),
                            'icon' => 'eicon-v-align-bottom',
                    ]
                ],
                'default' => 'left',
                'render_type' => 'template',
            ]
        );   
                    
        $this->add_responsive_control(
            'list_row_gap_col_inline',
            [
                    'label' => __( 'Columns', 'wdk-svg-map' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '' => esc_html__('Default', 'wdk-svg-map'),
                        'auto' => esc_html__('Auto', 'wdk-svg-map'),
                        '100%' => '1',
                        '50%' => '2',
                        'calc(100% / 3)' => '3',
                        '25%' => '4',
                        '20%' => '5',
                        'inline' => esc_html__('Inline', 'wdk-svg-map'),
                    ],
                    'selectors_dictionary' => [
                        'auto' => 'width:auto;-webkit-flex:0 0 auto;flex:0 0 auto',
                        '100%' =>  'width:100%;-webkit-flex:0 0 100%;flex:0 0 100%',
                        '50%' =>  'width:50%;-webkit-flex:0 0 50%;flex:0 0 50%',
                        'calc(100% / 3)' =>  'width:calc(100% / 3);-webkit-flex:0 0 calc(100% / 3);flex:0 0 calc(100% / 3)',
                        '25%' =>  'width:25%;-webkit-flex:0 0 25%;flex:0 0 25%',
                        '20%' =>  'width:20%;-webkit-flex:0 0 20%;flex:0 0 20%',
                        'inline' =>  'width:auto;flex: 0 0 auto;-webkit-flex: 0 0 auto;',
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-svg-map-element .map-list ul li' => '{{UNIT}}',
                    ],
                    'default' => '', 
                    'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
                'list_column_gap',
                [
                    'label' => esc_html__('Columns Gap', 'wdk-svg-map'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-svg-map-element .map-list ul li' => 'padding-left: {{SIZE}}{{UNIT}};padding-right: {{SIZE}}{{UNIT}};;',
                        '{{WRAPPER}} .wdk-svg-map-element .map-list ul' => 'margin-left: -{{SIZE}}{{UNIT}};margin-right: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
                'list_row_gap',
                [
                    'label' => esc_html__('Rows Gap', 'wdk-svg-map'),
                    'type' => Controls_Manager::SLIDER,
                    'default' => [
                        'size' => 10,
                    ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 60,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .wdk-svg-map-element .map-list ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                        '{{WRAPPER}} .wdk-svg-map-element .map-list ul' => 'margin-bottom: -{{SIZE}}{{UNIT}};',
                    ],
                ]
        );

        $this->add_responsive_control(
            'section_locations_list_align',
            [
                'label' => __( 'Align', 'wdk-svg-map' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-right',
                    ]
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'text-align:left;justify-content: flex-start;',
                    'center' => 'text-align:center;justify-content: center;',
                    'right' => 'text-align:right;justify-content: flex-end;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-svg-map-element .map-list ul' => '{{VALUE}};',
                ],
            ]
        );  

        $this->end_controls_section();

        /* TAB_STYLE */ 
        $this->start_controls_section(
            'section_locations_map',
            [
                'label' => __( 'Location Map', 'wdk-svg-map' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'section_locations_map_hide',
                [
                        'label' => esc_html__( 'SVG Map Locations Hide', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            '{{WRAPPER}} .wdk-svg-map-element .wdk-row .wdk-col:last-child' => 'display: {{VALUE}};',
                        ],
                        'separator' => 'before',
                ] 
        );    

        $this->add_responsive_control(
            'section_locations_map_align',
            [
                'label' => __( 'Align', 'wdk-svg-map' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                            'title' => esc_html__( 'Left', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                            'title' => esc_html__( 'Center', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                            'title' => esc_html__( 'Right', 'wdk-svg-map' ),
                            'icon' => 'eicon-text-align-right',
                    ]
                ],
                'render_type' => 'ui',
                'selectors_dictionary' => [
                    'left' => 'text-align:left',
                    'center' => 'text-align:center;',
                    'right' => 'text-align:right;',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-svg-map-element .wdk-row .wdk-col:last-child' => '{{VALUE}};',
                ],
            ]
        );       
        $this->end_controls_section();

        /* TAB_STYLE */ 
        $this->start_controls_section(
            'section_locations_multi_map',
            [
                'label' => __( 'Available Maps', 'wdk-svg-map' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

            $repeater = new Repeater();
            $repeater->start_controls_tabs( 'listings' );
                
            $repeater->add_control(
                'map',
                [
                        'label' => __( 'Map', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SELECT2,
                        'options' => $select_list,
                ]
            );

            $repeater->end_controls_tabs();

            $this->add_control(
                'section_locations_multi_maps',
                [
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        ['map'=>'world'],
                    ],
                    'title_field' => '{{{ map }}}',
                ]
            );

        $this->end_controls_section();
    }

    private function generate_controls_styles() {

        $items = [
            [
                'key'=>'tabs',
                'label'=> esc_html__('Tabs', 'wdk-svg-map'),
                'selector'=>'{{WRAPPER}} .wdk-svg-map-element .tab_label_panel .tab_label',
                'selector_hover'=>'{{WRAPPER}} .wdk-svg-map-element .tab_label_panel .tab_label%1$s',
                'options'=>['typo','color','padding','margin','background','border','border_radius','transition'],
            ],
            [
                'key'=>'list_map',
                'label'=> esc_html__('List', 'wdk-svg-map'),
                //'selector_hide'=>'{{WRAPPER}} .wdk-svg-map-element .map-list',
                'selector'=>'{{WRAPPER}} .wdk-svg-map-element .map-list ul li a',
                'selector_hover'=>'{{WRAPPER}} .wdk-svg-map-element .map-list ul li a%1$s',
                'options'=>['typo','color','background','border','border_radius','transition'],
            ],
        ];

        foreach ($items as $item) {
            $this->start_controls_section(
                $item['key'].'_section',
                [
                    'label' => $item['label'],
                    'tab' => 'tab_layout'
                ]
            );

            if(!empty($item['selector_hide'])) {
                $this->add_responsive_control(
                    $item['key'].'_hide',
                    [
                        'label' => esc_html__( 'Hide Element', 'wdk-svg-map' ),
                        'type' => Controls_Manager::SWITCHER,
                        'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                        'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                        'return_value' => 'none',
                        'default' => '',
                        'selectors' => [
                            $item['selector_hide'] => 'display: {{VALUE}};',
                        ],
                        ]
                );
            }

            if($item['key'] == 'tabs') {
                $this->add_responsive_control(
                    $item['key'].'_parent_align',
                    [
                        'label' => __( 'Align', 'wdk-svg-map' ),
                        'type' => Controls_Manager::CHOOSE,
                        'options' => [
                            'left' => [
                                    'title' => esc_html__( 'Left', 'wdk-svg-map' ),
                                    'icon' => 'eicon-text-align-left',
                            ],
                            'center' => [
                                    'title' => esc_html__( 'Center', 'wdk-svg-map' ),
                                    'icon' => 'eicon-text-align-center',
                            ],
                            'right' => [
                                    'title' => esc_html__( 'Right', 'wdk-svg-map' ),
                                    'icon' => 'eicon-text-align-right',
                            ]
                        ],
                        'render_type' => 'ui',
                        'selectors_dictionary' => [
                            'left' => 'text-align:left',
                            'center' => 'text-align:center;',
                            'right' => 'text-align:right;',
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .wdk-svg-map-element .tab_label_panel' => '{{VALUE}};',
                        ],
                    ]
                ); 
            }

            $selectors = array();

            if(!empty($item['selector']))
                $selectors['normal'] = $item['selector'];

            if(!empty($item['selector_hover']))
                $selectors['hover'] = $item['selector_hover'];

            if(!empty($item['selector_focus']))
                $selectors['focus'] = $item['selector_hover'];

            $this->generate_renders_tabs($selectors, $item['key'].'_dynamic', $item['options']);

            $this->end_controls_section();
        }

        $this->start_controls_section(
            'map_back_section',
            [
                'label' => esc_html__( 'Back Navigation Button', 'wdk-svg-map' ),
                'tab' => 'tab_layout'
            ]
        );

        $this->add_responsive_control(
            'map_back_hide',
            [
                'label' => esc_html__( 'Hide Element', 'wdk-svg-map' ),
                'type' => Controls_Manager::SWITCHER,
                'none' => esc_html__( 'Hide', 'wdk-svg-map' ),
                'block' => esc_html__( 'Show', 'wdk-svg-map' ),
                'return_value' => 'none',
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .wdk-svg-map-element .wdk-svg-map-box .map-back' => 'display: {{VALUE}};',
                ],
            ]
        );

        $selectors = array(
            'normal'=> '{{WRAPPER}} .wdk-svg-map-element .wdk-svg-map-box .map-back .dashicons ',
            'hover'=> '{{WRAPPER}} .wdk-svg-map-element .wdk-svg-map-box .map-back%1$s .dashicons ',
        );

        $this->generate_renders_tabs($selectors, 'map_back_icon_dynamic', ['font-size','color','padding']);

        $this->add_responsive_control(
            'map_back_text_head',
            [
                'label' => esc_html__('Text', 'wdk-svg-map'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $selectors = array(
            'normal'=> '{{WRAPPER}} .wdk-svg-map-element .wdk-svg-map-box .map-back .name',
            'hover'=> '{{WRAPPER}} .wdk-svg-map-element .wdk-svg-map-box .map-back%1$s .name',
        );

        $this->generate_renders_tabs($selectors, 'map_back_text_dynamic', ['margin','typo','color','padding','transition']);

        $this->end_controls_section();

        $this->start_controls_section(
            'svg_map_section',
            [
                'label' => esc_html__( 'Svg Map', 'wdk-svg-map' ),
                'tab' => 'tab_layout'
            ]
        );

        $this->add_control(
            'map_color_hover',
            [
                'label' => esc_html__( 'Color Hover', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#0074E4',
            ]
        );

        $this->add_control(
            'map_color_active',
            [
                'label' => esc_html__( 'Color Active', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#0074E4',
            ]
        );
        $this->add_control(
            'map_color_default',
            [
                'label' => esc_html__( 'Color Defaul', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#F9F9F9',
            ]
        );
        $this->add_control(
            'map_color_border',
            [
                'label' => esc_html__( 'Color Border', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#404040',
            ]
        );
        $this->add_control(
            'map_color_border_hover',
            [
                'label' => esc_html__( 'Color Border Hover', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
            ]
        );
        $this->add_control(
            'map_color_border_active',
            [
                'label' => esc_html__( 'Color Border Active', 'wdk-svg-map' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
            ]
        );
                        
        $this->end_controls_section();
                        
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-svg-map');
        wp_enqueue_style('wdk-geo-map-lib');
        wp_enqueue_style('dashicons');
        wp_enqueue_script('wdk-geo-map-lib');
    }
}
