<?php
/**
 * The template for Element Reviews Average.
 * This is the template that elementor element, fields, search form
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<div class="wdk-svg-map-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-svg-map-content">

        <?php if(count($svg_file_names)>1):?>
        <div class="tab_label_panel">
            <?php foreach ($svg_file_names as $key => $svg_map):?>
                <label class="tab_label <?php if($key == 0):?>active<?php endif;?>" for="wdk_el_<?php echo esc_html($id_element);?>_svg_tab_<?php echo esc_attr($key);?>"><?php echo esc_html(wmvc_show_data($svg_map, $select_list, $svg_map));?></label>
            <?php endforeach;?>
        </div>
        <?php endif;?>
        <div class="tabs
             location_list_position_<?php echo (isset($settings['section_locations_list_position'])) ? esc_attr($settings['section_locations_list_position']) : '';?> 
             location_list_position_tablet_<?php echo (isset($settings['section_locations_list_position_tablet'])) ? esc_attr($settings['section_locations_list_position_tablet']) : '';?> 
             location_list_position_mobile_<?php echo (isset($settings['section_locations_list_position_mobile'])) ? esc_attr($settings['section_locations_list_position_mobile']) : '';?> 
            <?php echo ($settings['list_row_gap_col_inline'] == 'inline') ? '' : 'list_padding_left_animation';?>">
            <?php foreach ($svg_file_names as $key => $svg_map):?>
                <input <?php if($key == 0):?>checked="checked"<?php endif;?> type="radio" id="wdk_el_<?php echo esc_html($id_element);?>_svg_tab_<?php echo esc_attr($key);?>" name="svg_tab" value="<?php echo esc_attr($key);?>">
                <div class="tab">
                    <div class="wdk-row">
                        <div class="wdk-col col-list">
                            <div class="map-list">
                            </div>
                        </div>
                        <div class="wdk-col col-map">
                            <div class="wdk-svg-map-box">
                                <a href="#" class="map-back" style="display: none"><span class="dashicons dashicons-undo"></span><span class="name"></span></a>
                                <div class="wdk_svg_map" data-map="<?php echo esc_attr($svg_map);?>" <?php if(isset($root_locations_id[wmvc_show_data($svg_map, $select_list, $svg_map)])):?> data-location-id="<?php echo esc_attr($root_locations_id[wmvc_show_data($svg_map, $select_list, $svg_map)]);?>" <?php endif;?>></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
        </div>
      
        <script>
            jQuery(document).ready(function($) {
                jQuery('#wdk_el_<?php echo esc_html($id_element);?> .tabs .tab').each(function(){
                    var that = $(this);

                    var geomap = that.find('.wdk_svg_map').WdkSvgMap('set_config', {
                        'base_path': '<?php echo esc_js(WDK_SVG_MAP_PACS_URL);?>',
                        'color_hover': '<?php echo esc_js($settings['map_color_hover']);?>',
                        'color_active': '<?php echo esc_js($settings['map_color_active']);?>',
                        'color_default': '<?php echo esc_js($settings['map_color_default']);?>',
                        'color_border': '<?php echo esc_js($settings['map_color_border']);?>',
                        'color_border_hover': '<?php echo esc_js($settings['map_color_border_hover']);?>',
                        'color_border_active': '<?php echo esc_js($settings['map_color_border_active']);?>',
                    });
                
                    /* events */
                    geomap.on('map_generated.WdkSvgMap', function(event){
                        var map_back = that.find('.map-back');
                        if(event.tree_maps.length) {
                            console.log(event.tree_maps);
                            var names = '';
                            for (let el of event.tree_maps) {
                                if(names !='')
                                    names += ' - ';
                                names += el.location_name;
                            }
                            map_back.find('.name').html(names);

                            map_back.show().off().on('click', function(e){
                                e.preventDefault();
                                geomap.WdkSvgMap('set_pre_map');
                            });
                        } else {
                            map_back.hide();
                        }
                        
                        var html = "";
                        if(event.locations_list) {
                            html += "<ul>"

                            html += "<li class='item_search_in'>";
                            /* sub maps */
                            if(event.tree_maps.length) {
                                let el = event.tree_maps[event.tree_maps.length-1];
                                let url = '<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'field_search='); ?>'+el.location_name;
                                if(el.location_id) {
                                    url = '<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'search_location='); ?>'+el.location_id;
                                }

                                html += "<a href='"+url+"' class='location search_in'><?php echo esc_js(__('Search', 'wdk-svg-map'));?> "+el.location_name+"</a>"

                            } else {
                                let url = '<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'field_search='); ?>'+event.location_name;
                                if(that.find('.wdk_svg_map').attr('data-location-id')) {
                                    url = '<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'search_location='); ?>'+that.find('.wdk_svg_map').attr('data-location-id');
                                }
                                html += "<a href='"+url+"' class='location search_in'><?php echo esc_js(__('Search', 'wdk-svg-map'));?> "+event.location_name+"</a>"
                            }
                            html += "</li>";

                            jQuery.each(event.locations_list, function(index,value){
                                html += "<li><a href='#' class='location' data-path='"+index+"'>"+value+"</a></li>"
                            })
                            html += "<li class='toggle-collapse'><a href='#' class='location'><?php echo __('Show More...', 'wdk-svg-map');?></a></li>"
                            html += "</ul>"
                        } else {

                        }

                        that.find('.map-list').html(html);
                        
                        that.find('.map-list a.location:not(.search_in)').on('click', function(e){
                            e.preventDefault();
                            geomap.WdkSvgMap('set_location', $(this).attr('data-path'));
                        })

                        that.find('.map-list a.location:not(.search_in)').on('mouseover', function(e){
                            e.preventDefault();
                            geomap.WdkSvgMap('hover_location', $(this).attr('data-path'));
                        })

                        var show_count = 16;
                        if(that.find('.map-list ul li:not(.toggle-collapse)').length > show_count) {
                            that.find('.map-list ul li:not(.toggle-collapse)').eq(show_count).nextAll().not(".toggle-collapse").hide();
                            
                            that.find('.map-list ul li.toggle-collapse a').attr('data-close', 'true');
                            that.find('.map-list ul li.toggle-collapse a').on('click', function(e){

                                if($(this).attr('data-close') == 'true') {
                                    $(this).attr('data-close', 'false').html('<?php echo __('Hide more...', 'wdk-svg-map');?>');
                                    that.find('.map-list ul li:not(.toggle-collapse)').show();
                                } else {
                                    jthat.find('.map-list ul li:not(.toggle-collapse)').eq(show_count).nextAll().not(".toggle-collapse").hide();
                                    $(this).attr('data-close', 'true').html('<?php echo __('more', 'wdk-svg-map');?>');
                                }

                            });
                        } else {
                            that.find('.map-list ul li.toggle-collapse').hide();
                        }
                    });

                    /* open location link */
                    geomap.on('location_selected.WdkSvgMap', function(event){
                        if(typeof event.location_id !='undefined' && event.location_id) {
                            window.location.href= "<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'search_location='); ?>"+event.location_id
                        } else {
                            window.location.href= "<?php echo wdk_url_suffix(get_permalink(get_option('wdk_results_page')),'field_search='); ?>"+event.location_name
                        }
                    });

                    geomap.WdkSvgMap('generate_map',  that.find('.wdk_svg_map').attr('data-map'));

                });

                jQuery('#wdk_el_<?php echo esc_html($id_element);?> .tab_label_panel .tab_label').on('click', function(){
                    $(this).addClass('active').siblings().removeClass('active');
                    jQuery('#'+$(this).attr('for')).next().find('.wdk_svg_map').WdkSvgMap('set_root_location');
                })
            });
        </script>
    </div>
</div>
 