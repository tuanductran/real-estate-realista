<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_svg_map_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function get_maps_data($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;

		if(empty($data['popup_text_error'])) {
			global $wp_filesystem;
			// Initialize the WP filesystem, no more using 'file-put-contents' function
			if (empty($wp_filesystem)) {
				require_once (ABSPATH . '/wp-admin/includes/file.php');
				WP_Filesystem();
			}
			// @codingStandardsIgnoreEnd

			$maps_data_json = $wp_filesystem->get_contents(WDK_SVG_MAP_PATH.'resourse/maps-db.json');
			$maps_data = json_decode($maps_data_json, JSON_OBJECT_AS_ARRAY);

			/* translate */
			foreach ($maps_data as $map_key => $map) {
				$maps_data[$map_key]['name'] = esc_html($map['name'], 'wdk-svg-map');
				foreach ($map['locations'] as $location_key => $location) {
					$maps_data[$map_key]['locations'][$location_key] = esc_html($location, 'wdk-svg-map');
				}
				asort($maps_data[$map_key]['locations']);
			}

			/* overwrite from db */
			global $Winter_MVC_WDK;
			$Winter_MVC_WDK->model('location_m');
			$locations_related_db = $Winter_MVC_WDK->location_m->get_by(array('(related_svg_map IS NOT NULL AND related_svg_map_location IS NOT NULL)'=>NULL));
			foreach ($locations_related_db as $locations_db) {
				if(isset($maps_data[$locations_db->related_svg_map]['locations'][$locations_db->related_svg_map_location])) {
					$maps_data[$locations_db->related_svg_map]['locations'][$locations_db->related_svg_map_location] = $locations_db->location_title;
					$maps_data[$locations_db->related_svg_map]['locations_id'][strtolower($locations_db->related_svg_map_location)] = $locations_db->idlocation;
					asort($maps_data[$locations_db->related_svg_map]['locations']);
				}
			}
			$data['success'] = true;
			$data['output'] = $maps_data;
		}

		$this->output($data);
    }

    public function get_map_data($output="", $atts=array(), $instance=NULL)
    {
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
        $data['output'] = '';
		$data['success'] = false;
		        
        $parameters = array();
		foreach ($_POST as $key => $value) {
			$parameters[$key] = sanitize_text_field($value);
		}

		if(empty($parameters['related_svg_map'])) {
			$data['popup_text_error'] = esc_html__('SVG map did not set','wdk-svg-map');
		}
		
		$map_data = NULL;
		if(empty($data['popup_text_error'])) {
			global $wp_filesystem;
			// Initialize the WP filesystem, no more using 'file-put-contents' function
			if (empty($wp_filesystem)) {
				require_once (ABSPATH . '/wp-admin/includes/file.php');
				WP_Filesystem();
			}
			// @codingStandardsIgnoreEnd

			$maps_data_json = $wp_filesystem->get_contents(WDK_SVG_MAP_PATH.'resourse/maps-db.json');
			$maps_data = json_decode($maps_data_json, JSON_OBJECT_AS_ARRAY);

			/* translate */
			foreach ($maps_data as $map_key => $map) {
				$maps_data[$map_key]['name'] = esc_html($map['name'], 'wdk-svg-map');
				foreach ($map['locations'] as $location_key => $location) {
					$maps_data[$map_key]['locations'][$location_key] = esc_html($location, 'wdk-svg-map');
				}

				asort($maps_data[$map_key]['locations']);
			}

			if(isset($parameters['related_svg_map']))
				$map_data = $maps_data[$parameters['related_svg_map']];
			
			$data['success'] = true;
			$data['output'] = $map_data;
		}

		$this->output($data);
    }
     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
