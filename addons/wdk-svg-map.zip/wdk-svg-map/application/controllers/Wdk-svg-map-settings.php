<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_svg_map_settings extends Winter_MVC_Controller {
    public $import_log = '';
    
	public function __construct(){
		parent::__construct();
	}
    
    public function index()
	{
        $this->load->model('settings_m');
        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;
        $this->data['fields'] = $this->settings_m->fields_list;

        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
    
            $data = $this->settings_m->prepare_data($this->input->post(), $this->data['fields']);

            // Save standard wp post
            foreach($data as $key => $val)
            {
                update_option( $key, $val, TRUE);
            }  

            // redirect
            if(empty($listing_post_id) && !empty($id))
            {
                //wp_redirect(admin_url("admin.php?page=wdk_settings&is_updated=true"));
                exit;
            }
                
        }

        // fetch data, after update/insert to get updated last data
        $fields_data = $this->settings_m->get();

        /* slug udpate rules*/
        //flush_rewrite_rules();

        foreach($fields_data as $field)
        {
            $this->data['db_data'][$field->option_name] = $field->option_value;
        }

        $this->load->view('wdk_settings/index', $this->data);
    }

    // Import demo data listing method
	public function generated_maps()
	{
        $this->data['installed'] = false;
        ini_set('max_execution_time', 900);   

        $this->data['db_data'] = NULL;
        $this->data['fields'] = array( 
            array('field' => 'generate_maps_db', 'field_label' => __('Generate maps db', 'wdk-svg-map'), 'hint' => __('Generate maps data', 'wdk-svg-map'), 'field_type' => 'CHECKBOX', 'rules' => ''),
        );

        $this->data['form'] = &$this->form;

        
        
        foreach($this->data['fields'] as $field)
        {
            $this->data['db_data'][$field['field']] = 1;
        }
        
        $this->data['import_log'] = '';
        $rules = array(
            array(
                'field' => 'generate_maps_db',
                'label' => __('Settings', 'wdk-svg-map'),
                'rules' => ''
            ),
        );    

        if($this->form->run($rules))
        {
            // Save procedure for basic data
            $data = $this->input->post();
         
            if( !empty($data['generate_maps_db'])) {
                $errors_svg = array();
                $geo_map_list = array();
                $geo_maps = array();
                $geo_tree_maps = array();
                $svg_path = WDK_SVG_MAP_PACS_PATH;
        
                global $wp_filesystem;
                // Initialize the WP filesystem, no more using 'file-put-contents' function
                if (empty($wp_filesystem)) {
                    require_once (ABSPATH . '/wp-admin/includes/file.php');
                    WP_Filesystem();
                }
                // @codingStandardsIgnoreEnd
                
                if( file_exists($svg_path)) {
                    $svg_files = array_diff( scandir($svg_path), array('..', '.'));
                
                    foreach ($svg_files  as $svg_name) {
        
                        $map_data = wdk_svg_map_generate_map_data($svg_path.$svg_name);
                        if($map_data) {
                            $geo_maps[strtolower($map_data['location_key'])] = $map_data;
                            $geo_map_list[$svg_name] = $map_data['name'];
                        }
                        else {
                            $errors_svg[] = "<p class='alert alert-danger alert-dismissible'>Map ".$svg." is not formatted correctly</p>";
                        }
                    }
                }
        
                /* generated map json and translate */
                
                $count_file = 1;
                $limit_size = '80000';
                $file_strings_content = '<?php ';
                foreach($geo_maps as $map)
                {
                    $file_strings_content.= '__(\''.addslashes($map['name']).'\',\'wdk-svg-map\');'."\n";
        
                    $file_strings_content.= '__(\''.addslashes($map['location_key']).'\',\'wdk-svg-map\');'."\n";
        
                    foreach ($map['locations'] as $maps_location) {
                        $file_strings_content.= '__(\''.addslashes($maps_location).'\',\'wdk-svg-map\');'."\n";
                    }
        
                    if(strlen($file_strings_content) > $limit_size) {
                        $file_strings_content.= "\n".'?>';
                        $wp_filesystem->put_contents(WDK_SVG_MAP_PATH.'translation_strings/strings_'.$count_file.'.php', $file_strings_content);
        
                        /* create new file */
                        $file_strings_content = '<?php ';
                        $count_file++;
                    }
                }
                $file_strings_content.= "\n".'?>';
                
                if(!empty($file_strings_content))
                    $wp_filesystem->put_contents(WDK_SVG_MAP_PATH.'translation_strings/strings_'.$count_file.'.php', $file_strings_content);
        
                $wp_filesystem->put_contents(WDK_SVG_MAP_PATH.'resourse/maps-db.json', json_encode($geo_maps));
                $wp_filesystem->put_contents(WDK_SVG_MAP_PATH.'resourse/maps-list-db.json', json_encode($geo_map_list));
                $this->data['import_log'] .= '<div class="alert alert-success" role="alert">'.esc_html__('Generated', 'wdk-svg-map').'</div>';        
            }
            
            update_option('wdk_svgmap_generated_maps', '1');
        } 
        $this->load->view('wdk_settings/generated_maps', $this->data);
    }


}