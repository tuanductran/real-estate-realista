<?php
/**
 * The template for Settings.
 *
 * This is the template that form edit settings
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('WDK Svg Map Settings', 'wdk-svg-map'); ?></h1>
    <div class="wdk-body">
    <div class="row fields_list">
        <form method="post" action="" novalidate="novalidate">
            <div class="postbox" style="display: block;">
                <div class="postbox-header">
                    <h3><?php echo esc_html__('General Settings', 'wdk-svg-map'); ?></h3>
                </div>
                <div class="inside">
                    <?php
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-svg-map'));
                    ?>
                    <?php echo wdk_generate_fields($fields, $db_data); ?>   

                    <div class="wdk-field-edit">
                        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-svg-map-settings&function=generated_maps"; ?>" class="button button-primary" id="import_demo_field_button"><?php echo esc_html__('Generate Data Maps','wdk-svg-map'); ?></a> 
                    </div>
                </div>
            </div>
            <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes', 'wdk-svg-map'); ?>">
        </form>
    </div>
</div>

<?php //$this->view('general/footer', $data); ?>