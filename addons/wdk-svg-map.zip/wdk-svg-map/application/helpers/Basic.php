<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}


if(!function_exists('wdk_svg_map_generate_map_data')) {
    function wdk_svg_map_generate_map_data($map_file = NULL) {
        $output = array();
        $location_name ='';
        $location_key ='';

        if(empty($map_file)) return NULL;

        global $wp_filesystem;
        // Initialize the WP filesystem, no more using 'file-put-contents' function
        if (empty($wp_filesystem)) {
            require_once (ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }
        // @codingStandardsIgnoreEnd
        
        $svg = $wp_filesystem->get_contents($map_file);

        $match = '';
        preg_match_all('/(data-title-map)=("[^"]*")/i', $svg, $match);
        if(!empty($match[2])) {
            $location_name = trim(str_replace('"', '', $match[2][0]));
        } else if(stristr($svg, "http://amcharts.com/ammap") != FALSE ) {
            $location_name = 'undefined';
            $match='';
            preg_match_all('/(SVG map) of ([^"]* -)/i', $svg, $match2);
            if(!empty($match2) && isset($match2[2][0])) {
                $location_name = str_replace(array(" -","High","Low"), '', $match2[2][0]);
                $location_name = trim($location_name);
            }
        }

        $match = '';
        preg_match_all('/(flag_code)=("[^"]*")/i', $svg, $match);
        if(!empty($match[2])) {
            $location_key = trim(str_replace('"', '', $match[2][0]));
        } else {
            $location_key = substr(basename($map_file), 0, strrpos(basename($map_file), '.'));
        }

        $dom = new DOMDocument();
        $dom->preserveWhiteSpace = false; 
        $dom->formatOutput = true; 
        $dom->loadXml($svg);

        $paths = $dom->getElementsByTagName('path'); //here you have an corresponding object
        foreach ($paths as $path) {
            $path_key = null;
            $path_name = null;
            
            $path_name = $path->getAttribute('data-name');
            if($path_name && !empty($path_name)){
                $path_name = trim($path_name);
            } else {
                $path_name = $path->getAttribute('title');
                if($path_name && !empty($path_name)){
                    $path_name = trim($path_name);
                }
            }
            
            $path_key = $path->getAttribute('id');
            if($path_key && !empty($path_key)){
                $path_key = trim($path_key);
            } else {
                $path_key = $path->getAttribute('data-id');
                if($path_key && !empty($path_key)){
                    $path_key = trim($path_key);
                }
            }

            if(empty($path_name)) continue;
            $output[$path_key] = $path_name;
        }     

        $g = $dom->getElementsByTagName('g'); //here you have an corresponding object
        foreach ($g as $path) {
            $path_key = null;
            $path_name = null;
            
            $path_name = $path->getAttribute('data-name');
            if($path_name && !empty($path_name)){
                $path_name = trim($path_name);
            } else {
                $path_name = $path->getAttribute('title');
                if($path_name && !empty($path_name)){
                    $path_name = trim($path_name);
                }
            }
            
            $path_key = $path->getAttribute('id');
            if($path_key && !empty($path_key)){
                $path_key = trim($path_key);
            } else {
                $path_key = $path->getAttribute('data-id');
                if($path_key && !empty($path_key)){
                    $path_key = trim($path_key);
                }
            }
            if(empty($path_name)) continue;
            $output[$path_key] = $path_name;
        }  

        return array('name' => $location_name, 'location_key' => $location_key,'file_name' => basename($map_file), 'locations' => $output);

    }
}
?>