<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_favorites_frontendajax extends Winter_MVC_Controller {

	public function __construct(){
		if(defined( 'WP_DEBUG' ) && WP_DEBUG) {
			ini_set('display_errors',1);
			ini_set('display_startup_errors',1);
			error_reporting(-1);
		}
		parent::__construct();

        $this->data['is_ajax'] = true;
        
	}
    
	public function index(&$output=NULL, $atts=array())
	{

	}

    public function favorite_add($output="", $atts=array(), $instance=NULL)
    {

		$this->load->load_helper('listing');
		$this->load->model('favorite_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();

		if(empty($user_id))
        {
            $data['popup_text_error'] .= __('Please login to use favorite', 'wdk-favorites');
        } 

		if(empty(intval($_POST['post_id'])))
        {
            $data['popup_text_error'] .= __('Missing post id', 'wdk-favorites');
        } 

		if(empty($data['popup_text_error'])) {
			if($this->favorite_m->check_if_exists($user_id, intval($_POST['post_id']))>0)
			{
				$data['popup_text_error'] = __('Favorite already exists!', 'wdk-favorites');
				$data['success'] = true;
			}
			// Save favorites to database
			else
			{
				$data_save = array();
				$data_save['user_id'] = $user_id;
				$data_save['post_id'] = intval($_POST['post_id']);
				$data_save['post_type'] = sanitize_key(wmvc_show_data('post_type',$_POST,''));
				$data_save['date'] = date('Y-m-d H:i:s');
				
				$insert_id = $this->favorite_m->insert($data_save, NULL);
				$data['popup_text_success'] = __('Favorite added!', 'wdk-favorites');
				$data['success'] = true;
			}
		}
        
		$this->output($data);
    }

    public function favorite_delete($output="", $atts=array(), $instance=NULL)
    {

		$this->load->load_helper('listing');
		$this->load->model('favorite_m');
		
        $data = array();
        $data['message'] = '';
        $data['popup_text_success'] = '';
        $data['popup_text_error'] = '';
		$data['success'] = false;

        $user_id = get_current_user_id();

		if(empty($user_id))
        {
            $data['popup_text_error'] .= __('Please login to use favorite', 'wdk-favorites');
        } 

		if(empty(intval($_POST['post_id'])))
        {
            $data['popup_text_error'] .= __('Missing post id', 'wdk-favorites');
        } 

		if(empty($data['popup_text_error'])) {
			$this->favorite_m->delete_where(array('user_id'=> $user_id,	'post_id'=> intval($_POST['post_id'])));
			$data['popup_text_success'] = __('Favorite removed!', 'wdk-favorites');
			$data['success'] = true;
		}
        
		$this->output($data);
    }

     
    private function output($data, $print = TRUE) {
		$data = json_encode($data);
        if($print) {
            header('Pragma: no-cache');
            header('Cache-Control: no-store, no-cache');
            header('Content-Type: application/json; charset=utf8');
            //header('Content-Length: '.$length); // special characters causing troubles
            echo wmvc_xss_clean($data);
            exit();
        } else {
            return $data;
        }
    }
	
    
}
