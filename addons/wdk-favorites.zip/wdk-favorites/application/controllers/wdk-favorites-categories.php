<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_favorites_categories extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
    /* categories */
    
	public function index()
	{
        $this->load->model('favoritecategory_m');

        /* filters */

        $this->data['order_by']   = array(  'idfavorite DESC' => __('ID', 'wdk-favorites').' DESC', 
                                            'idfavorite ASC' => __('ID', 'wdk-favorites').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-favorites').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-favorites').' DESC',
                                            'post_type ASC' => __('Post Type', 'wdk-favorites').' ASC',
                                            'post_type DESC' => __('Post Type', 'wdk-favorites').' DESC',
                                            'category_title ASC' => __('Category Title', 'wdk-favorites').' ASC',
                                            'category_title DESC' => __('Category Title', 'wdk-favorites').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-favorites'),
                'rules' => ''
            ),
        );
        $this->data['db_data'] = $this->favoritecategory_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $where = array('user_id'=> get_current_user_id());

        if(wmvc_show_data('search', $this->data['db_data'], false)){
            $gen_search = wmvc_show_data('search', $this->data['db_data'], '');
            $gen_q = '';
            $gen_q.="idcategory LIKE '%$gen_search%' OR ";
            $gen_q.="title LIKE '%$gen_search%' OR ";
            $gen_q.="date LIKE '%$gen_search%'";
            $where ["($gen_q)"] = NULL;
        }

        $this->db->where($where);
        $total_items = $this->favoritecategory_m->total();

        $current_page = 1;
        if(isset($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';

        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        $this->db->where($where);
        if(wmvc_show_data('order_by', $this->data['db_data'], false))
            $this->db->order_by(wmvc_show_data('order_by', $this->data['db_data']));
        $this->data['favorite_categories'] = $this->favoritecategory_m->get();



        $this->db->where($where);
        $this->data['favorite_categories'] = $this->favoritecategory_m->get();

        // Load view
        $this->load->view('wdk_favorites/categories_manage', $this->data);
    }
    
	public function category_delete()
	{
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('favoritecategory_m');
        
        $this->favoritecategory_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-favorites-categories&paged=$paged"));

    }

}
