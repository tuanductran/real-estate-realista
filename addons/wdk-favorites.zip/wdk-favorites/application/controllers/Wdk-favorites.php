<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_favorites_index extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $this->load->model('favorite_m');
        $this->load->model('favoritecategory_m');

        $this->data['favorite_categories'] = array();
        foreach($this->favoritecategory_m->get() as $category) {
            $this->data['favorite_categories'][wmvc_show_data('idcategory', $category)] = wmvc_show_data('title', $category);
        }

        $dbusers =  get_users( array( 'search' => '',
                                      'order_by' => 'ID', 'order' => 'DESC'));

        $users = array();
        foreach($dbusers as $dbuser) {
            $this->data['users'][wmvc_show_data('ID', $dbuser)] = '#'.wmvc_show_data('ID', $dbuser).', '.wmvc_show_data('display_name', $dbuser);
        }

        $this->data['post_types'] = array();
        /*foreach(get_post_types() as $type_key => $type_name) {
            $this->data['post_types'][$type_key] = $type_name;
        }*/

        global $Winter_MVC_WDK;
        $Winter_MVC_WDK->model('location_m');
        $Winter_MVC_WDK->model('category_m');
        $this->data['categories'] = $Winter_MVC_WDK->category_m->get_parents();
        $this->data['locations']  = $Winter_MVC_WDK->location_m->get_parents();

        $this->data['post_types']['profile'] = __('Profile', 'wdk-favorites');
        $this->data['post_types']['wdk-listing'] = __('Listing', 'wdk-favorites');

        $this->data['order_by']   = array(  'idfavorite DESC' => __('ID', 'wdk-favorites').' DESC', 
                                            'idfavorite ASC' => __('ID', 'wdk-favorites').' ASC', 
                                            'post_id ASC' => __('Post Id', 'wdk-favorites').' ASC',
                                            'post_id DESC' => __('Post Id', 'wdk-favorites').' DESC',
                                            'post_title ASC' => __('Post Title', 'wdk-favorites').' ASC',
                                            'post_title DESC' => __('Post Title', 'wdk-favorites').' DESC',
                                        );

        $rules = array(
            array(
                'field' => 'post_type',
                'label' => __('Post Type', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'user_id',
                'label' => __('User', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'category_id',
                'label' => __('Category', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'listing_location_id',
                'label' => __('Location', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'listing_category_id',
                'label' => __('Category', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'search',
                'label' => __('Search tag', 'wdk-favorites'),
                'rules' => ''
            ),
            array(
                'field' => 'order_by',
                'label' => __('Order By', 'wdk-favorites'),
                'rules' => ''
            ),
        );

        $this->data['db_data'] = $this->favorite_m->prepare_data($this->input->get(), $rules);
        /* end filters */

        $controller = 'favorite';
        $columns = array('idfavorite', 'post_title','order_by', 'post_type', 'user_id','listing_category_id', 'listing_location_id');
        $external_columns = array('post_title', 'post_type','listing_category_id', 'listing_location_id');

        wdk_favorites_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $total_items = $this->favorite_m->total_data( array(), FALSE);

        $current_page = 1;
        if(isset($_GET['paged']) && !empty($_GET['paged']))
            $current_page = intval($_GET['paged']);
            
        $this->data['paged'] = $current_page;

        $per_page = 10;
        $offset = $per_page*($current_page-1);

        $this->data['pagination_output'] = '';
        if(function_exists('wmvc_wp_paginate'))
            $this->data['pagination_output'] = wmvc_wp_paginate($total_items, $per_page);

        wdk_favorites_prepare_search_query_GET($columns, $controller.'_m', $external_columns);
        $this->data['favorites'] = $this->favorite_m->get_pagination($per_page, $offset, array(), NULL, FALSE);
       
        // Load view
        $this->load->view('wdk_favorites/index', $this->data);
    }

    public function delete()
    {
        $id = (int) $this->input->post_get('id');
        $paged = (int) $this->input->post_get('paged');
        $this->load->model('favorite_m');
        
        $this->favorite_m->delete($id);

        wp_redirect(admin_url("admin.php?page=wdk-favorites&paged=$paged"));
    }

    
    
}
