<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly;

class Wdk_favorites_edit extends Winter_MVC_Controller {

	public function __construct(){
		parent::__construct();
	}
    
	public function index()
	{
        $id = $this->input->post_get('id');
        $this->load->model('favorite_m');
        $this->load->model('favoritecategory_m');
        if(function_exists('wdk_access_check'))
            wdk_access_check('favorite_m', $id);
        $this->data['favorite_categories'] = array();

        foreach($this->favoritecategory_m->get() as $category) {
            $this->data['favorite_categories'][wmvc_show_data('idcategory', $category)] = wmvc_show_data('title', $category);
        }

        $this->data['db_data'] = NULL;
        $this->data['form'] = &$this->form;

        $this->data['fields'] = $this->favorite_m->fields_list;


        if($this->form->run($this->data['fields']))
        {
            // Save procedure for basic data
            $data = $this->favorite_m->prepare_data($this->input->post(), $rules);
            $data['date'] = date('Y-m-d H:i:s');
            $data['user_id'] = get_current_user_id();

            // Save standard wp post
            $insert_id = $this->favorite_m->insert($data, $id);

            //exit($this->db->last_error());

            // redirect
            if(!empty($insert_id) && empty($id))
            {
                wp_redirect(admin_url("admin.php?page=wdk-favorites-edit&id=$insert_id&is_updated=true"));
                exit;
            }
                
        }

        if(!empty($id))
        {
           $this->data['db_data'] = $this->favorite_m->get($id, TRUE);
        }

        $this->load->view('wdk_favorites/edit', $this->data);
    }

}
