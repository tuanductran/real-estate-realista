<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Favoritecategory_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_favorite_categories';
	public $_order_by = 'idcategory';
    public $_primary_key = 'idcategory';
    public $_own_columns = array('user_id');
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();
	}
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }

    public function get($id = NULL, $single = FALSE, $user_check = TRUE)
    {
        /* show only for current user */
        if($user_check)
            $this->db->where(array('user_id'=> get_current_user_id()));
            
        return parent::get($id, $single);
    }
    
    public function total($where = array(), $user_check = TRUE)
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        $this->db->order_by($this->_order_by);
        /* show only for current user */
        if($user_check)
            $this->db->where(array('user_id'=> get_current_user_id()));

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = TRUE)
    {
        $this->db->select('*');
        $this->db->from($this->_table_name);
        $this->db->where($where);
        /* show only for current user */
        if($user_check)
            $this->db->where(array('user_id'=> get_current_user_id()));

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }
        
        $query = $this->get();

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if(wmvc_user_in_role('administrator')) return true;
                                
        if(empty($user_id))
            $user_id = get_current_user_id();

        $favorite = $this->get($id, TRUE);
        if(isset($favorite->user_id) && $favorite->user_id == $user_id)
            return true;
            
        return false;
    }
    
     /* [END] For dynamic data table */
    
    public function check_if_exists($user_id, $post_id)
    {
        $this->db->from($this->_table_name);
        $this->db->where(array('user_id'=> $user_id, 
                               'post_id'=> $post_id));
        $query = $this->db->get();

        if (!empty($query))
            return true;

        return false;
    }

    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $favorite = $this->get($item_id, TRUE);
        if(isset($favorite->user_id) && $favorite->user_id == $user_id)
            return true;
            
        return false;
    }
}
?>