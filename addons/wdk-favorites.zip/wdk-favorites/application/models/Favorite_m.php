<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Favorite_m extends Winter_MVC_Model {

	public $_table_name = 'wdk_favorite';
	public $_order_by = 'idfavorite DESC';
    public $_primary_key = 'idfavorite';
    public $_own_columns = array();
    public $_timestamps = TRUE;
    protected $_primary_filter = 'intval';
    public $form_admin = array();
    public $fields_list = NULL;
    
	public function __construct(){
        parent::__construct();

        $this->fields_list = array(
            array(
                'field' => 'post_id',
                'field_label' => __('Listing', 'wdk-favorites'),
                'hint' => '', 
                'field_type' => 'NUMBER', 
                'rules' => 'required|numeric'
            ),
            array(
                'field' => 'post_type',
                'field_label' => __('Post Type', 'wdk-favorites'),
                'hint' => '', 
                'field_type' => 'INPUTBOX', 
                'rules' => 'numeric'
            ),
            array(
                'field' => 'category_id',
                'field_label' => __('Category', 'wdk-favorites'),
                'hint' => '', 
                'field_type' => 'NUMBER', 
                'rules' => 'required|numeric'
            ),
        );

        foreach($this->fields_list as $key=>$field)
        {
            $this->fields_list[$key]['label'] = $field['field_label'];
        }
	}
  
    public function get($id = NULL, $single = FALSE, $user_check = TRUE)
    {
        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        return parent::get($id, $single);
    }
   
    public function get_available_fields()
    {      
        $fields = $this->db->list_fields($this->_table_name);

        return $fields;
    }
    
    public function total($where = array(), $user_check = TRUE)
    {
        $this->db->select('COUNT(*) as total_count');
        $this->db->from($this->_table_name);
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));
        
        $this->db->order_by($this->_order_by);

        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }

    /* with data */
    public function total_data($where = array(), $user_check = TRUE)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select('COUNT(*) as total_count');
        
        $this->db->from($this->_table_name);
        $this->db->join($this->_table_name.'_categories ON '.$this->_table_name.'.category_id = '.$this->_table_name.'_categories.idcategory', NULL,  'LEFT');
        
        /* wp post table */
        $this->db->join($this->db->prefix.'wdk_listings ON '.$this->db->prefix.'wdk_listings.post_id = '.$this->_table_name.'.post_id', NULL, 'LEFT');
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID', NULL, 'LEFT');

        $this->db->from($this->_table_name);
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->order_by($this->_order_by);
        
        $query = $this->db->get();

        $res = $this->db->results();

        if(isset($res[0]->total_count))
            return $res[0]->total_count;

        return 0;
    }
    
    public function get_pagination($limit, $offset, $where = array(), $order_by = NULL, $user_check = TRUE)
    {
        $post_table = $this->db->prefix.'posts';

        $this->db->select($this->_table_name.'.*, '.$this->_table_name.'_categories.title AS category_title, '.$this->db->prefix.'posts.post_title,'.$this->db->prefix.'posts.post_type as post_table_post_type' );
        $this->db->from($this->_table_name);
        $this->db->join($this->_table_name.'_categories ON '.$this->_table_name.'.category_id = '.$this->_table_name.'_categories.idcategory', NULL,  'LEFT');
        
        /* wp post table */
        $this->db->join($this->db->prefix.'wdk_listings ON '.$this->db->prefix.'wdk_listings.post_id = '.$this->_table_name.'.post_id', NULL, 'LEFT');
        $this->db->join($post_table.' ON '.$this->_table_name.'.post_id = '.$post_table.'.ID', NULL, 'LEFT');

        $this->db->from($this->_table_name);
        
        $this->db->where($where);

        /* show only for current user */
        if($user_check)
            $this->db->where(array($this->_table_name.'`.`user_id'=> get_current_user_id()));

        $this->db->limit($limit);
        $this->db->offset($offset);

        if(!empty($order_by)){
            $this->db->order_by($order_by);
        } else {
            $this->db->order_by($this->_order_by);
        }

        $query = $this->get(NULL, FALSE, $user_check);

        if ($this->db->num_rows() > 0)
            return $this->db->results();
        
        return array();
    }
    
    public function check_deletable($id, $user_id=NULL)
    {
        if($user_id !== NULL)
        {
            $favorite = $this->get($id, TRUE, FALSE);
            if(isset($favorite->user_id) && $favorite->user_id == $user_id)
                return true;

            return false;
        }

        if(wmvc_user_in_role('administrator')) return true;
        
        $favorite = $this->get($id, TRUE);
        if(isset($favorite->user_id) && $favorite->user_id == get_current_user_id())
            return true;

        return false;
    }
    
     /* [END] For dynamic data table */
    
    public function check_if_exists($user_id, $post_id)
    {
        $this->db->from($this->_table_name);
        $this->db->where(array('user_id'=> $user_id, 
                               'post_id'=> $post_id));
        $query = $this->db->get();

        if (!empty($query))
            return true;

        return false;
    }

    public function delete($id, $user_id=NULL) {

        if(!$this->check_deletable($id, $user_id)) return false;

        /* remove */
        parent::delete($id);

        return true;
    }

    public function delete_by_post($post_id, $user_id=NULL)
    {
        if($user_id === NULL)
            $user_id = get_current_user_id();

        if(empty($user_id) || !is_numeric($user_id))return false;

        /* remove */

        $this->db->where(array('user_id'=> $user_id, 
                               'post_id'=> $post_id));
        $this->db->limit(1);
        $this->db->delete($this->_table_name);

        return true;
    }
  
    public function is_related($item_id, $user_id, $method = 'edit')
    {	 
        $favorite = $this->get($item_id, TRUE);
        if(isset($favorite->user_id) && $favorite->user_id == $user_id)
            return true;
            
        return false;
    }

        
    public function delete_where($where)
    {
        $this->db->where($where);
        $this->db->delete($this->_table_name);
    }
}
?>