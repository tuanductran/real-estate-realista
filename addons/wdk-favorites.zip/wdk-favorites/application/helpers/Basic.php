<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
function wdk_favorites_prepare_search_query_GET($columns = array(), $model_name = NULL, $external_columns = array())
{
    global $Winter_MVC_wdk_favorites;
    $WMVC = &$Winter_MVC_wdk_favorites;
    $_GET_clone = array_merge($_GET, $_POST);
    
    $_GET_clone = ($_GET_clone);

    //$WMVC->model('listing_m');
    
    $smart_search = '';
    if(isset($_GET_clone['search']))
        $smart_search = sanitize_text_field($_GET_clone['search']);
        
    $available_fields = $WMVC->$model_name->get_available_fields();

    /* Пet column names from wdk_package and add to allow search + 
        in _GET_clone replace field_#id to field_id_TYPE*/
    $list_fields = $WMVC->db->list_fields( $WMVC->db->prefix.'wdk_favorite');


    if(isset($_GET_clone['search_location'])) {
        $column_name ='location_id';
        $_GET_clone[$column_name] = $_GET_clone['search_location'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    if(isset($_GET_clone['search_category'])) {
        $column_name ='category_id';
        $_GET_clone[$column_name] = $_GET_clone['search_category'];
        $columns[] = $column_name;
        $external_columns[] = $column_name;
    }

    //$table_name = substr($model_name, 0, -2);  
    $columns_original = array();
    foreach($columns as $key=>$val)
    {
        $columns_original[$val] = $val;
        
        // if column contain also "table_name.*"
        $splited = explode('.', $val);
        if(wmvc_count($splited) == 2)
            $val = $splited[1];
        
        if(isset($available_fields[$val]))
        {
            
        }
        else
        {
            if(!in_array($columns[$key], $external_columns))
            {
                unset($columns[$key]);
            }
        }
    }

    if(wmvc_count($_GET_clone) > 0)
    {
        unset($_GET_clone['search']);
        
        // For quick/smart search
        if(wmvc_count($columns) > 0 && !empty($smart_search))
        {
            $gen_q = '';
            foreach($columns as $key=>$value)
            {

                if($value == 'post_type' || $value == 'user_id')
                {
                    $value = $WMVC->$model_name->_table_name.'.'.$value;
                }

                if($value == 'listing_category_id')
                {
                    $value  = $WMVC->db->prefix.'wdk_listings.category_id';
                }

                if($value == 'listing_location_id')
                {
                    $value  = $WMVC->db->prefix.'wdk_listings.location_id';
                }

                if(substr_count($value, 'id') > 0 && is_numeric($smart_search))
                {
                    $gen_q.="$value = $smart_search OR ";
                }
                else if(substr_count($value, 'date') > 0)
                {
                    //$gen_search = wmvc_generate_slug($smart_search, ' ');
                    
                    $gen_search = $smart_search;
                    
                    $gen_q.="$value LIKE '%$gen_search%' OR ";
                }
                else
                {
                    $gen_q.="$value LIKE '%$smart_search%' OR ";
                }
            }
            $gen_q = substr($gen_q, 0, -4);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }

        // For column search
        if(isset($_GET_clone)) 
        {
            $gen_q = '';
            
            foreach($_GET_clone as $key=>$val)
            {
                if(!empty($val) && in_array($key, $columns))
                {
                    $col_name = $key;

                    if($col_name == 'post_type' || $col_name == 'user_id')
                    {
                        $col_name = $WMVC->$model_name->_table_name.'.'.$col_name;
                    }
                                        
                    if($col_name == 'listing_category_id')
                    {
                        $col_name  = $WMVC->db->prefix.'wdk_listings.category_id';
                    }

                    if($col_name == 'listing_location_id')
                    {
                        $col_name  = $WMVC->db->prefix.'wdk_listings.location_id';
                    }
                  
                    //if(isset($key))
                    //    $col_name = $key;

                    if(strpos($key,  'skip') !== FALSE) continue;
                
                    if(substr($key, -8) == '_exactly')
                    {
                        $col_name = substr($key, 0, -8);
                        $gen_q.=$col_name." = '".$val."' AND ";
                    }
                    elseif(substr($key, -4) == '_max')
                    {
                        $col_name = substr($key, 0, -4);
                        $gen_q.=$col_name." <= '".$val."' AND ";
                    }
                    else if(substr($key, -4) == '_min')
                    {
                        $col_name = substr($key, 0, -4);

                        $gen_q.=$col_name." >= '".$val."' AND ";
                    }
                    elseif(substr_count($key, 'id') > 0 && is_numeric($val))
                    {
                        // ID is always numeric
                        
                        $gen_q.=$col_name." = ".$val." AND ";
                    }
                    else if(substr_count($key, 'date') > 0)
                    {
                        // DATE VALUES
                        
                        $gen_search = $val;
                        
                        $detect_date = strtotime($gen_search);

                        if(wdk_is_date($val) && $detect_date > 1000)
                        {
                            $gen_search = date('Y-m-d H:i:s', $detect_date);
                            $gen_q.=$col_name." > '".$gen_search."' AND ";
                        }
                        else
                        {
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                    }
                    else if(substr_count($key, 'is_') > 0)
                    {
                        // CHECKBOXES
                        
                        if($val=='on')
                        {
                            $gen_search = 1;
                            $gen_q.=$col_name." LIKE '%".$gen_search."%' AND ";
                        }
                        else if($val=='off')
                        {
                            $gen_q.=$col_name." IS NULL AND ";
                        }
                    }
                    else
                    {
                        $gen_q.=$col_name." LIKE '%".$val."%' AND ";
                    }
                }

            }
            
            $gen_q = substr($gen_q, 0, -5);
            
            if(!empty($gen_q))
                $WMVC->db->where("($gen_q)");
        }
        
        // order
        if(isset($_GET_clone['order_by']))
        {
            $_GET_clone['order_by'] = str_replace('post_id', $WMVC->db->prefix.'wdk_favorite.post_id', $_GET_clone['order_by']);
            $WMVC->db->order_by($_GET_clone['order_by']);
        }

    }
}

/*
 Get Favorite item title
*/
if ( ! function_exists('wdk_favorite_item_name'))
{
    // Get Favorite item title
    /**
    * @param object|array $row favorite row include post_type and post_id
    * @return string
    */
    function wdk_favorite_item_name($row)
    {
        $title = '';
        if(wmvc_show_data('post_type', $row, false) == 'profile' && wmvc_show_data('post_id', $row, false)) {
            $wdk_userdata = wdk_get_user_data(wmvc_show_data('post_id', $row));
            $title = $wdk_userdata['userdata']->display_name;
        } else {
            if(wmvc_show_data('post_title', $row)) {
                $title = wmvc_show_data('post_title', $row);
            } else {

            }
        }

        return $title;
    }
}

/*
 Get Favorite item title
*/
if ( ! function_exists('wdk_favorite_item_link'))
{
    // Get Favorite item title
    /**
    * @param object|array $row favorite row include post_type and post_id
    * @return string url
    */
    function wdk_favorite_item_link($row)
    {
        $link = '';
        if(wmvc_show_data('post_type', $row, false) == 'profile' && wmvc_show_data('post_id', $row, false)) {
            $wdk_userdata = wdk_get_user_data(wmvc_show_data('post_id', $row));
            $link = wdk_generate_profile_permalink($wdk_userdata['userdata']);
        } else {
            $link = get_permalink(wmvc_show_data('post_id', $row, '-'));
        }

        return $link;
    }
}

if(!function_exists('wdk_get_user_data')) {
    /**
    * Get user data
    *
    * @param      int    $user id
    * @return     array  user data ('userdata'=>$userdata, 'avatar'=>get_avatar_url($user_id),'user_id'=>$user_id, 'profile_url'=>'url on profile');
    */
   function wdk_get_user_data ($user_id='') {
       static $users_cache = array();
       
       $user = array();
       if(isset($users_cache[$user_id])) {
           $user = $users_cache [$user_id];
       } else {

           $userdata = get_userdata($user_id);
           if($userdata) {
               $user = array('userdata'=>$userdata, 'avatar'=>get_avatar_url($user_id, array("size"=>300)),'user_id'=>$user_id);
               $user['profile_url'] =NULL;

               if(function_exists('wdk_generate_profile_permalink'))
                   $user['profile_url'] = wdk_generate_profile_permalink($userdata);
           }

           if($user) {
               $users_cache [$user_id] = $user;
           } else {
               $users_cache [$user_id] = $user;
           }
       }
       return $user;
   }
}

?>