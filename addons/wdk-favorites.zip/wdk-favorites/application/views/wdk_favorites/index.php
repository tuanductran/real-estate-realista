<?php
/**
 * The template for Favorites list.
 *
 * This is the template that table layout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Favorites','wdk-favorites'); ?>   <?php if(false):?><a href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites-edit"; ?>" class="button button-primary" id="add_listing_button"><?php echo esc_html__('Add', 'wdk-favorites'); ?></a><?php endif;?></h1>

    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-favorites" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-favorites'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-favorites'); ?>" />
                 
                <label class="screen-reader-text" for="user_id"><?php echo esc_html__('Filter by user', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('user_id', $users, wmvc_show_data('user_id', $db_data, ''), NULL, __('User', 'wdk-favorites')); ?>
                
                <label class="screen-reader-text" for="listing_location_id"><?php echo esc_html__('Filter by location', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('listing_location_id', $locations, wmvc_show_data('listing_location_id', $db_data, ''), NULL, __('Location', 'wdk-favorites')); ?>
                
                <label class="screen-reader-text" for="listing_category_id"><?php echo esc_html__('Filter by category', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('listing_category_id', $categories, wmvc_show_data('listing_category_id', $db_data, ''), NULL, __('Category', 'wdk-favorites')); ?>

                <?php if(false):?>
                <label class="screen-reader-text" for="category_id"><?php echo esc_html__('Filter by category', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('category_id', $favorite_categories, wmvc_show_data('category_id', $db_data, ''), NULL, __('Category', 'wdk-favorites')); ?>
                <?php endif;?>
                <label class="screen-reader-text" for="post_type"><?php echo esc_html__('Filter by post type', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('post_type', $post_types, wmvc_show_data('post_type', $db_data, ''), NULL, __('Post Type', 'wdk-favorites')); ?>

                <label class="screen-reader-text" for="order_by"><?php echo esc_html__('Order By', 'wdk-favorites'); ?></label>
                <?php echo wmvc_select_option('order_by', $order_by, wmvc_show_data('order_by', $db_data, ''), NULL, __('Order by', 'wdk-favorites')); ?>

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-favorites'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Title','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Post type','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('User', 'wdk-favorites'); ?></th>
                <?php if(false):?>
                <th><?php echo esc_html__('Category','wdk-favorites'); ?></th>
                <?php endif;?>
                <th><?php echo esc_html__('Date','wdk-favorites'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-favorites'); ?></th>
            </tr>
        </thead>
        <?php if(count($favorites) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="6"><?php echo esc_html__('No Favorites found.','wdk-favorites'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $favorites as $favorite ):?>
            <tr>
                <td>
                   <?php echo wmvc_show_data('post_id', $favorite, '-'); ?>
                </td>
                <td>
                    <a href="<?php echo esc_url(wdk_favorite_item_link($favorite)); ?>">
                        <?php echo wdk_favorite_item_name($favorite); ?>
                    </a>
                </td>
                <td>
                    <?php echo wmvc_show_data('post_type', $favorite, '-'); ?>
                </td>
                <td>
                    <?php if(wmvc_show_data(wmvc_show_data('user_id', $favorite), $users, false)):?>
                        <?php echo esc_html(wmvc_show_data(wmvc_show_data('user_id', $favorite), $users, false)); ?>
                    <?php else:?>
                        <?php echo esc_html__('User not found', 'wdk-favorites');?>
                    <?php endif;?>
                </td>
                <?php if(false):?>
                <td>
                    <?php echo wmvc_show_data('category_title', $favorite, __('Uncategory','wdk-favorites')); ?>
                </td>
                <?php endif;?>
                <td>
                    <?php echo wdk_get_date(wmvc_show_data('date', $favorite), false); ?>
                </td>
                <td class="actions_column">
                    <?php if(false):?>
                        <a href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites-edit&id=".wmvc_show_data('idfavorite', $favorite, ''); ?>" title="<?php echo esc_attr__('Edit','wdk-favorites');?>"><span class="dashicons dashicons-edit"></span></a>
                    <?php endif;?>
                    <a href="<?php echo get_permalink(wmvc_show_data('post_id', $favorite, '-')); ?>" target="_blank" title="<?php echo esc_attr('View Listing','wdk-favorites');?> <?php echo esc_attr(wmvc_show_data('post_title', $favorite, '-')); ?>"><span class="dashicons dashicons-visibility"></span></a>
                    <a class="question_sure" href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites&function=delete&id=".wmvc_show_data('idfavorite', $favorite, '-'); ?>"  title="<?php echo esc_attr__('Remove', 'wdk-favorites');?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('#ID','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Title','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Post type','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('User', 'wdk-favorites'); ?></th>
                <?php if(false):?>
                <th><?php echo esc_html__('Category','wdk-favorites'); ?></th>
                <?php endif;?>
                <th><?php echo esc_html__('Date','wdk-favorites'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-favorites'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-favorites')); ?>");
        });
    });
</script>

<?php $this->view('general/footer', $data); ?>
