<?php
/**
 * The template for Edit Favorite Categories.
 *
 * This is the template that form edit
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Favorite Categories Management','wdk-favorites'); ?></h1>
    <br /><br />
        <div class="wdk-body">
            <div class="postbox" style="display: block;">
                <div class="postbox-header"><h3><?php echo esc_html__('Add/Edit Category','wdk-favorites'); ?></h3>
            </div>
            <div class="inside">

                <form method="post" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">

                    <?php 
                    $form->messages('class="alert alert-danger"',  __('Successfully saved', 'wdk-favorites'));
                    ?>

                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row"><label for="title"><?php echo esc_html__('Title','wdk-favorites'); ?></label></th>
                                <td>
                                    <input name="title" type="text" id="title" value="<?php echo wmvc_show_data('title', $db_data, ''); ?>" class="regular-text">
                                </td>
                            </tr>
                            <?php if(wmvc_show_data('post_id', $db_data, false)):?>
                            <tr>
                                <th scope="row"><label for="date"><?php echo esc_html__('Date','wdk-favorites'); ?></label></th>
                                <td>
                                    <input name="date" readonly="readonly" type="text" id="date" value="<?php echo wmvc_show_data('date', $db_data, ''); ?>" class="regular-text">
                                </td>
                            </tr>
                            <?php endif;?>
                        </tbody>
                    </table>
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php echo esc_html__('Save Changes','wdk-favorites'); ?>">
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->view('general/footer', $data); ?>