<?php
/**
 * The template for Favorite Categories List.
 *
 * This is the template that table lyout
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<div class="wrap wdk-wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html__('Favorite Categories','wdk-favorites'); ?> <a href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites-categoryedit"; ?>" class="button button-primary" id="add_listing_button"><?php echo esc_html__('Add', 'wdk-favorites'); ?></a> </h1>
    <br /><br />
    <form method="GET" action="<?php echo wmvc_current_edit_url(); ?>" novalidate="novalidate">
        <div class="tablenav top">
            <div class="alignleft actions">
                <input type="hidden" name="page" value="wdk-favorites" />
                <input type="hidden" name="function" value="categories" />
                <label class="screen-reader-text" for="search"><?php echo esc_html__('Filter by keyword', 'wdk-favorites'); ?></label>
                <input type="text" name="search" id="search" class="postform left" value="<?php echo esc_attr(wmvc_show_data('search', $db_data, '')); ?>" placeholder="<?php echo esc_html__('Filter by keyword', 'wdk-favorites'); ?>" />

                <input type="submit" name="filter_action" id="post-query-submit" class="button" value="<?php echo esc_html__('Filter', 'wdk-favorites'); ?>">
            </div>
            <?php echo wmvc_xss_clean($pagination_output); ?>
            <br class="clear">
        </div>
    </form>
    <table class="wp-list-table widefat fixed striped table-view-list pages">
        <thead>
            <tr>
                <th><?php echo esc_html__('id','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Title','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Date','wdk-favorites'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-favorites'); ?></th>
            </tr>
        </thead>
        <?php if(count($favorite_categories) == 0): ?>
            <tr class="no-items"><td class="colspanchange" colspan="4"><?php echo esc_html__('No Categories found.','wdk-favorites'); ?></td></tr>
        <?php endif; ?>
        <?php foreach ( $favorite_categories as $category ):?>
            <tr>
                <td>
                    <?php echo ' #'.wmvc_show_data('idcategory', $category, '-'); ?>
                </td>
                <td>
                    <?php echo wmvc_show_data('title', $category, '-'); ?>
                </td>
                <td>
                    <?php echo wdk_get_date(wmvc_show_data('date', $category), false); ?>
                </td>
                <td class="actions_column">
                    <a href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites-categoryedit&id=".wmvc_show_data('idcategory', $category, ''); ?>"><span class="dashicons dashicons-edit"></span></a>
                    <a class="question_sure"  title="<?php echo esc_attr__('Remove', 'wdk-favorites');?>"  href="<?php echo get_admin_url() . "admin.php?page=wdk-favorites&function=category_delete&id=".wmvc_show_data('idcategory', $category, '-'); ?>"><span class="dashicons dashicons-no"></span></a>
                </td>
            </tr>
        <?php endforeach; ?>
        <tfoot>
            <tr>
                <th><?php echo esc_html__('id','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Title','wdk-favorites'); ?></th>
                <th><?php echo esc_html__('Date','wdk-favorites'); ?></th>
                <th class="actions_column"><?php echo esc_html__('Actions','wdk-favorites'); ?></th>
            </tr>
        </tfoot>
    </table>
    <div class="tablenav bottom">
        <div class="alignleft actions">
        </div>
        <?php echo wmvc_xss_clean($pagination_output); ?>
        <br class="clear">
    </div>
</div>

<script>
    // Generate table
    jQuery(document).ready(function($) {
        $('.question_sure').on('click', function(){
            return confirm("<?php echo esc_js(__('Are you sure? Selected item will be completely removed!','wdk-favorites')); ?>");
        });
    });
</script>

<?php $this->view('general/footer', $data); ?>
