<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
* Widget [wdk-favorite-action], show action add/remove favorite
*
* Layout path : 
* get_template_directory().'/wdk-favorites/shortcodes/views/shortcode-favorite-action.php'
* WPDIRECTORYKIT_PATH.'shortcodes/views/shortcode-favorite-action.php'
*/

add_shortcode('wdk-favorite-action', 'wdk_favorite_action');
function wdk_favorite_action($atts, $content){
    $atts = shortcode_atts(array(
        'id'=>NULL,
        'post_id'=>'',
        'post_type'=>'',
    ), $atts);

    $data = array();

    /* settings from atts */
    $data = $atts;
    
    if(!wmvc_show_data('post_id', $data, false)){
        global $wdk_listing_id;

        if(isset($wdk_listing_id)){
            $data['post_id'] = $wdk_listing_id;
            $data['post_type'] = 'wdk-listing';

        }elseif(wdk_get_profile_page_id()){
            $data['post_id'] = wdk_get_profile_page_id();
            $data['post_type'] = 'profile';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $data['post_id'] = $post_object_id;

            $data['post_type'] = get_post_type();
        }
    }

    /* Favorite module */
    $favorite_added=false;
    global $Winter_MVC_wdk_favorites; 
    if(get_current_user_id() != 0 && isset($Winter_MVC_wdk_favorites) && wmvc_show_data('post_id', $data, false))
    {
        $Winter_MVC_wdk_favorites->model('favorite_m');
        $favorite_added = $Winter_MVC_wdk_favorites->favorite_m->check_if_exists(get_current_user_id(), 
                                                                wmvc_show_data('post_id', $data));
        if($favorite_added>0)$favorite_added = true;
    }
    
    $data ['favorite_added'] = $favorite_added;
    /* End Favorite module */
    
    return wdk_favorites_shortcodes_view('shortcode-favorite-action', $data);
}

?>