<?php

namespace WdkFavorites\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkFavoritesElementorBase extends WdkElementorBase {
    protected $WMVC_Favorites = NULL;

    public function __construct($data = array(), $args = null) {
        global $Winter_MVC_wdk_favorites;
        $this->WMVC_Favorites = $Winter_MVC_wdk_favorites;

        parent::__construct($data, $args);
    }


    public function view($view_file = '', $element = NULL, $print = false)
        {
            if(empty($view_file)) return false;
            $file = false;
            if(is_child_theme() && file_exists(get_stylesheet_directory().'/wdk-favorites/elementor-elements/views/'.$view_file.'.php'))
            {
                $file = get_stylesheet_directory().'/wdk-favorites/elementor-elements/views/'.$view_file.'.php';
            }
            elseif(file_exists(get_template_directory().'/wdk-favorites/elementor-elements/views/'.$view_file.'.php'))
            {
                $file = get_template_directory().'/wdk-favorites/elementor-elements/views/'.$view_file.'.php';
            }
            elseif(file_exists(WDK_FAVORITES_PATH.'elementor-elements/views/'.$view_file.'.php'))
            {
                $file = WDK_FAVORITES_PATH.'elementor-elements/views/'.$view_file.'.php';
            }

            if($file)
            {
                extract($element);
                if($print) {
                    include $file;
                } else {
                    ob_start();
                    include $file;
                    return ob_get_clean();
                }
            }
            else
            {
                if($print) {
                    echo 'View file not found in: '.esc_html(WDK_FAVORITES_PATH.'elementor-elements/views/'.$view_file.'.php');
                } else {
                    return 'View file not found in: '.esc_html(WDK_FAVORITES_PATH.'elementor-elements/views/'.$view_file.'.php');
                } 
            }
        }

}