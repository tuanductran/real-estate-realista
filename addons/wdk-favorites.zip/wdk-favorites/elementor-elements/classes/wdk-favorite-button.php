<?php

namespace WdkFavorites\Elementor\Widgets;

use Wdk\Elementor\Widgets\WdkElementorBase;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Typography;
use Elementor\Editor;
use Elementor\Plugin;
use Elementor\Repeater;
use Elementor\Core\Schemes;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class WdkFavoritesButton extends WdkFavoritesElementorBase {

    public $field_id = NULL;
    public $fields_list = array();

    public function __construct($data = array(), $args = null) {

        \Elementor\Controls_Manager::add_tab(
            'tab_conf',
            esc_html__('Settings', 'wdk-favorites')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_layout',
            esc_html__('Layout', 'wdk-favorites')
        );

        \Elementor\Controls_Manager::add_tab(
            'tab_content',
            esc_html__('Main', 'wdk-favorites')
        );

		if (method_exists($this, 'is_edit_mode_load') && $this->is_edit_mode_load()) {
            $this->enqueue_styles_scripts();
        }

        parent::__construct($data, $args);

    }

    /**
     * Retrieve the widget name.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'wdk-favorites-button';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return esc_html__('Wdk Favorites Button', 'wdk-favorites');
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.1.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'eicon-heart';
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function register_controls() {
        $this->generate_controls_conf();
        $this->generate_controls_layout();
        $this->generate_controls_styles();
        $this->generate_controls_content();

        parent::register_controls();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.1.0
     *
     * @access protected
     */
    protected function render() {
        parent::render();
        global $wdk_listing_id;
        $this->data['id_element'] = $this->get_id();
        $this->data['settings'] = $this->get_settings();
        global $wp_query;

        /* settings from atts */
        $this->data['post_id'] = '';
        if(isset($wdk_listing_id)){
            $this->data['post_id'] = $wdk_listing_id;
            $this->data['post_type'] = 'wdk-listing';

        } elseif(get_option('wdk_membership_profile_preview_page') && isset($wp_query->post) && get_option('wdk_membership_profile_preview_page') == $wp_query->post->ID) {
            if(!wdk_get_profile_page_id()) 
                return false;

            $this->data['post_id'] = wdk_get_profile_page_id();
            $this->data['post_type'] = 'profile';
        } else {
            $post_object_id = get_queried_object_id();
            if($post_object_id)
                $this->data['post_id'] = $post_object_id;

            $this->data['post_type'] = get_post_type();
        }

        /* Favorite module */
        $favorite_added=false;
        if(get_current_user_id() != 0 && wmvc_show_data('post_id', $this->data, false))
        {
            $this->WMVC_Favorites->model('favorite_m');
            $favorite_added = $this->WMVC_Favorites->favorite_m->check_if_exists(get_current_user_id(), 
                                                                    wmvc_show_data('post_id', $this->data));
            if($favorite_added>0)$favorite_added = true;
        }
        
        $this->data ['favorite_added'] = $favorite_added;

        /* End Favorite module */

        $this->data['is_edit_mode']= false;          
        if(Plugin::$instance->editor->is_edit_mode()){
            $this->data['is_edit_mode']= true;
        }

        echo $this->view('wdk-favorite-button', $this->data);
    }

    private function generate_controls_conf() {
        $this->start_controls_section(
            'tab_conf_main_section',
            [
                'label' => esc_html__('Main', 'wdk-favorites'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'favorite_notadded_icon',
            [
                'label' => esc_html__('Icon when not in favorite', 'wdk-favorites'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-heart-o',
                    'library' => 'solid',
                ],
            ]
        );

        $this->add_control(
            'favorite_added_icon',
            [
                'label' => esc_html__('Icon added in favorites', 'wdk-favorites'),
                'type' => Controls_Manager::ICONS,
                'label_block' => true,
                'default' => [
                    'value' => 'fa fa-heart',
                    'library' => 'solid',
                ],
            ]
        );

        $this->end_controls_section();
    }

    private function generate_controls_layout() {
    }

    private function generate_controls_styles() {

        $this->start_controls_section(
            'colors_sections_basic',
            [
                    'label' => esc_html__('Basic', 'wdk-favorites'),
                    'tab' => 'tab_layout'
                ]
        );

        $this->add_responsive_control(
            'favorite_basic_size',
            [
                'label' => esc_html__('Size', 'wdk-favorites'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 3,
                        'max' => 60,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wdk-favorite-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-favorite-button .wdk-remove-favorites-action',
            'hover'=>'{{WRAPPER}} .wdk-favorite-button .wdk-remove-favorites-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'ffavorite_basic_dynamic', ['padding']);

        $this->end_controls_section();

        $this->start_controls_section(
            'colors_sections_notadd_favofite',
            [
                    'label' => esc_html__('Syle not in favorite button', 'wdk-favorites'),
                    'tab' => 'tab_layout'
                ]
        );

        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-favorite-button .wdk-add-favorites-action',
            'hover'=>'{{WRAPPER}} .wdk-favorite-button .wdk-add-favorites-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'favorite_notadded_dynamic', ['color','padding','background']);


        $this->end_controls_section();

        $this->start_controls_section(
            'colors_sections_add_favofite',
            [
                    'label' => esc_html__('Syle in favorite button', 'wdk-favorites'),
                    'tab' => 'tab_layout'
                ]
        );


        $selectors = array(
            'normal' => '{{WRAPPER}} .wdk-favorite-button .wdk-remove-favorites-action',
            'hover'=>'{{WRAPPER}} .wdk-favorite-button .wdk-remove-favorites-action%1$s'
        );
        $this->generate_renders_tabs($selectors, 'favorite_added_dynamic', ['color','padding','background']);

        $this->end_controls_section();
    }

    private function generate_controls_content() {

    }
            
    public function enqueue_styles_scripts() {
        wp_enqueue_style('wdk-favorite-button');
    }
}
