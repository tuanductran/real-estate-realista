<?php
/**
 * The template for Element Favorite Button.
 * This is the template that elementor element form, button
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="wdk-favorites-element" id="wdk_el_<?php echo esc_html($id_element);?>">
    <div class="wdk-favorite-button">
        <span class="wdk-favorites-shortcode wdk-favorites-actions">
            <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-add-favorites-action <?php echo (esc_attr($favorite_added))?'wdk-hidden':''; ?>"  data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['favorite_notadded_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
            <a href="#" data-post_type="<?php echo esc_attr($post_type);?>" data-post_id="<?php echo esc_attr($post_id);?>" class="wdk-remove-favorites-action <?php echo (!esc_attr($favorite_added))?'wdk-hidden':''; ?>" data-ajax="<?php echo esc_url(admin_url( 'admin-ajax.php' )); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['favorite_added_icon'], [ 'aria-hidden' => 'true' ] ); ?>
            </a>
            <i class="fa fa-spinner fa-spin fa-custom-ajax-indicator"></i>
        </span>
    </div>
</div>

