<?php

/**
 * Fired during plugin activation
 *
 * @link       wpdirectorykit.com
 * @since      1.0.0
 *
 * @package    Wdk_Favorites
 * @subpackage Wdk_Favorites/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wdk_Favorites
 * @subpackage Wdk_Favorites/includes
 * @author     wpdirectorykit.com <support@wpdirectorykit.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Wdk_Favorites_Activator {
	public static $db_version = 1.1;

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
   		$prefix = 'wdk_favorites_';
	}

	public static function plugins_loaded(){
      
		if ( get_site_option( 'wdk_favorites_db_version' ) === false ||
		     get_site_option( 'wdk_favorites_db_version' ) < self::$db_version ) {
			self::install();
		}

    }

	
    // https://codex.wordpress.org/Creating_Tables_with_Plugins
    public static function install() {
        global $wpdb;
		
	

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        $charset_collate = $wpdb->get_charset_collate();
        // For init version 1.0

        if(get_site_option( 'wdk_favorites_db_version' ) === false)
        {
            // Main table for visited pages

            $table_name = $wpdb->prefix . 'wdk_favorite';

            $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                        `idfavorite` int(11) NOT NULL AUTO_INCREMENT,
                        `post_id` int DEFAULT NULL,
                        `post_type` varchar(45) DEFAULT NULL,
                        `user_id` int DEFAULT NULL,
                        `date` datetime DEFAULT NULL,
                PRIMARY KEY  (idfavorite)
                ) $charset_collate;";

 			dbDelta( $sql );

			$sql = "ALTER TABLE `$table_name` ADD `category_id`  INT NULL DEFAULT NULL;";
			$wpdb->query($sql);

			/* category */
            $table_name = $wpdb->prefix . 'wdk_favorite_categories';
            $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
                        `idcategory` int(11) NOT NULL AUTO_INCREMENT,
                        `title` VARCHAR(128) NULL DEFAULT NULL,
                        `user_id` int DEFAULT NULL,
                        `date` datetime DEFAULT NULL,
                PRIMARY KEY  (idcategory)
                ) $charset_collate;";
			dbDelta( $sql );

            update_option( 'wdk_favorites_db_version', "1" );

        }
        
        /* version 1.2.0 db install */
        if ( get_site_option( 'wdk_favorites_db_version' ) < '1.1' ) {

           
        }

        //update_option( 'wdk_db_version', self::$db_version );
    }

}
