(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

    $(function () {
        /* init favorite */
        wdk_favorite();
    });

})(jQuery);


const wdk_favorite = (parent_selector) => {

    if(typeof parent_selector == 'undefined') var parent_selector = 'body';

    // [START] Add to favorites //  
    jQuery(parent_selector+" .wdk-add-favorites-action").off().on('click',function(e){
        e.preventDefault();
        let self = jQuery(this);
        let self_parent = self.parent()
        var post_id = jQuery(this).attr('data-post_id')
        let post_type = jQuery(this).attr('data-post_type') || '';
        let ajax_url = jQuery(this).attr('data-ajax')

        var data = { post_id: post_id, post_type: post_type };
        jQuery.extend( data, {
            "action": 'wdk_favorite_public_action',
            "page": 'wdk_favorites_frontendajax',
            "function": 'favorite_add',
        });
        
        self_parent.addClass('loading');
        jQuery.post(ajax_url, data, 
            function(data){
                if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                    wdk_log_notify(data.popup_text_error, 'error');
                
                if(data.success)
                {
                    /* change icon for all same listings */
                    if(true) {
                        jQuery('.wdk-favorites-actions a.wdk-add-favorites-action[data-post_id="'+ post_id+'"]').addClass('wdk-hidden');
						jQuery('.wdk-favorites-actions a.wdk-remove-favorites-action[data-post_id="'+ post_id+'"]').removeClass('wdk-hidden');
                    } else {
                        self_parent.find("a.wdk-add-favorites-action").addClass('wdk-hidden');
                        self_parent.find("a.wdk-remove-favorites-action").removeClass('wdk-hidden');
                    }
                } else {
                    
                }
        }).always(function(){
            self_parent.removeClass('loading');
        });
        return false;
    });
    // [END] Add to favorites //  

    // [START] remove to favorites //  
    jQuery(parent_selector+" .wdk-remove-favorites-action").off().on('click',function(e){
        e.preventDefault();
        let self = jQuery(this);
        let self_parent = self.parent()
        var post_id = jQuery(this).attr('data-post_id')
        let post_type = jQuery(this).attr('data-post_type') || '';
        let ajax_url = jQuery(this).attr('data-ajax')

        var data = { post_id: post_id, post_type: post_type };
        jQuery.extend( data, {
            "action": 'wdk_favorite_public_action',
            "page": 'wdk_favorites_frontendajax',
            "function": 'favorite_delete',
        });
        
        self_parent.addClass('loading');
        jQuery.post(ajax_url, data, 
            function(data){
                if(data.popup_text_success)
                    wdk_log_notify(data.popup_text_success);
                    
                if(data.popup_text_error)
                        wdk_log_notify(data.popup_text_error, 'error');
                
            if(data.success)
            {
                if(true) {
                    jQuery('.wdk-favorites-actions a.wdk-add-favorites-action[data-post_id="'+ post_id+'"]').removeClass('wdk-hidden');
                    jQuery('.wdk-favorites-actions a.wdk-remove-favorites-action[data-post_id="'+ post_id+'"]').addClass('wdk-hidden');
                } else {
                    self_parent.find("a.wdk-add-favorites-action").removeClass('wdk-hidden');
                    self_parent.find("a.wdk-remove-favorites-action").addClass('wdk-hidden');
                }
            } else {
                
            }
        }).always(function(){
            self_parent.removeClass('loading');
        });
        return false;
    });
    // [END] remove to favorites //  
}

