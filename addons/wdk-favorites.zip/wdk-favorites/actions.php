<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action('wdk-membership/dash/homepage/widgets', function(){
    global $Winter_MVC_wdk_favorites;
    $Winter_MVC_wdk_favorites->model('favorite_m');
    $total_items = $Winter_MVC_wdk_favorites->favorite_m->total_data();

    if(function_exists('wdk_dash_url')) {
    ?>
    <div class="wdk-col-12 wdk-col-md-3 wdk-membership-dash-widget_favorites"> 
        <a href="<?php echo esc_url(wdk_dash_url('dash_page=favorites'));?>" class="wdk-membership-dash-widget">
            <span class="wdk-content">
            <span class="icon"><span class="dashicons dashicons-heart"></span></span>
            </span>
            <span class="wdk-side">
            <span class="title"><?php echo esc_html__('Favorites','wdk-favorites');?></span>
                <span class="wdk-count"><?php echo esc_html($total_items);?></span>
            </span>
        </a>
    </div>
    <?php
    }
});

add_action('wpdirectorykit/model/listing/delete', function($post_id){
    global $Winter_MVC_wdk_favorites;
    $Winter_MVC_wdk_favorites->model('favorite_m');
    
    if(!empty($post_id)) {
        $Winter_MVC_wdk_favorites->db->where(array('post_id'=>$post_id));
        $Winter_MVC_wdk_favorites->db->delete($Winter_MVC_wdk_favorites->favorite_m->_table_name);
    }
});

add_action('wpdirectorykit/listing/saved', 'wdk_favorite_action_alert_listing');

function wdk_favorite_action_alert_listing($post_id = NULL, $old_listing_date = NULL) {
    global $Winter_MVC_wdk_favorites, $Winter_MVC_WDK;
    $Winter_MVC_wdk_favorites->model('favorite_m');
    $Winter_MVC_WDK->model('listing_m');
    
    if(!empty($post_id)) {
        global $wpdb;
        
        $Winter_MVC_wdk_favorites->db->where(array('post_id'=>$post_id));
        $Winter_MVC_wdk_favorites->db->join($wpdb->users.' ON '.$wpdb->users.'.ID = '.$Winter_MVC_wdk_favorites->favorite_m->_table_name.'.user_id', NULL,  'LEFT');
        $favorites = $Winter_MVC_wdk_favorites->favorite_m->get();

        $listing_data = $Winter_MVC_WDK->listing_m->get($post_id, TRUE);

        if($favorites) {
            foreach ($favorites as $key => $favorite) {

                /* message */
                $data_message = array();
                $data_message['user'] = get_userdata(wdk_show_data('user_id', $favorite, '' , TRUE, TRUE)) ; /* user data */
                $data_message['favorite'] = $favorite;
                $data_message['listing'] = $listing_data;
                $data_message['post_id'] = $post_id;
                $data_message['data'] = array(
                    __('URL', 'wdk-membership')=> get_permalink($listing_data),
                );

                $data_message['message'] = wdk_sprintf(__( 'Listing %1$s udpated!', 'wpdirectorykit' ), wdk_field_value('post_title', $listing_data));
                if(!wdk_field_value('is_activated', $listing_data)) {
                    $data_message['message'] = wdk_sprintf(__( 'Listing %1$s now deactivated!', 'wpdirectorykit' ), wdk_field_value('post_title', $listing_data));
                }

                wdk_mail(wdk_show_data('user_email', $favorite, '' , TRUE, TRUE), __('Listing in Favorite Updated', 'wpdirectorykit'), $data_message, 'favorites_listing_updated_alert');
            }
        }
    }
}

?>